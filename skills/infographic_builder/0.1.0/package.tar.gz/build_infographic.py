"""Infographic Builder entry point: render a JSON spec into a PNG poster.

API:
    from build_infographic import build
    result = build(spec_path, out_path=None, strict=False)

CLI:
    python build_infographic.py spec.json [out.png] [--strict]

Exit codes: 0 - clean render; 1 - rendered but checks failed; 2 - spec or
render error.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from infographic import RenderError, SpecError, render  # noqa: E402

build = render


def main(argv=None):
    """Run the command-line interface; returns the process exit code."""
    parser = argparse.ArgumentParser(
        description="Render an infographic spec into a PNG poster.")
    parser.add_argument("spec", help="path to the JSON spec file")
    parser.add_argument("out", nargs="?", default=None,
                        help="output PNG path (default: <name>.png next to the spec)")
    parser.add_argument("--strict", action="store_true",
                        help="fail if any check or glyph probe fails")
    args = parser.parse_args(argv)
    try:
        result = build(args.spec, args.out, strict=args.strict)
    except (SpecError, RenderError) as exc:
        print("ERROR: %s" % exc, file=sys.stderr)
        return 2
    print(json.dumps({
        "ok": result["ok"],
        "out_path": result["out_path"],
        "size_px": result["size_px"],
        "check_failures": result["check_failures"],
        "missing_glyphs": result["missing_glyphs"],
        "warnings": result["warnings"],
    }, ensure_ascii=False, indent=2))
    if result["check_failures"] or result["missing_glyphs"]:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
