# Changelog

All notable changes to the Infographic Builder skill. Versioning: semantic.

## [0.1.0] - 2026-10-03

### Added
- Skill package `infographic-builder`: `SKILL.md` (workflow: data collection, section reference, QA loop, troubleshooting).
- Engine `infographic/`: `spec.py` (validation), `theme.py` (palettes), `textkit.py` (wrapping/measuring), `components.py` (sections), `engine.py` (canvas, self-checks, export).
- Entry point `build_infographic.py`: API `build(spec_path, out_path=None, strict=False)` and CLI `python build_infographic.py spec.json out.png [--strict]`.
- Sections: header, kpi_row, metrics_table, bar_chart, pros_cons, bullets, paragraph, sources, spacer, image.
- Auto canvas height, layout self-checks (`check_failures`), glyph probe (`missing_glyphs`), PNG validation.
- Example: `examples/demo_spec.json` + `examples/demo_infographic.png` (fictional bike-share service, Russian texts).
- Tests: unit + scenario suite (happy path, edge cases, error handling).

### Notes
- Offline (matplotlib + Pillow + numpy); writes exactly one file per render.
