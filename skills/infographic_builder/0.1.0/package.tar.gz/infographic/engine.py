"""Render engine: JSON spec to PNG with layout self-checks.

The public entry points are render() and the re-exported build() (see the
package __init__). Rendering runs in two passes: the first pass computes the
natural content height, the second renders into a canvas of the final size
and runs bbox self-checks (text inside its allowed box, panels inside the
canvas, cross-section panel overlaps), a glyph probe and PNG validation.
"""

from __future__ import annotations

import os

from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from .components import Ctx, RENDERERS
from .spec import load_spec
from .textkit import TextTool
from .theme import font_path, missing_glyphs, resolve_palette

GLYPH_CONSTANTS = "\u2022\u2713\u2717"  # bullet, check, cross used by components


class RenderError(RuntimeError):
    """Raised when the infographic cannot be rendered at all."""


def _collect_strings(value, out):
    """Recursively collect every string inside a spec fragment."""
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for item in value.values():
            _collect_strings(item, out)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _collect_strings(item, out)


def _render_sections(spec, pal, dpi, height):
    """Create a figure and draw all sections; returns (fig, ax, ctx, bottom)."""
    width = float(spec["canvas"]["width"])
    fig = Figure(figsize=(width / dpi, height / dpi), dpi=dpi)
    FigureCanvasAgg(fig)
    ax = fig.add_axes([0.0, 0.0, 1.0, 1.0])
    fig.patch.set_facecolor(pal["bg"])
    ax.set_facecolor(pal["bg"])
    ax.set_xlim(0.0, width)
    ax.set_ylim(float(height), 0.0)
    ax.set_axis_off()
    tt = TextTool(ax, dpi, spec["font"])
    ctx = Ctx(ax, tt, spec, pal)
    y = float(spec["margin"])
    last = len(spec["sections"]) - 1
    for i, sec in enumerate(spec["sections"]):
        ctx.section = i
        renderer = RENDERERS[sec["type"]]
        try:
            y = renderer(ctx, sec, y)
        except Exception as exc:
            raise RenderError("section %d (%s) failed: %s"
                              % (i, sec.get("type"), exc))
        if i != last:
            y += spec["gap"]
    return fig, ax, ctx, y


def _check_layout(ctx, ax, renderer, width, height, tol=2.0):
    """Return a list of layout failure strings for the current figure."""
    failures = []
    inv = ax.transData.inverted()
    for rec in ctx.tt.texts:
        item = rec["item"]
        text = item.get_text()
        try:
            bb = item.get_window_extent(renderer)
        except Exception as exc:  # pragma: no cover - defensive
            failures.append("cannot measure text %r (%s)" % (text[:40], exc))
            continue
        (dx0, dy0) = inv.transform((bb.x0, bb.y0))
        (dx1, dy1) = inv.transform((bb.x1, bb.y1))
        x0, x1 = min(dx0, dx1), max(dx0, dx1)
        y0, y1 = min(dy0, dy1), max(dy0, dy1)
        box = rec.get("meta")
        label = text.replace("\n", " ")[:48]
        if isinstance(box, tuple) and len(box) == 4:
            bx0, by0, bx1, by1 = box
            if (x0 < bx0 - tol or x1 > bx1 + tol
                    or y0 < by0 - tol or y1 > by1 + tol):
                failures.append(
                    "section %d: text overflows its box: %r" % (rec["section"], label))
        elif x0 < -1.0 or x1 > width + 1.0 or y0 < -1.0 or y1 > height + 1.0:
            failures.append(
                "section %d: text outside the canvas: %r" % (rec["section"], label))
    for rec in ctx.tt.boxes:
        bx0, by0, bx1, by1 = rec["bbox"]
        if bx0 < -1.0 or bx1 > width + 1.0 or by0 < -1.0 or by1 > height + 1.0:
            failures.append(
                "section %d: panel outside the canvas (%s)" % (rec["section"], rec["kind"]))
    panels = [b for b in ctx.tt.boxes if b["kind"] == "panel"]
    for i in range(len(panels)):
        for j in range(i + 1, len(panels)):
            a = panels[i]
            b = panels[j]
            if a["section"] == b["section"]:
                continue
            ax0, ay0, ax1, ay1 = a["bbox"]
            bx0, by0, bx1, by1 = b["bbox"]
            ox = min(ax1, bx1) - max(ax0, bx0)
            oy = min(ay1, by1) - max(ay0, by0)
            if ox <= 2.0 or oy <= 2.0:
                continue
            contains = (ax0 <= bx0 + tol and ax1 >= bx1 - tol
                        and ay0 <= by0 + tol and ay1 >= by1 - tol)
            reverse = (bx0 <= ax0 + tol and bx1 >= ax1 - tol
                       and by0 <= ay0 + tol and by1 >= ay1 - tol)
            if not contains and not reverse and ox * oy > 4.0:
                failures.append(
                    "panels of sections %d and %d overlap (%.0f px2)"
                    % (a["section"], b["section"], ox * oy))
    return failures


def _probe_glyphs(spec, fontfile):
    """Characters the chosen font cannot draw, in order of first appearance."""
    strings = []
    _collect_strings(spec["sections"], strings)
    strings.append(GLYPH_CONSTANTS)
    seen = []
    for s in strings:
        for ch in s:
            if ch not in seen:
                seen.append(ch)
    return missing_glyphs(fontfile, "".join(seen))


def render(spec, out_path=None, strict=False):
    """Render an infographic spec to a PNG file.

    Parameters
    ----------
    spec : dict | str | os.PathLike
        Spec content (dict or JSON string) or a path to a JSON spec file.
    out_path : str | os.PathLike | None
        Target PNG path; by default <spec folder>/<name>.png.
    strict : bool
        When True, raise RenderError if any check fails.

    Returns
    -------
    dict with keys: ok, out_path, size_px, check_failures, missing_glyphs,
    warnings.
    """
    data = load_spec(spec)
    pal = resolve_palette(data.get("theme"))
    width = float(data["canvas"]["width"])
    dpi = float(data["canvas"]["dpi"])
    fixed = data["canvas"]["height"]
    fixed_h = float(fixed) if fixed != "auto" else None
    fontfile = font_path(data.get("font") or "DejaVu Sans")

    # Pass 1: natural content height (layout does not depend on canvas height).
    provisional = fixed_h if fixed_h else 1600.0
    _, _, _, bottom = _render_sections(data, pal, dpi, provisional)
    height = fixed_h if fixed_h else max(200.0, bottom + data["margin"])

    # Pass 2: final render plus bbox self-checks.
    fig, ax, ctx, bottom2 = _render_sections(data, pal, dpi, height)
    failures = list(ctx.failures)
    warnings = list(ctx.warnings)
    if bottom2 + data["margin"] > height + 2.0:
        failures.append(
            "content needs %.0f px of height, canvas has %.0f px"
            % (bottom2 + data["margin"], height))
    renderer = fig.canvas.get_renderer()
    failures.extend(_check_layout(ctx, ax, renderer, width, height))

    glyphs = _probe_glyphs(data, fontfile)

    if not out_path:
        out_path = os.path.join(data.get("base_dir") or os.getcwd(),
                                "%s.png" % data["name"])
    out_path = os.fspath(out_path)
    parent = os.path.dirname(os.path.abspath(out_path))
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    fig.savefig(out_path, dpi=dpi, facecolor=pal["bg"])

    size_px = None
    try:
        from PIL import Image

        with Image.open(out_path) as im:
            im.verify()
        with Image.open(out_path) as im:
            if im.format != "PNG":
                failures.append("output is not a PNG: %s" % im.format)
            size_px = [int(im.size[0]), int(im.size[1])]
            want = (int(round(width)), int(round(height)))
            if abs(size_px[0] - want[0]) > 1 or abs(size_px[1] - want[1]) > 1:
                failures.append("PNG size %s does not match the canvas %s"
                                % (tuple(size_px), want))
    except Exception as exc:
        failures.append("PNG validation failed: %s" % exc)

    if strict and (failures or glyphs):
        raise RenderError("checks failed: %s" % "; ".join(
            failures + (["missing glyphs: %s" % "".join(glyphs)] if glyphs else [])))

    return {
        "ok": True,
        "out_path": os.path.abspath(out_path),
        "size_px": size_px,
        "check_failures": failures,
        "missing_glyphs": glyphs,
        "warnings": warnings,
    }
