"""Text measuring, wrapping and drawing helpers in pixel coordinates.

All layout math in the engine operates in output pixels; font sizes are given
in points and converted through the canvas dpi so measurements match the
rendered result exactly.
"""

from __future__ import annotations

from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
from matplotlib.text import Text


def fmt_number(value, decimals="auto", separator="."):
    """Format a numeric value for display: 4.6 -> '4.6', separator-aware."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return str(value)
    if decimals == "auto":
        s = ("%.2f" % v).rstrip("0").rstrip(".")
        if s in ("", "-0"):
            s = "0"
    else:
        s = ("%.*f" % (int(decimals), v))
    if separator != ".":
        s = s.replace(".", separator)
    return s


class TextTool:
    """Measure, wrap and draw text on an Axes whose data units equal pixels."""

    def __init__(self, ax, dpi, fontname):
        self.ax = ax
        self.dpi = float(dpi)
        self.fontname = fontname
        self.texts = []
        self.boxes = []
        self._cache = {}
        self._mfig = Figure(figsize=(4.0, 4.0), dpi=self.dpi)
        self._mrenderer = FigureCanvasAgg(self._mfig).get_renderer()

    # -- measuring ------------------------------------------------------

    def _fp(self, size, weight):
        return FontProperties(family=self.fontname, size=size, weight=weight)

    def measure(self, text, size, weight="normal", linespacing=1.35):
        """Return (width_px, height_px) of text as it will be rendered."""
        key = ("m", str(text), float(size), str(weight), round(float(linespacing), 3))
        if key not in self._cache:
            t = Text(0.0, 0.0, str(text), fontproperties=self._fp(size, weight))
            t.set_linespacing(linespacing)
            t.set_figure(self._mfig)
            bb = t.get_window_extent(self._mrenderer)
            self._cache[key] = (float(bb.width), float(bb.height))
        return self._cache[key]

    def height_of(self, lines, size, weight="normal", linespacing=1.35):
        """Height of a wrapped block of lines."""
        if isinstance(lines, str):
            lines = [lines]
        return self.measure("\n".join(lines), size, weight, linespacing)[1]

    def wrap(self, text, max_width, size, weight="normal"):
        """Wrap text into lines that fit max_width px (greedy, word based)."""
        key = ("w", str(text), round(float(max_width), 1), float(size), str(weight))
        hit = self._cache.get(key)
        if hit is not None:
            return list(hit)
        lines = []
        for para in str(text).split("\n"):
            words = para.split()
            if not words:
                lines.append("")
                continue
            line = ""
            for word in words:
                cand = word if not line else line + " " + word
                if not line or self.measure(cand, size, weight)[0] <= max_width:
                    line = cand
                else:
                    lines.append(line)
                    line = word
            if line:
                lines.append(line)
        self._cache[key] = list(lines)
        return lines

    # -- drawing --------------------------------------------------------

    def draw(self, x, y, text, size, color, weight="normal", ha="left", va="top",
             linespacing=1.35, section=None, meta="", zorder=5):
        """Draw a text at pixel position (x, y) and register it for checks."""
        item = self.ax.text(
            x, y, str(text),
            fontproperties=self._fp(size, weight),
            color=color, ha=ha, va=va, linespacing=linespacing, zorder=zorder,
        )
        self.texts.append({"item": item, "section": section, "meta": meta})
        return item

    def add_box(self, bbox, kind="panel", section=None, meta=""):
        """Register a container rectangle (x0, y0, x1, y1) in pixel coords."""
        x0, y0, x1, y1 = bbox
        if x0 > x1:
            x0, x1 = x1, x0
        if y0 > y1:
            y0, y1 = y1, y0
        self.boxes.append({"bbox": (float(x0), float(y0), float(x1), float(y1)),
                           "kind": kind, "section": section, "meta": meta})
