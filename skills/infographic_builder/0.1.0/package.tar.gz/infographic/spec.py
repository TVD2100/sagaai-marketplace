"""Spec loading, validation and defaults for the infographic engine."""

from __future__ import annotations

import json
import os

SECTION_TYPES = (
    "header", "kpi_row", "bullets", "paragraph", "spacer",
    "metrics_table", "bar_chart", "pros_cons", "sources", "image",
)


class SpecError(ValueError):
    """Raised when a spec cannot be validated."""


def _err(msg):
    raise SpecError(msg)


def _require(section, field, stype, index):
    value = section.get(field)
    if value is None or (isinstance(value, str) and not value.strip()):
        _err("section %d (%s): missing required field %r" % (index, stype, field))
    return value


def _as_list(section, field, stype, index):
    value = _require(section, field, stype, index)
    if not isinstance(value, list) or not value:
        _err("section %d (%s): field %r must be a non-empty list" % (index, stype, field))
    return value


def _strings(items, what, index):
    out = []
    for item in items:
        if not isinstance(item, str):
            _err("section %d: %s items must be strings" % (index, what))
        out.append(item)
    return out


def _items_with_value(section, index):
    items = _as_list(section, "items", "bar_chart", index)
    for item in items:
        if not isinstance(item, dict) or "label" not in item or "value" not in item:
            _err("section %d (bar_chart): each item needs label and value" % index)
        try:
            float(item["value"])
        except (TypeError, ValueError):
            _err("section %d (bar_chart): value of %r is not a number" % (index, item.get("label")))
    return items


def _validate_section(section, index):
    if not isinstance(section, dict):
        _err("section %d must be an object" % index)
    stype = section.get("type")
    if stype not in SECTION_TYPES:
        _err("section %d: unknown type %r; allowed: %s"
             % (index, stype, ", ".join(SECTION_TYPES)))
    if stype == "header":
        _require(section, "title", stype, index)
    elif stype == "kpi_row":
        items = _as_list(section, "items", stype, index)
        for it in items:
            if not isinstance(it, dict) or "value" not in it or "label" not in it:
                _err("section %d (kpi_row): each item needs value and label" % index)
        if len(items) > 10:
            _err("section %d (kpi_row): at most 10 items" % index)
    elif stype == "bullets":
        _strings(_as_list(section, "items", stype, index), "bullets", index)
    elif stype == "paragraph":
        _require(section, "text", stype, index)
    elif stype == "metrics_table":
        rows = _as_list(section, "rows", stype, index)
        width = None
        for row in rows:
            if not isinstance(row, list) or not row:
                _err("section %d (metrics_table): each row must be a list of cells" % index)
            if width is None:
                width = len(row)
            elif len(row) != width:
                _err("section %d (metrics_table): rows have different column counts" % index)
            for cell in row:
                if not isinstance(cell, (str, int, float)):
                    _err("section %d (metrics_table): cells must be strings or numbers" % index)
        cols = section.get("columns")
        if cols is not None and (not isinstance(cols, list) or len(cols) != width):
            _err("section %d (metrics_table): columns count must match row cells" % index)
    elif stype == "bar_chart":
        _items_with_value(section, index)
    elif stype == "pros_cons":
        _strings(_as_list(section, "pros", stype, index), "pros", index)
        _strings(_as_list(section, "cons", stype, index), "cons", index)
    elif stype == "sources":
        if not section.get("text") and not section.get("items"):
            _err("section %d (sources): provide text or items" % index)
    elif stype == "spacer":
        height = section.get("height", 24)
        if not isinstance(height, (int, float)) or height <= 0:
            _err("section %d (spacer): height must be a positive number" % index)
    elif stype == "image":
        _require(section, "path", stype, index)
    return section


def load_spec(source):
    """Load and validate a spec from a dict, a JSON string or a file path.

    Returns a normalized deep copy; raises SpecError on any problem. Relative
    image paths are later resolved against the spec file folder (base_dir).
    """
    if isinstance(source, dict):
        data = json.loads(json.dumps(source))
        base_dir = os.getcwd()
    elif isinstance(source, str) and source.strip().startswith("{"):
        try:
            data = json.loads(source)
        except json.JSONDecodeError as exc:
            _err("spec is not valid JSON: %s" % exc)
        base_dir = os.getcwd()
    elif isinstance(source, (str, os.PathLike)):
        path = os.fspath(source)
        if not os.path.isfile(path):
            _err("spec file not found: %s" % path)
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except json.JSONDecodeError as exc:
            _err("spec file is not valid JSON: %s" % exc)
        base_dir = os.path.dirname(os.path.abspath(path))
    else:
        _err("spec must be a dict, a JSON string or a file path")

    if not isinstance(data, dict):
        _err("spec root must be an object")
    canvas = data.get("canvas") or {}
    if not isinstance(canvas, dict):
        _err("canvas must be an object")
    width = canvas.get("width", 1800)
    height = canvas.get("height", "auto")
    dpi = canvas.get("dpi", 150)
    if not isinstance(width, (int, float)) or width < 200:
        _err("canvas.width must be a number >= 200")
    if not (height == "auto" or isinstance(height, (int, float))):
        _err("canvas.height must be 'auto' or a number")
    if isinstance(height, (int, float)) and height < 200:
        _err("canvas.height must be >= 200 or 'auto'")
    if not isinstance(dpi, (int, float)) or not 60 <= dpi <= 600:
        _err("canvas.dpi must be between 60 and 600")

    margin = data.get("margin", 80)
    gap = data.get("gap", 34)
    for name, value in (("margin", margin), ("gap", gap)):
        if not isinstance(value, (int, float)) or value < 0:
            _err("%s must be a non-negative number" % name)

    sections = data.get("sections")
    if not isinstance(sections, list) or not sections:
        _err("spec must contain a non-empty sections list")
    for i, section in enumerate(sections):
        _validate_section(section, i)

    normalized = {
        "name": str(data.get("name") or "infographic"),
        "canvas": {"width": float(width), "height": height, "dpi": float(dpi)},
        "margin": float(margin),
        "gap": float(gap),
        "font": str(data.get("font") or "DejaVu Sans"),
        "theme": data.get("theme", "default"),
        "sections": sections,
        "base_dir": base_dir,
    }
    return normalized
