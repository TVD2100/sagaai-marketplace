"""Infographic Builder engine: JSON spec -> PNG poster.

Public API:
    render(spec, out_path=None, strict=False) -> dict
    build - alias of render
    load_spec(source) - parse and validate a spec
    RenderError - unrenderable spec or strict-mode check failure
    SpecError - invalid spec
"""

from .engine import RenderError, render
from .spec import SpecError, load_spec

build = render

__all__ = ["render", "build", "load_spec", "RenderError", "SpecError"]
