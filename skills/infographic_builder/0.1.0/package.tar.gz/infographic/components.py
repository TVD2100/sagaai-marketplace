"""Section renderers for the infographic engine.

Each render_<type>(ctx, section, y) draws its section with the top edge at
the pixel coordinate y and returns the y coordinate after the section. All
layout math is done in output pixels; boxes and texts are registered in the
context for the layout self-checks performed by the engine.
"""

from __future__ import annotations

from matplotlib.patches import FancyBboxPatch, Rectangle

from .textkit import fmt_number
from .theme import LAYOUT, alpha


class Ctx:
    """Shared render context passed to every section renderer."""

    def __init__(self, ax, tt, spec, pal):
        self.ax = ax
        self.tt = tt
        self.spec = spec
        self.pal = pal
        self.failures = []
        self.warnings = []
        canvas = spec["canvas"]
        self.W = float(canvas["width"])
        self.margin = float(spec["margin"])
        self.x0 = self.margin
        self.x1 = self.W - self.margin
        self.cw = self.x1 - self.x0
        self.gap = float(spec["gap"])
        self.L = LAYOUT
        self.section = 0

    # -- low level drawing ---------------------------------------------

    def rect(self, x, y, w, h, radius=0, face=None, edge=None, lw=1.0,
             section=None, kind="panel", z=2):
        """Draw a rectangle with the top-left corner at (x, y)."""
        if radius and radius > 0:
            patch = FancyBboxPatch(
                (x, y), w, h,
                boxstyle="round,pad=0,rounding_size=%s" % radius,
                facecolor=face if face else "none",
                edgecolor=edge if edge else "none",
                linewidth=lw, zorder=z, mutation_aspect=1,
            )
        else:
            patch = Rectangle((x, y), w, h,
                              facecolor=face if face else "none",
                              edgecolor=edge if edge else "none",
                              linewidth=lw, zorder=z)
        self.ax.add_patch(patch)
        if kind:
            self.tt.add_box((x, y, x + w, y + h),
                            kind=kind, section=self.section, meta="")
        return patch

    def line(self, x0, y0, x1, y1, color, lw=1.2, z=3):
        """Draw a straight line in pixel coordinates."""
        self.ax.plot([x0, x1], [y0, y1], color=color, lw=lw,
                     solid_capstyle="round", zorder=z)

    def text(self, x, y, s, size, color, weight="normal", ha="left",
             va="top", ls=1.35, box=None, z=5):
        """Draw a text and register it with the allowed box for checks."""
        return self.tt.draw(x, y, s, size, color, weight=weight, ha=ha,
                            va=va, linespacing=ls, section=self.section,
                            meta=box if box else "", zorder=z)

    def block_title(self, s, y, size=None):
        """Small bold heading above a block; returns the y after it."""
        size = size or self.L["section_title_size"]
        w, h = self.tt.measure(s, size, "bold")
        self.text(self.x0, y, s, size, self.pal["ink"], "bold",
                  box=(self.x0, y, self.x0 + w + 4, y + h + 2))
        return y + h + 10


# -- sections -----------------------------------------------------------


def render_header(ctx, sec, y):
    """Full-width colored banner with a title, optional subtitle and right line."""
    p = ctx.pal
    L = ctx.L
    pad = 24
    title = str(sec["title"])
    sub = sec.get("subtitle")
    right = sec.get("right")
    rw = 0.0
    if right:
        rw = ctx.tt.measure(str(right), L["header_right_size"])[0] + 34
    avail = ctx.cw - 2 * pad - (rw if right else 0)
    lines = ctx.tt.wrap(title, avail, L["header_title_size"], "bold")
    th = ctx.tt.height_of(lines, L["header_title_size"], "bold")
    sh = 0.0
    if sub:
        sh = 8 + ctx.tt.measure(str(sub), L["header_sub_size"])[1]
    h = pad + th + sh + pad
    ctx.rect(ctx.x0, y, ctx.cw, h, radius=L["radius"], face=p["header_bg"],
             section=ctx.section, kind="panel", z=1)
    tx = ctx.x0 + pad
    ctx.text(tx, y + pad, "\n".join(lines), L["header_title_size"],
             p["header_ink"], "bold", box=(tx, y + pad, tx + avail, y + pad + th + 2))
    if sub:
        sy = y + pad + th + 8
        ctx.text(ctx.x0 + pad, sy, str(sub), L["header_sub_size"],
                 alpha(p["header_ink"], 0.85),
                 box=(ctx.x0 + pad, sy, ctx.x1 - pad - (rw if right else 0), sy + sh))
    if right:
        ctx.text(ctx.x1 - pad, y + pad + 4, str(right), L["header_right_size"],
                 alpha(p["header_ink"], 0.8), ha="right",
                 box=(ctx.x1 - pad - rw, y + pad, ctx.x1 - pad + 2, y + pad + 44))
    return y + h


def render_kpi_row(ctx, sec, y):
    """Row of KPI cards; wraps to several rows when items exceed per_row."""
    p = ctx.pal
    L = ctx.L
    items = sec["items"]
    per = int(sec.get("per_row") or 4)
    per = max(1, min(per, len(items)))
    cgap = 16.0
    cw = (ctx.cw - cgap * (per - 1)) / per
    pad = 16.0
    title = sec.get("title")
    if title:
        y = ctx.block_title(str(title), y)
    rows = [items[i:i + per] for i in range(0, len(items), per)]
    total = 0.0
    for row in rows:
        prepared = []
        heights = []
        for it in row:
            value = str(it["value"])
            label = str(it["label"])
            note = it.get("note")
            vsize = L["kpi_value_size"]
            for cand in (34, 30, 26, 22, 18, 16):
                if ctx.tt.measure(value, cand, "bold")[0] <= cw - 2 * pad:
                    vsize = cand
                    break
            else:
                vsize = 16
                ctx.failures.append(
                    "kpi_row: value %r does not fit the card even at 16pt" % value)
            vh = ctx.tt.measure(value, vsize, "bold")[1]
            ll = ctx.tt.wrap(label, cw - 2 * pad, L["kpi_label_size"])
            lh = ctx.tt.height_of(ll, L["kpi_label_size"])
            nh = 0.0
            nl = None
            if note:
                nl = ctx.tt.wrap(str(note), cw - 2 * pad, L["kpi_note_size"])
                nh = 6 + ctx.tt.height_of(nl, L["kpi_note_size"])
            h = 14 + vh + 8 + lh + nh + 14
            prepared.append((value, vsize, vh, ll, lh, nl, nh))
            heights.append(h)
        rh = max(heights)
        x = ctx.x0
        for prep, h in zip(prepared, heights):
            value, vsize, vh, ll, lh, nl, nh = prep
            ctx.rect(x, y, cw, rh, radius=10, face=p["panel_bg"],
                     edge=p["panel_edge"], section=ctx.section, kind="panel", z=1)
            yy = y + 14 + (rh - h) / 2
            ctx.text(x + pad, yy, value, vsize, p["accent"], "bold",
                     box=(x + pad, yy, x + cw - pad, yy + vh + 2))
            ly = yy + vh + 8
            ctx.text(x + pad, ly, "\n".join(ll), L["kpi_label_size"], p["muted"],
                     box=(x + pad, ly, x + cw - pad, ly + lh + 2))
            if nl:
                ny = ly + lh + 6
                ctx.text(x + pad, ny, "\n".join(nl), L["kpi_note_size"],
                         alpha(p["muted"], 0.9),
                         box=(x + pad, ny, x + cw - pad, ny + nh))
            x += cw + cgap
        y += rh + 16
        total += rh + 16
    return y - 16


def render_bullets(ctx, sec, y):
    """Bullet or numbered list with wrapped items."""
    p = ctx.pal
    L = ctx.L
    size = float(sec.get("fontsize") or L["body_size"])
    items = [str(s) for s in sec["items"]]
    numbered = bool(sec.get("numbered"))
    title = sec.get("title")
    if title:
        y = ctx.block_title(str(title), y)
    if numbered:
        mw = max(ctx.tt.measure("%d." % (i + 1), size, "bold")[0]
                 for i in range(len(items)))
    else:
        mw = ctx.tt.measure("•", size, "bold")[0]
    tx = ctx.x0 + mw + 10
    tw = ctx.x1 - tx
    first = True
    for i, s in enumerate(items):
        if not first:
            y += 8
        lines = ctx.tt.wrap(s, tw, size)
        h = ctx.tt.height_of(lines, size)
        marker = ("%d." % (i + 1)) if numbered else "•"
        ctx.text(ctx.x0, y + 1, marker, size, p["accent"], "bold",
                 box=(ctx.x0 - 1, y, ctx.x0 + mw + 2, y + h + 2))
        ctx.text(tx, y, "\n".join(lines), size, p["ink"],
                 box=(tx, y, tx + tw, y + h + 2))
        y += h
        first = False
    return y


def render_paragraph(ctx, sec, y):
    """A wrapped paragraph of body text with an optional heading."""
    p = ctx.pal
    L = ctx.L
    size = float(sec.get("fontsize") or L["body_size"])
    title = sec.get("title")
    if title:
        y = ctx.block_title(str(title), y)
    lines = ctx.tt.wrap(str(sec["text"]), ctx.cw, size)
    h = ctx.tt.height_of(lines, size, linespacing=L["paragraph_spacing"])
    ctx.text(ctx.x0, y, "\n".join(lines), size, p["ink"],
             ls=L["paragraph_spacing"],
             box=(ctx.x0, y, ctx.x1, y + h + 2))
    return y + h


def render_metrics_table(ctx, sec, y):
    """Table of figures: optional header row, zebra stripes, column alignment."""
    p = ctx.pal
    L = ctx.L
    size = float(sec.get("fontsize") or L["table_size"])
    rows = [[str(c) for c in row] for row in sec["rows"]]
    cols = [str(c) for c in sec.get("columns") or []]
    ncols = len(rows[0])
    widths = sec.get("widths")
    if widths and len(widths) == ncols:
        total = float(sum(float(w) for w in widths)) or 1.0
        fractions = [float(w) / total for w in widths]
    else:
        fractions = [1.0 / ncols] * ncols
    colw = [ctx.cw * f for f in fractions]
    aligns = sec.get("align")
    if aligns and len(aligns) == ncols:
        aligns = [str(a) for a in aligns]
    else:
        aligns = ["left"] + ["right"] * (ncols - 1)
    stripe = sec.get("stripe", True)
    title = sec.get("title")
    if title:
        y = ctx.block_title(str(title), y)
    py = 9.0

    def row_height(cells, weight):
        hmax = 0.0
        for c in cells:
            hmax = max(hmax, ctx.tt.measure(c, size, weight)[1])
        return py + hmax + py

    all_rows = ([cols] if cols else []) + rows
    body_index = 0
    for i, row in enumerate(all_rows):
        header = bool(cols) and i == 0
        weight = "bold" if header else "normal"
        rh = row_height(row, weight)
        if not header:
            if stripe and body_index % 2 == 1:
                ctx.rect(ctx.x0, y, ctx.cw, rh, face=p["panel_bg"], kind=None, z=1)
            body_index += 1
        x = ctx.x0
        for j, cell in enumerate(row):
            al = aligns[j]
            if al == "right":
                tx, ha = x + colw[j] - 8, "right"
            elif al == "center":
                tx, ha = x + colw[j] / 2, "center"
            else:
                tx, ha = x + 8, "left"
            ctx.text(tx, y + py, cell, size, p["ink"], weight, ha=ha,
                     box=(x + 6, y + 2, x + colw[j] - 6, y + rh - 2))
            x += colw[j]
        if header:
            ctx.line(ctx.x0, y + rh, ctx.x1, y + rh, p["panel_edge"], lw=1.2)
        y += rh
    return y


def render_bar_chart(ctx, sec, y):
    """Horizontal bars for ratings or comparisons; values are numbers."""
    p = ctx.pal
    L = ctx.L
    size = float(sec.get("fontsize") or L["bar_size"])
    items = [dict(it) for it in sec["items"]]
    srt = str(sec.get("sort") or "none")
    if srt in ("desc", "asc"):
        items.sort(key=lambda it: float(it["value"]), reverse=(srt == "desc"))
    maxv = sec.get("max_value")
    if not isinstance(maxv, (int, float)) or maxv <= 0:
        maxv = max([float(it["value"]) for it in items] + [1.0])
    maxv = float(maxv)
    suffix = str(sec.get("value_suffix") or "")
    decimals = sec.get("decimals", "auto")
    sep = str(sec.get("decimal_separator") or ".")
    show_values = sec.get("show_values", True)
    bar_h = float(sec.get("bar_height") or 26)
    lw_opt = sec.get("label_width")
    label_w = float(lw_opt) if isinstance(lw_opt, (int, float)) else ctx.cw * 0.30
    title = sec.get("title")
    if title:
        y = ctx.block_title(str(title), y)
    texts = []
    fracs = []
    for it in items:
        v = float(it["value"])
        if v > maxv:
            ctx.warnings.append(
                "bar_chart: value %s of %r exceeds max_value %s (clamped)"
                % (v, it.get("label"), maxv))
            v = maxv
        texts.append(fmt_number(it["value"], decimals, sep) + suffix)
        fracs.append(min(max(v / maxv, 0.0), 1.0))
    val_w = 0.0
    if show_values:
        val_w = max(ctx.tt.measure(t, size, "bold")[0] for t in texts) + 18
    gap_l = 14.0
    track_x = ctx.x0 + label_w + gap_l
    track_w = ctx.x1 - val_w - track_x
    if track_w < 40:
        ctx.failures.append("bar_chart: label_width leaves no room for the bars")
        track_w = max(40.0, ctx.x1 - track_x)
    first = True
    for it, vt, frac in zip(items, texts, fracs):
        if not first:
            y += 10
        lines = ctx.tt.wrap(str(it["label"]), label_w, size)
        lh = ctx.tt.height_of(lines, size)
        note = it.get("note")
        nl = None
        nh = 0.0
        if note:
            nl = ctx.tt.wrap(str(note), label_w, L["small_size"])
            nh = 3 + ctx.tt.height_of(nl, L["small_size"])
        row_h = max(bar_h, lh + nh)
        ty = y + (row_h - lh - nh) / 2
        ctx.text(ctx.x0 + label_w - 4, ty, "\n".join(lines), size, p["ink"],
                 ha="right", box=(ctx.x0 - 2, ty, ctx.x0 + label_w, y + row_h))
        if nl:
            ny = ty + lh + 3
            ctx.text(ctx.x0 + label_w - 4, ny, "\n".join(nl), L["small_size"],
                     p["muted"], ha="right",
                     box=(ctx.x0 - 2, ny, ctx.x0 + label_w, ny + nh + 2))
        by = y + (row_h - bar_h) / 2
        ctx.rect(track_x, by, track_w, bar_h, radius=bar_h / 2,
                 face=p["panel_bg"], kind=None, z=1)
        if frac > 0:
            fw = max(bar_h, frac * track_w)
            ctx.rect(track_x, by, fw, bar_h, radius=bar_h / 2,
                     face=p["accent"], kind=None, z=3)
        if show_values:
            ctx.text(ctx.x1, by + bar_h / 2, vt, size, p["accent"], "bold",
                     ha="right", va="center",
                     box=(ctx.x1 - val_w, by - 2, ctx.x1 + 2, by + bar_h + 2))
        y += row_h
        first = False
    return y


def render_pros_cons(ctx, sec, y):
    """Two panels side by side: praise vs complaints, strengths vs risks."""
    p = ctx.pal
    L = ctx.L
    size = float(sec.get("fontsize") or L["body_size"])
    pros = [str(s) for s in sec["pros"]]
    cons = [str(s) for s in sec["cons"]]
    p_title = str(sec.get("pros_title") or "Pros")
    c_title = str(sec.get("cons_title") or "Cons")
    tsize = L["section_title_size"]
    gap = 16.0
    pad = 16.0
    pw = (ctx.cw - gap) / 2

    def layout_side(icon, title, items, color):
        mw = ctx.tt.measure("•", size, "bold")[0]
        tw = pw - 2 * pad - mw - 10
        title_h = ctx.tt.measure(icon + "  " + title, tsize, "bold")[1]
        blocks = []
        content_h = 0.0
        for s in items:
            lines = ctx.tt.wrap(s, tw, size)
            ih = ctx.tt.height_of(lines, size)
            blocks.append((lines, ih))
            content_h += ih + 8
        if blocks:
            content_h -= 8
        return title_h, blocks, content_h

    pt_h, p_blocks, p_ch = layout_side("✓", p_title, pros, p["good"])
    ct_h, c_blocks, c_ch = layout_side("✗", c_title, cons, p["bad"])
    title_h = max(pt_h, ct_h)
    content_h = max(p_ch, c_ch)
    panel_h = 14 + title_h + 12 + content_h + 14
    x = ctx.x0
    for side in ("pros", "cons"):
        fill = p["good_soft"] if side == "pros" else p["bad_soft"]
        edge = alpha(p["good"] if side == "pros" else p["bad"], 0.28)
        ctx.rect(x, y, pw, panel_h, radius=10, face=fill, edge=edge,
                 section=ctx.section, kind="panel", z=1)
        x += pw + gap
    for side, icon, title, blocks, color in (
            ("pros", "✓", p_title, p_blocks, p["good"]),
            ("cons", "✗", c_title, c_blocks, p["bad"])):
        px = ctx.x0 if side == "pros" else ctx.x0 + pw + gap
        ctx.text(px + pad, y + 14, icon + "  " + title, tsize, color, "bold",
                 box=(px + pad, y + 14, px + pw - pad, y + 14 + title_h + 2))
        iy = y + 14 + title_h + 12
        mw = ctx.tt.measure("•", size, "bold")[0]
        for lines, ih in blocks:
            ctx.text(px + pad, iy + 1, "•", size, color, "bold",
                     box=(px + pad - 1, iy, px + pad + mw + 2, iy + ih + 2))
            ctx.text(px + pad + mw + 10, iy, "\n".join(lines), size, p["ink"],
                     box=(px + pad + mw + 10, iy, px + pw - pad, iy + ih + 2))
            iy += ih + 8
    y += panel_h
    footer = sec.get("footer")
    if footer:
        fsize = L["small_size"]
        fh = ctx.tt.measure(str(footer), fsize)[1]
        fy = y + 10
        ctx.text(ctx.x0 + ctx.cw / 2, fy, str(footer), fsize, p["muted"],
                 ha="center", box=(ctx.x0, fy, ctx.x1, fy + fh + 2))
        y = fy + fh
    return y


def render_sources(ctx, sec, y):
    """Footer block with data provenance: one paragraph or a list of lines."""
    p = ctx.pal
    L = ctx.L
    size = float(sec.get("fontsize") or L["small_size"])
    title = str(sec.get("title") or "Sources")
    tw = ctx.cw
    h = ctx.tt.measure(title, size, "bold")[1]
    ctx.text(ctx.x0, y, title, size, alpha(p["muted"], 0.95), "bold",
             box=(ctx.x0, y, ctx.x0 + ctx.tt.measure(title, size, "bold")[0] + 4, y + h + 2))
    y += h + 8
    items = sec.get("items")
    if items:
        for s in items:
            lines = ctx.tt.wrap("•  " + str(s), tw - 10, size)
            ih = ctx.tt.height_of(lines, size)
            ctx.text(ctx.x0 + 10, y, "\n".join(lines), size, p["muted"],
                     box=(ctx.x0 + 8, y, ctx.x1, y + ih + 2))
            y += ih + 6
        return y - 6
    lines = ctx.tt.wrap(str(sec.get("text") or ""), tw, size)
    ih = ctx.tt.height_of(lines, size)
    ctx.text(ctx.x0, y, "\n".join(lines), size, p["muted"],
             box=(ctx.x0, y, ctx.x1, y + ih + 2))
    return y + ih


def render_spacer(ctx, sec, y):
    """Blank vertical gap; the section contributes height and nothing else."""
    return y + float(sec.get("height") or 24)


def render_image(ctx, sec, y):
    """Embed an external PNG/JPEG with an optional caption."""
    import os

    from matplotlib.image import imread

    p = ctx.pal
    L = ctx.L
    path = str(sec["path"])
    if not os.path.isabs(path):
        path = os.path.join(ctx.spec.get("base_dir") or ".", path)
    align = str(sec.get("align") or "center")
    if not os.path.isfile(path):
        ctx.warnings.append("image: file not found, section skipped: %s" % path)
        return y
    try:
        img = imread(path)
    except Exception as exc:
        ctx.warnings.append("image: cannot read %s (%s)" % (path, exc))
        return y
    ih, iw = float(img.shape[0]), float(img.shape[1])
    width = sec.get("width")
    if isinstance(width, (int, float)) and width > 0:
        aw = float(width)
    else:
        aw = ctx.cw
    h_opt = sec.get("height")
    if isinstance(h_opt, (int, float)) and h_opt > 0:
        ah = float(h_opt)
    else:
        ah = aw * ih / iw
    ax = ctx.x0 + (ctx.cw - aw) / 2
    if align == "left":
        ax = ctx.x0
    elif align == "right":
        ax = ctx.x1 - aw
    z = 4
    if sec.get("border"):
        ctx.rect(ax - 1, y - 1, aw + 2, ah + 2, radius=0,
                 face=None, edge=p["panel_edge"], section=ctx.section,
                 kind="panel", z=z - 1)
    ctx.ax.imshow(img, extent=(ax, ax + aw, y + ah, y), zorder=z,
                  interpolation="antialiased")
    ctx.tt.add_box((ax, y, ax + aw, y + ah), kind="panel",
                   section=ctx.section, meta="image")
    y += ah
    caption = sec.get("caption")
    if caption:
        cs = L["small_size"]
        ch = ctx.tt.measure(str(caption), cs)[1]
        cy = y + 8
        ctx.text(ctx.x0 + ctx.cw / 2, cy, str(caption), cs, p["muted"],
                 ha="center", box=(ctx.x0, cy, ctx.x1, cy + ch + 2))
        y = cy + ch
    return y


RENDERERS = {
    "header": render_header,
    "kpi_row": render_kpi_row,
    "bullets": render_bullets,
    "paragraph": render_paragraph,
    "metrics_table": render_metrics_table,
    "bar_chart": render_bar_chart,
    "pros_cons": render_pros_cons,
    "sources": render_sources,
    "spacer": render_spacer,
    "image": render_image,
}
