"""Palettes, layout constants and font helpers for the infographic engine."""

from __future__ import annotations

from matplotlib import font_manager, ft2font
from matplotlib.colors import to_rgba

DEFAULT_FONT = "DejaVu Sans"

FALLBACK_FONTS = ("DejaVu Sans", "Arial Unicode MS", "Arial", "Helvetica")

# Palette keys: bg, ink, muted, accent, accent_soft, good, good_soft, bad,
# bad_soft, warn, panel_bg, panel_edge, header_bg, header_ink.
# The default theme follows the reference poster style: white page, deep green
# accents, soft green / soft rose panels for pros and cons.
THEMES = {
    "default": {
        "bg": "#FFFFFF",
        "ink": "#17211C",
        "muted": "#5B6B62",
        "accent": "#0C7142",
        "accent_soft": "#E9F4ED",
        "good": "#0C7142",
        "good_soft": "#E9F4ED",
        "bad": "#B4232A",
        "bad_soft": "#FBEDEA",
        "warn": "#B45309",
        "panel_bg": "#F7FAF8",
        "panel_edge": "#DFE7E2",
        "header_bg": "#0F3D2A",
        "header_ink": "#FFFFFF",
    },
    "blue": {
        "bg": "#FFFFFF",
        "ink": "#152238",
        "muted": "#5A6B85",
        "accent": "#1650A0",
        "accent_soft": "#E3EDFB",
        "good": "#0F7A45",
        "good_soft": "#E7F5EC",
        "bad": "#B4232A",
        "bad_soft": "#FBEDEA",
        "warn": "#9A5B00",
        "panel_bg": "#F5F8FD",
        "panel_edge": "#DCE4F0",
        "header_bg": "#122B54",
        "header_ink": "#FFFFFF",
    },
    "mono": {
        "bg": "#FFFFFF",
        "ink": "#1A1A1A",
        "muted": "#6B6B6B",
        "accent": "#333333",
        "accent_soft": "#ECECEC",
        "good": "#444444",
        "good_soft": "#F2F2F2",
        "bad": "#7A7A7A",
        "bad_soft": "#F7F7F7",
        "warn": "#666666",
        "panel_bg": "#F7F7F7",
        "panel_edge": "#E2E2E2",
        "header_bg": "#222222",
        "header_ink": "#FFFFFF",
    },
}

LAYOUT = {
    "radius": 12,
    "header_title_size": 34,
    "header_sub_size": 15,
    "header_right_size": 11,
    "section_title_size": 15,
    "body_size": 13,
    "small_size": 11,
    "tiny_size": 10.5,
    "kpi_value_size": 34,
    "kpi_label_size": 11,
    "kpi_note_size": 10,
    "table_size": 12.5,
    "bar_size": 12,
    "line_spacing": 1.35,
    "paragraph_spacing": 1.5,
}


def resolve_palette(theme):
    """Return a full palette dict for a theme name, an override object or None."""
    overrides = {}
    base = "default"
    if theme is None or theme == "default":
        pass
    elif isinstance(theme, str):
        if theme not in THEMES:
            raise ValueError(
                "unknown theme %r; expected one of %s or an object"
                % (theme, ", ".join(sorted(THEMES)))
            )
        base = theme
    elif isinstance(theme, dict):
        base = theme.get("base", "default")
        if base not in THEMES:
            raise ValueError("unknown theme base %r" % (base,))
        overrides = {k: v for k, v in theme.items() if k != "base"}
    else:
        raise ValueError("theme must be a name or an object")
    pal = dict(THEMES[base])
    pal.update(overrides)
    return pal


def font_path(name):
    """Resolve a font family name to a TTF path; fall back gracefully."""
    candidates = [name] + [f for f in FALLBACK_FONTS if f != name]
    for cand in candidates:
        try:
            return font_manager.findfont(
                font_manager.FontProperties(family=cand), fallback_to_default=False
            )
        except Exception:
            continue
    return font_manager.findfont(DEFAULT_FONT)


def missing_glyphs(path, text):
    """Characters of text the font at path cannot render, in first-seen order."""
    try:
        f = ft2font.FT2Font(path)
    except Exception:
        return []
    out = []
    for ch in text:
        if ch in "\n\r\t ":
            continue
        try:
            ok = bool(f.get_char_index(ord(ch)))
        except Exception:
            ok = False
        if not ok and ch not in out:
            out.append(ch)
    return out


def alpha(color, a):
    """Return color with the given alpha as an RGBA tuple."""
    r, g, b, _ = to_rgba(color)
    return (r, g, b, a)
