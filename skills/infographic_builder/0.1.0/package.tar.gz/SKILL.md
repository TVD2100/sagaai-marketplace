---
name: infographic-builder
description: Use when the user asks for an infographic, a data poster or a visual one-pager as a PNG ("инфографика", "постер с данными", "визуальная сводка", "карточка компании в цифрах"). Builds multi-section PNG infographics from a JSON spec: header, KPI cards, metrics tables, rating bar charts, pros/cons panels, bullet lists, paragraphs, sources footer and images; auto canvas height, pixel-accurate text wrapping, layout self-checks, glyph probe and PNG validation.
---

# Infographic Builder

Render multi-section infographics (.png) from a JSON specification. The engine is deterministic and offline (matplotlib + Pillow, no network). Workflow: collect data -> design sections -> write a spec -> render -> self-check -> vision QA -> deliver.

## 1. Contents and entry point

| File | Role |
|---|---|
| `build_infographic.py` | Entry point: CLI and `build(spec_path, out_path=None, strict=False)`. |
| `infographic/` | Engine package: `spec.py` (validation), `theme.py` (palettes), `textkit.py` (wrapping/measuring), `components.py` (section renderers), `engine.py` (canvas, checks, export). |
| `examples/demo_spec.json`, `examples/demo_infographic.png` | Worked example (fictional bike-share service, Russian texts). |
| `tests/`, `tests/scenarios/` | pytest suite. |
| `CHANGELOG.md` | Version history. |

How to use: load this file with `get_skill_prompt(<id>)`; copy the engine into `.dev_agent/scratch/skill_infographic/` (recipe in section 4); render; then delete the scratch copy (section 3.6). The engine writes exactly one file: the PNG you ask for.

## 2. When to use / when not

Use it when the user wants a raster visual summary on one long canvas:

- an infographic about a company, product, research or event; a data poster; a numbers one-pager;
- a company snapshot (facts + finances + ratings + reviews), comparison of options, a report summary;
- the deliverable is a PNG image.

Do not use it for:

- slide decks and presentations - use a presentation skill instead;
- a single chart for a report - plain matplotlib is enough;
- SVG / editable vector graphics - output is PNG only;
- live dashboards or interactive graphics.

## 3. Workflow

### 3.1 Collect the content (facts first, then design)

1. Fix scope when unclear: topic, audience, language of texts, and the "as of" date shown on the poster.
2. Gather facts with `web_search` (public information only):
   - entity facts (founding, key people, geography, scale);
   - key numbers (revenue, profit, ratings, counts) - every number needs a source, disputed ones need two;
   - reviews and opinions split into praise / complaints;
   - recent news and risks;
   - keep up to 5 primary domains (annual reports, regulators, official sites) for repeat searches.
3. Record for every figure: source, date, unit. If sources diverge, print the range (for example "4,4-4,8") - never invent an average.
4. The final `sources` section and the "collected on" date are mandatory.
5. Legal and ethical line: public information only, no personal data, neutral wording.

### 3.2 Design the canvas and sections

- Width 1800 px (dpi 150) is the production default; height `"auto"` - the canvas grows to fit the content.
- Typical order: header -> kpi_row -> bullets or metrics_table -> bar_chart(s) -> pros_cons -> paragraph -> sources.
- One idea per section; 2-6 items per panel; short labels (bar labels are single-line by design).

### 3.3 Write the spec

A minimal spec:

~~~json
{
  "name": "demo",
  "canvas": {"width": 1800, "height": "auto", "dpi": 150},
  "sections": [
    {"type": "header", "title": "Компания в цифрах", "subtitle": "Итоги года"},
    {"type": "kpi_row", "items": [{"value": "128", "label": "станций в городе"}]},
    {"type": "sources", "text": "Источники: ..."}
  ]
}
~~~

Every section type and option: section 6.

### 3.4 Render

Copy the engine to scratch and call it (recipes in section 4). Read the returned JSON - it is the self-check report.

### 3.5 QA loop (mandatory)

1. `check_failures` non-empty: each entry names the section, the text snippet and the overflow in px. Fix the spec (shorten text, lower `fontsize`, widen `label_width`, split the section) and re-render until empty.
2. `missing_glyphs` non-empty: replace those characters or change the font (section 7).
3. Vision pass: call `analyze_image` on the PNG (reviewer prompt in section 7). It catches what geometry checks cannot: overlaps, clipped glyphs, misalignment and overall design quality.
4. Fix and re-run the render plus the affected checks. Zero remaining issues across both passes = ready.

### 3.6 Deliver

- Copy the PNG where the user asked (or keep it in the dialog files folder and show the path).
- Remove `.dev_agent/scratch/skill_infographic/`.
- Report: coverage, sources, caveats (diverging data), the file path and the checks that passed.

## 4. Recipes

Copy the engine into the current workspace once per task. Set `src` to the folder path returned by `get_skill_folder(<id>)`:

~~~python
import shutil
src = "<skill_folder>/"
dst = ".dev_agent/scratch/skill_infographic"
shutil.copytree(src, dst, dirs_exist_ok=True,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".pytest_cache", ".dev_agent", ".DS_Store"))
print("copied:", dst)
~~~

Render a spec with inline `run_code` (paths resolve against the process cwd; if unsure of the cwd, build absolute paths first):

~~~python
import json, os, sys
root = os.getcwd()
sys.path.insert(0, os.path.join(root, ".dev_agent/scratch/skill_infographic"))
from build_infographic import build
res = build(os.path.join(root, "spec.json"), os.path.join(root, "out.png"))
print(json.dumps(res, ensure_ascii=False, indent=1))
~~~

Programmatic use without files on disk:

~~~python
from infographic import render
res = render({... spec dict ...}, "out.png")
~~~

CLI:

~~~bash
python build_infographic.py spec.json out.png [--strict]
~~~

With `--strict` a non-fatal warning becomes an error: the process exits with code 1 when any check fails.

Syntax sanity check of the copied engine:

~~~python
import py_compile, glob
for f in glob.glob(".dev_agent/scratch/skill_infographic/**/*.py", recursive=True):
    py_compile.compile(f, doraise=True)
print("ok")
~~~

## 5. Canvas, themes and fonts

Top-level spec fields:

| Field | Default | Meaning |
|---|---|---|
| `sections` | required | Non-empty list of section objects; each object needs a `type` (section 6). |
| `name` | "infographic" | Label used in the result report. |
| `canvas.width` | 1800 | Canvas width in px. |
| `canvas.height` | "auto" | `"auto"` grows to fit content; an int fixes the height (content past the bottom becomes a check failure). |
| `canvas.dpi` | 150 | Figure dpi; keep 150 for print-quality PNGs. |
| `margin` | 80 | Horizontal page margin in px. |
| `theme` | "default" | `"default"`, `"blue"`, `"mono"`, or an object overriding palette keys. |
| `font` | "DejaVu Sans" | Any font PyPlot can resolve; glyph coverage is checked and reported. |
| `gap` | 34 | Vertical gap between sections, px. |

Theme override example (unspecified keys fall back to the base palette):

~~~json
{"theme": {"accent": "#0E7490", "accent_soft": "#CFFAFE", "header_bg": "#0F172A"}}
~~~

Palette keys: `bg`, `ink`, `muted`, `accent`, `accent_soft`, `good`, `bad`, `panel_bg`, `panel_edge`, `header_bg`, `header_ink`.

Fonts: DejaVu Sans ships with matplotlib and covers Cyrillic, `₽`, `✓`, `✗`, `№`, typographic dashes and quotes - the reliable default for Russian posters. For another language or a brand font, set `font` and re-run; report any `missing_glyphs` in the result.

## 6. Section reference

Every section object requires `"type"`; the optional `"gap"` field overrides the vertical gap before it. Sections render top-down in list order.

### header

| Field | Req | Notes |
|---|---|---|
| `title` | yes | Large header text. |
| `subtitle` | no | Second line under the title. |
| `right` | no | Small right-aligned line (for example the collect date). |

~~~json
{"type": "header", "title": "Компания в цифрах", "subtitle": "Итоги 2025 года", "right": "Собрано 03.10.2026"}
~~~

### kpi_row

Cards in a row; more than `per_row` items wrap to additional rows.

| Field | Req | Notes |
|---|---|---|
| `items` | yes | 1-10 objects `{value, label, note?}`. `value` is bold accent (font auto-shrinks to fit the card), `label` is small muted text, `note` is an extra faint line. |
| `per_row` | no | Cards per row, default 4. |
| `title` | no | Small heading above the row. |

~~~json
{"type": "kpi_row", "title": "Ключевые цифры", "items": [
  {"value": "128", "label": "станций в городе"},
  {"value": "3 400", "label": "единиц техники"}
]}
~~~

### bullets

| Field | Req | Notes |
|---|---|---|
| `items` | yes | List of strings; each wraps to multiple lines. |
| `title` | no | Heading above the list. |
| `numbered` | no | `true` for "1. 2. 3.", default "•" bullets. |
| `fontsize` | no | Body size override. |

~~~json
{"type": "bullets", "title": "Факты", "items": ["Сервис запущен в 2019 году", "Работает в 12 городах"]}
~~~

### paragraph

| Field | Req | Notes |
|---|---|---|
| `text` | yes | Wrapped at the content width, line height 1.5. |
| `title` | no | Heading above the text. |
| `fontsize` | no | Text size override. |

~~~json
{"type": "paragraph", "title": "Контекст", "text": "Компания прошла реструктуризацию..."}
~~~

### spacer

~~~json
{"type": "spacer", "height": 40}
~~~

### metrics_table

Table for financial or operational figures: optional header row, zebra striping, right-aligned numbers.

| Field | Req | Notes |
|---|---|---|
| `rows` | yes | List of rows; each row is a list of cell strings (2-4 cells). |
| `columns` | no | Header cells; same count as row cells. |
| `align` | no | Per-column `"left"`/`"right"`/`"center"`; default: first column left, the rest right. |
| `widths` | no | Relative column widths; default equal. |
| `title` | no | Heading above the table. |
| `stripe` | no | Zebra striping, default `true`. |
| `fontsize` | no | Cell text size override. |

~~~json
{"type": "metrics_table", "title": "Показатели года", "columns": ["Показатель", "2024", "2025"],
 "rows": [["Поездки, млн", "0,9", "1,2"], ["Активные пользователи, тыс.", "86", "104"]]}
~~~

### bar_chart

Horizontal bars for ratings, comparisons or rankings; values are numbers.

| Field | Req | Notes |
|---|---|---|
| `items` | yes | List of `{label, value, note?}`; `value` is a number. |
| `title` | no | Heading above the chart. |
| `max_value` | no | Scale max; default = largest value (min 1). Use 5 or 10 for ratings. |
| `value_suffix` | no | Appended to the displayed number, e.g. `" из 5"` or `" %"`. |
| `decimals` | no | Decimal places: `"auto"` (default) or an int. |
| `decimal_separator` | no | `"."` (default) or `","` for Russian-style numbers. |
| `label_width` | no | Label column width in px; default 30% of content width. |
| `bar_height` | no | Bar thickness in px, default 26. |
| `sort` | no | `"none"` (default), `"desc"` or `"asc"`. |
| `show_values` | no | Show the value to the right of each bar, default `true`. |

~~~json
{"type": "bar_chart", "title": "Рейтинги", "max_value": 5, "value_suffix": " из 5", "decimal_separator": ",",
 "items": [{"label": "Маркетплейс A", "value": 4.6}, {"label": "Маркетплейс Б", "value": 4.5}]}
~~~

### pros_cons

Two panels side by side: praise vs complaints (reviews) or strengths vs risks.

| Field | Req | Notes |
|---|---|---|
| `pros` | yes | List of strings (positive panel). |
| `cons` | yes | List of strings (negative panel). |
| `pros_title` | no | Default `"Pros"`; Russian posters pass `"Плюсы"` or `"Хвалят"`. |
| `cons_title` | no | Default `"Cons"`. |
| `footer` | no | One muted line under both panels (for example an average-rating note). |

~~~json
{"type": "pros_cons", "pros_title": "Хвалят", "cons_title": "Ругают",
 "pros": ["Быстрая доставка", "Удобное приложение"], "cons": ["Долгая поддержка"],
 "footer": "Средняя оценка: 4,5 из 5"}
~~~

### sources

Required footer with data provenance.

| Field | Req | Notes |
|---|---|---|
| `text` | one of | A single paragraph. |
| `items` | one of | A list of source lines; renders as bullets. |
| `title` | no | Default `"Sources"`. |
| `fontsize` | no | Default small muted size. |

~~~json
{"type": "sources", "title": "Источники", "items": ["Данные сервиса - вымышленные, пример для демонстрации движка", "Все совпадения случайны"]}
~~~

### image

| Field | Req | Notes |
|---|---|---|
| `path` | yes | PNG/JPEG; absolute, or relative to the spec file folder. |
| `width` | no | Rendered width px; default = content width. |
| `height` | no | Fixed height; omitted keeps the aspect ratio. |
| `caption` | no | Small centered caption under the image. |
| `align` | no | `"center"` (default), `"left"`, `"right"`. |
| `border` | no | Thin frame around the image, default `false`. |

~~~json
{"type": "image", "path": "chart.png", "width": 1200, "caption": "Динамика показателя"}
~~~

## 7. Glyph probe and vision QA

The render result always includes `missing_glyphs` - characters from the spec that the active font cannot draw. When it is non-empty:

- replace the characters (for example "->" instead of "→", "x" instead of "×"), or
- switch `font` to one that covers them (verify with a quick probe), or
- drop them if purely decorative.

Inline probe before rendering, when unsure:

~~~python
from matplotlib import font_manager, ft2font
f = ft2font.FT2Font(font_manager.findfont("DejaVu Sans"))
chars = "₽ ✓ ✗ № « » - ≤ ≥"
missing = [c for c in chars if not c.isspace() and not f.get_char_index(ord(c))]
print("missing:", missing)
~~~

Vision QA prompt (use with `analyze_image` after rendering; the model gets the PNG):

~~~text
You are a senior information designer reviewing a PNG infographic for production.
Report, as a numbered list, ONLY real defects with approximate locations:
1) overlapping or colliding elements; 2) clipped or cut-off text or graphics;
3) misaligned columns or uneven card sizes; 4) unreadable contrast;
5) text that overflows its panel; 6) empty or placeholder-looking areas.
If the layout is clean, answer exactly: OK. Do not suggest content changes.
~~~

Fix every confirmed defect in the spec or the engine, re-render, re-check. Repeat until the vision pass answers OK and `check_failures` is empty.

## 8. Examples

A complete spec (fictional bike-share service "ВелоГород"; the shipped file `examples/demo_spec.json`):

~~~json
{
  "name": "velogorod_demo",
  "canvas": {"width": 1800, "height": "auto", "dpi": 150},
  "theme": "default",
  "sections": [
    {"type": "header", "title": "ВелоГород: городской велопрокат", "subtitle": "Итоги 2025 года", "right": "Собрано 03.10.2026"},
    {"type": "kpi_row", "title": "Ключевые цифры", "items": [
      {"value": "128", "label": "станций в городе"},
      {"value": "3 400", "label": "велосипедов"},
      {"value": "1,2 млн", "label": "поездок за год"},
      {"value": "4,4 из 5", "label": "средняя оценка"}
    ]},
    {"type": "bullets", "title": "Факты", "items": [
      "Сервис запущен в 2019 году",
      "Средняя поездка длится 18 минут",
      "Электровелосипеды - 22% парка"
    ]},
    {"type": "metrics_table", "title": "Показатели года", "columns": ["Показатель", "2024", "2025"],
     "rows": [["Поездки, млн", "0,9", "1,2"], ["Активные пользователи, тыс.", "86", "104"], ["Доступность станций, %", "92", "97"]]},
    {"type": "bar_chart", "title": "Оценки сервиса", "max_value": 5, "value_suffix": " из 5", "decimal_separator": ",",
     "items": [{"label": "Удобство приложения", "value": 4.6}, {"label": "Состояние велосипедов", "value": 4.3}, {"label": "Цена", "value": 3.9}]},
    {"type": "pros_cons", "pros_title": "Хвалят", "cons_title": "Критикуют",
     "pros": ["Быстрая регистрация", "Много станций у метро", "Электровелосипеды"],
     "cons": ["Зимой сервис недоступен", "Редкие сбои оплаты"],
     "footer": "По отзывам в приложениях, октябрь 2026"},
    {"type": "sources", "title": "Источники", "items": [
      "Данные сервиса - вымышленные, пример для демонстрации движка",
      "Все совпадения случайны"
    ]}
  ]
}
~~~

Render it with the recipe from section 4; the shipped PNG is `examples/demo_infographic.png`.

## 9. Rules and limits

- Offline and self-contained: no network calls; the engine writes exactly one file - the PNG at `out_path`.
- Output is PNG only (no SVG/PDF); to print, place the PNG into a document at its natural size.
- Every number on the poster must carry a source in the `sources` section; the "collected on" date is mandatory.
- Bar-chart labels are single-line by design - keep them short; long text belongs in `bullets` or `paragraph`.
- KPI values auto-shrink to fit their card down to a readable floor; a value below the floor is reported in `check_failures` - shorten it instead of fighting the layout.
- With `canvas.height` set to a number, content past the bottom becomes a check failure, not a silent crop.
- Never edit the engine to accommodate one spec: fix the spec and keep the engine deterministic.

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| `check_failures` shows an overflow in px | Shorten the text, lower `fontsize`, widen `label_width`, or split the section. |
| `missing_glyphs` non-empty | Replace the characters (a hyphen instead of a long dash, `x` instead of the multiplication sign) or set a `font` that covers them (section 7). |
| Table columns feel cramped | Trim cell text or pass `widths`; the default split is equal. |
| The poster looks too dense | Increase `gap` (globally or per section) and/or `margin`. |
| A fixed-height canvas clips content | Set `canvas.height` back to the string `auto`. |
| An `image` section is skipped | Check `warnings`: the path was not found (relative paths resolve against the spec file folder). |
| The vision pass finds overlaps | Increase `gap` around the section, shorten labels or reduce the number of cards. |

Before delivery, confirm: `check_failures` is empty; no `missing_glyphs`; the vision pass answered OK; sources and the collect date are present; the scratch copy is removed (section 3.6).