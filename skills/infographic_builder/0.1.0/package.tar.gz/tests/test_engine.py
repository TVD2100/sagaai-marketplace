"""Unit tests for the infographic engine and its CLI."""

from __future__ import annotations

import json
import os
import subprocess
import sys

import pytest

from infographic import RenderError, SpecError, load_spec, render
from infographic.textkit import fmt_number
from infographic.theme import THEMES, font_path, missing_glyphs, resolve_palette

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _min_spec(**over):
    spec = {
        "name": "unit",
        "canvas": {"width": 600, "dpi": 100},
        "sections": [{"type": "paragraph", "text": "Тестовый абзац."}],
    }
    spec.update(over)
    return spec


def test_fmt_number_auto_and_separator():
    assert fmt_number(4.6) == "4.6"
    assert fmt_number(5.0) == "5"
    assert fmt_number(4.5, decimals=2) == "4.50"
    assert fmt_number(4.6, separator=",") == "4,6"
    assert fmt_number("abc") == "abc"


def test_load_spec_defaults_and_normalization():
    data = load_spec({"sections": [{"type": "paragraph", "text": "x"}]})
    assert data["canvas"] == {"width": 1800.0, "height": "auto", "dpi": 150.0}
    assert data["margin"] == 80.0 and data["gap"] == 34.0
    assert data["font"] == "DejaVu Sans"
    assert data["name"] == "infographic"


@pytest.mark.parametrize("bad, fragment", [
    ({"sections": []}, "non-empty sections"),
    ({"sections": [{"type": "nope"}]}, "unknown type"),
    ({"sections": [{"type": "kpi_row", "items": [{"value": "1"}]}]},
     "value and label"),
    ({"sections": [{"type": "metrics_table", "rows": [["a", "b"], ["c"]]}]},
     "different column"),
    ({"sections": [{"type": "bar_chart", "items": [{"label": "a", "value": "abc"}]}]},
     "not a number"),
    ({"sections": [{"type": "sources"}]}, "text or items"),
    ({"sections": [{"type": "paragraph", "text": "x"}], "canvas": {"dpi": 10}},
     "dpi"),
])
def test_load_spec_rejects_invalid(bad, fragment):
    with pytest.raises(SpecError) as exc:
        load_spec(bad)
    assert fragment in str(exc.value)


def test_load_spec_file_and_json_string(tmp_path):
    sp = tmp_path / "s.json"
    sp.write_text(json.dumps(_min_spec()), encoding="utf-8")
    assert load_spec(str(sp))["name"] == "unit"
    assert load_spec(json.dumps(_min_spec()))["name"] == "unit"
    with pytest.raises(SpecError):
        load_spec(str(tmp_path / "missing.json"))


def test_palettes_and_overrides():
    pal = resolve_palette(None)
    assert set(THEMES["default"]) <= set(pal)
    assert resolve_palette("blue")["accent"] == THEMES["blue"]["accent"]
    custom = resolve_palette({"base": "mono", "accent": "#FF0000"})
    assert custom["accent"] == "#FF0000"
    assert custom["bg"] == THEMES["mono"]["bg"]
    with pytest.raises(ValueError):
        resolve_palette("neon")


def test_missing_glyphs_probe():
    fp = font_path("DejaVu Sans")
    assert missing_glyphs(fp, "\u2022 \u2713 \u2717 \u2116 \u00ab \u00bb \u2014 я") == []
    assert "\U0001F984" in missing_glyphs(fp, "unicorn \U0001F984")


def _all_sections_spec(tmp_path):
    from PIL import Image

    img = tmp_path / "pic.png"
    Image.new("RGB", (300, 150), (200, 30, 30)).save(img)
    return {
        "name": "all",
        "canvas": {"width": 1200, "dpi": 100},
        "sections": [
            {"type": "header", "title": "Заголовок", "subtitle": "Подзаголовок",
             "right": "01.01.2027"},
            {"type": "kpi_row", "items": [{"value": "1", "label": "один"},
                                            {"value": "2", "label": "два"}]},
            {"type": "bullets", "items": ["пункт один", "пункт два"], "numbered": True},
            {"type": "paragraph", "text": "Абзац текста."},
            {"type": "spacer", "height": 12},
            {"type": "metrics_table", "columns": ["A", "B"], "rows": [["1", "2"]]},
            {"type": "bar_chart", "max_value": 5,
             "items": [{"label": "x", "value": 4.5}]},
            {"type": "pros_cons", "pros": ["плюс"], "cons": ["минус"],
             "footer": "сноска"},
            {"type": "image", "path": str(img), "width": 300, "caption": "картинка"},
            {"type": "sources", "items": ["источник"]},
        ],
    }


def test_render_all_sections_clean(tmp_path):
    out = tmp_path / "all.png"
    res = render(_all_sections_spec(tmp_path), out_path=str(out))
    assert res["ok"] and out.is_file()
    assert res["check_failures"] == []
    assert res["missing_glyphs"] == []
    assert res["warnings"] == []
    assert res["size_px"][0] == 1200
    assert out.stat().st_size > 10_000


def test_render_image_missing_warns(tmp_path):
    spec = _min_spec(sections=[{"type": "image", "path": "nope.png"}])
    res = render(spec, out_path=str(tmp_path / "n.png"))
    assert any("not found" in w for w in res["warnings"])
    assert res["check_failures"] == []


def test_fixed_height_clip_detected_and_strict(tmp_path):
    spec = _min_spec(canvas={"width": 600, "dpi": 100, "height": 220},
                     sections=[{"type": "paragraph", "text": "Слово " * 400}])
    res = render(spec, out_path=str(tmp_path / "clip.png"))
    assert any("content needs" in f for f in res["check_failures"])
    with pytest.raises(RenderError):
        render(spec, out_path=str(tmp_path / "clip2.png"), strict=True)


def test_bar_chart_clamp_warns(tmp_path):
    spec = _min_spec(canvas={"width": 900, "dpi": 100}, sections=[{
        "type": "bar_chart", "max_value": 5, "sort": "desc",
        "items": [{"label": "b", "value": 3}, {"label": "a", "value": 9}],
    }])
    res = render(spec, out_path=str(tmp_path / "bars.png"))
    assert any("clamped" in w for w in res["warnings"])
    assert res["check_failures"] == []


def test_kpi_oversized_value_reported(tmp_path):
    spec = _min_spec(canvas={"width": 600, "dpi": 100}, sections=[{
        "type": "kpi_row", "items": [{"value": "X" * 80, "label": "ярлык"}]}])
    res = render(spec, out_path=str(tmp_path / "kpi.png"))
    assert any("does not fit" in f for f in res["check_failures"])


def test_theme_override_via_json_string(tmp_path):
    spec = json.dumps({
        "name": "t", "theme": {"base": "blue", "accent": "#FF0000"},
        "canvas": {"width": 600, "dpi": 100},
        "sections": [{"type": "paragraph", "text": "x"}],
    })
    res = render(spec, out_path=str(tmp_path / "t.png"))
    assert res["check_failures"] == []


def test_cli_exit_codes(tmp_path):
    good = tmp_path / "good.json"
    good.write_text(json.dumps(_min_spec()), encoding="utf-8")
    bad = tmp_path / "bad.json"
    bad.write_text('{"sections": [{"type": "nope"}]}', encoding="utf-8")
    clip = tmp_path / "clip.json"
    clip.write_text(json.dumps(_min_spec(
        canvas={"width": 600, "dpi": 100, "height": 220},
        sections=[{"type": "paragraph", "text": "Слово " * 400}])), encoding="utf-8")
    cli = os.path.join(ROOT, "build_infographic.py")
    r0 = subprocess.run([sys.executable, cli, str(good), str(tmp_path / "g.png")],
                        capture_output=True, text=True, timeout=180)
    assert r0.returncode == 0, r0.stderr
    report = json.loads(r0.stdout)
    assert report["ok"] is True
    r2 = subprocess.run([sys.executable, cli, str(bad), str(tmp_path / "b.png")],
                        capture_output=True, text=True, timeout=180)
    assert r2.returncode == 2
    r1 = subprocess.run([sys.executable, cli, str(clip), str(tmp_path / "c.png")],
                        capture_output=True, text=True, timeout=180)
    assert r1.returncode == 1
