"""User-scenario tests for the Infographic Builder (given-when-then).

Scenarios walked through the public entry points (CLI and the render()
API):

1. Happy path: a designer renders a complete poster file via the CLI.
2. Workflow edge: a too-small fixed canvas is flagged with clear fix advice;
   switching to auto height produces a clean poster.
3. Customization: switching the theme to blue actually changes the pixels.
4. Error path: broken spec files exit with code 2 and a readable message.
5. Graceful degradation: a referenced image that no longer exists becomes a
   warning instead of a crash.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys

from PIL import Image

from infographic import render
from infographic.theme import THEMES

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CLI = os.path.join(ROOT, "build_infographic.py")


def _is_bg(pixel):
    """True for the near-white background color of the default theme."""
    return pixel[0] > 250 and pixel[1] > 250 and pixel[2] > 250


def _rgb(hex_color):
    """Convert '#RRGGBB' into an (R, G, B) tuple."""
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _write(spec, path):
    """Dump a spec dict to a JSON file and return the path as a string."""
    path = str(path)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(spec, fh, ensure_ascii=False)
    return path


def _run_cli(spec_path, out_path):
    """Run the CLI like a user would and capture its report."""
    return subprocess.run(
        [sys.executable, CLI, str(spec_path), str(out_path)],
        capture_output=True, text=True, timeout=180)


def _full_poster(tmp_path):
    """A complete poster spec covering all ten section types."""
    pic = tmp_path / "logo.png"
    Image.new("RGB", (300, 150), (30, 60, 200)).save(str(pic))
    return {
        "name": "scenario_poster",
        "canvas": {"width": 1800, "dpi": 150},
        "sections": [
            {"type": "header", "title": "Городской велопрокат: итоги",
             "subtitle": "Сценарий полного постера", "right": "03.10.2026"},
            {"type": "kpi_row", "items": [
                {"value": "128", "label": "станций"},
                {"value": "1,2 млн", "label": "поездок"},
                {"value": "4,4", "label": "оценка", "note": "из 5"}]},
            {"type": "bullets", "title": "Факты", "numbered": True,
             "items": ["Запуск в 2019 году", "18 минут - средняя поездка"]},
            {"type": "paragraph", "text": "Короткий поясняющий абзац."},
            {"type": "spacer", "height": 16},
            {"type": "metrics_table", "columns": ["Показатель", "2024", "2025"],
             "rows": [["Поездки, млн", "0,9", "1,2"]]},
            {"type": "bar_chart", "title": "Оценки", "max_value": 5,
             "value_suffix": " из 5", "decimal_separator": ",", "sort": "desc",
             "items": [{"label": "Цена", "value": 3.9},
                       {"label": "Удобство", "value": 4.6}]},
            {"type": "pros_cons", "pros": ["Быстро"], "cons": ["Зимой закрыт"],
             "footer": "Из отзывов"},
            {"type": "image", "path": str(pic), "width": 360,
             "caption": "Логотип"},
            {"type": "sources", "items": ["Вымышленные данные примера"]},
        ],
    }


def test_scenario_full_poster_via_cli(tmp_path):
    # Given a designer with a complete spec file,
    # when they render it through the CLI,
    # then the poster is a valid PNG with no check failures.
    spec = _write(_full_poster(tmp_path), tmp_path / "poster.json")
    out = tmp_path / "poster.png"
    r = _run_cli(spec, out)
    assert r.returncode == 0, r.stderr + r.stdout
    report = json.loads(r.stdout)
    assert report["check_failures"] == []
    assert report["missing_glyphs"] == []
    assert report["warnings"] == []
    im = Image.open(out).convert("RGB")
    im.load()
    assert im.size[0] == 1800 and im.size[1] > 1000
    px = im.load()
    nonbg = sum(1 for y in range(0, im.size[1], 9)
                for x in range(0, im.size[0], 9) if not _is_bg(px[x, y]))
    assert nonbg > 1500


def test_scenario_fixed_height_diagnosed_then_auto_fixed(tmp_path):
    # Given a spec whose fixed canvas is too short,
    # when the designer renders it,
    # then the CLI reports the needed height (exit 1); after switching the
    # canvas to auto height the same spec renders cleanly (exit 0).
    spec = _full_poster(tmp_path)
    spec["canvas"]["height"] = 500
    r1 = _run_cli(_write(spec, tmp_path / "clip.json"), tmp_path / "clip.png")
    assert r1.returncode == 1
    failures = json.loads(r1.stdout)["check_failures"]
    assert any("content needs" in f for f in failures)
    spec["canvas"]["height"] = "auto"
    r2 = _run_cli(_write(spec, tmp_path / "auto.json"), tmp_path / "auto.png")
    assert r2.returncode == 0, r2.stderr + r2.stdout
    assert json.loads(r2.stdout)["check_failures"] == []


def test_scenario_theme_switch_changes_pixels(tmp_path):
    # Given two specs that differ only in theme,
    # when both render,
    # then the blue accent color appears in the blue poster and never in the
    # default one.
    accent = _rgb(THEMES["blue"]["accent"])
    spec = {
        "name": "theme", "canvas": {"width": 1000, "dpi": 100},
        "sections": [
            {"type": "bar_chart", "max_value": 5,
             "items": [{"label": "a", "value": 4},
                       {"label": "b", "value": 2}]},
            {"type": "kpi_row", "items": [{"value": "42", "label": "ответ"}]}],
    }
    out = tmp_path / "blue.png"
    res = render(dict(spec, theme="blue"), out_path=str(out))
    assert res["check_failures"] == []
    im = Image.open(out).convert("RGB")
    px = im.load()
    hits = sum(1 for y in range(0, im.size[1], 2)
               for x in range(0, im.size[0], 2)
               if all(abs(px[x, y][i] - accent[i]) <= 40 for i in range(3)))
    assert hits > 100

    out2 = tmp_path / "default.png"
    res2 = render(spec, out_path=str(out2))
    assert res2["check_failures"] == []
    im2 = Image.open(out2).convert("RGB")
    px2 = im2.load()
    hits2 = sum(1 for y in range(0, im2.size[1], 2)
                for x in range(0, im2.size[0], 2)
                if all(abs(px2[x, y][i] - accent[i]) <= 15 for i in range(3)))
    assert hits2 == 0


def test_scenario_broken_specs_get_readable_errors(tmp_path):
    # Given malformed or semantically wrong spec files,
    # when they are rendered via the CLI,
    # then each exits with code 2 and an error message naming the problem.
    bad_json = tmp_path / "bad.json"
    bad_json.write_text("{oops", encoding="utf-8")
    r1 = _run_cli(bad_json, tmp_path / "b1.png")
    assert r1.returncode == 2
    assert "ERROR" in r1.stderr

    r2 = _run_cli(_write({"sections": [{"type": "donut_chart"}]},
                         tmp_path / "type.json"), tmp_path / "b2.png")
    assert r2.returncode == 2
    assert "donut_chart" in r2.stderr
    assert "section 0" in r2.stderr

    r3 = _run_cli(_write({"sections": [{"type": "metrics_table",
                                        "rows": [["a", "b"], ["c"]]}]},
                         tmp_path / "row.json"), tmp_path / "b3.png")
    assert r3.returncode == 2
    assert "different column" in r3.stderr


def test_scenario_missing_image_degrades_to_warning(tmp_path):
    # Given a spec that references a picture which no longer exists,
    # when the poster renders,
    # then the render succeeds and the missing file is reported as a warning.
    spec = {
        "name": "noimg", "canvas": {"width": 900, "dpi": 100},
        "sections": [
            {"type": "paragraph", "text": "Текст без картинки."},
            {"type": "image", "path": "missing_logo.png", "width": 400}],
    }
    out = tmp_path / "noimg.png"
    res = render(spec, out_path=str(out))
    assert res["ok"] and os.path.isfile(out)
    assert res["check_failures"] == []
    assert any("not found" in w for w in res["warnings"])
    im = Image.open(out)
    im.load()
    assert im.format == "PNG"
