"""QA validator for lecture decks (skill entry - see SKILL.md, QA contract).

``check_deck(spec, result)`` inspects the spec and the layout records
produced by ``lecture.deck.build_deck`` and returns a report dict::

    {'ok': bool, 'errors': [str], 'warnings': [str], 'slides': int,
     'note_words': int, 'duration_est_min': float, 'duration_target_min': int,
     'theme': str, 'settings': {...}, 'slide_rows': [...], 'summary': str,
     'status': str, 'caveats': [str]}

Errors (make the report fail): missing or too-short speaker notes; empty
slides; content that failed to render (formula/image error boxes); build
errors collected by ``build_deck``; text overflow beyond the recorded box
(slack: ``max(0.03 in, 8% of the box)`` - the recorder computes needs with
line-spacing factors, so a small slack avoids false positives); boxes
outside the safe margins; code listings longer than ``max_code_lines``;
body font below ``min_body_pt``; the speaking-time estimate deviating
from ``meta.duration_min`` beyond ``qa.duration_tolerance`` in either
direction (``qa.check_duration``); overlapping content shapes (more than
``overlap_frac`` of the smaller box, ``qa.check_overlaps``).

Warnings (review; fail only when ``strict``): too-long notes; more than
``max_bullets`` list items; tight margins (closer than ``min_margin_in``);
deep empty strips below the content (``qa.check_void``,
``qa.max_void_in``); hyphens used as em dashes in the visible text
(``qa.check_dashes``; ``meta.normalize_dashes`` rewrites them);
sparse content slides and empty columns (``qa.check_density``); long
uniform item lists better shown as a table or cards (``qa.check_lists``: at
least ``min_list_items`` items of at most four words each); standalone
formulas with several variables and no explanatory caption
(``qa.check_formula_caption``); figures without a source and sources slides
without hyperlinks (only when ``meta.sources`` is non-empty,
``qa.check_source_refs``: percentages, grouped and long numbers need
``source_refs`` or a link on the slide); low text contrast (WCAG < 4.5) in
the theme
palette; characters the
resolved fonts cannot draw (only with ``qa.check_glyphs``: per-family
summary from the build result); spec/build warnings collected earlier.

The pass runs three named stages (see ``lecture.stages``): content
(the spec text), file (the saved pptx package) and visual (rendered pages
supplied via ``pages=``). Their findings merge into ``errors``/``warnings``
with ``[content]``/``[file]``/``[visual]`` prefixes and are summarised in
``report['stages']``; a stage without its input reports itself as skipped,
never as a silent PASS.

``report_markdown(report, spec)`` renders the ``<stem>_service/qa.md`` companion.
The module CLI rebuilds the deck in memory from a spec and applies the same
checks; exit codes: 0 - clean, 1 - errors found, 2 - spec or build failure.
"""

from __future__ import annotations

import argparse
import json
import re
import tempfile
from pathlib import Path

from lecture import baseline, fingerprint, imgqa, stages, textfit, themes
from lecture import apa
from lecture.deck import build_deck
from lecture.spec import (SpecError, is_safe_link, load_spec, split_markup,
                          strip_markup)

DEFAULTS = {
    'min_note_words': 12,
    'max_note_words': 260,
    'max_bullets': 6,
    'max_code_lines': 22,
    'min_body_pt': 16.0,
    'min_margin_in': 0.45,
    'check_images': True,
    'min_image_px': 200,
    'check_glyphs': False,
    'check_density': True,
    'min_slide_words': 20,
    'min_column_words': 3,
    'min_fill': 0.15,
    'check_lists': True,
    'min_list_items': 5,
    'check_overlaps': True,
    'overlap_frac': 0.25,
    'check_formula_caption': True,
    'check_source_refs': True,
    'check_apa': True,
    'check_duration': True,
    'duration_tolerance': 0.35,
    'check_void': True,
    'max_void_in': 1.2,
    'check_dashes': True,
    'check_layout_advice': True,
    'strict': False,
}

CONTRAST_MIN = 4.5
CONTRAST_PAIRS = (
    ('ink', 'bg'), ('muted', 'bg'), ('ink', 'card'), ('muted', 'card'),
    ('cover_ink', 'cover_bg'), ('cover_accent', 'cover_bg'),
)
EXEMPT_MARGIN_KINDS = ('cover', 'section')
FONT_CHECK_KINDS = ('text',)

# Content-completeness checks (see SKILL.md, QA contract).
LAYOUT_TYPES = ('cards', 'timeline', 'process', 'compare')
VISUAL_KINDS = ('image', 'table', 'formula', 'code', 'chart')
CONTAINER_KINDS = ('card',)
OVERLAP_EXEMPT_KINDS = ('cover', 'section', 'header', 'slot_marker')
LIST_CHECK_TYPES = ('bullets',)
LIST_ITEM_MAX_WORDS = 4

# Frame-fill density metric: the share of the slide area covered by
# the content boxes replaces the 'has a visual' bypass; airy layouts keep
# an explicit exemption with a recorded reason instead of a silent PASS.
DENSITY_SKIP_KINDS = ('slot_marker',)
DENSITY_EXEMPT_REASONS = {
    'title': 'the cover is airy by design',
    'section': 'a section divider is airy by design',
    'cards': 'card grids keep their own spacing by design',
    'timeline': 'a timeline spine is airy by design',
    'process': 'a process spine is airy by design',
    'compare': 'two labelled panels breathe by design',
}

# Empty-bottom metric: distance between the lowest drawn content and
# the bottom of the content frame. Airy-by-design types keep an exemption
# with a recorded reason instead of a silent PASS.
VOID_SKIP_KINDS = ('slot_marker',)
VOID_EXEMPT_REASONS = {
    'title': 'the cover is airy by design',
    'section': 'a section divider is airy by design',
    'formula': 'a centered display formula is airy by design',
    'timeline': 'a timeline spine is airy by design',
}

# Layout advice: a short parallel bullet list leaves the lower part
# of the body frame empty; the advisor points at a visual slide type instead.
# The check is a WARNING (never an error): ``meta.auto_layout`` can rewrite
# such slides automatically, and an author may keep the list on purpose.
LAYOUT_ADVICE_TYPE = 'bullets'

# Typography: a hyphen between two Cyrillic letters reads as a dash.
DASH_RE = re.compile(r'(?<=[\u0410-\u044f\u0401\u0451]) - (?=[\u0410-\u044f\u0401\u0451])')

# Fact-checking (C1; see SKILL.md, 'Sources and fact-checking'): a deck
# with a non-empty ``meta.sources`` registry must back its figure facts
# (percentages, grouped or long numbers) with ``source_refs`` or a link,
# and its sources slide must carry at least one hyperlink.
FACT_EXEMPT_TYPES = ('title', 'section', 'formula', 'code', 'homework', 'literature')
FACT_PERCENT_RE = re.compile(r'\d+(?:[.,]\d+)?\s*%')
FACT_GROUP_RE = re.compile(r'\d{1,3}(?:[ \u00a0]\d{3})+')
FACT_BIG_RE = re.compile(r'(?<![\d.,])(\d{4,})(?![\d.,])')
FACT_YEAR_RANGE = (1500, 2100)
FACT_MAX_SHOWN = 4


def _settings(spec):
    """Resolve QA settings: defaults overridden by the spec's ``qa`` object."""
    settings = dict(DEFAULTS)
    raw = getattr(spec, 'qa', None) or {}
    for key, default in DEFAULTS.items():
        if key not in raw:
            continue
        value = raw.get(key)
        try:
            if key == 'check_duration':
                settings[key] = _duration_mode(value)
            elif key in ('strict', 'check_images', 'check_glyphs', 'check_density',
                         'check_lists', 'check_overlaps', 'check_formula_caption',
                         'check_source_refs', 'check_apa', 'check_void', 'check_dashes',
                         'check_layout_advice'):
                settings[key] = bool(value)
            elif key in ('min_body_pt', 'min_margin_in', 'overlap_frac',
                         'duration_tolerance', 'min_fill', 'max_void_in'):
                settings[key] = float(value)
            else:
                settings[key] = int(value)
        except (TypeError, ValueError):
            settings[key] = default
    return settings


def _duration_mode(value):
    """Resolve ``qa.check_duration`` into an error/warn/off mode.

    Accepts the modern string modes (``'error'`` / ``'warn'`` / ``'off'``)
    and the legacy booleans (``True`` -> error, ``False`` -> off). Any other
    value falls back to the strict error mode.
    """
    if isinstance(value, bool):
        return value
    text = str(value or '').strip().lower()
    if text in ('error', 'warn', 'off'):
        return text
    return True


def _glyph_warnings(missing):
    """Warning lines for characters the resolved fonts cannot draw (A5)."""
    if not isinstance(missing, dict) or not missing:
        return []
    lines = []
    for family in sorted(missing):
        chars = list(missing.get(family) or [])
        if not chars:
            continue
        shown = ' '.join(chars[:12])
        more = ' (+%d more)' % (len(chars) - 12) if len(chars) > 12 else ''
        lines.append("font '%s' cannot draw %d character(s): %s%s; PowerPoint substitutes them"
                     % (family, len(chars), shown, more))
    return lines


def _metrics_warnings(metrics):
    """Warning when the text-fit check is only approximate.

    Roles whose local TTF differs from the face PowerPoint renders (DejaVu
    fallbacks, unknown files) get the larger safety margin, but a margin is
    still a guess: the report must say the overflow verdict is approximate
    there instead of passing silently.
    """
    approximate = []
    for role in sorted(metrics or {}):
        info = metrics.get(role) or {}
        status = str(info.get('status') or '')
        if status not in ('no', 'unknown'):
            continue
        face = str(info.get('face') or textfit.ROLE_FACES.get(role, role))
        font = Path(str(info.get('font') or '')).name or 'not resolved'
        approximate.append('%s (%s, %s)' % (face, font, status))
    if not approximate:
        return []
    return [('text-fit check is approximate for fonts: %s; overflow errors '
             'are less reliable there - install the theme fonts or verify '
             'these slides manually') % '; '.join(approximate)]


def _baseline_comparison(spec, result):
    """Compare the new deck against ``meta.baseline``.

    Returns ``(report_or_None, warnings)``: headings present in the baseline
    deck but lost in the new one become QA warnings (errors under ``strict``).
    A missing baseline file or an unsaved candidate yields a note inside the
    comparison dict instead of a hard failure.
    """
    ref = (getattr(spec, 'meta', None) or {}).get('baseline')
    if not ref:
        return None, []
    base_dir = Path(getattr(spec, 'base_dir', None) or '.')
    baseline_path = Path(str(ref))
    if not baseline_path.is_absolute():
        baseline_path = base_dir / baseline_path
    placeholder = {
        'ok': True, 'baseline_slides': 0, 'candidate_slides': 0,
        'missing': [], 'added': [], 'warnings': [],
        'baseline_path': str(baseline_path),
    }
    if not baseline_path.exists():
        message = ('baseline deck not found: %s (meta.baseline); '
                   'comparison skipped' % ref)
        placeholder['warnings'] = [message]
        return placeholder, [message]
    candidate = result.get('out_path')
    if not candidate or not Path(candidate).exists():
        placeholder['warnings'] = ['baseline comparison skipped: the candidate '
                                   'deck was not saved to disk']
        return placeholder, []
    try:
        comparison = baseline.compare_decks(baseline_path, candidate)
    except Exception as exc:  # noqa: BLE001 - a broken baseline must not kill QA
        message = 'baseline comparison failed: %s: %s' % (type(exc).__name__, exc)
        placeholder['warnings'] = [message]
        return placeholder, [message]
    messages = []
    for title in comparison['missing']:
        messages.append("baseline deck: heading '%s' is missing in the new "
                        'deck; restore the slide or update meta.baseline' % title)
    return comparison, messages


def _as_list(value):
    """Normalize a spec field into a list without importing the spec module."""
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def _word_count(value):
    """Count words with letters/digits in a spec text value."""
    if value is None:
        return 0
    if isinstance(value, dict):
        value = value.get('text') or value.get('title') or ''
    return len([token for token in strip_markup(str(value)).split()
                if any(ch.isalnum() for ch in token)])


def _block_words(block):
    """Words contributed by a two_column/compare block (visuals count zero)."""
    if not isinstance(block, dict):
        return 0
    if block.get('kind') in ('image', 'table', 'formula', 'code'):
        return 0
    total = 0
    for item in _as_list(block.get('items')):
        total += _word_count(item)
    total += _word_count(block.get('text'))
    return total


def _slide_words(slide):
    """Total words of a slide's text fields (density heuristic)."""
    if not isinstance(slide, dict):
        return 0
    total = 0
    for item in _as_list(slide.get('items')):
        total += _word_count(item)
    for key in ('text', 'statement', 'paragraphs', 'steps'):
        for fragment in _as_list(slide.get(key)):
            total += _word_count(fragment)
    for key in ('term', 'caption', 'verdict'):
        total += _word_count(slide.get(key))
    for side in ('left', 'right'):
        total += _block_words(slide.get(side))
    return total


def _frame_fill(rec):
    """Share of the slide frame covered by the record's content boxes.

    Text boxes contribute their needed height where it is recorded (a
    formula box reserves a tall frame for a short formula), grid markers
    (``slot_marker``) are decoration and contribute nothing. Returns
    ``None`` when the record carries no usable geometry; the value is
    clamped to 1.0 because overlapping card-and-text boxes may
    double-count.
    """
    area = 0.0
    used = 0
    for box in rec.get('boxes') or []:
        if box.get('kind') in DENSITY_SKIP_KINDS:
            continue
        try:
            w = max(0.0, float(box.get('w') or 0.0))
            h = max(0.0, float(box.get('h') or 0.0))
            need = box.get('need_h')
            if need is not None:
                h = min(h, max(0.0, float(need)))
        except (TypeError, ValueError):
            continue
        area += w * h
        used += 1
    if not used:
        return None
    return min(1.0, area / (themes.SLIDE_W * themes.SLIDE_H))


def _void_in(rec):
    """Empty space (inches) between the drawn content and the frame bottom.

    Uses the recorded ``content_bottom`` of the non-decoration boxes (the
    bottom of the content actually drawn, not of the frame); falls back to
    ``y + need_h`` where ``content_bottom`` is absent. Returns ``None``
    when the record carries no usable geometry.
    """
    bottoms = []
    for box in rec.get('boxes') or []:
        if box.get('kind') in VOID_SKIP_KINDS:
            continue
        bottom = box.get('content_bottom')
        if bottom is None:
            need = box.get('need_h')
            if need is None:
                continue
            bottom = float(box.get('y') or 0.0) + float(need)
        bottoms.append(float(bottom))
    if not bottoms:
        return None
    body_bottom = themes.SLIDE_H - themes.MARGIN_BOTTOM
    return body_bottom - max(bottoms)


def _dash_count(slide):
    """Prose hyphens (to be em dashes) in a slide's visible text."""
    if not isinstance(slide, dict):
        return 0
    return sum(len(DASH_RE.findall(text)) for text in _slide_texts(slide))


def _dash_warnings(slides, records):
    """Warnings for hyphens used as em dashes in the visible text."""
    warnings = []
    for rec in records:
        if rec.get('empty'):
            continue
        slide = _aligned_slide(slides, rec)
        if slide is None:
            continue
        count = _dash_count(slide)
        if not count:
            continue
        where = 'slide %s (%s)' % (rec.get('index'), rec.get('type'))
        warnings.append('%s: %d hyphen used as a dash; use an em dash instead, '
                        'or enable meta.normalize_dashes to rewrite the '
                        'visible text' % (where, count))
    return warnings


def _layout_warnings(spec, records):
    """Warnings for short bullet lists that should become a visual type."""
    from lecture.layout_advisor import suggest_layout

    warnings = []
    slides = list(getattr(spec, 'slides', None) or [])
    for rec in records:
        if rec.get('empty') or rec.get('type') != LAYOUT_ADVICE_TYPE:
            continue
        slide = _aligned_slide(slides, rec)
        if slide is None:
            continue
        advice = suggest_layout(slide)
        if not advice:
            continue
        where = 'slide %s (%s)' % (rec.get('index'), rec.get('type'))
        warnings.append("%s: %s; suggested type '%s'"
                        % (where, advice['reason'], advice['suggested_type']))
    return warnings


def _void_warnings(records, settings):
    """Warnings for content that leaves a deep empty strip below."""
    warnings = []
    threshold = float(settings.get('max_void_in') or 0.0)
    for rec in records:
        if rec.get('empty'):
            continue
        stype = rec.get('type')
        if stype in VOID_EXEMPT_REASONS:
            continue
        void = _void_in(rec)
        if void is None or void <= threshold + 1e-9:
            continue
        where = 'slide %s (%s)' % (rec.get('index'), stype)
        warnings.append('%s: %.2f in of empty space under the content '
                        '(max %.2f in); split the slide, enlarge the visual '
                        'or add content' % (where, void, threshold))
    return warnings


def _block_has_content(block, min_words=1):
    """True when a block draws at least ``min_words`` text words."""
    if not isinstance(block, dict):
        return False
    if block.get('kind') in ('bullets', 'paragraphs'):
        items = block.get('items')
        if isinstance(items, list):
            return sum(_word_count(item) for item in items) >= min_words
        return _word_count(block.get('text')) >= min_words
    return True


def _aligned_slide(slides, rec):
    """Spec slide matching a layout record (by index and type), or None."""
    index = rec.get('index')
    if not isinstance(index, int) or not 0 < index <= len(slides):
        return None
    slide = slides[index - 1]
    if isinstance(slide, dict) and slide.get('type') == rec.get('type'):
        return slide
    return None


_VARIABLE_PATTERNS = (
    r'(?<![A-Za-z])([A-Za-z])\s*[_^]',
    r'(?<![A-Za-z])([A-Za-z])\s*\(',
    r'(?<![A-Za-z])([A-Za-z])(?![A-Za-z])',
)


def _formula_variables(lines):
    """Best-effort set of variable letters used by a LaTeX formula."""
    text = ' '.join(str(line) for line in _as_list(lines))
    names = set()
    for pattern in _VARIABLE_PATTERNS:
        names.update(re.findall(pattern, text))
    return names


def _content_warnings(spec, records, settings):
    """Warnings for sparse slides, empty columns, flat lists, bare formulas."""
    warnings = []
    slides = list(getattr(spec, 'slides', None) or [])
    for rec in records:
        if rec.get('empty'):
            continue
        stype = rec.get('type')
        where = 'slide %s (%s)' % (rec.get('index'), stype)
        slide = _aligned_slide(slides, rec)
        if slide is None:
            continue
        if settings.get('check_density') and stype not in DENSITY_EXEMPT_REASONS:
            fill = _frame_fill(rec)
            if fill is None:
                # No recorded geometry (fabricated or pre- results): the
                # legacy word-count heuristic still applies.
                kinds = {box.get('kind') for box in rec.get('boxes') or []}
                has_visual = stype in LAYOUT_TYPES or bool(kinds.intersection(VISUAL_KINDS))
                words = _slide_words(slide)
                if not has_visual and words < int(settings['min_slide_words']):
                    warnings.append('%s: sparse content (no visual, %d words); '
                                    'add a figure/table/cards or expand the text'
                                    % (where, words))
            elif fill < float(settings['min_fill']) - 0.0005:
                warnings.append('%s: frame fill %.2f below the minimum %.2f; '
                                'split the slide, add content or enlarge the visual'
                                % (where, fill, settings['min_fill']))
        if settings.get('check_density') and stype in ('two_column', 'compare'):
            min_words = int(settings['min_column_words'])
            for side in ('left', 'right'):
                if not _block_has_content(slide.get(side), min_words):
                    warnings.append('%s: %s column appears empty' % (where, side))
        if settings.get('check_lists') and stype in LIST_CHECK_TYPES:
            items = slide.get('items') or []
            counts = [_word_count(item) for item in items]
            if (len(items) >= int(settings['min_list_items']) and counts
                    and all(0 < count <= LIST_ITEM_MAX_WORDS for count in counts)):
                warnings.append('%s: %d uniform short items read as a classification; '
                                'use a table or cards slide' % (where, len(items)))
        if settings.get('check_formula_caption') and stype == 'formula':
            names = _formula_variables(slide.get('formula'))
            caption = strip_markup(str(slide.get('caption') or '')).lower()
            if len(names) >= 2 and '\u0433\u0434\u0435' not in caption and 'where' not in caption:
                warnings.append("%s: formula variables (%s) are not explained; "
                                "add a '\u0433\u0434\u0435 ...' caption"
                                % (where, ', '.join(sorted(names))))
    return warnings


def _overlap_fraction(b1, b2):
    """Intersection area over the smaller box area (0 when disjoint)."""
    x1, y1 = float(b1.get('x') or 0.0), float(b1.get('y') or 0.0)
    x2, y2 = float(b2.get('x') or 0.0), float(b2.get('y') or 0.0)
    w1, h1 = float(b1.get('w') or 0.0), float(b1.get('h') or 0.0)
    w2, h2 = float(b2.get('w') or 0.0), float(b2.get('h') or 0.0)
    ox = max(0.0, min(x1 + w1, x2 + w2) - max(x1, x2))
    oy = max(0.0, min(y1 + h1, y2 + h2) - max(y1, y2))
    smaller = min(w1 * h1, w2 * h2)
    if ox <= 0.0 or oy <= 0.0 or smaller <= 0.0:
        return 0.0
    return (ox * oy) / smaller


def _visible_box(box):
    """Return ``{'x','y','w','h'}`` of the *visible* content of a layout box.

    A frame box records the whole frame while the text inside is centered or
    stretched, so comparing raw frames reports overlaps between two pieces of
    text that never touch (e.g. a short list and the homework deadline under
    it). When the box records ``content_bottom`` and ``need_h`` the visible
    region is ``[content_bottom - need_h, content_bottom]``; otherwise the
    frame itself is the best available estimate.
    """
    x = float(box.get('x') or 0.0)
    y = float(box.get('y') or 0.0)
    w = float(box.get('w') or 0.0)
    h = float(box.get('h') or 0.0)
    bottom = box.get('content_bottom')
    need = box.get('need_h')
    if bottom is not None and need is not None:
        bottom = float(bottom)
        top = bottom - float(need)
        if bottom > top:
            # Never claim a visible region larger than the frame itself.
            y = max(y, min(top, y + h))
            h = max(0.0, min(bottom, y + h) - y)
    return {'x': x, 'y': y, 'w': w, 'h': h}


def _overlap_errors(records, settings):
    """Errors for content shapes whose visible content overlaps too much (E2)."""
    errors = []
    threshold = float(settings.get('overlap_frac') or 0.25)
    for rec in records:
        boxes = []
        for box in rec.get('boxes') or []:
            kind = box.get('kind')
            if kind in OVERLAP_EXEMPT_KINDS or kind in CONTAINER_KINDS:
                continue
            if float(box.get('w') or 0.0) < 0.05 or float(box.get('h') or 0.0) < 0.05:
                continue
            visible = _visible_box(box)
            if visible['h'] < 0.05:
                continue
            visible['kind'] = kind
            boxes.append(visible)
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                frac = _overlap_fraction(boxes[i], boxes[j])
                if frac > threshold:
                    errors.append('%s: %s and %s shapes overlap (%.0f%% of the smaller '
                                  'box); move or resize them'
                                  % ('slide %s (%s)' % (rec.get('index'), rec.get('type')),
                                     boxes[i].get('kind'), boxes[j].get('kind'), frac * 100.0))
    return errors


def _item_texts(items):
    """Strings carried by a list of spec items (objects or plain strings)."""
    out = []
    for item in _as_list(items):
        if isinstance(item, dict):
            for key in ('text', 'title', 'label'):
                value = item.get(key)
                if value:
                    out.append(str(value))
        elif item is not None:
            out.append(str(item))
    return out


def _block_texts(block):
    """Strings drawn by a two_column/compare block (text, items, table)."""
    if not isinstance(block, dict):
        return []
    out = _item_texts(block.get('items'))
    if block.get('text'):
        out.append(str(block['text']))
    for row in _as_list(block.get('rows')):
        if isinstance(row, (list, tuple)):
            out.extend(str(cell) for cell in row if cell is not None)
    out.extend(str(cell) for cell in _as_list(block.get('columns')))
    return out


def _slide_texts(slide):
    """All text fragments drawn on one slide (fact-checking heuristics)."""
    if not isinstance(slide, dict):
        return []
    out = _item_texts(slide.get('items'))
    if slide.get('header'):
        out.append(str(slide['header']))
    for key in ('text', 'statement', 'paragraphs', 'steps'):
        out.extend(str(fragment) for fragment in _as_list(slide.get(key))
                   if fragment is not None)
    for key in ('term', 'caption', 'verdict', 'deadline'):
        if slide.get(key):
            out.append(str(slide[key]))
    for side in ('left', 'right'):
        out.extend(_block_texts(slide.get(side)))
    for row in _as_list(slide.get('rows')):
        if isinstance(row, (list, tuple)):
            out.extend(str(cell) for cell in row if cell is not None)
    out.extend(str(cell) for cell in _as_list(slide.get('columns')))
    return out


def _expand_references(spec, slide):
    """Slide with ``[@id]`` markers expanded, for reference heuristics.

    The QA pass reads the SPEC, while the deck is built from the expanded
    slide: a ``[@id]`` marker would otherwise look like plain text and a
    properly cited claim would be reported as unreferenced.
    """
    registry = list((getattr(spec, 'meta', None) or {}).get('sources') or [])
    if not registry or not isinstance(slide, dict):
        return slide
    lang = (getattr(spec, 'meta', None) or {}).get('lang') or 'ru'
    return apa.expand_slide(slide, registry, lang=lang)


def _slide_has_link(slide):
    """True when a slide carries a hyperlink target (item url or markup)."""
    if not isinstance(slide, dict):
        return False
    for item in _as_list(slide.get('items')):
        if isinstance(item, dict) and is_safe_link(item.get('url')):
            return True
    for text in _slide_texts(slide):
        if any(flags.get('url') for _, flags in split_markup(text)):
            return True
    return False


def _slide_figures(texts):
    """Unique figure-like numbers in slide texts (percent, grouped, long)."""
    found = []
    for text in texts:
        for pattern in (FACT_PERCENT_RE, FACT_GROUP_RE):
            for match in pattern.finditer(text):
                found.append(match.group(0).strip())
        for match in FACT_BIG_RE.finditer(text):
            year = int(match.group(1))
            if FACT_YEAR_RANGE[0] <= year <= FACT_YEAR_RANGE[1]:
                continue
            found.append(match.group(1))
    unique = []
    for value in found:
        if value not in unique:
            unique.append(value)
    return unique


def _fact_warnings(spec, records):
    """Warnings for figures without sources and link-less sources slides."""
    warnings = []
    registry = list((getattr(spec, 'meta', None) or {}).get('sources') or [])
    if not registry:
        return warnings
    by_id = {}
    for entry in registry:
        if isinstance(entry, dict) and entry.get('id'):
            by_id[entry['id']] = entry
    slides = list(getattr(spec, 'slides', None) or [])
    for rec in records:
        if rec.get('empty'):
            continue
        slide = _expand_references(spec, _aligned_slide(slides, rec))
        if slide is None:
            continue
        stype = rec.get('type')
        where = 'slide %s (%s)' % (rec.get('index'), stype)
        refs = list(slide.get('source_refs') or [])
        has_link = _slide_has_link(slide) or any(
            apa.has_apa_caption(text) for text in _slide_texts(slide))
        if stype not in FACT_EXEMPT_TYPES:
            figures = _slide_figures(_slide_texts(slide))
            if figures and not refs and not has_link:
                shown = ', '.join(figures[:FACT_MAX_SHOWN])
                more = (' (+%d more)' % (len(figures) - FACT_MAX_SHOWN)
                        if len(figures) > FACT_MAX_SHOWN else '')
                warnings.append('%s: figures (%s%s) without a source; '
                                'add source_refs or a link to the claim'
                                % (where, shown, more))
            if stype == 'chart' and not refs and not has_link:
                warnings.append('%s: chart data without a source; add '
                                'source_refs or a link' % where)
        if stype == 'literature' and refs:
            entries = [by_id.get(ref) for ref in refs]
            linkable = any(entry is not None and not apa.is_internal(entry)
                           for entry in entries)
            if linkable and not has_link:
                warnings.append('%s: sources slide has no hyperlinks; '
                                'add url to the referenced meta.sources entries' % where)
            for ref, entry in zip(refs, entries):
                if entry is None or apa.is_internal(entry):
                    continue
                if not entry.get('url') and not entry.get('doi'):
                    warnings.append("%s: source '%s' has no url; add one to "
                                    'make it clickable' % (where, ref))
    return warnings


def _apa_warnings(spec, records, include_figures=True):
    """Warnings for claims, quotes and cases without an APA reference (C2).

    The rule fires only when the deck carries a sources registry:
    without one there is nothing to cite, and legacy decks stay clean.
    A claim is a figure fact (a percentage, a grouped or a long number),
    a quoted fragment or a case marker. Each such slide must carry either
    ``source_refs`` or an APA in-text citation in the visible text.
    A source without authors and year is reported once, because the
    reference cannot be formatted as APA.
    """
    warnings = []
    registry = list((getattr(spec, 'meta', None) or {}).get('sources') or [])
    if not registry:
        return warnings
    slides = list(getattr(spec, 'slides', None) or [])
    for rec in records:
        if rec.get('empty'):
            continue
        slide = _expand_references(spec, _aligned_slide(slides, rec))
        if slide is None or rec.get('type') in FACT_EXEMPT_TYPES:
            continue
        where = 'slide %s (%s)' % (rec.get('index'), rec.get('type'))
        refs = list(slide.get('source_refs') or [])
        texts = _slide_texts(slide)
        has_caption = any(apa.has_apa_caption(text) for text in texts)
        if refs or has_caption:
            continue
        figures = _slide_figures(texts)
        quotes = []
        cases = []
        for text in texts:
            for quote in apa.find_quotes(text):
                if quote not in quotes:
                    quotes.append(quote)
            for case in apa.find_case_markers(text):
                if case not in cases:
                    cases.append(case)
        if figures and include_figures:
            shown = ', '.join(figures[:FACT_MAX_SHOWN])
            warnings.append('%s: figures (%s) without an APA reference; add '
                            'source_refs or a [@id] citation' % (where, shown))
        if quotes:
            warnings.append('%s: quote %s without an APA reference; add '
                            'source_refs or a [@id] citation'
                            % (where, quotes[0]))
        if cases:
            warnings.append('%s: case %s without an APA reference; add '
                            'source_refs or a [@id] citation'
                            % (where, cases[0]))
    for entry in registry:
        if not isinstance(entry, dict) or not entry.get('id'):
            continue
        if apa.has_apa_data(entry) or apa.is_internal(entry):
            continue
        warnings.append("source '%s' has no APA data (authors, year or apa); "
                        'the reference cannot be formatted as APA' % entry['id'])
    return warnings


def _slot_errors(spec, records):
    """Errors for template slot groups left without data.

    A layout slide may declare ``slots`` - the number of places its
    template has. The build removes empty slot groups entirely, so any
    recorded slot decoration outside the filled prefix is an orphaned
    graphic; a slide with declared slots must also carry slot bookkeeping.
    """
    errors = []
    slides = list(getattr(spec, 'slides', None) or [])
    for rec in records:
        where = 'slide %s (%s)' % (rec.get('index'), rec.get('type'))
        slide = _aligned_slide(slides, rec)
        declared = int((slide or {}).get('slots') or 0)
        book = rec.get('slots')
        if declared and not book:
            errors.append('%s: template declares %d slots but the build has '
                          'no slot bookkeeping; report filled and removed '
                          'slots' % (where, declared))
            continue
        if not book:
            continue
        filled = int(book.get('filled') or 0)
        for box in rec.get('boxes') or []:
            slot = box.get('slot')
            if slot is None:
                continue
            if int(slot) >= filled:
                errors.append('%s: orphaned slot decoration %d drawn while '
                              'only %d slots are filled; remove the empty '
                              'group' % (where, int(slot) + 1, filled))
    return errors


def check_deck(spec, result, strict=None, pages=None):
    """Validate a built deck from its spec and layout records."""
    settings = _settings(spec)
    if strict is not None:
        settings['strict'] = bool(strict)
    errors = []
    warnings = []
    records = list(result.get('records') or [])
    slides = list(getattr(spec, 'slides', None) or [])
    slide_rows = []

    for message in result.get('errors') or []:
        errors.append(str(message))

    for rec in records:
        index = rec.get('index')
        stype = rec.get('type')
        where = 'slide %s (%s)' % (index, stype)
        words = int(rec.get('note_words') or 0)
        bullets = int(rec.get('bullets') or 0)
        code_lines = int(rec.get('code_lines') or 0)

        if words < settings['min_note_words']:
            if words == 0:
                errors.append('%s: speaker notes missing' % where)
            else:
                errors.append('%s: speaker notes too short (%d words, min %d)'
                              % (where, words, settings['min_note_words']))
        if words > settings['max_note_words']:
            warnings.append('%s: speaker notes too long (%d words, max %d)'
                            % (where, words, settings['max_note_words']))
        if rec.get('empty'):
            errors.append('%s: no content drawn' % where)
        if bullets > settings['max_bullets']:
            warnings.append('%s: %d list items (max %d); split the slide'
                            % (where, bullets, settings['max_bullets']))
        if code_lines > settings['max_code_lines']:
            errors.append('%s: code listing has %d lines (max %d); split it'
                          % (where, code_lines, settings['max_code_lines']))

        for box in rec.get('boxes') or []:
            kind = box.get('kind')
            if box.get('error'):
                errors.append('%s: %s content failed to render' % (where, kind))
            need = box.get('need_h')
            if textfit.overflow(need, box.get('h')):
                errors.append('%s: %s overflows its box (need %.2f in, box %.2f in)'
                              % (where, kind, need, box.get('h')))
            font_pt = box.get('font_pt')
            if (kind in FONT_CHECK_KINDS and font_pt is not None
                    and float(font_pt) < settings['min_body_pt'] - 0.001):
                errors.append('%s: body font %.1f pt below the minimum %.1f pt'
                              % (where, font_pt, settings['min_body_pt']))
            if kind == 'image' and settings.get('check_images') and box.get('image'):
                findings = imgqa.inspect_image(box.get('image'),
                                               min_px=settings.get('min_image_px'))
                errors.extend('%s: %s' % (where, message) for message in findings['errors'])
                warnings.extend('%s: %s' % (where, message) for message in findings['warnings'])
            for problem in box.get('omml_problems') or []:
                warnings.append('%s: formula structure: %s' % (where, problem))
            if kind not in EXEMPT_MARGIN_KINDS:
                x = float(box.get('x') or 0.0)
                y = float(box.get('y') or 0.0)
                w = float(box.get('w') or 0.0)
                h = float(box.get('h') or 0.0)
                distances = (
                    ('left', x),
                    ('top', y),
                    ('right', themes.SLIDE_W - (x + w)),
                    ('bottom', themes.SLIDE_H - (y + h)),
                )
                for edge, dist in distances:
                    if dist < -0.02:
                        errors.append('%s: %s extends outside the safe margins (%s, %.2f in)'
                                      % (where, kind, edge, dist))
                    elif dist < settings['min_margin_in']:
                        warnings.append('%s: tight %s margin on %s (%.2f in, min %.2f in)'
                                        % (where, edge, kind, dist, settings['min_margin_in']))

        slide = _aligned_slide(slides, rec)
        slide_rows.append({
            'index': index, 'type': stype, 'note_words': words,
            'bullets': bullets, 'code_lines': code_lines,
            'fill': _frame_fill(rec),
            'density_exempt': DENSITY_EXEMPT_REASONS.get(stype),
            'void': _void_in(rec),
            'void_exempt': VOID_EXEMPT_REASONS.get(stype),
            'dashes': _dash_count(slide) if slide is not None else 0,
        })

    if (settings.get('check_density') or settings.get('check_lists')
            or settings.get('check_formula_caption')):
        warnings.extend(_content_warnings(spec, records, settings))
    if settings.get('check_overlaps'):
        errors.extend(_overlap_errors(records, settings))
    errors.extend(_slot_errors(spec, records))
    if settings.get('check_source_refs'):
        warnings.extend(_fact_warnings(spec, records))
    if settings.get('check_apa'):
        warnings.extend(_apa_warnings(spec, records,
                                      include_figures=not settings.get('check_source_refs')))
    if settings.get('check_void'):
        warnings.extend(_void_warnings(records, settings))
    if settings.get('check_layout_advice'):
        warnings.extend(_layout_warnings(spec, records))
    if settings.get('check_dashes'):
        warnings.extend(_dash_warnings(slides, records))

    if settings.get('check_glyphs'):
        warnings.extend(_glyph_warnings(result.get('missing_glyphs')))
    warnings.extend(_metrics_warnings(result.get('font_metrics')))
    baseline_report, baseline_messages = _baseline_comparison(spec, result)
    warnings.extend(baseline_messages)

    palette = themes.get_theme(getattr(spec, 'theme', ''))
    for fg_key, bg_key in CONTRAST_PAIRS:
        if fg_key not in palette or bg_key not in palette:
            continue
        ratio = textfit.contrast_ratio(palette[fg_key], palette[bg_key])
        if ratio < CONTRAST_MIN:
            warnings.append("theme '%s': low text contrast %s on %s (%.2f < %.1f)"
                            % (spec.theme, fg_key, bg_key, ratio, CONTRAST_MIN))

    formula_modes = result.get('formula_modes') or {}
    formula_modes = {'omml': int(formula_modes.get('omml') or 0),
                     'image': int(formula_modes.get('image') or 0)}
    meta = getattr(spec, 'meta', None) or {}
    formula_mode = str(meta.get('formula_mode') or 'omml')

    note_words = int(result.get('note_words') or 0)
    est = round(float(result.get('duration_est_min') or 0.0), 1)
    duration = int(getattr(spec, 'duration_min', 0) or 0)
    tolerance = float(settings.get('duration_tolerance') or 0.35)
    duration_mode = settings.get('check_duration')
    if duration_mode not in (False, 'off') and duration > 0:
        sink = warnings if duration_mode == 'warn' else errors
        low = duration * max(0.0, 1.0 - tolerance)
        high = duration * (1.0 + tolerance)
        if est < low - 0.05:
            missing = int(round((duration - est) * 132))
            sink.append('speaker notes estimate %.1f min vs the %d min target '
                        '(underrun, %.0f%% short); add about %d words of notes '
                        'or lower duration_min'
                        % (est, duration, (duration - est) / duration * 100.0, missing))
        elif est > high + 0.05:
            extra = int(round((est - duration) * 132))
            sink.append('speaker notes estimate %.1f min vs the %d min target '
                        '(overrun, %.0f%% over); trim about %d words of notes '
                        'or raise duration_min'
                        % (est, duration, (est - duration) / duration * 100.0, extra))

    stage_reports = stages.run_stages(spec, result, pages=pages)
    for stage_name in stages.STAGE_NAMES:
        stage_report = stage_reports.get(stage_name) or {}
        for message in stage_report.get('errors') or []:
            errors.append('[%s] %s' % (stage_name, message))
        for message in stage_report.get('warnings') or []:
            warnings.append('[%s] %s' % (stage_name, message))

    for message in result.get('warnings') or []:
        warnings.append(str(message))

    ok = not errors and (not settings['strict'] or not warnings)
    summary = 'QA: %d errors, %d warnings (%d slides; notes %d words, ~%s min)%s' % (
        len(errors), len(warnings), len(records), note_words, est,
        '; strict' if settings['strict'] else '')
    delivery = delivery_status({'errors': errors, 'warnings': warnings})
    return {
        'ok': ok,
        'status': delivery,
        'caveats': list(warnings) if delivery == 'delivery_ready' else [],
        'errors': errors,
        'warnings': warnings,
        'slides': len(records),
        'note_words': note_words,
        'duration_est_min': est,
        'duration_target_min': duration,
        'theme': str(getattr(spec, 'theme', '') or ''),
        'settings': settings,
        'slide_rows': slide_rows,
        'stages': stage_reports,
        'baseline': baseline_report,
        'artifact_sha256': result.get('artifact_sha256'),
        'skill_fingerprint': result.get('skill_fingerprint'),
        'formula_mode': formula_mode,
        'formula_modes': formula_modes,
        'summary': summary,
    }


def report_markdown(report, spec=None):
    """Render a QA report dict as the ``qa.md`` markdown document."""
    title = str(getattr(spec, 'title', '') or '') if spec is not None else ''
    lines = ['# QA report%s' % (': ' + title if title else ''), '']
    status = 'PASS' if report.get('ok') else 'FAIL'
    lines.append('- Status: **%s** (%d errors, %d warnings)'
                 % (status, len(report.get('errors') or []), len(report.get('warnings') or [])))
    delivery = delivery_status(report)  # recomputed, never the recorded field
    lines.append('- Delivery status: **%s**' % delivery)
    lines.append('- Slides: %s; speaker notes: %s words (~%s min)'
                 % (report.get('slides'), report.get('note_words'), report.get('duration_est_min')))
    target = report.get('duration_target_min') or 0
    if target:
        lines.append('- Target duration: %d min' % target)
    settings = report.get('settings') or {}
    lines.append('- Strict mode: %s; min note words: %s; max bullets: %s; max code lines: %s'
                 % ('on' if settings.get('strict') else 'off', settings.get('min_note_words'),
                    settings.get('max_bullets'), settings.get('max_code_lines')))
    if report.get('artifact_sha256'):
        lines.append('- Artifact SHA-256: `%s`' % report['artifact_sha256'])
    if report.get('skill_fingerprint'):
        lines.append('- Skill fingerprint: `%s`' % report['skill_fingerprint'])
    modes = report.get('formula_modes') or {}
    lines.append('- Formula mode: %s (editable OMML: %s, raster images: %s)'
                 % (report.get('formula_mode') or 'omml',
                    modes.get('omml', 0), modes.get('image', 0)))

    stage_map = report.get('stages') or {}
    if stage_map:
        lines.append('')
        lines.append('## Stages')
        lines.append('')
        lines.append('| stage | status | errors | warnings |')
        lines.append('|-------|--------|--------|----------|')
        for stage_name in ('content', 'file', 'visual'):
            stage_report = stage_map.get(stage_name) or {}
            if stage_report.get('skipped'):
                status = 'skipped'
            elif stage_report.get('ok'):
                status = 'ok'
            else:
                status = 'failed'
            lines.append('| %s | %s | %d | %d |'
                         % (stage_name, status,
                            len(stage_report.get('errors') or []),
                            len(stage_report.get('warnings') or [])))

    lines.append('')
    lines.append('## Errors')
    lines.append('')
    if report.get('errors'):
        lines.extend('- ' + str(message) for message in report['errors'])
    else:
        lines.append('None.')

    lines.append('')
    lines.append('## Warnings')
    lines.append('')
    if report.get('warnings'):
        lines.extend('- ' + str(message) for message in report['warnings'])
    else:
        lines.append('None.')

    caveats = list(report.get('warnings') or []) if delivery == 'delivery_ready' else []
    if caveats:
        lines.append('')
        lines.append('## Caveats')
        lines.append('')
        lines.append('Known issues accepted for delivery of this deck:')
        lines.append('')
        lines.extend('- ' + str(caveat) for caveat in caveats)

    rows = report.get('slide_rows') or []
    if any(row.get('density_exempt') or row.get('fill') is not None for row in rows):
        minimum = (report.get('settings') or {}).get('min_fill')
        lines.append('')
        lines.append('## Density')
        lines.append('')
        for row in rows:
            reason = row.get('density_exempt')
            if reason:
                lines.append('- slide %s (%s): exempt from the density check (%s)'
                             % (row.get('index'), row.get('type'), reason))
            elif row.get('fill') is not None:
                fill = float(row['fill'])
                if minimum is not None and fill < float(minimum) - 0.0005:
                    lines.append('- slide %s (%s): frame fill %.2f below the minimum %.2f'
                                 % (row.get('index'), row.get('type'), fill, float(minimum)))
                else:
                    lines.append('- slide %s (%s): frame fill %.2f'
                                 % (row.get('index'), row.get('type'), fill))
    if any(row.get('void') is not None or row.get('void_exempt') for row in rows):
        maximum = (report.get('settings') or {}).get('max_void_in')
        lines.append('')
        lines.append('## Voids')
        lines.append('')
        for row in rows:
            reason = row.get('void_exempt')
            if reason:
                lines.append('- slide %s (%s): exempt from the void check (%s)'
                             % (row.get('index'), row.get('type'), reason))
            elif row.get('void') is not None:
                void = float(row['void'])
                if maximum is not None and void > float(maximum) + 0.0005:
                    lines.append('- slide %s (%s): %.2f in of empty space under '
                                 'the content (max %.2f in)'
                                 % (row.get('index'), row.get('type'), void,
                                    float(maximum)))
                else:
                    lines.append('- slide %s (%s): %.2f in of empty space under the content'
                                 % (row.get('index'), row.get('type'), void))
    if rows:
        lines.append('')
        lines.append('## Slides')
        lines.append('')
        lines.append('| # | type | note (words) | list items | code lines |')
        lines.append('|---|------|--------------|------------|------------|')
        for row in rows:
            lines.append('| %s | %s | %s | %s | %s |'
                         % (row.get('index'), row.get('type'), row.get('note_words'),
                            row.get('bullets'), row.get('code_lines')))
    return '\n'.join(lines) + '\n'


def verify_report(report, artifact_path):
    """Re-hash an artifact and report whether a QA report still describes it.

    Returns ``{'valid': bool, 'expected': str|None, 'actual': str|None,
    'reason': str}``. A report without a recorded hash is refused - an
    unbound report cannot be verified.
    """
    expected = str((report or {}).get('artifact_sha256') or '')
    if not expected:
        return {'valid': False, 'expected': None, 'actual': None,
                'reason': 'no artifact hash recorded in the report'}
    path = Path(artifact_path)
    if not path.exists():
        return {'valid': False, 'expected': expected, 'actual': None,
                'reason': 'artifact not found: %s' % path}
    actual = fingerprint.sha256_file(path)
    if actual == expected:
        return {'valid': True, 'expected': expected, 'actual': actual,
                'reason': 'artifact matches the report'}
    return {'valid': False, 'expected': expected, 'actual': actual,
            'reason': 'artifact changed since the report was written'}


def delivery_status(report):
    """Recompute the delivery status from the findings.

    ``complete`` - no errors and no warnings; ``delivery_ready`` - no
    errors, the warnings travel forward as ``caveats``; ``draft`` - errors
    block delivery. The status is derived from the findings, never trusted
    from the report field.
    """
    errors = list((report or {}).get('errors') or [])
    warnings = list((report or {}).get('warnings') or [])
    if errors:
        return 'draft'
    if warnings:
        return 'delivery_ready'
    return 'complete'


def verify_delivery(report):
    """Check the recorded delivery status against the recomputed one.

    Returns ``{'ok': bool, 'recorded': str|None, 'recomputed': str|None,
    'reason': str}``. A report that claims ``complete`` while its findings
    say otherwise is refused.
    """
    recorded = (report or {}).get('status')
    if not recorded:
        return {'ok': False, 'recorded': None, 'recomputed': None,
                'reason': 'no delivery status recorded in the report'}
    expected = delivery_status(report)
    if str(recorded) == expected:
        return {'ok': True, 'recorded': str(recorded), 'recomputed': expected,
                'reason': 'delivery status matches the findings'}
    return {'ok': False, 'recorded': str(recorded), 'recomputed': expected,
            'reason': 'recorded delivery status does not match the findings'}


def main(argv=None):
    """CLI: rebuild a spec in memory, run the QA pass, write the report."""
    parser = argparse.ArgumentParser(
        description='Validate a lecture deck spec (QA pass; see SKILL.md).')
    parser.add_argument('spec_path', help='lecture spec (JSON, UTF-8)')
    parser.add_argument('--strict', action='store_true', default=False,
                        help='treat QA warnings as errors')
    parser.add_argument('--json', action='store_true', dest='qa_json',
                        help='also write the machine-readable report (.json)')
    parser.add_argument('--visual', action='store_true', default=False,
                        help='rasterize the deck (LibreOffice) and run the visual QA stage')
    parser.add_argument('--report', help='markdown report path (default: next to the spec)')
    args = parser.parse_args(argv)

    spec_path = Path(args.spec_path)
    try:
        spec = load_spec(spec_path)
    except SpecError as exc:
        print('spec error: ' + '; '.join(exc.errors))
        return 2

    try:
        with tempfile.TemporaryDirectory() as tmp:
            # Save the candidate to disk: file-stage checks and the
            # meta.baseline comparison both read the saved pptx.
            result = build_deck(spec, out_path=Path(tmp) / 'deck.pptx',
                                assets_dir=Path(tmp))
            pages = None
            if args.visual:
                import render_preview  # local import: only the CLI needs it
                preview = render_preview.render(result['out_path'], pdf=True,
                                                png=True, out_dir=Path(tmp) / 'preview')
                pages = preview.get('png') or None
                if not pages:
                    note = '; '.join(preview.get('warnings') or []) or 'no pages rendered'
                    print('visual stage skipped: ' + note)
            report = check_deck(spec, result, strict=True if args.strict else None,
                                pages=pages)
    except Exception as exc:  # noqa: BLE001 - CLI boundary: report the crash and exit 2
        print('build failed: %s: %s' % (type(exc).__name__, exc))
        return 2

    report_path = (Path(args.report) if args.report
                   else spec_path.with_name(spec_path.stem + '_service') / 'qa.md')
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report_markdown(report, spec=spec), encoding='utf-8')
    if args.qa_json:
        json_path = report_path.with_suffix('.json')
        json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                             encoding='utf-8')

    print(report['summary'])
    for message in report['errors']:
        print('QA ERROR: ' + str(message))
    for message in report['warnings']:
        print('QA WARNING: ' + str(message))
    return 0 if report['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
