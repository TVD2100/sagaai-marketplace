"""Build a lecture deck (PPTX) from a JSON spec - bundle entry point.

Usage:
    python build_lecture.py <spec.json> [<out.pptx>] [--qa] [--qa-json] [--strict] [--visual]
    python build_lecture.py --check-env

Also imported by DevAgent workflows::

    from build_lecture import build
    res = build("lectures/newton/lecture.json", "lectures/newton/newton.pptx", qa=True)

``build()`` loads and validates the spec (``lecture.spec``), renders the deck
(``lecture.deck``) and, with ``qa=True``, runs the QA pass (``qa_check``) and
writes ``qa.md`` plus one report per QA stage (``qa_content.md``,
``qa_file.md``, ``qa_visual.md``) and ``qa.json`` when ``qa_json=True`` into
``<stem>_service/`` next to the deck (``service_dir=False`` keeps the older
``<stem>_qa.md`` layout). Returns a result dict:

    {"ok": bool, "pptx": str|None, "slides": int, "qa": dict|None,
     "errors": [...], "warnings": [...], "note_words": int,
     "duration_est_min": float, "assets": [...], "missing_images": [...],
     "missing_glyphs": {font: [chars]}, "font_metrics": {...},
     "formula_modes": {omml: int, image: int},
     "artifact_sha256": str|None, "skill_fingerprint": str,
     "qa_reports": [...], "summary": str}

CLI exit codes: 0 - success, 1 - QA errors (or warnings in strict mode),
2 - spec/build failure. ``--check-env`` prints the environment preflight
report (``compatibility.json``) and exits 0, or 2 when a required
component is missing.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from lecture import SpecError, build_deck, load_spec, stages


def build(spec_path, out_path=None, qa=False, qa_json=False, strict=None, assets_dir=None,
          qa_visual=False, service_dir=True):
    """Build one lecture deck; returns the result dict described in the module docstring.

    With ``qa=True`` the QA pass runs; ``qa_visual=True`` additionally
    rasterizes the deck (LibreOffice + PDF rasterizer) and feeds the
    rendered pages to the visual QA stage, so ``build()`` alone can run
    all three stages. When the rasterizer is unavailable the visual stage
    reports itself skipped with a reason instead of failing the build.

    Helper files (QA reports, formula rasters, preview pages) go to
    ``<out_stem>_service/`` with ``service_dir=True`` (the default), so the
    deck folder holds only the artifacts. ``service_dir=False`` restores the
    older flat layout (``<stem>_qa.md`` next to the deck).
    """
    spec_path = Path(spec_path)
    if out_path is None:
        out_path = spec_path.with_suffix('.pptx')
    out_path = Path(out_path)

    try:
        spec = load_spec(spec_path)
    except SpecError as exc:
        return {
            'ok': False, 'pptx': None, 'slides': 0, 'qa': None,
            'errors': list(exc.errors), 'warnings': [], 'note_words': 0,
            'duration_est_min': 0.0, 'assets': [], 'missing_images': [],
            'qa_reports': [],
            'summary': 'spec error in %s: %s' % (spec_path.name, '; '.join(exc.errors)),
        }

    result = build_deck(spec, out_path=out_path, assets_dir=assets_dir,
                        service_dir=service_dir)

    auto_layout_changes = list(result.get('auto_layout') or [])

    qa_report = None
    qa_reports = []
    if qa:
        import qa_check  # local import: the QA module is optional at build time
        pages = None
        if qa_visual:
            pages = _render_pages(result)
        qa_report = qa_check.check_deck(spec, result, strict=strict, pages=pages)
        report_dir = _service_dir(out_path, service_dir)
        report_dir.mkdir(parents=True, exist_ok=True)
        prefix = '' if service_dir else out_path.stem + '_'
        report_path = report_dir / (prefix + 'qa.md')
        report_path.write_text(qa_check.report_markdown(qa_report, spec=spec), encoding='utf-8')
        qa_reports.append(str(report_path))
        for stage_name in stages.STAGE_NAMES:
            stage_report = (qa_report.get('stages') or {}).get(stage_name)
            if not stage_report:
                continue
            stage_path = report_dir / ('%sqa_%s.md' % (prefix, stage_name))
            stage_path.write_text(stages.stage_markdown(stage_report), encoding='utf-8')
            qa_reports.append(str(stage_path))
        if qa_json:
            json_path = report_dir / (prefix + 'qa.json')
            json_path.write_text(json.dumps(qa_report, ensure_ascii=False, indent=2),
                                 encoding='utf-8')
            qa_reports.append(str(json_path))

    ok = bool(result['ok'])
    if qa_report is not None:
        ok = ok and bool(qa_report['ok'])

    parts = ['%d slides' % result['slides'],
             'notes %d words (~%s min)' % (result['note_words'],
                                           result['duration_est_min'])]
    if result['errors']:
        parts.append('%d build errors' % len(result['errors']))
    if qa_report is not None:
        parts.append('QA: %d errors, %d warnings'
                     % (len(qa_report['errors']), len(qa_report['warnings'])))
        parts.append('delivery: %s' % qa_report.get('status'))
    parts.append(('OK ' if ok else 'FAILED ') + str(out_path))
    if auto_layout_changes:
        parts.append('auto-layout rewrote %d slide(s)' % len(auto_layout_changes))

    return {
        'ok': ok,
        'pptx': str(out_path),
        'slides': result['slides'],
        'qa': qa_report,
        'errors': list(result['errors']),
        'warnings': list(result['warnings']),
        'note_words': result['note_words'],
        'duration_est_min': result['duration_est_min'],
        'assets_dir': result['assets_dir'],
        'assets': list(result.get('assets') or []),
        'missing_images': list(result.get('missing_images') or []),
        'missing_glyphs': dict(result.get('missing_glyphs') or {}),
        'font_metrics': dict(result.get('font_metrics') or {}),
        'formula_modes': dict(result.get('formula_modes') or {}),
        'artifact_sha256': result.get('artifact_sha256'),
        'skill_fingerprint': result.get('skill_fingerprint') or '',
        'qa_reports': qa_reports,
        'auto_layout': auto_layout_changes,
        'summary': '; '.join(parts),
    }


def _service_dir(out_path, service_dir):
    """Folder for the helper files of one build.

    Returns ``<out_stem>_service/`` when ``service_dir`` is true, so the deck
    folder holds only the artifacts; otherwise the deck's own folder keeps the
    older flat layout.
    """
    out_path = Path(out_path)
    if service_dir:
        return out_path.parent / (out_path.stem + '_service')
    return out_path.parent


def _render_pages(result):
    """Rasterize the built deck and return page image paths, or None.

    Best-effort helper for ``build(qa_visual=True)``: a missing rasterizer,
    a missing LibreOffice or a failed export is reported as a build warning
    and the caller passes ``pages=None`` so the visual stage reports itself
    as skipped with a reason instead of failing the whole build. Rendered
    pages go to ``<stem>_service/preview/page_NN.png`` (with the PDF next to
    the PPTX), which keeps them available for a human review of the same run.
    """
    pptx = (result or {}).get('out_path')
    if not pptx:
        return None
    try:
        import render_preview  # local import: only needed for the visual pass
    except Exception as exc:  # noqa: BLE001 - optional dependency
        result.setdefault('warnings', []).append(
            'visual QA skipped: render_preview is unavailable (%s)' % exc)
        return None
    try:
        preview = render_preview.render(pptx, pdf=True, png=True)
    except Exception as exc:  # noqa: BLE001 - never fail the build over a preview
        result.setdefault('warnings', []).append(
            'visual QA skipped: rasterization failed: %s: %s' % (type(exc).__name__, exc))
        return None
    pages = preview.get('png') or None
    if not pages:
        note = '; '.join(preview.get('warnings') or []) or 'no pages rendered'
        result.setdefault('warnings', []).append('visual QA skipped: ' + note)
    return pages


def check_drift(spec_path, pptx_path=None, service_dir=True):
    """Check whether a saved deck still matches its spec.

    A deck built from a spec can be edited by hand in PowerPoint afterwards.
    Rebuilding from the spec would silently destroy those edits, so the agent
    must ASK the user first - this helper produces the facts behind the
    question: which slides and notes differ, and whether the user already
    accepted the manual edits (``drift_ack.json``).

    ``pptx_path`` defaults to the spec path with a ``.pptx`` suffix. Returns
    the ``lecture.drift.compare`` report plus ``markdown`` - a ready-to-show
    block for the user. Never modifies the deck, the spec or the ack file.

    Read it as: ``changed`` - the deck and the spec disagree; ``ok`` - no
    action needed (in sync, or the drift is acknowledged); ``user_added``
    lines are the manual edits, ``user_removed`` lines are text the spec has
    but the deck lost.
    """
    from lecture import drift  # local import: keeps the CLI startup cheap

    spec_path = Path(spec_path)
    if pptx_path is None:
        pptx_path = spec_path.with_suffix('.pptx')
    report = drift.compare(spec_path, pptx_path)
    report['markdown'] = drift.report_markdown(report)
    report['ack_path'] = str(drift.ack_path(pptx_path, service_dir=service_dir))
    return report


def acknowledge_manual_edits(pptx_path, service_dir=True):
    """Record that the user accepted the manual edits of a deck as final.

    Called only after the user answered the drift question with 'keep the
    deck as is'. The ack stores the deck's SHA-256, so a later edit makes it
    stale and the question is asked again. Returns the ack file path.
    """
    from lecture import drift

    return str(drift.write_ack(pptx_path, service_dir=service_dir))


def main(argv=None):
    """CLI entry point: build a deck or run the preflight check; see exit codes above."""
    parser = argparse.ArgumentParser(
        description='Build a lecture deck (PPTX) from a JSON spec.')
    parser.add_argument('spec_path', nargs='?', help='lecture spec (JSON, UTF-8)')
    parser.add_argument('out_path', nargs='?',
                        help='target .pptx (default: next to the spec)')
    parser.add_argument('--qa', action='store_true',
                        help='run the QA pass and write qa.md into <stem>_service/')
    parser.add_argument('--qa-json', action='store_true', dest='qa_json',
                        help='also write qa.json into <stem>_service/')
    parser.add_argument('--strict', action='store_true', default=False,
                        help='treat QA warnings as errors')
    parser.add_argument('--visual', action='store_true', default=False,
                        help='rasterize the deck and run the visual QA stage '
                             '(requires LibreOffice; skipped with a reason otherwise)')
    parser.add_argument('--check-env', action='store_true', dest='check_env',
                        help='run the environment preflight check and exit')
    parser.add_argument('--flat', action='store_true', default=False,
                        help='write helper files next to the deck instead of '
                             '<stem>_service/ (pre-1.5 layout)')
    parser.add_argument('--check-drift', action='store_true', dest='check_drift',
                        help='compare an existing deck with its spec and exit '
                             '(0 in sync, 1 drifted, 2 error); builds nothing')
    parser.add_argument('--ack-manual-edit', action='store_true',
                        dest='ack_manual_edit',
                        help='record that the manual edits of the deck are '
                             'accepted as final (stops the drift question)')
    args = parser.parse_args(argv)

    if args.check_env:
        import preflight  # stdlib-only module: runs on a host without the bundle deps
        report = preflight.check_environment()
        print(preflight.report_text(report))
        return 0 if report['ok'] else 2

    if not args.spec_path:
        parser.error('missing the lecture spec path (or use --check-env)')

    if args.ack_manual_edit:
        deck = args.out_path or str(Path(args.spec_path).with_suffix('.pptx'))
        print('acknowledged: ' + acknowledge_manual_edits(
            deck, service_dir=False if args.flat else True))
        return 0

    if args.check_drift:
        report = check_drift(args.spec_path, args.out_path,
                             service_dir=False if args.flat else True)
        print(report['markdown'], end='')
        if report['errors']:
            return 2
        return 0 if report['ok'] else 1

    res = build(args.spec_path, args.out_path, qa=args.qa, qa_json=args.qa_json,
                strict=True if args.strict else None, qa_visual=args.visual,
                service_dir=False if args.flat else True)
    print(res['summary'])
    for message in res['errors']:
        print('ERROR: ' + message)
    if res['qa'] is not None:
        for message in res['qa']['errors']:
            print('QA ERROR: ' + message)
        for message in res['qa']['warnings']:
            print('QA WARNING: ' + message)

    if res['pptx'] is None or res['errors']:
        return 2
    if res['qa'] is not None and not res['qa']['ok']:
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
