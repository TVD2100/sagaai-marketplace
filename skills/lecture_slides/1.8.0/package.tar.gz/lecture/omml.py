"""LaTeX -> OMML converter for editable PowerPoint formulas.

The deck builder embeds Office Math (a14:m wrapping m:oMathPara / m:oMath)
into the slide text body, so formulas stay editable in PowerPoint and Word.
This module is a small, dependency-free (lxml only) LaTeX subset parser: it
understands the constructs used in lecture decks - fractions, radicals,
scripts, big operators, delimiters, accents and Greek letters - and raises
OmmlError for anything it cannot express, so the caller can fall back to a
rasterized image.

Public API:

- latex_to_omml(text) -> m:oMath element for one formula line;
- omml_paragraph(lines, fontsize) -> a14:m element with a centered
  m:oMathPara holding one m:oMath per line, run size set in hundredths of a
  point;
- validate_omml(element) -> list of structural problems (empty when the
  element is a well-formed math paragraph);
- estimate_height(lines, fontsize) -> best-effort height in inches for
  layout planning (PowerPoint-specific metrics are unavailable offline).
"""

from __future__ import annotations

from lxml import etree

from .render import clean_formula

A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'
M_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
A14_NS = 'http://schemas.microsoft.com/office/drawing/2010/main'

A14_M = '{%s}m' % A14_NS


class OmmlError(Exception):
    """Raised when a formula cannot be expressed as Office Math."""


def _m(tag):
    return '{%s}%s' % (M_NS, tag)


def _a(tag):
    return '{%s}%s' % (A_NS, tag)


GREEK = {
    'alpha': 'α', 'beta': 'β', 'gamma': 'γ', 'delta': 'δ', 'epsilon': 'ϵ',
    'varepsilon': 'ε', 'zeta': 'ζ', 'eta': 'η', 'theta': 'θ', 'vartheta': 'ϑ',
    'iota': 'ι', 'kappa': 'κ', 'lambda': 'λ', 'mu': 'μ', 'nu': 'ν', 'xi': 'ξ',
    'omicron': 'ο', 'pi': 'π', 'varpi': 'ϖ', 'rho': 'ρ', 'varrho': 'ϱ',
    'sigma': 'σ', 'varsigma': 'ς', 'tau': 'τ', 'upsilon': 'υ', 'phi': 'ϕ',
    'varphi': 'φ', 'chi': 'χ', 'psi': 'ψ', 'omega': 'ω',
    'Gamma': 'Γ', 'Delta': 'Δ', 'Theta': 'Θ', 'Lambda': 'Λ', 'Xi': 'Ξ',
    'Pi': 'Π', 'Sigma': 'Σ', 'Upsilon': 'Υ', 'Phi': 'Φ', 'Psi': 'Ψ',
    'Omega': 'Ω',
}

SYMBOLS = {
    'pm': '±', 'mp': '∓', 'times': '×', 'div': '÷', 'cdot': '⋅', 'ast': '∗',
    'star': '⋆', 'circ': '∘', 'bullet': '∙',
    'leq': '≤', 'le': '≤', 'geq': '≥', 'ge': '≥', 'neq': '≠', 'ne': '≠',
    'approx': '≈', 'equiv': '≡', 'sim': '∼', 'simeq': '≃', 'propto': '∝',
    'll': '≪', 'gg': '≫', 'subset': '⊂', 'supset': '⊃', 'subseteq': '⊆',
    'supseteq': '⊇', 'in': '∈', 'notin': '∉', 'ni': '∋', 'forall': '∀',
    'exists': '∃', 'nexists': '∄', 'emptyset': '∅', 'varnothing': '∅',
    'infty': '∞', 'partial': '∂', 'nabla': '∇', 'to': '→', 'rightarrow': '→',
    'longrightarrow': '⟶', 'leftarrow': '←', 'leftrightarrow': '↔',
    'Rightarrow': '⇒', 'Leftarrow': '⇐', 'Leftrightarrow': '⇔', 'mapsto': '↦',
    'uparrow': '↑', 'downarrow': '↓', 'prime': '′', 'ldots': '…', 'dots': '…',
    'cdots': '⋯', 'vdots': '⋮', 'ddots': '⋱', 'angle': '∠', 'perp': '⊥',
    'parallel': '∥', 'langle': '⟨', 'rangle': '⟩', 'lceil': '⌈', 'rceil': '⌉',
    'lfloor': '⌊', 'rfloor': '⌋', 'ell': 'ℓ', 'hbar': 'ℏ',
    'Re': 'ℜ', 'Im': 'ℑ', 'aleph': 'ℵ', 'neg': '¬', 'land': '∧', 'lor': '∨',
    'oplus': '⊕', 'otimes': '⊗', 'odot': '⊙', 'cup': '∪', 'cap': '∩',
    'setminus': '∖', 'triangle': '△',
}

ACCENTS = {
    'hat': '^', 'widehat': '^', 'tilde': '~', 'widetilde': '~', 'bar': '¯',
    'vec': '⃗', 'dot': '˙', 'ddot': '¨', 'check': 'ˇ', 'breve': '˘',
    'acute': '´', 'grave': '`',
}

FUNCTIONS = (
    'sin', 'cos', 'tan', 'cot', 'sec', 'csc', 'sinh', 'cosh', 'tanh', 'coth',
    'arcsin', 'arccos', 'arctan', 'log', 'ln', 'lg', 'exp', 'det', 'dim',
    'ker', 'deg', 'gcd', 'hom', 'min', 'max', 'arg',
)

NARY = {
    'sum': '∑', 'prod': '∏', 'coprod': '∐', 'int': '∫', 'oint': '∮',
    'iint': '∬', 'iiint': '∭', 'bigcup': '⋃', 'bigcap': '⋂', 'bigoplus': '⨁',
    'bigotimes': '⨂', 'bigvee': '⋁', 'bigwedge': '⋀',
}

SPACE_COMMANDS = (',', ';', ':', '!', ' ', 'quad', 'qquad', 'thinspace',
                  'enspace', 'medspace', 'thickspace')

# Binary operators that terminate the body of a big operator (sum x + y).
_BODY_STOPS = ('+', '-', '=', '≈', '≠', '≤', '≥', '±')

_VARIABLE_MAP = {"'": '′', '"': '″'}


def _run(text):
    """One m:r math run carrying text in m:t."""
    run = etree.Element(_m('r'))
    node = etree.SubElement(run, _m('t'))
    node.text = str(text)
    return run


def _wrap(parent, tag, items):
    """Append items into a new m:<tag> child of parent."""
    child = etree.SubElement(parent, _m(tag))
    for item in items:
        child.append(item)
    return child


def _script_element(tag, base_items, sub=None, sup=None):
    """Build an m:sSup / m:sSub / m:sSubSup element."""
    element = etree.Element(_m(tag))
    _wrap(element, 'e', base_items)
    if sub is not None:
        _wrap(element, 'sub', sub)
    if sup is not None:
        _wrap(element, 'sup', sup)
    return element


def _map_char(char):
    """Map a literal LaTeX character to its math glyph (empty = skip)."""
    if char == '~':
        return ''
    return _VARIABLE_MAP.get(char, char)


class _Parser:
    """Recursive-descent parser for the supported LaTeX subset."""

    def __init__(self, text):
        self.text = str(text)
        self.pos = 0

    # -- cursor helpers -------------------------------------------------

    def skip_spaces(self):
        while self.pos < len(self.text) and self.text[self.pos] in ' \t\n':
            self.pos += 1

    def peek_char(self):
        return self.text[self.pos] if self.pos < len(self.text) else ''

    def peek_command(self):
        """Name of the command at the cursor without consuming it."""
        if self.peek_char() != '\\':
            return ''
        index = self.pos + 1
        if index >= len(self.text):
            return ''
        if self.text[index].isalpha():
            end = index
            while end < len(self.text) and self.text[end].isalpha():
                end += 1
            return self.text[index:end]
        return self.text[index]

    def read_command(self):
        """Consume a backslash command name; returns it without the slash."""
        self.pos += 1
        if self.pos >= len(self.text):
            raise OmmlError('dangling backslash in %r' % self.text)
        char = self.text[self.pos]
        if char.isalpha():
            start = self.pos
            while self.pos < len(self.text) and self.text[self.pos].isalpha():
                self.pos += 1
            return self.text[start:self.pos]
        self.pos += 1
        return char

    # -- structure -------------------------------------------------------

    def parse_items(self, stop_chars='', stop_commands=(), stop_ops=False):
        """Parse a run of atoms until a stop condition is met."""
        items = []
        depth = 0
        while self.pos < len(self.text):
            self.skip_spaces()
            if self.pos >= len(self.text):
                break
            char = self.text[self.pos]
            if char in stop_chars and depth == 0:
                break
            if char == '\\' and self.peek_command() in stop_commands:
                break
            if char == '(':
                depth += 1
            elif char == ')':
                depth = max(0, depth - 1)
            if stop_ops and items and depth <= 0 and char in _BODY_STOPS:
                break
            items.extend(self._parse_atom())
        return items

    def _parse_atom(self):
        self.skip_spaces()
        char = self.peek_char()
        if not char:
            return []
        if char == '\\':
            return self._parse_command()
        if char == '{':
            return self._attach_scripts(self._group())
        if char == '}':
            raise OmmlError('unexpected closing brace in %r' % self.text)
        self.pos += 1
        mapped = _map_char(char)
        if not mapped:
            return []
        return self._attach_scripts([_run(mapped)])

    def _group(self):
        """Consume a curly-brace group; returns the parsed items."""
        self.pos += 1  # consume the opening brace
        items = self.parse_items(stop_chars='}')
        if self.peek_char() != '}':
            raise OmmlError('unbalanced braces in %r' % self.text)
        self.pos += 1
        return items

    def _argument(self):
        self.skip_spaces()
        if not self.peek_char():
            raise OmmlError('missing argument in %r' % self.text)
        if self.peek_char() == '{':
            return self._group()
        return self._parse_atom()

    def _script_argument(self):
        """Read one script argument; a bare token must not eat later scripts."""
        self.skip_spaces()
        char = self.peek_char()
        if not char:
            raise OmmlError('missing script argument in %r' % self.text)
        if char == '{':
            return self._group()
        if char == '\\':
            return self._parse_command()
        self.pos += 1
        mapped = _map_char(char)
        return [_run(mapped)] if mapped else []

    def _read_scripts(self):
        """Read trailing ^ / _ arguments; returns (sub, sup)."""
        sub = None
        sup = None
        while True:
            saved = self.pos
            self.skip_spaces()
            char = self.peek_char()
            if char not in ('^', '_'):
                self.pos = saved
                break
            self.pos += 1
            if char == '^':
                if sup is not None:
                    raise OmmlError('double superscript in %r' % self.text)
                sup = self._script_argument()
            else:
                if sub is not None:
                    raise OmmlError('double subscript in %r' % self.text)
                sub = self._script_argument()
        return sub, sup

    def _attach_scripts(self, items):
        sub, sup = self._read_scripts()
        if sub is None and sup is None:
            return items
        if not items:
            raise OmmlError('script without a base in %r' % self.text)
        if sub is not None and sup is not None:
            return [_script_element('sSubSup', items, sub=sub, sup=sup)]
        if sup is not None:
            return [_script_element('sSup', items, sup=sup)]
        return [_script_element('sSub', items, sub=sub)]

    # -- commands ---------------------------------------------------------

    def _parse_command(self):
        name = self.read_command()
        if name in SPACE_COMMANDS:
            return []
        if name in ('{', '}'):
            return self._attach_scripts([_run(name)])
        if name == '|':
            return self._attach_scripts([_run('‖')])
        if name == 'frac':
            return self._attach_scripts([self._fraction()])
        if name == 'sqrt':
            return self._attach_scripts([self._radical()])
        if name in ('overline', 'bar'):
            return self._attach_scripts([self._bar()])
        if name in ACCENTS:
            return self._attach_scripts([self._accent(ACCENTS[name])])
        if name in NARY:
            return [self._nary(name)]
        if name == 'lim':
            return self._lim()
        if name == 'left':
            return self._attach_scripts([self._delimited()])
        if name == 'right':
            raise OmmlError('unexpected right delimiter in %r' % self.text)
        if name in ('begin', 'end'):
            raise OmmlError('unsupported LaTeX environment %r in %r; use '
                            'supported mathtext or the image formula mode'
                            % (name, self.text))
        if name in ('text', 'mathrm', 'mathbf', 'mathit', 'operatorname'):
            raise OmmlError('unsupported text-mode command %r in %r; use '
                            'plain math symbols or the image formula mode'
                            % (name, self.text))
        if name in GREEK:
            return self._attach_scripts([_run(GREEK[name])])
        if name in SYMBOLS:
            return self._attach_scripts([_run(SYMBOLS[name])])
        if name in FUNCTIONS:
            return self._attach_scripts([_run(name)])
        raise OmmlError('unsupported LaTeX command %r in %r' % (name, self.text))

    def _fraction(self):
        numerator = self._argument()
        denominator = self._argument()
        element = etree.Element(_m('f'))
        _wrap(element, 'num', numerator)
        _wrap(element, 'den', denominator)
        return element

    def _radical(self):
        inline_degree = None
        self.skip_spaces()
        if self.peek_char() == '[':
            end = self.text.find(']', self.pos + 1)
            if end < 0:
                raise OmmlError('unclosed radical index in %r' % self.text)
            inline_degree = self.text[self.pos + 1:end]
            self.pos = end + 1
        body = self._argument()
        element = etree.Element(_m('rad'))
        if inline_degree:
            _wrap(element, 'deg', [_run(inline_degree)])
        _wrap(element, 'e', body)
        return element

    def _bar(self):
        element = etree.Element(_m('bar'))
        _wrap(element, 'e', self._argument())
        return element

    def _accent(self, char):
        element = etree.Element(_m('acc'))
        props = etree.SubElement(element, _m('accPr'))
        chr_el = etree.SubElement(props, _m('chr'))
        chr_el.set(_m('val'), char)
        _wrap(element, 'e', self._argument())
        return element

    def _nary(self, name):
        sub, sup = self._read_scripts()
        body = self.parse_items(stop_ops=True)
        element = etree.Element(_m('nary'))
        props = etree.SubElement(element, _m('naryPr'))
        chr_el = etree.SubElement(props, _m('chr'))
        chr_el.set(_m('val'), NARY[name])
        lim = etree.SubElement(props, _m('limLoc'))
        lim.set(_m('val'), 'undOvr')
        if sub is not None:
            _wrap(element, 'sub', sub)
        if sup is not None:
            _wrap(element, 'sup', sup)
        _wrap(element, 'e', body)
        return element

    def _lim(self):
        sub, sup = self._read_scripts()
        if sub is None and sup is None:
            return self._attach_scripts([_run('lim')])
        tag = 'limUpp' if sub is None else 'limLow'
        element = etree.Element(_m(tag))
        _wrap(element, 'e', [_run('lim')])
        _wrap(element, 'lim', sub if sub is not None else sup)
        return [element]

    def _read_delimiter(self):
        """Read one delimiter; returns its glyph (None for an invisible one)."""
        self.skip_spaces()
        char = self.peek_char()
        if not char:
            raise OmmlError('missing delimiter in %r' % self.text)
        if char != '\\':
            self.pos += 1
            return None if char == '.' else char
        name = self.read_command()
        mapping = {'{': '{', '}': '}', '|': '‖', 'langle': '⟨', 'rangle': '⟩',
                   'lceil': '⌈', 'rceil': '⌉', 'lfloor': '⌊', 'rfloor': '⌋',
                   'lvert': '|', 'rvert': '|', 'vert': '|', 'Vert': '‖',
                   '.': None}
        if name not in mapping:
            raise OmmlError('unsupported delimiter %r in %r' % (name, self.text))
        return mapping[name]

    def _delimited(self):
        begin = self._read_delimiter()
        body = self.parse_items(stop_chars='}', stop_commands=('right',))
        if self.peek_command() != 'right':
            raise OmmlError('missing right delimiter in %r' % self.text)
        self.read_command()
        end = self._read_delimiter()
        element = etree.Element(_m('d'))
        props = etree.SubElement(element, _m('dPr'))
        if begin:
            char_el = etree.SubElement(props, _m('begChr'))
            char_el.set(_m('val'), begin)
        if end:
            char_el = etree.SubElement(props, _m('endChr'))
            char_el.set(_m('val'), end)
        _wrap(element, 'e', body)
        return element


# ------------------------------ public API --------------------------------

def latex_to_omml(text):
    """Convert one LaTeX formula line into an m:oMath element.

    Raises OmmlError for empty input and for every construct outside the
    supported subset (unknown or text-mode commands, environments,
    unbalanced braces).
    """
    body = clean_formula(text)
    if not body.strip():
        raise OmmlError('formula is empty')
    parser = _Parser(body)
    items = parser.parse_items(stop_chars='}')
    parser.skip_spaces()
    if parser.pos < len(parser.text):
        raise OmmlError('unexpected fragment %r in %r'
                        % (parser.text[parser.pos:], body))
    if not items:
        raise OmmlError('formula is empty')
    element = etree.Element(_m('oMath'))
    for item in items:
        element.append(item)
    return element


def omml_paragraph(lines, fontsize=24.0):
    """Build the a14:m math block for one slide.

    lines is a string or a list of strings (stacked display lines);
    fontsize is in points and is written as a:rPr/@sz in hundredths of a
    point on every math run.
    """
    if lines is None:
        raise OmmlError('formula is empty')
    raw = [lines] if isinstance(lines, str) else list(lines)
    texts = [str(item) for item in raw if str(item).strip()]
    if not texts:
        raise OmmlError('formula is empty')
    element = etree.Element(A14_M, nsmap={'a14': A14_NS, 'm': M_NS})
    paragraph = etree.SubElement(element, _m('oMathPara'))
    props = etree.SubElement(paragraph, _m('oMathParaPr'))
    justify = etree.SubElement(props, _m('jc'))
    justify.set(_m('val'), 'center')
    size = str(int(round(float(fontsize) * 100)))
    for line in texts:
        math = latex_to_omml(line)
        for run in math.iter(_m('r')):
            run_pr = run.find(_a('rPr'))
            if run_pr is None:
                run_pr = etree.Element(_a('rPr'))
                run.insert(0, run_pr)
            run_pr.set('sz', size)
        paragraph.append(math)
    return element


_STRUCTURE_CHECKS = (
    ('f', ('num', 'den'), 'm:f without m:num and m:den'),
    ('rad', ('e',), 'm:rad without m:e'),
    ('sSup', ('e', 'sup'), 'm:sSup without m:e and m:sup'),
    ('sSub', ('e', 'sub'), 'm:sSub without m:e and m:sub'),
    ('sSubSup', ('e', 'sub', 'sup'), 'm:sSubSup without m:e, m:sub and m:sup'),
    ('nary', ('e',), 'm:nary without m:e'),
    ('d', ('e',), 'm:d without m:e'),
    ('acc', ('e',), 'm:acc without m:e'),
    ('bar', ('e',), 'm:bar without m:e'),
    ('limLow', ('e', 'lim'), 'm:limLow without m:e and m:lim'),
    ('limUpp', ('e', 'lim'), 'm:limUpp without m:e and m:lim'),
)


def validate_omml(element):
    """Return the structural problems of an OMML element (empty when clean)."""
    if element is None:
        return ['formula element is missing']
    problems = []
    if element.tag != A14_M:
        problems.append('formula is not wrapped in a14:m (found %s)' % element.tag)
    container = element.find(_m('oMathPara'))
    if container is None:
        container = element.find(_m('oMath'))
    if container is None:
        problems.append('formula has no m:oMathPara / m:oMath container')
        return problems
    if container.tag == _m('oMathPara') and container.find(_m('oMath')) is None:
        problems.append('m:oMathPara contains no m:oMath')
    texts = [node.text or '' for node in element.iter(_m('t'))]
    if not any(text.strip() for text in texts):
        problems.append('formula has no non-empty text (m:t) runs')
    for tag, children, message in _STRUCTURE_CHECKS:
        for node in element.iter(_m(tag)):
            if any(node.find(_m(child)) is None for child in children):
                problems.append(message)
    return problems


def estimate_height(lines, fontsize):
    """Best-effort rendered height (inches) used for layout records."""
    raw = [lines] if isinstance(lines, str) else list(lines or [])
    rows = max(1, len([item for item in raw if str(item).strip()]))
    return round(rows * float(fontsize) * 1.62 / 72.0, 3)
