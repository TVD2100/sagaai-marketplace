"""Baseline deck comparison: catch content lost between deck versions.

A lecturer often keeps the previous version of a deck as the reference
("template") and expects the new one to preserve its structure.
``meta.baseline`` points at that previous ``.pptx``; ``compare_decks``
extracts the dominant heading of every slide (the largest alphabetic text
on it) and reports headings that survived in the candidate plus those that
went missing. Slide numbers and section digits are not headings, so the
60 pt '1' of a section divider never shadows its title.

Matching is whitespace/case-insensitive with containment tolerance: the
baseline heading "Введение в анализ" counts as present when the candidate
has "Введение". Missing headings become QA warnings (errors under
``strict``), so a routine rebuild is never blocked, but the loss is visible
the moment it happens.
"""

from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

_MIN_SIZE_EPS = 1e-6


def _iter_shapes(shapes):
    """All shapes of a slide, group members included, depth-first."""
    for shape in shapes:
        if getattr(shape, 'shape_type', None) == MSO_SHAPE_TYPE.GROUP:
            yield from _iter_shapes(shape.shapes)
        else:
            yield shape


def _paragraph_size(paragraph):
    """Explicit point size of a paragraph (max over runs), or None."""
    sizes = []
    for run in paragraph.runs:
        size = run.font.size
        if size is not None:
            sizes.append(float(size.pt))
    if sizes:
        return max(sizes)
    size = paragraph.font.size
    return float(size.pt) if size is not None else None


def _paragraph_text(paragraph):
    """Collapsed text of a paragraph."""
    return ' '.join(''.join(run.text for run in paragraph.runs).split())


def _has_word(text):
    """True when the text carries at least one letter."""
    return any(ch.isalpha() for ch in text)


def _iter_slide_paragraphs(slide):
    """Text paragraphs of one slide, table cells included."""
    for shape in _iter_shapes(slide.shapes):
        if getattr(shape, 'has_text_frame', False):
            yield from shape.text_frame.paragraphs
        if getattr(shape, 'has_table', False):
            for row in shape.table.rows:
                for cell in row.cells:
                    yield from cell.text_frame.paragraphs


def slide_title(slide):
    """Dominant heading of one slide: the largest alphabetic text, or ''.

    Pure digits/punctuation (slide numbers, the 60 pt section number) never
    win, so a divider's number cannot shadow its header.
    """
    best_size = None
    best_text = ''
    for paragraph in _iter_slide_paragraphs(slide):
        text = _paragraph_text(paragraph)
        if not text or not _has_word(text):
            continue
        size = _paragraph_size(paragraph)
        if size is None:
            continue
        if best_size is None or size > best_size + _MIN_SIZE_EPS:
            best_size = size
            best_text = text
    return best_text


def deck_titles(path):
    """Dominant heading of every slide of a .pptx deck, in slide order."""
    presentation = Presentation(str(path))
    return [slide_title(slide) for slide in presentation.slides]


def _norm(text):
    """Case/whitespace-independent form of a heading."""
    return ' '.join(str(text or '').split()).casefold()


def _matched(title, titles):
    """Containment-tolerant match of one heading against a title list."""
    needle = _norm(title)
    if not needle:
        return True
    for other in titles:
        hay = _norm(other)
        if needle == hay or needle in hay or hay in needle:
            return True
    return False


def compare_decks(baseline_path, candidate_path):
    """Compare heading structure of two decks; returns a report dict.

    Keys: ``ok`` (no baseline heading lost), ``baseline_slides``,
    ``candidate_slides``, ``missing``, ``added``, ``warnings`` (empty),
    ``baseline_path``, ``candidate_path``.
    """
    baseline_path = Path(baseline_path)
    candidate_path = Path(candidate_path)
    base_titles = deck_titles(baseline_path)
    cand_titles = deck_titles(candidate_path)
    missing = []
    for title in base_titles:
        if (_norm(title) and not _matched(title, cand_titles)
                and title not in missing):
            missing.append(title)
    added = []
    for title in cand_titles:
        if (_norm(title) and not _matched(title, base_titles)
                and title not in added):
            added.append(title)
    return {
        'ok': not missing,
        'baseline_slides': len(base_titles),
        'candidate_slides': len(cand_titles),
        'missing': missing,
        'added': added,
        'warnings': [],
        'baseline_path': str(baseline_path),
        'candidate_path': str(candidate_path),
    }
