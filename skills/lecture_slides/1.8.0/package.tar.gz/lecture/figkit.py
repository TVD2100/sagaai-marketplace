"""Figure layout kit: self-auditing composition of lecture illustrations.

Illustrations are assembled programmatically (matplotlib patches + real
font metrics) instead of hand-placed: ``Canvas.save()`` returns a list of
layout problems - text spilling out of its box, elements leaving the canvas,
overlapping captions, ink touching the bitmap border. This is the
countermeasure for the classic defect "captions run off the plate or overlap
each other", which slide-level QA cannot see because it only inspects
PowerPoint text boxes, not the pixels of a picture.

Public API:

- ``palette(theme)`` - deck palette as ``#RRGGBB`` strings; keys match
  ``lecture.themes.get_theme`` plus ``soft`` (= ``accent_soft``) and four
  chart accents (``green``, ``orange``, ``red``, ``violet``).
- ``Canvas(w_in, h_in, theme=..., dpi=...)`` - one figure with drawing
  helpers ``rect``, ``circ``, ``arrow``, ``line``, ``multiline``,
  ``boxtext``, ``label``; ``save(path)`` writes the PNG and returns the
  ``problems`` list.
- ``check_border(path, edge_px=3, thresh=200)`` - ink next to the bitmap
  border (a cheap catch-all for anything drawn past the edge).
- ``audit_fig(fig, inter_frac=0.25, only_gid='annot')`` - for hand-made
  matplotlib charts: checks overlaps between texts tagged with
  ``gid='annot'`` (axis ticks are skipped on purpose, they are dense but
  never overlap).

Coordinates are axes fractions: (0, 0) is the bottom-left corner, (1, 1) the
top-right (``ax.set_xlim(0, 1)``). Font sizes are typographic points (72 pt =
1 inch), so captions keep their physical size regardless of the canvas size.
No network access; matplotlib runs on the Agg backend.
"""

from __future__ import annotations

from pathlib import Path

from . import textfit, themes

# Short font keys used by figure scripts -> textfit font roles.
FONT_ROLES = {
    'r': 'arial',
    'b': 'arial_bold',
    'g': 'georgia',
    'gb': 'georgia_bold',
    'm': 'courier',
    'mb': 'courier_bold',
}

# Extra accents for charts (semantic colors: good / warning / risk / special).
EXTRA_COLORS = {
    'green': '#2E7D5B',
    'orange': '#C77400',
    'red': '#B23A48',
    'violet': '#6B4FA0',
}

_FP_CACHE = {}
_PATCHES = None


def _hex(value):
    """'RRGGBB' / '#RRGGBB' -> '#RRGGBB' (always with a leading hash)."""
    text = str(value or '').strip().lstrip('#')
    return '#' + (text or '000000')


def palette(theme=None):
    """Deck palette for illustrations; keys usable as ``canvas.colors[...]``."""
    raw = themes.get_theme(theme or themes.DEFAULT_THEME)
    colors = {key: _hex(value) for key, value in raw.items()}
    colors['soft'] = colors.get('accent_soft', colors.get('card', colors.get('bg')))
    colors['white'] = '#FFFFFF'
    for key, value in EXTRA_COLORS.items():
        colors.setdefault(key, value)
    return colors


def _pyplot():
    """Import matplotlib with the Agg backend (idempotent)."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        matplotlib.rcParams['axes.unicode_minus'] = False
    except Exception:  # noqa: BLE001 - cosmetic setting only
        pass
    return plt


def _patches():
    """Lazily import and cache the matplotlib patch classes."""
    global _PATCHES
    if _PATCHES is None:
        from matplotlib.patches import Ellipse, FancyArrowPatch, FancyBboxPatch
        _PATCHES = (FancyBboxPatch, FancyArrowPatch, Ellipse)
    return _PATCHES


def _font_props(key):
    """Cache a FontProperties for a short font key ('r', 'gb', ...)."""
    role = FONT_ROLES.get(str(key or 'r').lower(), 'arial')
    if role not in _FP_CACHE:
        from matplotlib.font_manager import FontProperties
        path = textfit.font_path(role)
        if path:
            try:
                from matplotlib import font_manager as fm
                fm.fontManager.addfont(path)
            except Exception:  # noqa: BLE001 - registration improves matching only
                pass
            _FP_CACHE[role] = FontProperties(fname=path)
        else:
            _FP_CACHE[role] = FontProperties(family='DejaVu Sans')
    return _FP_CACHE[role]


def wrap(text, key, size_pt, max_width_in):
    """Greedy word wrap in figure units (inches); returns visual lines."""
    role = FONT_ROLES.get(str(key or 'r').lower(), 'arial')
    return textfit.wrap(text, role, size_pt, max_width_in)


def text_width(text, key, size_pt):
    """Width of a single line in inches (safety factor included)."""
    role = FONT_ROLES.get(str(key or 'r').lower(), 'arial')
    return textfit.measure_in(text, role, size_pt)


def flatten(image):
    """Return a bitmap composited over white (transparent PNGs included).

    Alpha channels must be flattened before both the color count and the
    border scan: a raw RGB conversion would judge fully transparent pixels
    by their (usually black) color values.
    """
    from PIL import Image
    if image.mode in ('RGBA', 'LA', 'PA') or 'transparency' in image.info:
        rgba = image.convert('RGBA')
        background = Image.new('RGBA', rgba.size, (255, 255, 255, 255))
        return Image.alpha_composite(background, rgba).convert('RGB')
    return image.convert('RGB')


def check_border(path, edge_px=3, thresh=200):
    """Return a problem string when 'ink' touches the PNG border, else None.

    Works on the saved bitmap, so it catches graphics that silently extend
    past the canvas. ``thresh`` is the per-channel darkness threshold; on
    dark backgrounds pass ``border=False`` to ``save()`` instead.
    """
    try:
        import numpy as np
        from PIL import Image
    except Exception:  # noqa: BLE001 - optional dependency chain
        return None
    try:
        with Image.open(str(path)) as image:
            array = np.asarray(flatten(image))
    except Exception:  # noqa: BLE001 - unreadable bitmap cannot be audited
        return None
    edge_px = max(1, int(edge_px))
    mask = array.min(axis=2) < int(thresh)
    count = int(mask[:edge_px, :].sum() + mask[-edge_px:, :].sum()
                + mask[:, :edge_px].sum() + mask[:, -edge_px:].sum())
    if count == 0:
        return None
    return 'border ink: %d px' % count


def audit_fig(fig, inter_frac=0.25, only_gid='annot'):
    """Check overlaps between tagged texts of a hand-made matplotlib figure.

    Only texts with ``set_gid(only_gid)`` are inspected (axis ticks and
    labels are skipped on purpose); pass ``only_gid=None`` to audit all
    texts. Returns a list of problem strings (empty = clean).
    """
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    import matplotlib.text as mtext
    seen, boxes = set(), []
    for text in fig.findobj(mtext.Text):
        if only_gid is not None and str(text.get_gid() or '') != str(only_gid):
            continue
        value = str(text.get_text())
        if not value.strip() or id(text) in seen:
            continue
        seen.add(id(text))
        try:
            box = text.get_window_extent(renderer=renderer)
        except Exception:  # noqa: BLE001 - a broken artist cannot be measured
            continue
        if box.width <= 0 or box.height <= 0:
            continue
        boxes.append((value[:40], box.x0, box.y0, box.x1, box.y1))
    problems = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            first, second = boxes[i], boxes[j]
            ix = min(first[3], second[3]) - max(first[1], second[1])
            iy = min(first[4], second[4]) - max(first[2], second[2])
            if ix <= 0 or iy <= 0:
                continue
            area = ix * iy
            smaller = min((first[3] - first[1]) * (first[4] - first[2]),
                          (second[3] - second[1]) * (second[4] - second[2]))
            if smaller > 0 and area / smaller > inter_frac:
                problems.append('text overlap: %r x %r' % (first[0], second[0]))
    return problems


class Canvas:
    """One illustration figure with measured text and a built-in audit."""

    def __init__(self, w_in, h_in, theme=None, dpi=160, bg=None):
        plt = _pyplot()
        self.W = float(w_in)
        self.H = float(h_in)
        self.dpi = int(dpi or 160)
        self.colors = palette(theme)
        self.fig = plt.figure(figsize=(self.W, self.H), dpi=self.dpi)
        self.ax = self.fig.add_axes([0, 0, 1, 1])
        self.ax.set_xlim(0, 1)
        self.ax.set_ylim(0, 1)
        self.ax.set_axis_off()
        self.fig.patch.set_facecolor(bg or self.colors['bg'])
        self.items = []      # measured text boxes ('t', x0, y0, x1, y1)
        self.problems = []   # issues found while drawing (bounds checks)

    # ─────────────────────────── shapes ────────────────────────────

    def rect(self, x, y, w, h, fc=None, ec=None, lw=1.0, r=0.02, z=2, track=False):
        """Rounded rectangle; ``track=True`` adds it to overlap auditing."""
        FancyBboxPatch, _, _ = _patches()
        patch = FancyBboxPatch((x, y), w, h,
                               boxstyle='round,pad=0,rounding_size=%s' % r,
                               fc=(fc if fc else self.colors['card']),
                               ec=(ec if ec else 'none'), lw=lw, zorder=z)
        self.ax.add_patch(patch)
        if track:
            self.items.append(('s', x, y, x + w, y + h))
        return patch

    def circ(self, cx, cy, rx, ry=None, fc=None, ec=None, lw=0.9, z=3, track=False):
        """Ellipse centered at (cx, cy); radii are axes fractions."""
        _, _, Ellipse = _patches()
        patch = Ellipse((cx, cy), 2 * rx, 2 * (ry if ry else rx),
                        fc=(fc if fc else self.colors['soft']),
                        ec=(ec if ec else 'none'), lw=lw, zorder=z)
        self.ax.add_patch(patch)
        if track:
            self.items.append(('s', cx - rx, cy - (ry or rx), cx + rx, cy + (ry or rx)))
        return patch

    def arrow(self, x0, y0, x1, y1, color=None, lw=1.7, ms=10, rad=0.0, z=3, ls='-'):
        """Straight or arc connection with an arrow head."""
        _, FancyArrowPatch, _ = _patches()
        patch = FancyArrowPatch(
            (x0, y0), (x1, y1), arrowstyle='-|>', mutation_scale=ms, lw=lw,
            color=(color or self.colors['accent']),
            connectionstyle='arc3,rad=%s' % rad, zorder=z, linestyle=ls,
            shrinkA=0, shrinkB=0)
        self.ax.add_patch(patch)
        return patch

    def line(self, x0, y0, x1, y1, color=None, lw=1.2, z=1, ls='-'):
        """Thin connector line (defaults to the palette rule color)."""
        painter, = self.ax.plot([x0, x1], [y0, y1],
                                color=(color or self.colors['rule']), lw=lw,
                                zorder=z, linestyle=ls, solid_capstyle='round')
        return painter

    # ──────────────────────────── text ─────────────────────────────

    def multiline(self, x, y, lines, fs, key='r', color=None, align='center',
                  z=5, lh=1.24, bounds=None, check=True):
        """Centered multi-line block; measures every row for the audit.

        ``bounds`` = (x, y, w, h) in axes fractions: when a row does not fit
        inside, a problem is recorded (``check=False`` disables it).
        """
        lines = [str(line) for line in (lines or []) if str(line).strip()]
        if not lines:
            return
        n = len(lines)
        lh_in = fs * lh / 72.0
        y_top = y + n * lh_in / 2.0 / self.H
        row_boxes = []
        for i, line in enumerate(lines):
            row_y = y_top - (i + 0.5) * lh_in / self.H
            self.ax.text(x, row_y, line, fontproperties=_font_props(key),
                         fontsize=fs, color=(color or self.colors['ink']),
                         ha=align, va='center', zorder=z)
            line_w = text_width(line, key, fs) / self.W
            if align == 'center':
                x0 = x - line_w / 2.0
            elif align == 'right':
                x0 = x - line_w
            else:
                x0 = x
            box = (x0, row_y - lh_in / 2.0 / self.H, x0 + line_w, row_y + lh_in / 2.0 / self.H)
            row_boxes.append(box)
            self.items.append(('t',) + box)
        if bounds and check:
            bx, by, bw, bh = bounds
            if (min(b[0] for b in row_boxes) < bx - 1e-9
                    or max(b[2] for b in row_boxes) > bx + bw + 1e-9
                    or min(b[1] for b in row_boxes) < by - 1e-9
                    or max(b[3] for b in row_boxes) > by + bh + 1e-9):
                self.problems.append('text overflows box: %r' % lines[0][:48])

    def boxtext(self, x, y, w, h, text, fs=11, key='r', color=None, pad=0.012,
                fs_min=7.0, align='center', z=5, check=True):
        """Wrapped text fitted into a plate; returns the chosen font size.

        Shrinks the font in 0.5 pt steps until the wrapped block fits both the
        width and the height of the plate (never below ``fs_min``).
        """
        max_w = max(0.01, (w - 2 * pad)) * self.W
        size = float(fs)
        lines = wrap(text, key, size, max_w)
        while True:
            height = len(lines) * size * 1.24 / 72.0
            fits_w = all(text_width(line, key, size) <= max_w for line in lines)
            if (height <= (h - 2 * pad) * self.H and fits_w) or size <= fs_min:
                break
            size = max(float(fs_min), size - 0.5)
            lines = wrap(text, key, size, max_w)
        self.multiline(x + w / 2.0, y + h / 2.0, lines, size, key, color, align, z,
                       bounds=(x + pad, y + pad, w - 2 * pad, h - 2 * pad),
                       check=check)
        return size

    def label(self, x, y, text, fs=10, key='r', color=None, ha='center',
              va='center', z=6, bounds=None, check=True):
        """Single-line label; records its box and checks optional bounds."""
        text = str(text)
        self.ax.text(x, y, text, fontproperties=_font_props(key), fontsize=fs,
                     color=(color or self.colors['ink']), ha=ha, va=va, zorder=z)
        line_w = text_width(text, key, fs) / self.W
        line_h = fs * 1.24 / 72.0 / self.H
        if ha == 'center':
            x0 = x - line_w / 2.0
        elif ha == 'right':
            x0 = x - line_w
        else:
            x0 = x
        if va == 'center':
            y0 = y - line_h / 2.0
        elif va == 'top':
            y0 = y - line_h
        else:
            y0 = y
        self.items.append(('t', x0, y0, x0 + line_w, y0 + line_h))
        if bounds and check:
            bx, by, bw, bh = bounds
            if (x0 < bx - 1e-9 or x0 + line_w > bx + bw + 1e-9
                    or y0 < by - 1e-9 or y0 + line_h > by + bh + 1e-9):
                self.problems.append('label overflows: %r' % text[:48])

    # ──────────────────────────── audit ────────────────────────────

    def save(self, path, margin=0.008, inter_frac=0.05, border=True,
             edge_px=3, thresh=200):
        """Save the PNG, close the figure and return the problems list.

        Checks: every measured text inside the canvas margin; pairwise
        overlaps above ``inter_frac`` of the smaller box; optional border-ink
        scan of the saved bitmap (``border=False`` on dark backgrounds).
        """
        problems = list(self.problems)
        for _kind, x0, y0, x1, y1 in self.items:
            if (x0 < margin - 1e-9 or x1 > 1 - margin + 1e-9
                    or y0 < margin - 1e-9 or y1 > 1 - margin + 1e-9):
                problems.append('out of canvas: %.3f %.3f %.3f %.3f' % (x0, y0, x1, y1))
        for i in range(len(self.items)):
            for j in range(i + 1, len(self.items)):
                first, second = self.items[i], self.items[j]
                ix = min(first[3], second[3]) - max(first[1], second[1])
                iy = min(first[4], second[4]) - max(first[2], second[2])
                if ix <= 0 or iy <= 0:
                    continue
                area = ix * iy
                smaller = min((first[3] - first[1]) * (first[4] - first[2]),
                              (second[3] - second[1]) * (second[4] - second[2]))
                if smaller > 0 and area / smaller > inter_frac:
                    problems.append('overlap %d x %d (%.2f)' % (i, j, area / smaller))
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.fig.savefig(str(path), dpi=self.dpi, facecolor=self.colors['bg'])
        _pyplot().close(self.fig)
        if border:
            issue = check_border(path, edge_px=edge_px, thresh=thresh)
            if issue:
                problems.append(issue)
        return problems
