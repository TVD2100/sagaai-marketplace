"""Text metrics (PIL) and WCAG contrast helpers for the deck builder.

Why this module exists: python-pptx exposes no text measurement, yet the
builders must (a) predict the height of wrapped paragraphs to stack blocks,
(b) auto-fit code listings, and (c) let QA report overflow before the deck is
opened in PowerPoint. Measurements use real font files (Arial / Georgia /
Courier New on macOS; Liberation or the DejaVu fonts bundled with matplotlib
elsewhere).

Units: font sizes in points; widths and heights in inches. Glyph coverage:
``missing_glyphs`` compares rendered masks against the font's ``.notdef``
box to flag characters a role's font cannot draw (QA picture, not guessing).

Metric compatibility: ``metric_status`` / ``metrics_report`` declare whether
the local TTF resolved for a role has the same advance widths as the face
PowerPoint renders ('yes'/'no'/'unknown'). Incompatible local faces get the
larger ``SAFETY_APPROX`` width margin and a QA warning that the fit check is
approximate - the overflow verdict must never silently pass as reliable.
"""

from __future__ import annotations

from pathlib import Path

from PIL import ImageFont

DPI = 96.0
SAFETY = 1.04              # width safety factor for PowerPoint vs PIL rendering
SAFETY_APPROX = 1.12       # enlarged margin when the local face is not metric-compatible
LINE_FALLBACK = 1.24       # line height / font size when metrics are unavailable

_FONT_CANDIDATES = {
    'arial': [
        '/System/Library/Fonts/Supplemental/Arial.ttf',
        '/Library/Fonts/Arial.ttf',
        '/usr/share/fonts/truetype/msttcorefonts/Arial.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
    ],
    'arial_bold': [
        '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
        '/Library/Fonts/Arial Bold.ttf',
        '/usr/share/fonts/truetype/msttcorefonts/Arial_Bold.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
    ],
    'georgia': [
        '/System/Library/Fonts/Supplemental/Georgia.ttf',
        '/Library/Fonts/Georgia.ttf',
        '/usr/share/fonts/truetype/msttcorefonts/Georgia.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf',
    ],
    'georgia_bold': [
        '/System/Library/Fonts/Supplemental/Georgia Bold.ttf',
        '/Library/Fonts/Georgia Bold.ttf',
        '/usr/share/fonts/truetype/msttcorefonts/Georgia_Bold.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf',
    ],
    'courier': [
        '/System/Library/Fonts/Supplemental/Courier New.ttf',
        '/Library/Fonts/Courier New.ttf',
        '/usr/share/fonts/truetype/msttcorefonts/Courier_New.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf',
    ],
    'courier_bold': [
        '/System/Library/Fonts/Supplemental/Courier New Bold.ttf',
        '/Library/Fonts/Courier New Bold.ttf',
        '/usr/share/fonts/truetype/msttcorefonts/Courier_New_Bold.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf',
    ],
}

_FALLBACK_KEYS = {
    'arial': 'regular',
    'arial_bold': 'bold',
    'georgia': 'serif',
    'georgia_bold': 'serif_bold',
    'courier': 'mono',
    'courier_bold': 'mono_bold',
}

ROLE_FACES = {
    'arial': 'Arial',
    'arial_bold': 'Arial Bold',
    'georgia': 'Georgia',
    'georgia_bold': 'Georgia Bold',
    'courier': 'Courier New',
    'courier_bold': 'Courier New Bold',
}

# Metric compatibility of a local TTF against the face PowerPoint renders.
# The first matching marker wins; anything unmatched is judged 'unknown'
# (see metric_status) - never silently trusted as exact.
_COMPAT_RULES = (
    ('dejavu', 'no'),            # substituted rendering: different advance widths
    ('liberationserif', 'no'),   # Times-metric face, used for Georgia on Linux
    ('liberationsans', 'yes'),   # metric-compatible with Arial
    ('liberationmono', 'yes'),   # metric-compatible with Courier New
    ('liberation', 'unknown'),
    ('arial', 'yes'),
    ('georgia', 'yes'),
    ('courier', 'yes'),
)

_PATH_CACHE = {}
_FONT_CACHE = {}


def _fallback_paths():
    """DejaVu font paths shipped with matplotlib (always present when plotted)."""
    try:
        import matplotlib
        base = Path(matplotlib.get_data_path()) / 'fonts' / 'ttf'
    except Exception:
        return {}
    return {
        'regular': base / 'DejaVuSans.ttf',
        'bold': base / 'DejaVuSans-Bold.ttf',
        'serif': base / 'DejaVuSerif.ttf',
        'serif_bold': base / 'DejaVuSerif-Bold.ttf',
        'mono': base / 'DejaVuSansMono.ttf',
        'mono_bold': base / 'DejaVuSansMono-Bold.ttf',
    }


def font_path(role):
    """Resolve a font role ('arial', 'georgia_bold', 'courier', ...) to a TTF path."""
    if role in _PATH_CACHE:
        return _PATH_CACHE[role]
    path = None
    for candidate in _FONT_CANDIDATES.get(role, ()):
        if Path(candidate).exists():
            path = candidate
            break
    if path is None:
        fallback = _fallback_paths().get(_FALLBACK_KEYS.get(role, 'regular'))
        if fallback and Path(fallback).exists():
            path = str(fallback)
    _PATH_CACHE[role] = path
    return path


def resolved_fonts():
    """Return a {role: path-or-None} report of the fonts actually used."""
    return {role: font_path(role) for role in _FONT_CANDIDATES}


def metric_status(role):
    """Compatibility of the resolved TTF face with the rendered face.

    'yes' - the local file is (or is metric-compatible with) the face
    PowerPoint renders for this role; 'no' - a substituted face with
    different advance widths (DejaVu fallback, Liberation Serif for
    Georgia); 'unknown' - any other local file. Only 'yes' makes the
    overflow verdict exact.
    """
    path = font_path(role)
    if not path:
        return 'unknown'
    name = Path(str(path)).name.lower()
    for marker, status in _COMPAT_RULES:
        if marker in name:
            return status
    return 'unknown'


def safety_factor(role):
    """Width safety factor for a role: the base one, enlarged when unsure."""
    return SAFETY_APPROX if metric_status(role) in ('no', 'unknown') else SAFETY


def metrics_report():
    """Per-role font-metric report: {role: {font, face, status}}.

    ``face`` is the typeface name written into the PPTX run properties;
    ``font`` is the local TTF measurements were taken from.
    """
    report = {}
    for role in _FONT_CANDIDATES:
        path = font_path(role)
        report[role] = {
            'font': path or '',
            'face': ROLE_FACES.get(role, role),
            'status': metric_status(role),
        }
    return report


def load_font(role, size_pt):
    """Load (and cache) a PIL font for a role at a size given in points."""
    px = max(6, int(round(float(size_pt) * DPI / 72.0)))
    key = (role, px)
    if key not in _FONT_CACHE:
        path = font_path(role)
        if path:
            _FONT_CACHE[key] = ImageFont.truetype(path, px)
        else:
            try:
                _FONT_CACHE[key] = ImageFont.load_default(px)
            except TypeError:  # very old Pillow
                _FONT_CACHE[key] = ImageFont.load_default()
    return _FONT_CACHE[key]


def measure_in(text, role, size_pt):
    """Width of a single line of text in inches."""
    if not text:
        return 0.0
    return load_font(role, size_pt).getlength(str(text)) / DPI * safety_factor(role)


def line_height_in(role, size_pt):
    """Height of one text line in inches (from font metrics when available)."""
    font = load_font(role, size_pt)
    try:
        ascent, descent = font.getmetrics()
        return (ascent + descent) / DPI
    except Exception:
        return float(size_pt) * LINE_FALLBACK / 72.0


def height_in(n_lines, role, size_pt):
    """Height of ``n_lines`` text lines in inches."""
    if n_lines <= 0:
        return 0.0
    return n_lines * line_height_in(role, size_pt)


def _split_long_word(word, role, size_pt, max_width_in):
    """Hard-break a word that cannot fit on one line."""
    chunks = []
    current = ''
    for char in word:
        trial = current + char
        if current and measure_in(trial, role, size_pt) > max_width_in:
            chunks.append(current)
            current = char
        else:
            current = trial
    if current:
        chunks.append(current)
    return chunks


def wrap(text, role, size_pt, max_width_in):
    """Greedy word wrap; returns the list of visual lines.

    Words longer than the line width are hard-broken so that the estimate
    stays honest for long identifiers and URLs.
    """
    text = str(text or '').strip()
    if not text:
        return []
    max_width_in = max(0.25, float(max_width_in))
    lines = []
    current = ''
    for word in text.split():
        trial = word if not current else current + ' ' + word
        if measure_in(trial, role, size_pt) <= max_width_in:
            current = trial
            continue
        if current:
            lines.append(current)
            current = ''
        if measure_in(word, role, size_pt) <= max_width_in:
            current = word
        else:
            chunks = _split_long_word(word, role, size_pt, max_width_in)
            lines.extend(chunks[:-1])
            current = chunks[-1] if chunks else ''
    if current:
        lines.append(current)
    return lines


def n_lines(text, role, size_pt, max_width_in):
    """Number of wrapped lines for a text run (>= 1 for non-empty text)."""
    if not str(text or '').strip():
        return 0
    return max(1, len(wrap(text, role, size_pt, max_width_in)))


def fit_size(texts, role, size_pt, max_width_in, max_height_in, min_size_pt):
    """Largest size <= size_pt at which the texts fit the given box.

    ``texts`` is a list of paragraphs. Returns the chosen size (never below
    ``min_size_pt``; the caller decides what to do if it still overflows).
    """
    size = float(size_pt)
    while size > min_size_pt:
        total = sum(height_in(n_lines(t, role, size, max_width_in), role, size)
                    for t in texts)
        widest = max((measure_in(t, role, size) for t in texts), default=0.0)
        if total <= max_height_in and widest <= max_width_in:
            break
        size = round(size - 0.5, 2)
    return max(size, float(min_size_pt))


# ───────────────────────────── WCAG contrast ──────────────────────────────

def overflow(need_h, box_h, min_slack=0.03, rel_slack=0.08):
    """True when a recorded content need exceeds its box beyond slack.

    Layout records often carry needs computed with line-spacing factors while
    boxes are sized from bare line heights, so a small relative slack is
    applied to avoid false positives; ``need_h=None`` means unknown height
    and is never treated as overflow.
    """
    if need_h is None:
        return False
    box_h = float(box_h or 0.0)
    return float(need_h) > box_h + max(float(min_slack), float(rel_slack) * box_h)


def hex_to_rgb(color):
    """'RRGGBB' / '#RRGGBB' -> (r, g, b) integers."""
    text = str(color or '').strip().lstrip('#')
    if len(text) == 3:
        text = ''.join(ch * 2 for ch in text)
    if len(text) != 6:
        return (0, 0, 0)
    try:
        return tuple(int(text[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return (0, 0, 0)


def relative_luminance(color):
    """WCAG relative luminance of a hex color."""
    def channel(value):
        value = value / 255.0
        return value / 12.92 if value <= 0.03928 else ((value + 0.055) / 1.055) ** 2.4
    r, g, b = hex_to_rgb(color)
    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)


def contrast_ratio(foreground, background):
    """WCAG contrast ratio between two hex colors (1.0 .. 21.0)."""
    first = relative_luminance(foreground)
    second = relative_luminance(background)
    high, low = max(first, second), min(first, second)
    return (high + 0.05) / (low + 0.05)


# ------------------------------ glyph coverage ------------------------------

MISSING_GLYPH_CHAR = chr(0xE000)  # Private Use Area; no text font maps it
GLYPH_AUDIT_PT = 32.0
_GLYPH_CACHE = {}


def _glyph_signature(role, char):
    """Cached (mask size, mask bytes) of one character; None when unavailable."""
    key = (role, char)
    if key not in _GLYPH_CACHE:
        try:
            mask = load_font(role, GLYPH_AUDIT_PT).getmask(char)
            _GLYPH_CACHE[key] = (tuple(mask.size), bytes(mask))
        except Exception:  # noqa: BLE001 - any rendering failure means 'cannot judge'
            _GLYPH_CACHE[key] = None
    return _GLYPH_CACHE[key]


def missing_glyphs(text, role):
    """Characters of ``text`` that the font resolved for ``role`` cannot draw.

    A character is reported when its rendered mask equals the mask of the
    guaranteed-missing reference U+E000 (the font's ``.notdef`` box). Plain
    whitespace and blank masks are skipped, so only visible "tofu"
    candidates come back - unique, in first-seen order.
    """
    reference = _glyph_signature(role, MISSING_GLYPH_CHAR)
    if not reference or not reference[1]:
        return []
    missing = []
    seen = set()
    for char in str(text or ''):
        if char in seen or char.isspace():
            continue
        seen.add(char)
        if _glyph_signature(role, char) == reference:
            missing.append(char)
    return missing
