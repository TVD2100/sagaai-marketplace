"""APA 7th references for lecture sources and in-text citations.

A lecture deck that states a case, quotes a text or reports a figure must
let the audience verify it: the claim carries a clickable reference in the
same bullet, paragraph or caption, formatted as an APA 7th in-text
citation. Sources taken from the open web get a hyperlink; sources taken
from an internal knowledge base (RAG) keep the APA wording but carry no
link, because the audience cannot reach them.

The module works on the ``meta.sources`` registry of a spec:

    {"id": "press2007", "kind": "book",
     "authors": ["Press, W. H."], "year": 2007,
     "title": "Numerical Recipes", "publisher": "Cambridge University Press",
     "url": "https://numerical.recipes/"}

Optional APA fields: ``authors`` (string or list), ``year`` (int or
string), ``container`` (journal or site name), ``volume``, ``issue``,
``pages``, ``publisher``, ``doi``, ``url``, ``accessed`` (retrieval
date), ``internal`` (true for a knowledge-base document), ``rag_base``
(the knowledge-base slug), ``apa`` (a ready-made reference that replaces
the generated one).

Public helpers:

- ``normalize_entry`` - clean one registry entry, reporting problems;
- ``format_apa`` - the full reference for the literature slide;
- ``intext`` - the ``(Author, year)`` label used next to a claim;
- ``citation_markup`` - that label as clickable markup, or plain text for
  an internal source;
- ``expand_citations`` / ``expand_slide`` - replace ``[@id]`` markers with
  formatted citations;
- ``is_internal``, ``has_apa_caption``, ``find_quotes``,
  ``find_case_markers`` - predicates used by the QA pass.
"""

from __future__ import annotations

import re

# An inline citation marker: [@press2007] or [@press2007, с. 12].
CITATION_RE = re.compile(r'\[@([A-Za-z0-9_.:\-]+)(?:\s*,\s*([^\]\n]+))?\]')

# An APA in-text label: a short parenthetical expression whose last comma
# part is a year (2019, 2019a, б. г., n.d.) with an optional page suffix.
APA_INTEXT_RE = re.compile(
    r'\([^()\n]{1,120},\s*(?:\d{4}[a-z]?|б\.\s?г\.|n\.d\.)'
    r'(?:,\s*(?:с|стр|p|pp)\.\s*\d+[^()\n]*)?\)',
    re.IGNORECASE)

# Quoted speech: Russian angle quotes and ASCII double quotes.
QUOTE_RES = (
    re.compile(r'«[^«»\n]{3,400}»'),
    re.compile(r'"[^"\n]{3,400}"'),
)

# Case-study markers. Deliberately narrow: a plain example ('Пример:
# вычисление корня') is not a case and must not trigger the rule.
CASE_RE = re.compile(
    r'(?:\bкейс[а-яё]*|case[\s-]?stud(?:y|ies)|пример\s+компании|'
    r'пример\s+из\s+практики|из\s+опыта\s+компании)',
    re.IGNORECASE)

INTERNAL_KINDS = ('internal', 'rag', 'knowledge_base', 'knowledge-base')

SAFE_PREFIXES = ('http://', 'https://', 'mailto:')

MONTHS_RU = ('января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля',
             'августа', 'сентября', 'октября', 'ноября', 'декабря')
MONTHS_EN = ('January', 'February', 'March', 'April', 'May', 'June', 'July',
             'August', 'September', 'October', 'November', 'December')

NO_YEAR = {'ru': 'б. г.', 'en': 'n.d.'}
NO_AUTHOR = {'ru': 'Без автора', 'en': 'Anonymous'}
PAGE_PREFIX = {'ru': 'с.', 'en': 'p.'}


def _lang(lang):
    """Normalise a language code to 'ru' or 'en' (default 'ru')."""
    return 'en' if str(lang or '').strip().lower().startswith('en') else 'ru'


def safe_link(url):
    """True when a link may be embedded as a clickable hyperlink."""
    return str(url or '').strip().lower().startswith(SAFE_PREFIXES)


def is_internal(entry):
    """True for a source that lives in an internal knowledge base (RAG)."""
    if not isinstance(entry, dict):
        return False
    if entry.get('internal') is True:
        return True
    kind = str(entry.get('kind') or '').strip().lower()
    return kind in INTERNAL_KINDS


def has_apa_data(entry):
    """True when the entry carries data for an APA reference.

    A legacy registry entry with only ``title`` and ``url`` keeps the
    pre-APA rendering, so existing decks do not change appearance.
    """
    if not isinstance(entry, dict):
        return False
    return bool(entry.get('apa') or entry.get('authors') or entry.get('year'))


def doi_url(entry):
    """Resolvable https URL for the entry: ``url`` first, then ``doi``."""
    if not isinstance(entry, dict):
        return ''
    url = str(entry.get('url') or '').strip()
    if safe_link(url) and not is_internal(entry):
        return url
    doi = str(entry.get('doi') or '').strip()
    if doi and not is_internal(entry):
        doi = re.sub(r'^(?:https?://(?:dx\.)?doi\.org/|doi:)', '', doi)
        candidate = 'https://doi.org/' + doi
        if safe_link(candidate):
            return candidate
    return ''


# ─────────────────────────── normalisation ───────────────────────────

def _as_text(value):
    """Trimmed string for a scalar field, '' when absent."""
    if value is None:
        return ''
    return str(value).strip()


def _authors(value, warnings=None, where=''):
    """Normalise ``authors`` into a list of non-empty strings."""
    if value is None:
        return []
    if isinstance(value, str):
        items = [value]
    elif isinstance(value, (list, tuple)):
        items = list(value)
    else:
        if warnings is not None:
            warnings.append(where + ": 'authors' must be a string or a list; ignored")
        return []
    out = []
    for item in items:
        text = _as_text(item)
        if text:
            out.append(text)
        elif warnings is not None:
            warnings.append(where + ": 'authors' items must be non-empty strings; skipped")
    return out


def normalize_entry(entry, warnings=None, where='source'):
    """Return the entry with clean APA fields; collect problems in warnings.

    Unknown keys are preserved (the spec may carry its own metadata), but
    every known APA field is normalised to the expected type. A ``year``
    may be an int or a string; ``internal`` is a strict boolean.
    """
    if not isinstance(entry, dict):
        return {}
    clean = dict(entry)
    notes = warnings if warnings is not None else []

    if 'authors' in entry:
        authors = _authors(entry.get('authors'), notes, where)
        if authors:
            clean['authors'] = authors
        else:
            clean.pop('authors', None)

    if 'year' in entry:
        year = entry.get('year')
        if isinstance(year, bool) or year is None:
            notes.append(where + ": 'year' must be a number or a string; ignored")
            clean.pop('year', None)
        elif isinstance(year, int):
            clean['year'] = str(year)
        else:
            text = _as_text(year)
            if text:
                clean['year'] = text
            else:
                clean.pop('year', None)

    for key in ('container', 'volume', 'issue', 'pages', 'publisher', 'doi',
                'accessed', 'rag_base', 'apa'):
        if key not in entry:
            continue
        text = _as_text(entry.get(key))
        if text:
            clean[key] = text
        else:
            clean.pop(key, None)

    if 'internal' in entry:
        clean['internal'] = bool(entry.get('internal'))

    return clean


# ─────────────────────────── author and year ───────────────────────────

def apa_author(name):
    """Rewrite ``Ivanov I. I.`` as ``Ivanov, I. I.``; keep APA input as is.

    The surname may consist of several words; trailing initials are
    collected into the post-comma part ('van der Berg J.' ->
    'van der Berg, J.'). Input that already has a comma is returned as is.
    """
    text = _as_text(name)
    if not text or ',' in text:
        return text
    parts = text.split()
    if len(parts) < 2:
        return text
    initials = []
    while len(parts) > 1 and re.fullmatch(r'(?:[A-Za-zА-Яа-яЁё]\.)+', parts[-1]):
        initials.insert(0, parts.pop())
    if not initials:
        return text
    return '%s, %s' % (' '.join(parts), ' '.join(initials))


def _author_list(entry):
    """APA-formatted authors of the entry (possibly empty)."""
    if not isinstance(entry, dict):
        return []
    return [apa_author(name) for name in _authors(entry.get('authors'))]


def _join_authors(authors, lang):
    """Join APA author strings with the APA separator of the language."""
    if not authors:
        return ''
    if len(authors) == 1:
        return authors[0]
    if len(authors) > 20:
        authors = authors[:19] + ['...'] + [authors[-1]]
    if lang == 'en':
        head, last = authors[:-1], authors[-1]
        return ', '.join(head) + ', & ' + last
    return ', '.join(authors[:-1]) + ', и ' + authors[-1]


def _year(entry):
    """Year as written in the entry, '' when missing."""
    if not isinstance(entry, dict):
        return ''
    return _as_text(entry.get('year'))


def _year_label(entry, lang):
    """Year or the language-specific 'no date' marker."""
    return _year(entry) or NO_YEAR[lang]


def _first_surname(entry):
    """Surname of the first author, or '' when the entry has no authors."""
    authors = _author_list(entry)
    if not authors:
        return ''
    return authors[0].split(',')[0].strip()


def _short_title(entry, words=3):
    """First few words of the title, used when the entry has no author."""
    title = _as_text((entry or {}).get('title'))
    title = re.sub(r'[*`]', '', title)
    return ' '.join(title.split()[:words])


def _title(entry, markup=False):
    """Entry title, optionally wrapped in the italic markup."""
    title = _as_text((entry or {}).get('title'))
    if markup and title:
        return '*%s*' % title
    return title


def _container(entry, markup=False):
    """Journal or site name of the entry, optionally italicised."""
    text = _as_text((entry or {}).get('container'))
    if markup and text:
        return '*%s*' % text
    return text


# ─────────────────────────── in-text citation ───────────────────────────

def _page_suffix(page, lang):
    """Normalise a page argument into ``с. 12`` / ``p. 12``."""
    text = _as_text(page)
    if not text:
        return ''
    if re.match(r'^(?:с|стр|p|pp)\.', text, re.IGNORECASE):
        return text
    return '%s %s' % (PAGE_PREFIX[lang], text)


def intext(entry, lang='ru', page=None):
    """APA in-text label of the entry: ``(Иванов, 2007, с. 12)``.

    One author - the surname; two - both surnames joined with «и» (``&``
    in English); three and more - the first surname plus «и др.»
    (``et al.``). An entry without authors falls back to the short title
    in double quotes, as APA prescribes.
    """
    lang = _lang(lang)
    entry = entry if isinstance(entry, dict) else {}
    authors = _author_list(entry)
    year = _year_label(entry, lang)
    if not authors:
        short = _short_title(entry)
        if short:
            label = '"%s"' % short
        else:
            label = NO_AUTHOR[lang]
    elif len(authors) == 1:
        label = _first_surname(entry)
    elif len(authors) == 2:
        first = _first_surname(entry)
        second = authors[1].split(',')[0].strip()
        joiner = ' & ' if lang == 'en' else ' и '
        label = first + joiner + second
    else:
        label = _first_surname(entry) + (' et al.' if lang == 'en' else ' и др.')
    parts = [label, year]
    suffix = _page_suffix(page, lang)
    if suffix:
        parts.append(suffix)
    return '(%s)' % ', '.join(parts)


def citation_markup(entry, lang='ru', page=None):
    """In-text label as clickable markup, or plain text for internal data.

    An external source with a reachable URL or DOI becomes
    ``[(Author, year)](https://...)``; an internal knowledge-base source
    stays plain text, because the audience has no link to follow.
    """
    label = intext(entry, lang, page=page)
    url = doi_url(entry)
    if not url:
        return label
    return '[%s](%s)' % (label, url)


# ─────────────────────────── full reference ───────────────────────────

def _date_parts(entry, lang):
    """Parenthetical date of the entry: ``(2021, 15 марта)`` when known."""
    year = _year(entry)
    if not year:
        return '(%s)' % NO_YEAR[lang]
    raw = _as_text(entry.get('date'))
    match = re.match(r'^(\d{4})-(\d{2})-(\d{2})$', raw)
    if match and match.group(1) == year:
        month = int(match.group(2))
        day = int(match.group(3))
        if 1 <= month <= 12:
            names = MONTHS_EN if lang == 'en' else MONTHS_RU
            return '(%s, %d %s)' % (year, day, names[month - 1])
    return '(%s)' % year


def _internal_note(entry, lang):
    """Bracketed note that marks a source as internal and unlinkable."""
    base = _as_text(entry.get('rag_base'))
    if lang == 'en':
        note = '[Internal source, knowledge base "%s"]' % base if base \
            else '[Internal source]'
    else:
        note = '[Внутренний источник, база знаний «%s»]' % base if base \
            else '[Внутренний источник]'
    return note


def _volume_issue(entry, markup=False):
    """``12(3)`` part of a journal reference, '' when unknown.

    APA italicises the volume but not the issue, so the markup form is
    ``*12*(3)``.
    """
    volume = _as_text(entry.get('volume'))
    issue = _as_text(entry.get('issue'))
    if markup and volume:
        volume = '*%s*' % volume
    if volume and issue:
        return '%s(%s)' % (volume, issue)
    return volume or ''


def _kind(entry):
    """Lower-case source kind of the entry ('book', 'article', ...)."""
    return _as_text((entry or {}).get('kind')).lower()


def format_apa(entry, lang='ru', markup=False):
    """Full APA 7th reference of one registry entry.

    ``markup=True`` wraps the italic parts (book title, journal name and
    volume) in ``*...*`` so the deck renderer draws them in italics. A
    ready-made ``apa`` field, when present, replaces the generated text.
    Internal sources end with a bracketed note naming the knowledge base;
    they never carry a URL.
    """
    lang = _lang(lang)
    if not isinstance(entry, dict):
        return ''
    custom = _as_text(entry.get('apa'))
    if custom:
        return custom

    kind = _kind(entry)
    authors = _join_authors(_author_list(entry), lang)
    title = _title(entry, markup)
    date = _date_parts(entry, lang)
    container = _container(entry, markup)
    volume = _volume_issue(entry, markup)
    pages = _as_text(entry.get('pages'))
    publisher = _as_text(entry.get('publisher'))

    head_parts = []
    if authors:
        head_parts.append(authors)
    elif title:
        # No author: the title moves to the author position (APA 7).
        head_parts.append(title)
        title = ''
    head_parts.append(date)

    tail_parts = []
    if title:
        tail_parts.append(title)

    is_article = kind in ('article', 'journal', 'paper')
    if is_article and container:
        source = container
        if volume:
            source += ', ' + volume
        if pages:
            source += ', ' + pages
        tail_parts.append(source)
    else:
        if container:
            tail_parts.append(container)
        if publisher:
            tail_parts.append(publisher)
        if pages and not container:
            tail_parts.append(pages)

    if is_internal(entry):
        tail_parts.append(_internal_note(entry, lang))
    else:
        url = doi_url(entry)
        accessed = _as_text(entry.get('accessed'))
        if url and accessed and not _year(entry):
            prefix = 'Retrieved %s, from' % accessed if lang == 'en' \
                else 'Дата обращения: %s,' % accessed
            tail_parts.append('%s %s' % (prefix, url))
        elif url:
            tail_parts.append(url)

    # Authors and the parenthetical date are separated by a space: the
    # initials already end with periods ('Иванов, И. И. (2020)').
    text = ' '.join(part for part in head_parts if part)
    body = '. '.join(part for part in tail_parts if part)
    if body:
        text = text + '. ' + body if text else body
    text = text.strip()
    if text and not re.search(r'https?://\S+$', text) and not text.endswith('.'):
        text += '.'
    return text


# ─────────────────────────── citation markers ───────────────────────────

def source_index(sources):
    """Map source id to its registry entry."""
    index = {}
    for entry in sources or []:
        if isinstance(entry, dict) and entry.get('id'):
            index[str(entry['id'])] = entry
    return index


def expand_citations(text, sources, lang='ru'):
    """Replace ``[@id]`` markers with formatted APA citations.

    ``[@id]`` becomes the clickable in-text label for an external source
    and a plain label for an internal one; ``[@id, с. 12]`` adds the page.
    An unknown id is left untouched so the spec validation can report it.
    """
    raw = str(text or '')
    if '[@' not in raw:
        return raw
    index = source_index(sources)

    def _replace(match):
        sid = match.group(1)
        entry = index.get(sid)
        if entry is None:
            return match.group(0)
        return citation_markup(entry, lang, page=match.group(2))

    return CITATION_RE.sub(_replace, raw)


# Keys whose string values are not visible prose and keep their markers.
EXPAND_SKIP_KEYS = ('note', 'code', 'formula', 'language', 'path', 'type',
                    'source_refs', 'id', 'url', 'doi', 'apa', 'slug')


def expand_slide(slide, sources, lang='ru'):
    """Return the slide with every ``[@id]`` marker expanded in its texts."""
    if not isinstance(slide, dict):
        return slide

    def _walk(value, key=None):
        if isinstance(value, str):
            if key in EXPAND_SKIP_KEYS:
                return value
            return expand_citations(value, sources, lang)
        if isinstance(value, list):
            return [_walk(item, key) for item in value]
        if isinstance(value, dict):
            return {name: _walk(item, name) for name, item in value.items()}
        return value

    return _walk(slide)


# ─────────────────────────── QA predicates ───────────────────────────

def has_apa_caption(text):
    """True when the text carries an APA in-text label with a year."""
    return bool(APA_INTEXT_RE.search(str(text or '')))


def find_quotes(text):
    """Quoted fragments of a text (Russian angle or ASCII double quotes)."""
    raw = str(text or '')
    found = []
    for pattern in QUOTE_RES:
        for match in pattern.finditer(raw):
            value = match.group(0).strip()
            if value and value not in found:
                found.append(value)
    return found


def find_case_markers(text):
    """Case-study markers of a text ('кейс', 'case study', ...)."""
    raw = str(text or '')
    found = []
    for match in CASE_RE.finditer(raw):
        value = match.group(0).strip().lower()
        if value and value not in found:
            found.append(value)
    return found


def is_reference_text(text):
    """True when a literature item already looks like an APA reference."""
    raw = str(text or '').strip()
    if not raw:
        return False
    if not re.search(r'\(\d{4}[a-z]?\)|\(б\.\s?г\.\)|\(n\.d\.\)', raw):
        return False
    return bool(re.search(r'[.,]', raw))
