"""Artifact and source fingerprints: binding reports to exact bytes.

``sha256_file`` records the digest of a built artifact (the PPTX);
``source_fingerprint`` hashes the runtime sources that produced it
(``source_files`` = the entry points plus the ``lecture`` package). Any
source edit changes the fingerprint, so a QA report can always be traced
back to the exact code version behind it. Sources are read as bytes
(byte-exact, encoding-independent).
"""

from __future__ import annotations

import hashlib
from pathlib import Path

# Entry points at the skill root (see SKILL.md, 'Bundle map').
RUNTIME_FILES = ('build_lecture.py', 'qa_check.py', 'render_preview.py')
PACKAGE_DIR = 'lecture'
_CHUNK = 1 << 16


def sha256_file(path):
    """SHA-256 hex digest of a file's bytes (streamed, memory-friendly)."""
    digest = hashlib.sha256()
    with open(str(path), 'rb') as handle:
        for chunk in iter(lambda: handle.read(_CHUNK), b''):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data):
    """SHA-256 hex digest of a bytes object (in-memory builds)."""
    return hashlib.sha256(bytes(data)).hexdigest()


def source_files(root=None):
    """Runtime source files that determine the deck, in stable order.

    ``root`` defaults to the skill folder (two levels above this module);
    missing entries are skipped so the list stays tolerant to packaging.
    """
    base = Path(root) if root is not None else Path(__file__).resolve().parent.parent
    files = [base / name for name in RUNTIME_FILES]
    files.extend(sorted((base / PACKAGE_DIR).glob('*.py')))
    return [path for path in files if path.exists()]


def source_fingerprint(root=None):
    """Combined SHA-256 over ``source_files``: file names + contents."""
    digest = hashlib.sha256()
    for path in source_files(root):
        path = Path(path)
        digest.update(path.name.encode('utf-8'))
        digest.update(b'\x00')
        digest.update(path.read_bytes())
        digest.update(b'\x00')
    return digest.hexdigest()
