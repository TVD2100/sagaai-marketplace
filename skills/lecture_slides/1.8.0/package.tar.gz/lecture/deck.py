"""Deck builder: lecture spec -> python-pptx presentation.

``DeckBuilder`` owns the presentation, the theme palette, per-slide records
(used by QA) and the content engines shared by all slide types:

- ``text_block`` - bulleted/numbered/paragraph lists with auto-fit and
  wrap-aware height estimation (PIL metrics);
- ``concept_card`` - rounded card with an accent bar for definitions and
  theorems;
- ``formula_block`` - editable OMML by default, 300-dpi PNG reserve;
- ``code_block`` - pygments-highlighted listing with line numbers and
  auto-fit font size;
- ``table_block`` - native PowerPoint table with themed fills;
- ``image_block`` - scaled picture with caption and missing-file handling;
- ``block`` - dispatcher used by ``two_column``.

Every content box is recorded via ``record_box`` so ``lecture/qa.py`` can
check overflow, margins and minimum font sizes without parsing the PPTX.
Slide renderers live in ``lecture/slides.py`` and are imported lazily by
``build()`` to avoid an import cycle.
"""

from __future__ import annotations

import io
import re
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

from . import fingerprint, omml, render, textfit, themes
from . import apa
from .spec import SpecError, strip_markup, split_markup  # noqa: F401

# Font family -> textfit role used by the glyph-coverage audit (A5).
GLYPH_AUDIT_ROLES = {
    'Arial': 'arial',
    'Georgia': 'georgia',
    'Courier New': 'courier',
}

CONTENT_KINDS = ('text', 'formula', 'code', 'table', 'chart', 'image', 'cover',
                 'section', 'card')
MARGIN_KINDS = CONTENT_KINDS + ('header',)

# Spec chart_type -> python-pptx chart enum.
CHART_TYPE_ENUMS = {
    'bar': XL_CHART_TYPE.COLUMN_CLUSTERED,
    'line': XL_CHART_TYPE.LINE_MARKERS,
    'pie': XL_CHART_TYPE.PIE,
}

# Frame-filling layout: short lists and tables grow their inner
# spacing (never the font size) up to these caps, so the content does not
# hug the top of a tall frame while the gaps stay visually reasonable.
MAX_ITEM_PAD_IN = 0.42          # extra space_after per list item, inches
MAX_TABLE_ROW_PAD_IN = 0.5      # extra row height per table row, inches


def build_deck(spec, out_path=None, assets_dir=None, service_dir=True):
    """Build a presentation from a ``Spec``; returns a result dict.

    When ``out_path`` is given and ``assets_dir`` is not, the helper files go
    to ``<out_stem>_service/assets/`` so the deck folder itself holds only the
    artifacts (the pptx and the optional pdf). ``service_dir=False`` restores
    the older flat layout ``<out_stem>_assets/``.
    """
    if assets_dir is None:
        if out_path:
            out = Path(out_path)
            if service_dir:
                assets_dir = out.parent / (out.stem + '_service') / 'assets'
            else:
                assets_dir = out.parent / (out.stem + '_assets')
        else:
            assets_dir = Path(spec.base_dir) / 'lecture_assets'
    builder = DeckBuilder(spec, assets_dir=assets_dir)
    return builder.build(out_path=out_path)


class DeckBuilder:
    """Renders one lecture spec into a Presentation and collects QA records."""

    def __init__(self, spec, assets_dir=None):
        self.spec = spec
        self.pal = themes.get_theme(spec.theme)
        self.head_font, self.body_font, self.mono_font = themes.get_fonts(spec.theme)
        self.prs = Presentation()
        self.prs.slide_width = Inches(themes.SLIDE_W)
        self.prs.slide_height = Inches(themes.SLIDE_H)
        self.assets_dir = Path(assets_dir) if assets_dir else Path(spec.base_dir) / 'lecture_assets'
        self.records = []
        self.errors = []
        self.warnings = []
        self.asset_files = []
        self.missing_images = []
        self.formula_cache = {}
        self.formula_modes = {'omml': 0, 'image': 0}
        self.glyph_text = {}
        self.formula_no = 0
        self.section_no = 0
        self._slide_no = 0
        self.slide = None
        self.current = None

    # ────────────────────────── slide plumbing ──────────────────────────

    def new_slide(self, stype):
        """Add a blank slide and start a fresh record."""
        self.slide = self.prs.slides.add_slide(self.prs.slide_layouts[6])
        self._slide_no += 1
        self.current = {
            'index': self._slide_no,
            'type': stype,
            'boxes': [],
            'note_words': 0,
            'bullets': 0,
            'code_lines': 0,
            'formula_count': 0,
            'empty': True,
        }
        self.records.append(self.current)
        return self.slide

    def build(self, out_path=None):
        """Render every spec slide, save the pptx and return a result dict."""
        from . import slides as slides_module

        # Optional deterministic layout pass (meta.auto_layout): rewrite short
        # parallel bullet lists into visual types before anything is drawn.
        auto_layout = []
        if self.spec.meta_value('auto_layout'):
            from .layout_advisor import apply_auto_layout
            auto_layout = apply_auto_layout(self.spec)
            if auto_layout:
                self.warnings.extend(
                    'auto-layout: slide %s rewritten %s -> %s (%s)'
                    % (item['index'], item['from'], item['to'], item['reason'])
                    for item in auto_layout)

        total = len(self.spec.slides)
        sources = list((self.spec.meta or {}).get('sources') or [])
        lang = str((self.spec.meta or {}).get('lang') or 'ru')
        for idx, slide_data in enumerate(self.spec.slides, start=1):
            # APA markers ([@id]) become in-text citations at render time, so
            # the spec keeps the short id while the deck shows the reference.
            slide_data = apa.expand_slide(slide_data, sources, lang)
            stype = slide_data['type']
            self.new_slide(stype)
            renderer = slides_module.RENDERERS.get(stype)
            if renderer is None:
                self.errors.append('slide %d: no renderer for type %s' % (idx, stype))
                continue
            try:
                renderer(self, slide_data)
            except render.RenderError as exc:
                self.errors.extend('slide %d: %s' % (idx, message) for message in exc.errors)
            except Exception as exc:  # noqa: BLE001 - keep building the rest of the deck
                self.errors.append('slide %d (%s): %s: %s' % (idx, stype, type(exc).__name__, exc))
            if stype != 'title':
                try:
                    self.footer(idx, total)
                except Exception as exc:  # noqa: BLE001
                    self.errors.append('slide %d: footer failed: %s' % (idx, exc))
            note = str(slide_data.get('note') or '')
            self.current['note_words'] = len(note.split())
            if note:
                try:
                    self.slide.notes_slide.notes_text_frame.text = note
                except Exception as exc:  # noqa: BLE001
                    self.errors.append('slide %d: notes failed: %s' % (idx, exc))

        if out_path:
            out_path = Path(out_path)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            self.prs.save(str(out_path))
            artifact_sha256 = fingerprint.sha256_file(out_path)
        else:
            buffer = io.BytesIO()
            self.prs.save(buffer)
            artifact_sha256 = fingerprint.sha256_bytes(buffer.getvalue())
        words = sum(int(rec.get('note_words') or 0) for rec in self.records)
        return {
            'ok': not self.errors,
            'errors': list(self.errors),
            'warnings': list(self.warnings) + list(self.spec.warnings),
            'records': self.records,
            'auto_layout': list(auto_layout),
            'slides': len(self.records),
            'assets': list(self.asset_files),
            'missing_images': list(self.missing_images),
            'formula_modes': dict(self.formula_modes),
            'missing_glyphs': self._missing_glyphs(),
            'font_metrics': textfit.metrics_report(),
            'artifact_sha256': artifact_sha256,
            'skill_fingerprint': fingerprint.source_fingerprint(),
            'note_words': words,
            'duration_est_min': round(words / 2.2 / 60.0, 1),
            'out_path': str(out_path) if out_path else None,
            'assets_dir': str(self.assets_dir),
        }

    # ────────────────────────── low-level helpers ───────────────────────

    def add_shape(self, shape_type, x, y, w, h, fill=None, line=None, line_w=0.75, radius=None):
        """Add an autoshape with themed fill/line; no shadow."""
        shp = self.slide.shapes.add_shape(shape_type, Inches(x), Inches(y), Inches(w), Inches(h))
        if radius is not None:
            try:
                shp.adjustments[0] = radius
            except Exception:  # noqa: BLE001
                pass
        if fill is None:
            shp.fill.background()
        else:
            shp.fill.solid()
            shp.fill.fore_color.rgb = RGBColor.from_string(str(fill).lstrip('#'))
        if line is None:
            shp.line.fill.background()
        else:
            shp.line.color.rgb = RGBColor.from_string(str(line).lstrip('#'))
            shp.line.width = Pt(line_w)
        try:
            shp.shadow.inherit = False
        except Exception:  # noqa: BLE001
            pass
        return shp

    def rule(self, x, y, w, color, h=0.016):
        """Thin decorative rectangle (hairline, accent bar)."""
        return self.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h, fill=color)

    def add_bg(self, color=None):
        """Fill the slide background (with a full-bleed fallback rectangle)."""
        color = str(color or self.pal['bg']).lstrip('#')
        try:
            fill = self.slide.background.fill
            fill.solid()
            fill.fore_color.rgb = RGBColor.from_string(color)
        except Exception:  # noqa: BLE001
            self.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, themes.SLIDE_W, themes.SLIDE_H, fill=color)

    def textbox(self, x, y, w, h, anchor=MSO_ANCHOR.TOP):
        """Add a marginless word-wrapped text box; returns (shape, text_frame)."""
        tb = self.slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = 0
        tf.margin_right = 0
        tf.margin_top = 0
        tf.margin_bottom = 0
        tf.vertical_anchor = anchor
        return tb, tf

    def style_run(self, run, name, size, color, bold=False, italic=False):
        """Apply font name (latin/ea/cs), size, color, bold and italic to a run."""
        font = run.font
        font.name = name
        font.size = Pt(size)
        font.bold = bool(bold)
        font.italic = bool(italic)
        font.color.rgb = RGBColor.from_string(str(color).lstrip('#'))
        rPr = run._r.get_or_add_rPr()
        for tag in ('a:ea', 'a:cs'):
            el = rPr.find(qn(tag))
            if el is None:
                el = etree.SubElement(rPr, qn(tag))
            el.set('typeface', name)
        if run.text and GLYPH_AUDIT_ROLES.get(name):
            self.glyph_text.setdefault(name, []).append(run.text)

    def _missing_glyphs(self):
        """Characters per font family the resolved font cannot draw (A5)."""
        report = {}
        for family, parts in self.glyph_text.items():
            role = GLYPH_AUDIT_ROLES.get(family)
            if not role:
                continue
            chars = textfit.missing_glyphs(''.join(parts), role)
            if chars:
                report[family] = chars
        return report

    def write_paragraph(self, tf, spans, size, role='body', color=None, bold=False,
                        italic=False, first=False, space_after=0.0, line_spacing=1.0,
                        align=None, indent=0.0, hanging=0.0, mono=False):
        """Write one paragraph from markup spans into a text frame."""
        if role == 'mono' or mono:
            font_name = self.mono_font
        elif role == 'head':
            font_name = self.head_font
        else:
            font_name = self.body_font
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        if align is not None:
            p.alignment = align
        p.line_spacing = line_spacing
        p.space_before = Pt(0)
        p.space_after = Pt(float(space_after))
        if indent or hanging:
            pPr = p._p.get_or_add_pPr()
            pPr.set('marL', str(int(Inches(indent))))
            pPr.set('indent', str(int(Inches(-hanging))))
        color = color or self.pal['ink']
        wrote = False
        for text, flags in spans:
            if not text:
                continue
            run = p.add_run()
            run.text = text
            self.style_run(run, self.mono_font if flags.get('mono') else font_name, size, color,
                           bold=bold or flags.get('bold'), italic=italic or flags.get('italic'))
            if flags.get('url'):
                run.hyperlink.address = flags['url']
                run.font.underline = True
            wrote = True
        if not wrote:
            run = p.add_run()
            run.text = ' '
            self.style_run(run, font_name, size, color, bold=bold, italic=italic)
        return p

    def write_code_line(self, tf, spans, size, first=False, color=None):
        """Write one highlighted code line: spans carry their own hex color."""
        base = color or self.pal['ink']
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        p.line_spacing = 1.0
        p.space_before = Pt(0)
        p.space_after = Pt(0)
        wrote = False
        for text, span_color in spans:
            if not text:
                continue
            run = p.add_run()
            run.text = text
            hex_color = span_color if isinstance(span_color, str) and span_color else base
            self.style_run(run, self.mono_font, size, hex_color)
            wrote = True
        if not wrote:
            run = p.add_run()
            run.text = ' '
            self.style_run(run, self.mono_font, size, base)
        return p

    def record_box(self, kind, x, y, w, h, need_h=None, overflow=False, font_pt=None,
                   error=False, extra=None):
        """Record a layout box for the QA pass; returns the record."""
        box = {
            'kind': kind,
            'x': round(float(x), 3), 'y': round(float(y), 3),
            'w': round(float(w), 3), 'h': round(float(h), 3),
            'need_h': round(float(need_h), 3) if need_h is not None else None,
            'overflow': bool(overflow),
            'font_pt': float(font_pt) if font_pt is not None else None,
            'error': bool(error),
        }
        if extra:
            box.update(extra)
        self.current['boxes'].append(box)
        if kind in CONTENT_KINDS:
            self.current['empty'] = False
        return box

    def record_slots(self, declared, filled):
        """Record template-slot bookkeeping for the current slide."""
        declared = int(declared or 0)
        filled = int(filled or 0)
        if declared:
            filled = min(filled, declared)
        self.current['slots'] = {
            'declared': declared,
            'filled': filled,
            'removed': max(0, declared - filled),
        }
        return self.current['slots']

    def label(self, key, **fmt):
        """Localized label from the spec."""
        return self.spec.label(key, **fmt)

    def meta(self, key, default=''):
        """Meta value with a default."""
        return self.spec.meta_value(key, default)

    def next_section_no(self):
        self.section_no += 1
        return self.section_no

    def next_formula_no(self):
        self.formula_no += 1
        return self.formula_no

    # ────────────────────────── text engine ─────────────────────────────

    def _metric_role(self, role, bold=False):
        base = {'head': 'georgia', 'body': 'arial', 'mono': 'courier'}.get(role, 'arial')
        return base + '_bold' if bold else base

    def _norm_items(self, items):
        """Normalize text-block items into dicts with prefixes and indents."""
        norm = []
        for raw in items or []:
            item = dict(raw) if isinstance(raw, dict) else {'text': str(raw)}
            level = int(item.get('level') or 0)
            item['level'] = level
            prefix = item.get('prefix')
            if prefix is None:
                prefix = '' if item.get('no_bullet') else ('•  ' if level == 0 else '-  ')
            item['prefix'] = prefix
            item['text'] = str(item.get('text') or '')
            item['indent'] = float(item.get('indent', 0.22 + 0.36 * level))
            default_hang = min(0.22, item['indent']) if prefix else 0.0
            item['hanging'] = float(item.get('hanging', default_hang))
            norm.append(item)
        return norm

    def _item_size(self, item, size, min_size):
        if item.get('size'):
            return float(item['size'])
        if item['level'] == 0:
            return float(size)
        return max(float(min_size), float(size) - 2.0)

    def _text_need(self, norm, size, w, space_after, line_spacing, min_size):
        total = 0.0
        for item in norm:
            item_size = self._item_size(item, size, min_size)
            role = self._metric_role(item.get('role', 'body'), bool(item.get('bold')))
            text = item['prefix'] + strip_markup(item['text'])
            avail = max(0.5, w - item['indent'])
            lines = textfit.n_lines(text, role, item_size, avail)
            total += lines * textfit.line_height_in(role, item_size) * line_spacing
            total += float(item.get('space_after', space_after)) / 72.0
        return total

    def text_block(self, items, x, y, w, h, base_size=20.0, min_size=16.0,
                   space_after=7.0, line_spacing=1.05, kind='text'):
        """Render a list of bullets/paragraphs with auto-fit; returns (need, overflow, size)."""
        norm = self._norm_items(items)
        if not norm:
            return 0.0, False, float(base_size)
        bullet_count = sum(1 for item in norm if not item.get('no_bullet'))
        if bullet_count:
            self.current['bullets'] = int(self.current.get('bullets') or 0) + bullet_count
        size = float(base_size)
        while True:
            need = self._text_need(norm, size, w, space_after, line_spacing, min_size)
            if need <= h + 0.01 or size <= min_size:
                break
            size = max(float(min_size), round(size - 1.0, 2))
        need = self._text_need(norm, size, w, space_after, line_spacing, min_size)
        # Frame-filling stretch: grow the gaps between list items (never
        # the font size) so a short list does not hug the top of a tall frame.
        gaps = len(norm) - 1
        if gaps > 0 and need < h:
            extra = min(MAX_ITEM_PAD_IN, (h - need) / gaps)
            if extra > 0.01:
                for item in norm[:-1]:
                    item['space_after'] = (float(item.get('space_after', space_after))
                                           + extra * 72.0)
                need = self._text_need(norm, size, w, space_after, line_spacing, min_size)
        overflow = need > h + 0.02
        offset = max(0.0, (h - need) / 2.0)  # vertical centering: balance the list in its frame
        _, tf = self.textbox(x, y + offset, w, h - offset)
        first = True
        for item in norm:
            item_size = self._item_size(item, size, min_size)
            spans = []
            if item['prefix']:
                spans.append((item['prefix'], {}))
            spans.extend(split_markup(item['text']))
            self.write_paragraph(
                tf, spans, item_size, item.get('role', 'body'),
                item.get('color') or self.pal['ink'],
                bold=bool(item.get('bold')), italic=bool(item.get('italic')),
                first=first, space_after=float(item.get('space_after', space_after)),
                line_spacing=line_spacing, align=item.get('align'),
                indent=item['indent'], hanging=item['hanging'],
                mono=bool(item.get('mono')),
            )
            first = False
        self.record_box(kind, x, y, w, h, need_h=need, overflow=overflow, font_pt=size,
                        extra={'content_bottom': y + offset + need})
        return need, overflow, size

    def simple_text(self, x, y, w, h, text, size=16.0, role='body', color=None, bold=False,
                    italic=False, align=None, kind='text', mono=False, extra=None):
        """Render a single paragraph with markup and record its box."""
        _, tf = self.textbox(x, y, w, h)
        self.write_paragraph(tf, split_markup(text), size, role, color or self.pal['ink'],
                             bold=bold, italic=italic, first=True, align=align,
                             space_after=0.0, line_spacing=1.05, mono=mono)
        metric_role = self._metric_role(role, bold)
        lines = textfit.n_lines(strip_markup(text), metric_role, size, w)
        need = textfit.height_in(lines, metric_role, size) * 1.05
        box_extra = dict(extra or {})
        box_extra.setdefault('content_bottom', y + need)
        self.record_box(kind, x, y, w, h, need_h=need, overflow=need > h + 0.02, font_pt=size,
                        extra=box_extra)
        return need

    # ────────────────────────── formula engine ──────────────────────────

    def formula_image(self, lines, fontsize, max_width):
        """Render (with cache) a formula PNG; returns image info dict."""
        color = '#' + self.pal['ink'].lstrip('#')
        key = render.formula_key(lines, color, fontsize)
        if key in self.formula_cache:
            return self.formula_cache[key]
        index = len(self.formula_cache) + 1
        path = self.assets_dir / ('formula_%02d.png' % index)
        info = render.render_formula(lines, path, color=color, fontsize=fontsize,
                                     max_width_in=max_width)
        self.formula_cache[key] = info
        self.asset_files.append(str(path))
        return info

    def formula_block(self, lines, x, y, w, h, fontsize=26.0, caption=None, number=None,
                      align='center'):
        """Draw a centered formula: editable OMML or a raster image."""
        if self.formula_mode() == 'omml':
            try:
                return self.omml_block(lines, x, y, w, h, fontsize=fontsize,
                                       caption=caption, number=number)
            except omml.OmmlError as exc:
                raw = [lines] if isinstance(lines, str) else list(lines or [])
                text = '; '.join(str(line) for line in raw)
                self.warnings.append('formula %r fell back to a raster image: %s'
                                     % (text, exc))
        return self.formula_image_block(lines, x, y, w, h, fontsize=fontsize,
                                        caption=caption, number=number, align=align)

    def formula_mode(self):
        """Effective formula mode from meta: 'omml' (default) or 'image'."""
        return str(self.spec.meta_value('formula_mode', 'omml') or 'omml')

    def formula_measure(self, lines, fontsize, width):
        """Estimated formula height (inches) in the effective mode."""
        if self.formula_mode() == 'omml':
            try:
                omml.omml_paragraph(lines, fontsize)
                return omml.estimate_height(lines, fontsize)
            except omml.OmmlError:
                pass
        return float(self.formula_image(lines, fontsize, width)['height_in'])

    def omml_block(self, lines, x, y, w, h, fontsize=26.0, caption=None, number=None):
        """Editable OMML formula (a14:m / m:oMathPara) with caption/number."""
        element = omml.omml_paragraph(lines, fontsize)
        problems = omml.validate_omml(element)
        est_h = omml.estimate_height(lines, fontsize)
        cap_h, num_h = self._formula_furniture(caption, w, number)
        avail = max(0.5, h - cap_h - num_h)
        overflow = est_h > avail + 0.02
        if overflow:
            est_h = avail
        ty = y + max(0.0, (avail - est_h) / 2.0)
        _, tf = self.textbox(x, ty, w, max(0.3, est_h), anchor=MSO_ANCHOR.MIDDLE)
        tf.paragraphs[0]._p.append(element)
        cy = y + avail + 0.04
        if caption:
            _, tfc = self.textbox(x, cy, w, cap_h)
            self.write_paragraph(tfc, split_markup(caption), themes.TYPE['formula_caption'],
                                 'body', self.pal['muted'], first=True, align=PP_ALIGN.CENTER,
                                 space_after=0, line_spacing=1.0)
            cy += cap_h
        if number:
            _, tfn = self.textbox(x, y + avail + 0.02, w, 0.3)
            self.write_paragraph(tfn, [(number, {})], 16.0, 'body', self.pal['muted'],
                                 first=True, align=PP_ALIGN.RIGHT, space_after=0,
                                 line_spacing=1.0)
        used = est_h + cap_h + num_h
        self.record_box('formula', x, y, w, h, need_h=used, overflow=overflow,
                        font_pt=fontsize,
                        extra={'omml': True, 'omml_problems': problems})
        self.formula_modes['omml'] += 1
        self.current['formula_count'] = int(self.current.get('formula_count') or 0) + 1
        return used, overflow, est_h

    def _formula_furniture(self, caption, w, number):
        """Heights (inches) of the optional caption and number rows."""
        cap_h = 0.0
        if caption:
            cap_role = self._metric_role('body')
            cap_lines = max(1, textfit.n_lines(strip_markup(caption), cap_role,
                                               themes.TYPE['formula_caption'], w))
            cap_h = (cap_lines * textfit.line_height_in(cap_role, themes.TYPE['formula_caption'])
                     + 0.06)
        num_h = 0.30 if number else 0.0
        return cap_h, num_h

    def formula_image_block(self, lines, x, y, w, h, fontsize=26.0, caption=None,
                            number=None, align='center'):
        """Raster formula (300-dpi PNG) - the fallback and explicit image mode."""
        try:
            info = self.formula_image(lines, fontsize, w)
        except render.RenderError as exc:
            self.errors.extend(exc.errors)
            message = '; '.join(exc.errors)
            _, tf = self.textbox(x, y, w, min(h, 1.2))
            self.write_paragraph(tf, [('formula error: ' + message, {})], 13.0, 'mono',
                                 'AA0000', first=True, space_after=0, line_spacing=1.0)
            self.record_box('formula', x, y, w, min(h, 1.2), need_h=min(h, 1.2), error=True)
            return 0.0, False, 0.0
        img_w = min(float(info['width_in']), float(w))
        scale = img_w / float(info['width_in']) if info['width_in'] else 1.0
        img_h = float(info['height_in']) * scale
        cap_h = 0.0
        if caption:
            cap_role = self._metric_role('body')
            cap_lines = max(1, textfit.n_lines(strip_markup(caption), cap_role,
                                               themes.TYPE['formula_caption'], w))
            cap_h = (cap_lines * textfit.line_height_in(cap_role, themes.TYPE['formula_caption'])
                     + 0.06)
        num_h = 0.30 if number else 0.0
        avail = max(0.5, h - cap_h - num_h)
        overflow = img_h > avail + 0.02
        if overflow and img_h > 0:
            shrink = max(0.2, avail / img_h)
            img_w *= shrink
            img_h *= shrink
        ix = x + (w - img_w) / 2.0 if align == 'center' else x
        iy = y + max(0.0, (avail - img_h) / 2.0)
        self.slide.shapes.add_picture(info['path'], Inches(ix), Inches(iy), width=Inches(img_w))
        cy = y + avail + 0.04
        if caption:
            _, tfc = self.textbox(x, cy, w, cap_h)
            self.write_paragraph(tfc, split_markup(caption), themes.TYPE['formula_caption'],
                                 'body', self.pal['muted'], first=True, align=PP_ALIGN.CENTER,
                                 space_after=0, line_spacing=1.0)
            cy += cap_h
        if number:
            _, tfn = self.textbox(x, y + avail + 0.02, w, 0.3)
            self.write_paragraph(tfn, [(number, {})], 16.0, 'body', self.pal['muted'],
                                 first=True, align=PP_ALIGN.RIGHT, space_after=0, line_spacing=1.0)
        used = img_h + cap_h + num_h
        self.record_box('formula', x, y, w, h, need_h=used, overflow=overflow,
                        font_pt=fontsize,
                        extra={'image': info['path'], 'omml': False})
        self.formula_modes['image'] += 1
        self.current['formula_count'] = int(self.current.get('formula_count') or 0) + 1
        return used, overflow, img_h

    # ────────────────────────── concept cards ───────────────────────────

    def concept_card(self, x, y, w, h, heading=None, paragraphs=None, formula=None,
                     label=None, heading_size=22.0, paragraphs_italic=False, fill=None):
        """Rounded card with an accent bar: label, heading, paragraphs and formula."""
        pad = 0.30
        inner_w = w - 2.0 * pad
        label_h = 0.30 if label else 0.0
        heading_h = 0.0
        if heading:
            hl = textfit.n_lines(strip_markup(heading), 'georgia_bold', heading_size, inner_w)
            heading_h = textfit.height_in(hl, 'georgia_bold', heading_size) * 1.05
            heading_h += 0.14 if (paragraphs or formula) else 0.04
        items = self._norm_items([{'text': t, 'italic': paragraphs_italic, 'no_bullet': True}
                                  for t in (paragraphs or [])])
        psize = 20.0
        pneed = 0.0
        fneed = 0.0
        total = 0.0
        while True:
            pneed = self._text_need(items, psize, inner_w, 9.0, 1.06, 16.0) if items else 0.0
            fneed = 0.0
            if formula:
                fneed = min(self.formula_measure(formula, 22.0, inner_w),
                            max(0.8, h * 0.5)) + 0.16
            total = pad * 0.8 + label_h + heading_h + pneed + fneed + pad * 0.9
            if total <= h or psize <= 16.0:
                break
            psize = max(16.0, round(psize - 1.0, 2))
        # Frame-filling card: the card grows to the whole frame and
        # the inner block is centered vertically, so a short definition no
        # longer leaves the bottom of the slide empty.
        card_h = float(h)
        overflow = total > h + 0.02
        self.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, card_h,
                       fill=fill or self.pal['card'], radius=0.035)
        self.add_shape(MSO_SHAPE.RECTANGLE, x, y + 0.02, 0.07, max(0.2, card_h - 0.04),
                       fill=self.pal['accent'])
        inner_h = label_h + heading_h + pneed + fneed
        cx = x + pad
        cy = y + max(pad * 0.8, (card_h - inner_h) / 2.0)
        if label:
            self.simple_text(cx, cy, inner_w, label_h, label, size=14.0,
                             color=self.pal['accent'], bold=True, kind='card_label')
            cy += label_h
        if heading_h:
            self.simple_text(cx, cy, inner_w, heading_h, heading, size=heading_size,
                             role='head', color=self.pal['ink'], bold=True, kind='card_head')
            cy += heading_h
        if pneed:
            used, _, _ = self.text_block(items, cx, cy, inner_w, pneed, base_size=psize,
                                         min_size=16.0, space_after=9.0, line_spacing=1.06)
            cy += used
        if formula:
            used_f, _, _ = self.formula_block(formula, cx, cy, inner_w, fneed, fontsize=22.0)
            cy += used_f
        self.record_box('card', x, y, w, h, need_h=total, overflow=overflow,
                        extra={'content_bottom': y + card_h})
        return card_h, overflow

    # ────────────────────────── code engine ─────────────────────────────

    def code_block(self, x, y, w, h, language, code, start_line=1, caption=None, badge=True):
        """Highlighted code listing with line numbers and auto-fit font size."""
        lex_error = None
        try:
            hl_lines = render.highlight_code(code, language)
        except render.RenderError as exc:
            lex_error = exc
            self.errors.extend(exc.errors)
            hl_lines = [[(line or ' ', self.pal['ink'])] for line in str(code).split('\n')]
        n_lines = len(hl_lines)
        numbering = start_line is not None
        pad_x, pad_y = 0.18, 0.14
        inner_w = w - 2 * pad_x
        badge_h = 0.36 if badge else 0.0
        cap_h = 0.40 if caption else 0.0
        box_y = y + badge_h
        box_h = max(0.8, h - badge_h - cap_h)
        inner_h = box_h - 2 * pad_y
        last_no = int(start_line or 1) + n_lines - 1
        num_width = len(str(last_no)) + 2
        size = float(themes.TYPE['code'])
        chosen = None
        while size >= float(themes.TYPE['code_min']):
            line_h = textfit.line_height_in('courier', size)
            total_h = n_lines * line_h * 1.02
            widest = 0.0
            for spans in hl_lines:
                flat = ''.join(text for text, _ in spans)
                prefix = (' ' * num_width) if numbering else ''
                widest = max(widest, textfit.measure_in(prefix + flat, 'courier', size))
            if widest <= inner_w and total_h <= inner_h:
                chosen = size
                break
            size = round(size - 0.5, 2)
        if chosen is None:
            chosen = float(themes.TYPE['code_min'])
        line_h = textfit.line_height_in('courier', chosen)
        total_h = n_lines * line_h * 1.02
        overflow = total_h > inner_h + 0.02
        if badge:
            badge_w = min(2.4, 0.13 * len(str(language)) + 0.5)
            self.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x + w - badge_w, y, badge_w, 0.30,
                           fill=self.pal['accent_soft'], radius=0.30)
            _, tfb = self.textbox(x + w - badge_w, y + 0.02, badge_w, 0.26)
            self.write_paragraph(tfb, [(str(language), {})], 12.0, 'mono', self.pal['accent'],
                                 first=True, align=PP_ALIGN.CENTER, space_after=0, line_spacing=1.0)
        self.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, box_y, w, box_h,
                       fill=self.pal['code_bg'], line=self.pal['rule'], radius=0.03)
        _, tf = self.textbox(x + pad_x, box_y + pad_y, inner_w, inner_h)
        first = True
        for i, spans in enumerate(hl_lines):
            line_spans = list(spans)
            if numbering:
                line_spans = [('%*d  ' % (num_width - 2, int(start_line or 1) + i),
                               self.pal['muted'])] + line_spans
            if not line_spans:
                line_spans = [(' ', self.pal['ink'])]
            self.write_code_line(tf, line_spans, chosen, first=first)
            first = False
        if caption:
            _, tfc = self.textbox(x, box_y + box_h + 0.05, w, cap_h)
            self.write_paragraph(tfc, split_markup(caption), themes.TYPE['caption'], 'body',
                                 self.pal['muted'], first=True, space_after=0, line_spacing=1.0)
        used = total_h + badge_h + cap_h
        self.record_box('code', x, y, w, h, need_h=used, overflow=overflow,
                        font_pt=chosen, extra={'lines': n_lines, 'language': language})
        self.current['code_lines'] = int(self.current.get('code_lines') or 0) + n_lines
        if lex_error:
            self.current['boxes'][-1]['error'] = True
        return used, overflow, chosen

    # ────────────────────────── table engine ────────────────────────────

    def _fill_cell(self, cell, color):
        cell.fill.solid()
        cell.fill.fore_color.rgb = RGBColor.from_string(str(color).lstrip('#'))

    def _cell_text(self, cell, text, size, bold, color, align=PP_ALIGN.LEFT):
        tf = cell.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.09)
        tf.margin_right = Inches(0.09)
        tf.margin_top = Inches(0.05)
        tf.margin_bottom = Inches(0.05)
        p = tf.paragraphs[0]
        p.alignment = align
        p.line_spacing = 1.0
        p.space_before = Pt(0)
        p.space_after = Pt(0)
        for text_part, flags in split_markup(text):
            if not text_part:
                continue
            run = p.add_run()
            run.text = text_part
            self.style_run(run, self.body_font, size, color,
                           bold=bold or flags.get('bold'), italic=flags.get('italic'))

    def _plain_table_style(self, table):
        """Switch the table to 'No Style, Table Grid' for theme-neutral borders."""
        try:
            tbl_pr = table._tbl.tblPr
            tbl_pr.set('firstRow', '1')
            tbl_pr.set('bandRow', '0')
            style_el = tbl_pr.find(qn('a:tableStyleId'))
            if style_el is None:
                style_el = etree.SubElement(tbl_pr, qn('a:tableStyleId'))
            style_el.text = '{5940675A-B579-460E-94D1-54222C63F5DA}'
        except Exception:  # noqa: BLE001
            pass

    def table_block(self, x, y, w, h, columns, rows, caption=None, col_widths=None):
        """Native table with themed header; returns (used, overflow)."""
        n_cols = len(columns)
        n_rows = len(rows)
        size = float(themes.TYPE['table'])
        widths = [float(v) for v in col_widths] if col_widths else [1.0] * n_cols
        total_w = sum(widths) or float(n_cols)
        col_w = [w * value / total_w for value in widths]
        head_lines = 1
        for i, name in enumerate(columns):
            head_lines = max(head_lines, textfit.n_lines(strip_markup(str(name)), 'arial_bold',
                                                         size, max(0.4, col_w[i] - 0.22)))
        head_h = textfit.height_in(head_lines, 'arial_bold', size) + 0.14
        row_hs = []
        for row in rows:
            lines = 1
            for i, cell_value in enumerate(row):
                lines = max(lines, textfit.n_lines(strip_markup(str(cell_value)), 'arial', size,
                                                   max(0.4, col_w[i] - 0.22)))
            row_hs.append(textfit.height_in(lines, 'arial', size) + 0.12)
        cap_h = 0.36 if caption else 0.0
        avail_h = max(0.8, h - cap_h)
        total_h = head_h + sum(row_hs)
        # Frame-filling table: a short table grows its row heights (up
        # to a cap) and centers vertically in the frame instead of sitting
        # at the top with a large empty area below it.
        if n_rows and total_h < avail_h:
            extra = min(MAX_TABLE_ROW_PAD_IN, (avail_h - total_h) / n_rows)
            if extra > 0.01:
                row_hs = [row_h + extra for row_h in row_hs]
                total_h = head_h + sum(row_hs)
        overflow = total_h > avail_h + 0.02
        table_h = min(total_h, avail_h)
        table_y = y + max(0.0, (avail_h - table_h) / 2.0)
        graphic = self.slide.shapes.add_table(n_rows + 1, n_cols, Inches(x), Inches(table_y),
                                              Inches(w), Inches(table_h))
        table = graphic.table
        self._plain_table_style(table)
        for i, width in enumerate(col_w):
            table.columns[i].width = Inches(width)
        table.rows[0].height = Inches(head_h)
        for r, row_h in enumerate(row_hs):
            table.rows[r + 1].height = Inches(row_h)
        for i, name in enumerate(columns):
            cell = table.cell(0, i)
            self._fill_cell(cell, self.pal['table_head_bg'])
            self._cell_text(cell, str(name), size, True, self.pal['ink'],
                            PP_ALIGN.LEFT if i == 0 else PP_ALIGN.CENTER)
        for r, row in enumerate(rows):
            band = self.pal['bg'] if r % 2 == 0 else self.pal['card']
            for i, cell_value in enumerate(row):
                cell = table.cell(r + 1, i)
                self._fill_cell(cell, band)
                self._cell_text(cell, str(cell_value), size, False, self.pal['ink'],
                                PP_ALIGN.LEFT if i == 0 else PP_ALIGN.CENTER)
        if caption:
            _, tfc = self.textbox(x, table_y + table_h + 0.06, w, cap_h)
            self.write_paragraph(tfc, split_markup(caption), themes.TYPE['caption'], 'body',
                                 self.pal['muted'], first=True, space_after=0, line_spacing=1.0)
        content_bottom = table_y + table_h + cap_h
        self.record_box('table', x, y, w, h, need_h=total_h + cap_h, overflow=overflow,
                        font_pt=size, extra={'content_bottom': content_bottom})
        return total_h + cap_h, overflow

    # ────────────────────────── image engine ────────────────────────────

    def image_block(self, x, y, w, h, path, caption=None, width=None, height=None):
        """Scaled picture with caption; a placeholder + error when missing."""
        resolved = Path(str(path))
        if not resolved.is_absolute():
            resolved = Path(str(self.spec.base_dir)) / resolved
        cap_h = 0.36 if caption else 0.0
        avail_h = max(0.6, h - cap_h)
        if not resolved.exists():
            self.errors.append('image not found: %s' % path)
            self.missing_images.append(str(path))
            box_h = min(avail_h, 1.4)
            self.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, box_h,
                           fill=self.pal['card'], line=self.pal['rule'])
            _, tf = self.textbox(x + 0.2, y + 0.2, w - 0.4, box_h - 0.4)
            self.write_paragraph(tf, [('image not found: ' + str(path), {})], 13.0, 'mono',
                                 'AA0000', first=True, space_after=0, line_spacing=1.0)
            self.record_box('image', x, y, w, box_h, need_h=box_h, error=True)
            return 0.0, False
        from PIL import Image
        with Image.open(str(resolved)) as image:
            px_w, px_h = image.size
        aspect = (float(px_w) / float(px_h)) if px_h else 1.6
        if width:
            img_w = float(width)
            img_h = img_w / aspect
        elif height:
            img_h = float(height)
            img_w = img_h * aspect
        else:
            img_w = float(w)
            img_h = img_w / aspect
            if img_h > avail_h:
                img_h = avail_h
                img_w = img_h * aspect
        if img_w > w:
            img_w = float(w)
            img_h = img_w / aspect
        overflow = img_h > avail_h + 0.02
        ix = x + (w - img_w) / 2.0
        iy = y + max(0.0, (avail_h - img_h) / 2.0)
        self.slide.shapes.add_picture(str(resolved), Inches(ix), Inches(iy), width=Inches(img_w))
        if caption:
            _, tfc = self.textbox(x, y + avail_h + 0.04, w, cap_h)
            self.write_paragraph(tfc, split_markup(caption), themes.TYPE['caption'], 'body',
                                 self.pal['muted'], first=True, align=PP_ALIGN.CENTER,
                                 space_after=0, line_spacing=1.0)
        self.record_box('image', x, y, w, h, need_h=img_h + cap_h, overflow=overflow,
                        extra={'image': str(resolved)})
        return img_h + cap_h, img_h <= avail_h + 0.02

    # ────────────────────────── block dispatcher ────────────────────────

    def chart_block(self, x, y, w, h, data):
        """Native PowerPoint chart (bar/line/pie) with an embedded workbook.

        Draws the chart into (x, y, w, h) minus the caption strip, records a
        'chart' QA box and returns the used height. The data workbook is
        embedded into the .pptx by python-pptx, so the chart stays editable.
        """
        chart_type = str(data.get('chart_type') or 'bar')
        enum = CHART_TYPE_ENUMS.get(chart_type) or CHART_TYPE_ENUMS['bar']
        categories = [str(item) for item in (data.get('categories') or [])]
        series = [entry for entry in (data.get('series') or [])
                  if isinstance(entry, dict)]
        caption = data.get('caption')
        cap_h = 0.34 if caption else 0.0
        avail_h = max(1.2, h - cap_h)
        chart_data = CategoryChartData()
        chart_data.categories = categories
        for index, entry in enumerate(series, start=1):
            name = str(entry.get('name') or '').strip() or self.spec.label('series', no=index)
            values = [float(value) for value in (entry.get('values') or [])]
            chart_data.add_series(name, values)
        frame = self.slide.shapes.add_chart(enum, Inches(x), Inches(y),
                                            Inches(w), Inches(avail_h), chart_data)
        chart = frame.chart
        chart.font.size = Pt(themes.TYPE['caption'])
        chart.font.name = self.body_font
        if chart_type == 'pie' or len(series) > 1:
            chart.has_legend = True
            chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            chart.legend.include_in_layout = False
        else:
            chart.has_legend = False
        if chart_type == 'pie':
            plot = chart.plots[0]
            plot.has_data_labels = True
            plot.data_labels.show_percentage = True
        self.record_box('chart', x, y, w, avail_h, need_h=avail_h,
                        extra={'chart_type': chart_type,
                               'categories': len(categories),
                               'series': len(series)})
        used = avail_h
        if caption:
            self.simple_text(x, y + avail_h + 0.04, w, cap_h, caption,
                             size=themes.TYPE['caption'], color=self.pal['muted'],
                             kind='caption')
            used += cap_h
        return used

    def block(self, block_data, x, y, w, h):
        """Render a two_column block ({'kind': ...}) inside a column."""
        kind = block_data.get('kind')
        if kind in ('bullets', 'paragraphs'):
            raw_items = block_data.get('items')
            if raw_items is None:
                raw_items = [{'text': part.strip(), 'no_bullet': True}
                             for part in str(block_data.get('text') or '').split('\n')
                             if part.strip()]
            items = []
            for raw in raw_items:
                if isinstance(raw, dict):
                    item = dict(raw)
                    item['no_bullet'] = item.get('no_bullet', kind == 'paragraphs')
                else:
                    item = {'text': str(raw), 'no_bullet': kind == 'paragraphs'}
                items.append(item)
            return self.text_block(items, x, y, w, h, base_size=18.0, min_size=16.0,
                                   space_after=6.0)
        if kind == 'formula':
            return self.formula_block(block_data.get('formula'), x, y, w, h,
                                      fontsize=20.0, caption=block_data.get('caption'))
        if kind == 'code':
            return self.code_block(x, y, w, h, block_data.get('language'),
                                   block_data.get('code'),
                                   start_line=block_data.get('start_line', 1),
                                   caption=block_data.get('caption'), badge=False)
        if kind == 'image':
            return self.image_block(x, y, w, h, block_data.get('path'),
                                    caption=block_data.get('caption'),
                                    width=block_data.get('width'),
                                    height=block_data.get('height'))
        if kind == 'table':
            return self.table_block(x, y, w, h, block_data.get('columns'),
                                    block_data.get('rows'),
                                    caption=block_data.get('caption'),
                                    col_widths=block_data.get('col_widths'))
        if kind == 'chart':
            return self.chart_block(x, y, w, h, block_data), True
        self.warnings.append("two_column: unknown block kind '%s'" % kind)
        return 0.0, False

    # ────────────────────────── shared chrome ───────────────────────────

    def header(self, text):
        """Slide header + hairline; returns the body frame (x, y, w, h)."""
        x, w = themes.MARGIN_X, themes.CONTENT_W
        size = float(themes.TYPE['header'])
        lines = textfit.n_lines(strip_markup(text), 'georgia_bold', size, w)
        if lines > 1:
            size = 24.0
            lines = textfit.n_lines(strip_markup(text), 'georgia_bold', size, w)
        if lines > 2:
            size = 22.0
            lines = textfit.n_lines(strip_markup(text), 'georgia_bold', size, w)
        need = textfit.height_in(lines, 'georgia_bold', size)
        _, tf = self.textbox(x, themes.HEADER_Y, w, themes.HEADER_H)
        self.write_paragraph(tf, split_markup(text), size, 'head', self.pal['ink'],
                             bold=True, first=True, space_after=0, line_spacing=1.0)
        self.rule(themes.MARGIN_X, themes.RULE_Y, themes.CONTENT_W, self.pal['rule'])
        self.record_box('header', x, themes.HEADER_Y, w, themes.HEADER_H, need_h=need,
                        overflow=need > themes.HEADER_H + 0.02, font_pt=size)
        return (themes.MARGIN_X, themes.BODY_TOP, themes.CONTENT_W, themes.BODY_H)

    def plain_body(self):
        """Body frame for slides without a header."""
        return (themes.MARGIN_X, themes.MARGIN_TOP + 0.12,
                themes.CONTENT_W, themes.CONTENT_H - 0.12)

    def footer(self, index, total):
        """Footer line: deck label on the left, page numbers on the right."""
        left = str(self.spec.meta_value('footer_left') or '') or self._footer_left()
        _, tf = self.textbox(themes.MARGIN_X, themes.FOOTER_Y, themes.CONTENT_W * 0.7,
                             themes.FOOTER_H)
        self.write_paragraph(tf, split_markup(left), themes.TYPE['footer'], 'body',
                             self.pal['muted'], first=True, space_after=0, line_spacing=1.0)
        _, tfr = self.textbox(themes.MARGIN_X + themes.CONTENT_W * 0.6, themes.FOOTER_Y,
                              themes.CONTENT_W * 0.4, themes.FOOTER_H)
        page = self.spec.label('page', current=index, total=total)
        self.write_paragraph(tfr, split_markup(page), themes.TYPE['footer'], 'body',
                             self.pal['muted'], first=True, align=PP_ALIGN.RIGHT,
                             space_after=0, line_spacing=1.0)
        self.rule(themes.MARGIN_X, themes.FOOTER_RULE_Y, themes.CONTENT_W, self.pal['rule'], h=0.012)

    def _footer_left(self):
        parts = []
        course = str(self.spec.meta_value('course') or '').strip()
        if course:
            parts.append(course)
        no = self.spec.meta_value('lecture_no')
        if no:
            parts.append(self.spec.label('lecture', no=no))
        if not parts:
            parts.append(str(self.spec.title or '').strip())
        return ' • '.join(part for part in parts if part)
