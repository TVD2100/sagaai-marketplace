"""Themes (palettes, typography) and slide geometry for lecture decks.

A theme is a plain dict with color keys and a font role map. Geometry is
fixed at 16:9 (13.333 x 7.5 in) with a safe content frame; every renderer
lays content inside that frame so QA margins stay meaningful.

Color keys used by the renderers:
``bg`` background, ``ink`` primary text, ``muted`` secondary text,
``accent`` brand color, ``accent_soft`` tinted fill, ``rule`` hairlines,
``card`` card fill, ``code_bg`` code box fill, ``table_head_bg`` table
header fill, ``cover_bg`` cover background, ``cover_ink`` cover text.
"""

from __future__ import annotations

SLIDE_W = 13.333
SLIDE_H = 7.5

# Safe frame: content stays inside these bounds (QA checks them).
MARGIN_X = 0.62
MARGIN_TOP = 0.46
MARGIN_BOTTOM = 0.70          # bottom of the content frame (above the footer)
CONTENT_W = SLIDE_W - 2 * MARGIN_X
CONTENT_H = SLIDE_H - MARGIN_TOP - MARGIN_BOTTOM

HEADER_Y = MARGIN_TOP
HEADER_H = 0.78
RULE_Y = MARGIN_TOP + HEADER_H                 # 1.20 - hairline under the header
BODY_TOP = RULE_Y + 0.18                       # 1.38 - body content starts here
BODY_H = (SLIDE_H - MARGIN_BOTTOM) - BODY_TOP  # 5.42

FOOTER_RULE_Y = SLIDE_H - 0.62                 # 6.88 - hairline above the footer
FOOTER_Y = SLIDE_H - 0.54                      # 6.96 - footer text line
FOOTER_H = 0.26

FONTS = {
    'academic_blue': ('Georgia', 'Arial', 'Courier New'),
    'graphite': ('Georgia', 'Arial', 'Courier New'),
    'deep_green': ('Georgia', 'Arial', 'Courier New'),
    'burgundy': ('Georgia', 'Arial', 'Courier New'),
}

THEMES = {
    'academic_blue': {
        'bg': 'FFFFFF',
        'ink': '1B2A41',
        'muted': '5A6B85',
        'accent': '1F4E9C',
        'accent_soft': 'E8EFF9',
        'rule': 'C9D6EA',
        'card': 'F4F7FC',
        'code_bg': 'F6F8FA',
        'table_head_bg': 'E8EFF9',
        'cover_bg': '16324F',
        'cover_ink': 'FFFFFF',
        'cover_accent': '7FB2FF',
    },
    'graphite': {
        'bg': 'F7F7F5',
        'ink': '23272B',
        'muted': '5C636A',
        'accent': '343A40',
        'accent_soft': 'E9ECEF',
        'rule': 'CED4DA',
        'card': 'FFFFFF',
        'code_bg': 'F1F3F5',
        'table_head_bg': 'E9ECEF',
        'cover_bg': '212529',
        'cover_ink': 'FFFFFF',
        'cover_accent': 'ADB5BD',
    },
    'deep_green': {
        'bg': 'FFFFFF',
        'ink': '14261C',
        'muted': '4F6A58',
        'accent': '1E6B45',
        'accent_soft': 'E3F1E9',
        'rule': 'BFD8C9',
        'card': 'F2F9F5',
        'code_bg': 'F6F8F6',
        'table_head_bg': 'E3F1E9',
        'cover_bg': '133B27',
        'cover_ink': 'FFFFFF',
        'cover_accent': '8FD3AC',
    },
    'burgundy': {
        'bg': 'FFFFFF',
        'ink': '2B1418',
        'muted': '6E4A50',
        'accent': '7B1E2B',
        'accent_soft': 'F7E7E9',
        'rule': 'E0C4C8',
        'card': 'FBF3F4',
        'code_bg': 'FAF6F6',
        'table_head_bg': 'F7E7E9',
        'cover_bg': '57121C',
        'cover_ink': 'FFFFFF',
        'cover_accent': 'E8A6AF',
    },
}

DEFAULT_THEME = 'academic_blue'

# Typography scale (pt). QA enforces MIN_BODY_PT for body text.
TYPE = {
    'cover_title': 40,
    'cover_subtitle': 20,
    'cover_meta': 16,
    'section_number': 60,
    'section_header': 34,
    'header': 27,
    'body': 20,
    'sub': 18,
    'caption': 14,
    'footer': 11,
    'table': 16,
    'code': 16,
    'code_min': 11.0,
    'formula_caption': 14,
    'label': 14,
}

MIN_BODY_PT = 16.0


def get_theme(name):
    """Return the palette for a theme name (falls back to the default)."""
    return dict(THEMES.get(str(name or '').strip(), THEMES[DEFAULT_THEME]))


def get_fonts(name):
    """Return (header_font, body_font, mono_font) for a theme name."""
    head, body, mono = FONTS.get(str(name or '').strip(), FONTS[DEFAULT_THEME])
    return head, body, mono


def theme_names():
    """Return the list of available theme names."""
    return list(THEMES)
