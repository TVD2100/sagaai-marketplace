"""Slide renderers for every lecture spec type.

Each renderer receives the ``DeckBuilder`` and one normalized spec slide
dict, draws on ``builder.slide`` and records layout boxes through the
builder engines so the QA pass sees one uniform picture of the deck.

``RENDERERS`` maps every slide type from ``lecture.spec.SLIDE_TYPES`` to its
renderer; ``DeckBuilder.build()`` imports this module lazily to avoid an
import cycle (slides -> deck -> slides).
"""

from __future__ import annotations

from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN

from . import textfit, themes
from .spec import is_safe_link, strip_markup


def _fit_lines_size(text, role, base_size, min_size, width, max_lines=2):
    """Largest size <= base_size at which the text fits max_lines lines."""
    size = float(base_size)
    while size > min_size and textfit.n_lines(strip_markup(text), role, size, width) > max_lines:
        size = round(size - 2.0, 2)
    return max(size, float(min_size))


def _words_fit(text, role, size, width):
    """True when every word fits a line with a safety margin.

    The measured width carries its own safety factor, but at the very edge
    (a word using 98-99% of the line) the real renderer still breaks it, so
    a word must leave ~6% of the line free to count as fitting.
    """
    limit = max(0.25, float(width)) * 0.94
    return all(textfit.measure_in(word, role, size) <= limit
               for word in strip_markup(text).split())


def _fit_size_by_height(text, role, base_size, min_size, width, max_h, line_factor=1.05):
    """Largest size <= base_size whose wrapped block still fits max_h inches.

    The size is also reduced until no single word has to be hard-broken: a
    tall box alone tempts the fitter to pick a size where the wrap splits a
    word in the middle ("Краткосрочн / ый эффект"), which reads as a layout
    bug. A very long unbreakable word still falls back to the min size.
    """
    size = float(base_size)
    while size > min_size:
        lines = max(1, textfit.n_lines(strip_markup(text), role, size, width))
        fits_h = textfit.height_in(lines, role, size) * line_factor <= max_h
        if fits_h and _words_fit(text, role, size, width):
            break
        size = round(size - 1.0, 2)
    return max(size, float(min_size))


def _wrap_height(text, role, size, width, line_factor=1.05):
    """Height in inches of the wrapped text at the given size."""
    lines = max(1, textfit.n_lines(strip_markup(text), role, size, width))
    return textfit.height_in(lines, role, size) * line_factor


def _body(builder, data, default_label=None):
    """Body frame for a slide: header frame or the plain frame."""
    header = data.get('header')
    if not header and default_label:
        header = builder.label(default_label)
    if header:
        return builder.header(header)
    return builder.plain_body()


def _caption(builder, data, x, y, w):
    """Optional caption paragraph under a card or listing."""
    caption = data.get('caption')
    if caption:
        builder.simple_text(x, y, w, 0.34, caption, size=themes.TYPE['caption'],
                            color=builder.pal['muted'], kind='caption')


# ─────────────────────────────── renderers ────────────────────────────────

def render_title(builder, data):
    """Cover slide: dark background, deck title, subtitle and course meta."""
    pal = builder.pal
    builder.add_bg(pal['cover_bg'])
    x = 0.9
    w = themes.SLIDE_W - 1.8
    builder.rule(x, 1.06, 1.5, pal['cover_accent'], h=0.055)

    title_text = str(data.get('title') or builder.meta('title') or '')
    subtitle = str(data.get('subtitle') or builder.meta('subtitle') or '')
    course = str(data.get('course') or builder.meta('course') or '')
    lecturer = str(data.get('lecturer') or builder.meta('lecturer') or '')
    org = str(data.get('org') or builder.meta('org') or '')
    date = str(data.get('date') or builder.meta('date') or '')
    no = data.get('lecture_no')
    if no is None:
        no = builder.meta('lecture_no')

    top_parts = []
    if course:
        top_parts.append(course)
    if no:
        top_parts.append(builder.label('lecture', no=no))
    y = 1.32
    if top_parts:
        builder.simple_text(x, y, w, 0.34, ' \u2022 '.join(top_parts), size=15.0,
                            color=pal['cover_accent'], bold=True, kind='cover')
        y += 0.52

    size = _fit_lines_size(title_text, 'georgia_bold', themes.TYPE['cover_title'], 28.0, w,
                           max_lines=3)
    lines = max(1, textfit.n_lines(strip_markup(title_text), 'georgia_bold', size, w))
    title_h = textfit.height_in(lines, 'georgia_bold', size)
    builder.simple_text(x, y, w, title_h, title_text, size=size, role='head',
                        color=pal['cover_ink'], bold=True, kind='cover')
    y += title_h + 0.28

    if subtitle:
        sub_size = _fit_lines_size(subtitle, 'arial', themes.TYPE['cover_subtitle'], 16.0, w,
                                   max_lines=2)
        sub_lines = max(1, textfit.n_lines(strip_markup(subtitle), 'arial', sub_size, w))
        sub_h = textfit.height_in(sub_lines, 'arial', sub_size)
        builder.simple_text(x, y, w, sub_h, subtitle, size=sub_size,
                            color=pal['cover_accent'], kind='cover')

    builder.rule(x, 6.28, w, pal['cover_accent'], h=0.02)
    bottom = ' \u2022 '.join(part for part in (lecturer, org, date) if part)
    builder.simple_text(x, 6.46, w, 0.5, bottom, size=15.0, color=pal['cover_ink'],
                        kind='cover')


def render_section(builder, data):
    """Section divider: accent bar, optional number, header and subtitle."""
    pal = builder.pal
    builder.add_bg(pal['bg'])
    builder.add_shape(MSO_SHAPE.RECTANGLE, themes.MARGIN_X, 2.42, 0.09, 2.0,
                      fill=pal['accent'])
    number = data.get('number')
    header = str(data.get('header') or data.get('title') or '')
    subtitle = str(data.get('subtitle') or '')
    x = themes.MARGIN_X + 0.44
    w = themes.CONTENT_W - 0.44
    y = 2.48
    if number:
        builder.simple_text(x, y, w, 1.0, str(number), size=themes.TYPE['section_number'],
                            role='head', color=pal['accent'], bold=True, kind='section')
        y += 1.02
    size = _fit_lines_size(header, 'georgia_bold', themes.TYPE['section_header'], 22.0, w,
                           max_lines=2)
    lines = max(1, textfit.n_lines(strip_markup(header), 'georgia_bold', size, w))
    head_h = textfit.height_in(lines, 'georgia_bold', size)
    builder.simple_text(x, y, w, head_h, header, size=size, role='head',
                        color=pal['ink'], bold=True, kind='section')
    y += head_h + 0.24
    if subtitle:
        builder.simple_text(x, y, w, 0.6, subtitle, size=themes.TYPE['sub'],
                            color=pal['muted'], kind='section')


def render_bullets(builder, data):
    """Bulleted content slide with auto-fit."""
    x, y, w, h = _body(builder, data)
    builder.text_block(data.get('items') or [], x, y, w, h, base_size=21.0, min_size=16.0)


def render_definition(builder, data):
    """Definition card: term as heading, text paragraphs, optional formula."""
    x, y, w, h = _body(builder, data)
    cap_h = 0.34 if data.get('caption') else 0.0
    card_h, _ = builder.concept_card(x, y, w, max(1.2, h - cap_h),
                                     label=builder.label('definition'),
                                     heading=data.get('term'),
                                     paragraphs=data.get('text'),
                                     formula=data.get('formula'))
    _caption(builder, data, x, y + card_h + 0.06, w)


def render_theorem(builder, data):
    """Theorem-like card: kind label, optional name, italic statement, formula."""
    x, y, w, h = _body(builder, data)
    kind = str(data.get('kind') or 'theorem').lower()
    cap_h = 0.34 if data.get('caption') else 0.0
    card_h, _ = builder.concept_card(x, y, w, max(1.2, h - cap_h),
                                     label=builder.label(kind),
                                     heading=data.get('name'),
                                     paragraphs=data.get('statement'),
                                     formula=data.get('formula'),
                                     paragraphs_italic=True)
    _caption(builder, data, x, y + card_h + 0.06, w)


def render_proof(builder, data):
    """Proof slide: numbered steps, optional formula and a QED mark."""
    x, y, w, h = _body(builder, data)
    pal = builder.pal
    builder.simple_text(x, y, w, 0.34, builder.label('proof'), size=15.0,
                        color=pal['accent'], bold=True, kind='card_label')
    cy = y + 0.40
    qed = data.get('qed', True) is not False
    qed_h = 0.36 if qed else 0.0
    formula = data.get('formula')
    formula_h = min(1.55, max(0.8, (h - 0.4) * 0.42)) if formula else 0.0
    avail = max(1.0, h - 0.40 - qed_h - formula_h)
    steps = []
    for i, step in enumerate(data.get('steps') or [], start=1):
        text = step.get('text') if isinstance(step, dict) else str(step)
        steps.append({'text': text, 'prefix': '%d.  ' % i, 'indent': 0.36, 'hanging': 0.36})
    builder.text_block(steps, x, cy, w, avail, base_size=19.0, min_size=16.0, space_after=6.0)
    cy += avail
    if formula:
        builder.formula_block(formula, x, cy, w, formula_h, fontsize=20.0)
        cy += formula_h
    if qed:
        builder.simple_text(x, min(cy, y + h - qed_h), w, qed_h, '\u220e', size=16.0,
                            color=pal['ink'], align=PP_ALIGN.RIGHT, kind='text')


def render_formula(builder, data):
    """Standalone formula slide with optional caption and numbering."""
    x, y, w, h = _body(builder, data)
    number = None
    if data.get('numbered'):
        number = '(%d)' % builder.next_formula_no()
    builder.formula_block(data.get('formula'), x, y, w, h, fontsize=27.0,
                          caption=data.get('caption'), number=number)


def render_code(builder, data):
    """Code listing slide with highlighting, line numbers and auto-fit."""
    x, y, w, h = _body(builder, data)
    builder.code_block(x, y, w, h, data.get('language'), data.get('code'),
                       start_line=data.get('start_line', 1), caption=data.get('caption'))


def render_table(builder, data):
    """Table slide rendered as a native PowerPoint table."""
    x, y, w, h = _body(builder, data)
    builder.table_block(x, y, w, h, data.get('columns') or [], data.get('rows') or [],
                        caption=data.get('caption'), col_widths=data.get('col_widths'))


def render_image(builder, data):
    """Image slide with caption; missing files become an explicit placeholder."""
    x, y, w, h = _body(builder, data)
    builder.image_block(x, y, w, h, data.get('path'), caption=data.get('caption'),
                        width=data.get('width'), height=data.get('height'))


def render_two_column(builder, data):
    """Two columns with an optional divider; each column holds one block."""
    x, y, w, h = _body(builder, data)
    gap = 0.36
    split = float(data.get('split') or 0.48)
    left_w = (w - gap) * split
    right_w = w - gap - left_w
    builder.block(data.get('left') or {}, x, y, left_w, h)
    builder.block(data.get('right') or {}, x + left_w + gap, y, right_w, h)
    builder.add_shape(MSO_SHAPE.RECTANGLE, x + left_w + gap / 2.0 - 0.006, y, 0.012, h,
                      fill=builder.pal['rule'])


def render_summary(builder, data):
    """Summary slide: bulleted takeaways."""
    x, y, w, h = _body(builder, data, 'summary')
    builder.text_block(data.get('items') or [], x, y, w, h, base_size=20.0, min_size=16.0)


def render_homework(builder, data):
    """Homework slide: task list plus an optional deadline line."""
    x, y, w, h = _body(builder, data, 'homework')
    deadline = data.get('deadline')
    extra = 0.46 if deadline else 0.0
    used, _overflow, _size = builder.text_block(
        data.get('items') or [], x, y, w, max(1.0, h - extra),
        base_size=20.0, min_size=16.0)
    if deadline:
        # The deadline follows the visible bottom of the task list instead
        # of being pinned to the very bottom of the frame.
        item_box = builder.current['boxes'][-1] if builder.current['boxes'] else None
        list_bottom = y + used
        if item_box is not None and item_box.get('content_bottom') is not None:
            list_bottom = float(item_box['content_bottom'])
        dy = min(y + h - 0.38, max(list_bottom + 0.12, y))
        builder.simple_text(x, dy, w, 0.38,
                            builder.label('deadline', deadline=deadline),
                            size=themes.TYPE['sub'], color=builder.pal['accent'],
                            bold=True, kind='text', extra={'deadline': True})


def render_literature(builder, data):
    """References slide: numbered list of sources."""
    x, y, w, h = _body(builder, data, 'literature')
    items = []
    for i, raw in enumerate(data.get('items') or [], start=1):
        text = str(raw.get('text') if isinstance(raw, dict) else raw or '')
        url = str(raw.get('url') or '') if isinstance(raw, dict) else ''
        if url and is_safe_link(url):
            text = '[%s](%s)' % (text, url)
        items.append({'text': text, 'prefix': '%d.  ' % i, 'indent': 0.36, 'hanging': 0.36})
    builder.text_block(items, x, y, w, h, base_size=18.0, min_size=16.0, space_after=6.0)


def _card_items(raw_items):
    """Normalize cards spec items into {'title', 'text'} dicts."""
    items = []
    for raw in raw_items or []:
        if isinstance(raw, dict):
            title = str(raw.get('title') or '').strip()
            text = str(raw.get('text') or '').strip()
        else:
            title, text = '', str(raw or '').strip()
        if not text:
            continue
        items.append({'title': title, 'text': text})
    return items


def _timeline_items(raw_items):
    """Normalize timeline spec items into {'label', 'text'} dicts."""
    items = []
    for raw in raw_items or []:
        if isinstance(raw, dict):
            label = raw.get('label')
            if label is None:
                label = raw.get('date')
            text = str(raw.get('text') or '').strip()
            label = '' if label is None else str(label).strip()
        else:
            text, label = str(raw or '').strip(), ''
        if not text:
            continue
        items.append({'label': label, 'text': text})
    return items


def _step_items(raw_items):
    """Normalize process spec items into {'text'} dicts."""
    items = []
    for raw in raw_items or []:
        text = str(raw.get('text') if isinstance(raw, dict) else raw or '').strip()
        if text:
            items.append({'text': text})
    return items


def render_cards(builder, data):
    """Card grid: 1-4 columns; empty template slots are dropped whole.

    ``slots`` (the number of places the template has) fixes the grid and
    every filled card keeps its template position; with fewer items than
    slots the empty groups are simply not drawn.
    """
    x, y, w, h = _body(builder, data)
    items = _card_items(data.get('items'))
    if not items:
        return
    pal = builder.pal
    declared = int(data.get('slots') or len(items))
    columns = max(1, min(4, int(data.get('columns') or min(3, declared))))
    rows = (declared + columns - 1) // columns
    gap = 0.28
    cap_h = 0.34 if data.get('caption') else 0.0
    area_h = max(1.0, h - cap_h)
    cell_w = (w - gap * (columns - 1)) / columns
    cell_h = (area_h - gap * (rows - 1)) / rows
    pad = 0.22
    builder.record_slots(declared, len(items))
    for index, item in enumerate(items):
        row, col = divmod(index, columns)
        cx = x + col * (cell_w + gap)
        cy = y + row * (cell_h + gap)
        builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, cy, cell_w, cell_h,
                          fill=pal['card'], line=pal['rule'], radius=0.05)
        builder.record_box('card', cx, cy, cell_w, cell_h, extra={'slot': index})
        inner_x = cx + pad
        inner_w = max(0.6, cell_w - 2 * pad)
        inner_y = cy + 0.18
        if item['title']:
            title_lines = max(1, textfit.n_lines(strip_markup(item['title']),
                                                 'georgia_bold', 17.0, inner_w))
            title_h = textfit.height_in(title_lines, 'georgia_bold', 17.0) * 1.05 + 0.04
            builder.simple_text(inner_x, inner_y, inner_w, title_h, item['title'], size=17.0,
                                role='head', color=pal['accent'], bold=True, kind='card_head')
            inner_y += title_h + 0.10
        text_h = max(0.4, cy + cell_h - 0.16 - inner_y)
        builder.text_block([{'text': item['text'], 'no_bullet': True}], inner_x, inner_y,
                           inner_w, text_h, base_size=17.0, min_size=16.0, space_after=0.0)
    _caption(builder, data, x, y + area_h + 0.06, w)


def render_timeline(builder, data):
    """Horizontal timeline: markers with optional labels above and text below.

    ``slots`` keeps the markers on the template grid; the spine spans only
    the filled markers, so no decoration is left without data.
    """
    x, y, w, h = _body(builder, data)
    items = _timeline_items(data.get('items'))
    if not items:
        return
    pal = builder.pal
    declared = int(data.get('slots') or len(items))
    col_w = w / declared
    line_y = y + 0.30 * h
    radius = 0.085
    if len(items) > 1:
        builder.rule(x + col_w / 2.0, line_y, col_w * (len(items) - 1),
                     pal['rule'], h=0.028)
    builder.record_slots(declared, len(items))
    for index, item in enumerate(items):
        center = x + col_w * (index + 0.5)
        builder.add_shape(MSO_SHAPE.OVAL, center - radius, line_y - radius,
                          radius * 2, radius * 2, fill=pal['accent'])
        builder.record_box('slot_marker', center - radius, line_y - radius,
                           radius * 2, radius * 2, extra={'slot': index})
        if item['label']:
            label_h = max(0.3, line_y - radius - y - 0.06)
            builder.simple_text(center - col_w / 2.0 + 0.04, y, col_w - 0.08, label_h,
                                item['label'], size=16.0, role='head', color=pal['accent'],
                                bold=True, align=PP_ALIGN.CENTER, kind='card_head')
        text_y = line_y + radius + 0.10
        text_h = max(0.5, y + h - text_y)
        builder.simple_text(center - col_w / 2.0 + 0.04, text_y, col_w - 0.08, text_h,
                            item['text'], size=16.0, color=pal['ink'],
                            align=PP_ALIGN.CENTER, kind='text')


def render_process(builder, data):
    """Vertical process: numbered steps joined by a spine, optional caption.

    ``slots`` fixes the vertical rhythm of the template; only filled steps
    are drawn (circle, number, text) and the spine stops at the last one.
    """
    x, y, w, h = _body(builder, data)
    items = _step_items(data.get('items'))
    if not items:
        return
    pal = builder.pal
    declared = int(data.get('slots') or len(items))
    cap_h = 0.34 if data.get('caption') else 0.0
    area_h = max(1.0, h - cap_h)
    gap = 0.14
    step_h = (area_h - gap * (declared - 1)) / declared
    circle = 0.40
    spine_len = (len(items) - 1) * (step_h + gap)
    if spine_len > 0:
        builder.rule(x + circle / 2.0 - 0.011, y + circle / 2.0, 0.022,
                     pal['rule'], h=spine_len)
    builder.record_slots(declared, len(items))
    for index, item in enumerate(items, start=1):
        cy = y + (index - 1) * (step_h + gap)
        builder.add_shape(MSO_SHAPE.OVAL, x, cy, circle, circle, fill=pal['accent'])
        builder.record_box('slot_marker', x, cy, circle, circle,
                           extra={'slot': index - 1})
        builder.simple_text(x, cy + (circle - 0.28) / 2.0, circle, 0.28, str(index),
                            size=16.0, color=pal['bg'], bold=True,
                            align=PP_ALIGN.CENTER, kind='card_head')
        tx = x + circle + 0.26
        tw = w - circle - 0.26
        builder.text_block([{'text': item['text'], 'no_bullet': True}], tx, cy,
                           tw, max(0.5, step_h), base_size=19.0, min_size=16.0,
                           space_after=0.0)
    _caption(builder, data, x, y + area_h + 0.06, w)


def render_compare(builder, data):
    """Two labelled panels with column blocks plus an optional verdict banner."""
    x, y, w, h = _body(builder, data)
    pal = builder.pal
    gap = 0.36
    pad = 0.24
    verdict = str(data.get('verdict') or '')
    label_h = 0.42 if (data.get('left_label') or data.get('right_label')) else 0.0
    verdict_h = 0.56 if verdict else 0.0
    area_h = max(1.2, h - verdict_h - (0.16 if verdict else 0.0))
    half = (w - gap) / 2.0
    for side, sx in (('left', x), ('right', x + half + gap)):
        builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, sx, y, half, area_h,
                          fill=pal['card'], line=pal['rule'], radius=0.04)
        cy = y + 0.18
        if label_h:
            label = str(data.get(side + '_label') or '').strip()
            if label:
                builder.simple_text(sx + pad, cy, half - 2 * pad, label_h - 0.04, label,
                                    size=17.0, role='head', color=pal['accent'], bold=True,
                                    kind='card_head')
            cy += label_h
        builder.block(data.get(side) or {}, sx + pad, cy, half - 2 * pad,
                      max(0.8, y + area_h - 0.18 - cy))
    if verdict:
        vy = y + area_h + 0.14
        builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, vy, w, verdict_h,
                          fill=pal['accent_soft'], radius=0.12)
        builder.simple_text(x + pad, vy + (verdict_h - 0.30) / 2.0, w - 2 * pad, 0.30,
                            verdict, size=16.0, color=pal['ink'], bold=True, kind='text')


def render_chart(builder, data):
    """Chart slide: native PowerPoint chart with an embedded data workbook."""
    x, y, w, h = _body(builder, data)
    builder.chart_block(x, y, w, h, data)


def render_steps_grid(builder, data):
    """Numbered tile grid: 2-6 equal tiles, each with a big step number.

    The grid fills the whole body frame by construction, so a short list
    of parallel points never leaves the lower half of the slide empty.
    ``columns`` (1-3) overrides the automatic 2x2 / 3x2 choice; ``slots``
    keeps the template grid when fewer tiles are filled.
    """
    x, y, w, h = _body(builder, data)
    items = _card_items(data.get('items'))
    if not items:
        return
    pal = builder.pal
    declared = int(data.get('slots') or len(items))
    default_columns = 2 if declared <= 4 else 3
    columns = max(1, min(3, int(data.get('columns') or default_columns)))
    rows = (declared + columns - 1) // columns
    gap = 0.26
    cap_h = 0.34 if data.get('caption') else 0.0
    area_h = max(1.0, h - cap_h)
    cell_w = (w - gap * (columns - 1)) / columns
    cell_h = (area_h - gap * (rows - 1)) / rows
    pad = 0.24
    builder.record_slots(declared, len(items))
    for index, item in enumerate(items):
        row, col = divmod(index, columns)
        cx = x + col * (cell_w + gap)
        cy = y + row * (cell_h + gap)
        builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, cy, cell_w, cell_h,
                          fill=pal['card'], line=pal['rule'], radius=0.05)
        builder.record_box('card', cx, cy, cell_w, cell_h,
                           extra={'slot': index, 'content_bottom': cy + cell_h})
        inner_x = cx + pad
        inner_w = max(0.6, cell_w - 2 * pad)
        inner_top = cy + pad
        inner_h = max(0.5, cell_h - 2 * pad)

        # The number scales with the tile so a tall plate never holds a small
        # clump of text; its box is derived from the chosen size so a big
        # numeral can never overflow the box that measures it.
        num_size = min(48.0, max(30.0, cell_h * 12.0))
        num_h = textfit.height_in(1, 'georgia_bold', num_size) * 1.05
        title = item['title']
        title_size = 22.0
        title_h = 0.0
        if title:
            title_size = _fit_lines_size(title, 'georgia_bold', 22.0, 16.0, inner_w,
                                         max_lines=2)
            title_h = _wrap_height(title, 'georgia_bold', title_size, inner_w)
        text = item['text']
        text_gap = 0.14
        text_avail = max(0.4, inner_h - num_h - title_h - text_gap)
        text_size = _fit_size_by_height(text, 'arial', 26.0, 17.0, inner_w, text_avail)
        text_h = min(text_avail, _wrap_height(text, 'arial', text_size, inner_w))
        # Number + title + caption form one group centred vertically inside
        # the tile. A tile is deliberately tall, so a group glued to the top
        # edge leaves a wide dead strip underneath and the plate reads empty.
        group_h = num_h + title_h + text_gap + text_h
        top = inner_top + max(0.0, (inner_h - group_h) / 2.0)

        builder.simple_text(inner_x, top, inner_w, num_h, '%02d' % (index + 1),
                            size=num_size, role='head', color=pal['accent'], bold=True,
                            kind='card_head')
        if title:
            builder.simple_text(inner_x, top + num_h, inner_w, title_h, title,
                                size=title_size, role='head', color=pal['ink'],
                                bold=True, kind='card_head')
        builder.text_block([{'text': text, 'no_bullet': True}], inner_x,
                           top + num_h + title_h + text_gap, inner_w,
                           max(0.4, text_h), base_size=text_size, min_size=16.0,
                           space_after=0.0)
    _caption(builder, data, x, y + area_h + 0.06, w)


def render_pillars(builder, data):
    """Vertical pillars: one full-height column per item, accent header band.

    Columns stretch from the top of the body frame to its bottom, which
    removes the empty lower third typical of a short bulleted list. The
    header band carries the item title; the text sits underneath.
    """
    x, y, w, h = _body(builder, data)
    items = _card_items(data.get('items'))
    if not items:
        return
    pal = builder.pal
    declared = int(data.get('slots') or len(items))
    gap = 0.24
    cap_h = 0.34 if data.get('caption') else 0.0
    area_h = max(1.2, h - cap_h)
    # ``columns`` is documented (2-4) and used to be ignored: every item always
    # landed in one never-wrapping row, so a spec asking for 2 columns still got
    # four narrow ones. It now builds a real grid, like ``steps_grid``.
    columns = max(1, min(4, int(data.get('columns') or declared)))
    rows = (declared + columns - 1) // columns
    col_w = (w - gap * (columns - 1)) / columns
    row_h = (area_h - gap * (rows - 1)) / rows
    band_h = max(0.62, min(1.05, row_h * 0.16))
    pad = 0.22
    builder.record_slots(declared, len(items))
    for index, item in enumerate(items):
        row, col = divmod(index, columns)
        cx = x + col * (col_w + gap)
        cy = y + row * (row_h + gap)
        builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, cy, col_w, row_h,
                          fill=pal['card'], line=pal['rule'], radius=0.04)
        builder.record_box('card', cx, cy, col_w, row_h,
                           extra={'slot': index, 'content_bottom': cy + row_h})
        builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, cy, col_w, band_h,
                          fill=pal['accent'], radius=0.10)
        head = item['title'] or item['text']
        head_w = max(0.5, col_w - 2 * pad)
        # Prefer a single-line band headline: shrink the size until the whole
        # title fits one line, only then allow a two-line break.
        head_size = _fit_lines_size(head, 'georgia_bold', 19.0, 13.0, head_w, max_lines=1)
        head_lines = max(1, textfit.n_lines(strip_markup(head), 'georgia_bold',
                                            head_size, head_w))
        head_h = textfit.height_in(head_lines, 'georgia_bold', head_size) * 1.05
        builder.simple_text(cx + pad, cy + max(0.08, (band_h - head_h) / 2.0),
                            head_w, head_h, head, size=head_size, role='head',
                            color=pal['bg'], bold=True, align=PP_ALIGN.CENTER,
                            kind='card_head')
        if item['title']:
            body_top = cy + band_h
            body_h = max(0.5, cy + row_h - body_top)
            text = item['text']
            text_size = _fit_size_by_height(text, 'arial', 34.0, 18.0, head_w,
                                            max(0.5, body_h - 2 * pad))
            need = _wrap_height(text, 'arial', text_size, head_w)
            # The caption is centred in the room under the header band, so the
            # white space above and below it is symmetric; anchoring it to the
            # band left every column visually bottom-heavy.
            ty = body_top + max(pad, (body_h - need) / 2.0)
            builder.text_block([{'text': text, 'no_bullet': True}],
                               cx + pad, ty, head_w, max(0.4, need),
                               base_size=text_size, min_size=16.0, space_after=0.0)
    _caption(builder, data, x, y + area_h + 0.06, w)


def render_focus(builder, data):
    """One key statement on an accent banner plus 2-3 supporting blocks.

    Used when a slide carries a single thesis: the statement gets a wide
    banner in the upper part, the supports sit in a row underneath, so the
    frame stays balanced instead of holding one lonely bullet at the top.
    """
    x, y, w, h = _body(builder, data)
    pal = builder.pal
    statement = str(data.get('statement') or '').strip()
    if not statement:
        return
    supports = [str(value).strip() for value in (data.get('supports') or [])
                if value is not None and str(value).strip()]
    cap_h = 0.34 if data.get('caption') else 0.0
    area_h = max(1.2, h - cap_h)
    pad = 0.32
    inner_w = max(1.0, w - 2 * pad)
    # The banner hugs its statement: a fixed fraction of the frame left a
    # single short line floating in a tall plate. With supports they take the
    # rest of the frame; without them the statement itself grows to fill it,
    # otherwise a lone thesis left several inches of empty space (QA void).
    if supports:
        size = _fit_lines_size(statement, 'georgia_bold', 28.0, 19.0, inner_w,
                               max_lines=3)
        lines = max(1, textfit.n_lines(strip_markup(statement), 'georgia_bold',
                                       size, inner_w))
        text_h = textfit.height_in(lines, 'georgia_bold', size) * 1.05
        band_h = max(1.05, min(area_h * 0.5, text_h + 0.52))
    else:
        # Statement-only slide: the thesis grows until it fills the frame
        # instead of sitting as one small line in a tall plate.
        size = _fit_size_by_height(statement, 'georgia_bold', 54.0, 22.0, inner_w,
                                   max(1.2, area_h - 1.0))
        lines = max(1, textfit.n_lines(strip_markup(statement), 'georgia_bold',
                                       size, inner_w))
        text_h = textfit.height_in(lines, 'georgia_bold', size) * 1.05
        band_h = max(text_h + 1.0, min(area_h, text_h + 2.2))
    builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, band_h,
                      fill=pal['accent_soft'], radius=0.06)
    builder.record_box('card', x, y, w, band_h, extra={'content_bottom': y + band_h})
    builder.simple_text(x + pad, y + max(0.16, (band_h - text_h) / 2.0), inner_w, text_h,
                        statement, size=size, role='head', color=pal['ink'], bold=True,
                        kind='card_head')
    if supports:
        top = y + band_h + 0.26
        avail = max(0.9, y + area_h - top)
        gap = 0.24
        declared = int(data.get('columns') or min(3, len(supports)))
        columns = max(1, min(4, declared))
        rows = (len(supports) + columns - 1) // columns
        card_w = (w - gap * (columns - 1)) / columns
        card_h = (avail - gap * (rows - 1)) / rows
        for index, text in enumerate(supports):
            row, col = divmod(index, columns)
            cx = x + col * (card_w + gap)
            cy = top + row * (card_h + gap)
            builder.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, cy, card_w, card_h,
                              fill=pal['card'], line=pal['rule'], radius=0.05)
            builder.record_box('card', cx, cy, card_w, card_h,
                               extra={'slot': index, 'content_bottom': cy + card_h})
            # Marker and caption form one centred group: a support card is
            # tall, and a group pinned to the top edge reads as an empty plate.
            text_x = cx + 0.46
            text_w = max(0.6, card_w - 0.66)
            text_size = _fit_size_by_height(text, 'arial', 27.0, 16.0, text_w,
                                            max(0.5, card_h - 0.7))
            need = _wrap_height(text, 'arial', text_size, text_w)
            group_h = max(0.32, need)
            group_top = cy + max(0.24, (card_h - group_h) / 2.0)
            builder.add_shape(MSO_SHAPE.OVAL, cx + 0.20, group_top + 0.06, 0.14, 0.14,
                              fill=pal['accent'])
            builder.text_block([{'text': text, 'no_bullet': True}], text_x, group_top,
                               text_w, max(0.4, need), base_size=text_size,
                               min_size=16.0, space_after=0.0)
    _caption(builder, data, x, y + area_h + 0.06, w)


RENDERERS = {
    'title': render_title,
    'section': render_section,
    'bullets': render_bullets,
    'definition': render_definition,
    'theorem': render_theorem,
    'proof': render_proof,
    'formula': render_formula,
    'code': render_code,
    'table': render_table,
    'chart': render_chart,
    'image': render_image,
    'two_column': render_two_column,
    'cards': render_cards,
    'timeline': render_timeline,
    'process': render_process,
    'compare': render_compare,
    'summary': render_summary,
    'homework': render_homework,
    'literature': render_literature,
    'steps_grid': render_steps_grid,
    'pillars': render_pillars,
    'focus': render_focus,
}
