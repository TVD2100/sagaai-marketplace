"""Layout advice: pick a visual slide type instead of a short bullet list.

A ``bullets`` slide with a handful of short parallel points is the main
source of half-empty frames in the audited course decks: the text occupies
the upper part of the body frame and the lower third stays empty, while
frame-filling by stretching item spacing reads as a layout defect. The
advisor recognizes that shape of content and proposes one of the visual
types added in 1.5.0:

- ``focus`` - one or two points: a key statement banner plus supports;
- ``steps_grid`` - 3-6 short parallel points as numbered tiles;
- ``pillars`` - 3-5 titled components as full-height columns.

Public API:

- ``suggest_layout(slide)`` - advice for one normalized spec slide, or
  ``None`` when the slide is already fine or the content does not match;
- ``apply_auto_layout(spec)`` - rewrite every slide the advisor flags and
  return the list of applied changes (used by ``meta.auto_layout``);
- ``build_replacement(slide, target)`` - the ready-to-paste slide dict for
  a suggested target type.

Both functions are deterministic and never invent content: they only move
user-supplied items into the fields of another slide type.
"""

from __future__ import annotations

# Types the advisor may rewrite: short parallel lists only. ``summary`` and
# ``homework`` keep their list form on purpose (takeaways and tasks read
# better as a list), and every other type already carries a visual.
ADVISED_TYPES = ('bullets',)

# A point is "short" when it fits roughly one line of a tile or column.
SHORT_ITEM_CHARS = 80
SHORT_ITEM_WORDS = 14

# Below this many items a list cannot fill the body frame by itself.
FEW_ITEMS = 2
LAST_FEW = 6


def _item_texts(items):
    """Plain texts of a slide's ``items`` (strings or ``{'text'}`` dicts)."""
    texts = []
    for raw in items or []:
        if isinstance(raw, dict):
            text = str(raw.get('text') or '').strip()
        else:
            text = str(raw or '').strip()
        texts.append(text)
    return texts


def _has_titles(items):
    """True when every item carries its own title (pillar component)."""
    if not items or not all(isinstance(raw, dict) for raw in items):
        return False
    return all(str(raw.get('title') or '').strip() for raw in items)


def _is_short(text):
    """True when a point reads as a one-line tile label."""
    text = str(text or '').strip()
    if not text:
        return False
    return len(text) <= SHORT_ITEM_CHARS and len(text.split()) <= SHORT_ITEM_WORDS


def suggest_layout(slide):
    """Advice for one normalized slide dict; ``None`` when nothing to change.

    Returns ``{'suggested_type', 'reason', 'replacement'}`` where
    ``replacement`` is the complete slide dict for the suggested type.
    """
    if not isinstance(slide, dict):
        return None
    stype = slide.get('type')
    if stype not in ADVISED_TYPES:
        return None
    items = slide.get('items') or []
    texts = [text for text in _item_texts(items) if text]
    count = len(texts)
    if not count or count > LAST_FEW:
        return None
    short = all(_is_short(text) for text in texts)
    if not short:
        return None
    if count <= FEW_ITEMS:
        target = 'focus'
        reason = ('%d short point(s) cannot fill the body frame; a focus slide '
                  'with a statement banner and supports reads as a balanced page'
                  % count)
    elif _has_titles(items) and 3 <= count <= 5:
        target = 'pillars'
        reason = ('%d titled components read as full-height columns; pillars '
                  'fill the frame instead of a list in its upper third' % count)
    else:
        target = 'steps_grid'
        reason = ('%d short parallel points map onto a numbered tile grid, '
                  'which fills the frame by construction' % count)
    return {
        'suggested_type': target,
        'reason': reason,
        'replacement': build_replacement(slide, target),
    }


def build_replacement(slide, target):
    """Build the slide dict for ``target`` from a bullets slide.

    Keeps ``header``, ``caption``, ``note`` and ``source_refs`` unchanged;
    only the item layout changes, so the author keeps control of the text.
    """
    slide = dict(slide or {})
    texts = [text for text in _item_texts(slide.get('items')) if text]
    out = {'type': target}
    for key in ('header', 'caption', 'note', 'source_refs'):
        if slide.get(key) not in (None, '', []):
            out[key] = slide[key]
    if target == 'focus':
        out['statement'] = texts[0] if texts else ''
        if len(texts) > 1:
            out['supports'] = texts[1:3]
    elif target == 'pillars':
        items = []
        for raw in slide.get('items') or []:
            if isinstance(raw, dict):
                entry = {'text': str(raw.get('text') or '').strip()}
                title = str(raw.get('title') or '').strip()
                if title:
                    entry['title'] = title
                items.append(entry)
            else:
                items.append({'text': str(raw).strip()})
        out['items'] = items
    else:
        out['items'] = [{'text': text} for text in texts]
    return out


def apply_auto_layout(spec):
    """Rewrite every flagged slide of ``spec`` in place; returns the changes.

    Each change is ``{'index', 'from', 'to', 'reason'}`` where ``index`` is
    the 1-based slide number, so the build report can name the rewritten
    slides. A slide that the advisor does not flag is left untouched.
    """
    changes = []
    slides = getattr(spec, 'slides', None)
    if not isinstance(slides, list):
        return changes
    for index, slide in enumerate(list(slides), start=1):
        advice = suggest_layout(slide)
        if not advice:
            continue
        slides[index - 1] = advice['replacement']
        changes.append({
            'index': index,
            'from': slide.get('type'),
            'to': advice['suggested_type'],
            'reason': advice['reason'],
        })
    return changes
