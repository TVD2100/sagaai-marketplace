"""Deck-versus-source drift: did the user edit the PPTX by hand?.

A deck is generated from a spec, but the user may open the `.pptx` in
PowerPoint and edit it directly - retitle a slide, rewrite a bullet, add a
note. The spec then no longer describes the file, and the next rebuild would
silently destroy those edits. This module detects that situation so the agent
can ASK before touching anything.

``compare(spec_path, pptx_path)`` rebuilds the spec into a temporary folder
and compares the two decks **by text**, not by bytes: a `.pptx` is a zip whose
member timestamps differ between two identical builds, so a byte comparison
would report drift on every run. For every slide the comparison collects the
visible text (text frames, tables, grouped shapes) and the speaker notes and
reports the lines that exist only in the deck (``user_added`` - a manual edit)
and only in the rebuilt spec deck (``user_removed`` - the spec moved on, or
the user deleted something).

An acknowledged drift can be recorded with ``write_ack(pptx_path)``; the ack
stores the deck's SHA-256, so it stops applying as soon as the deck changes
again. ``is_acknowledged(pptx_path)`` reads it back.

CLI (exit codes: 0 - in sync or acknowledged, 1 - drift, 2 - error)::

    python -m lecture.drift <spec.json> <deck.pptx>

No network access. The temporary rebuild writes into the system temp folder
and is removed immediately.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
from pathlib import Path

ACK_NAME = 'drift_ack.json'
_WS = re.compile(r'\s+')


def _norm(text):
    """Collapse whitespace and strip; empty strings become ''."""
    return _WS.sub(' ', str(text or '')).strip()


def _shape_lines(shape, lines):
    """Collect normalized text lines of one shape, recursing into groups."""
    if getattr(shape, 'has_text_frame', False):
        for paragraph in shape.text_frame.paragraphs:
            text = _norm(''.join(run.text or '' for run in paragraph.runs))
            if not text:
                text = _norm(paragraph.text)
            if text:
                lines.append(text)
    if getattr(shape, 'has_table', False):
        for row in shape.table.rows:
            for cell in row.cells:
                text = _norm(cell.text)
                if text:
                    lines.append(text)
    if getattr(shape, 'shape_type', None) is not None and hasattr(shape, 'shapes'):
        try:
            for child in shape.shapes:
                _shape_lines(child, lines)
        except (AttributeError, TypeError):
            pass


def deck_snapshot(pptx_path):
    """Read a saved deck as ``{'slides': [...], 'count': n}``.

    Every slide entry is ``{'index': int, 'lines': [str], 'notes': [str]}``
    with normalized, non-empty text. Raises ``FileNotFoundError`` for a
    missing file and ``ValueError`` when the file is not a readable PPTX.
    """
    path = Path(pptx_path)
    if not path.exists():
        raise FileNotFoundError('deck not found: %s' % path)
    from pptx import Presentation  # local import: keeps the module importable

    try:
        presentation = Presentation(str(path))
    except Exception as exc:  # noqa: BLE001 - any parser failure means 'unreadable'
        raise ValueError('not a readable pptx: %s (%s)' % (path, exc)) from exc

    slides = []
    for index, slide in enumerate(presentation.slides, start=1):
        lines = []
        for shape in slide.shapes:
            _shape_lines(shape, lines)
        notes = []
        if getattr(slide, 'has_notes_slide', False):
            frame = slide.notes_slide.notes_text_frame
            for paragraph in frame.paragraphs:
                text = _norm(paragraph.text)
                if text:
                    notes.append(text)
        slides.append({'index': index, 'lines': lines, 'notes': notes})
    return {'slides': slides, 'count': len(slides)}


def expected_snapshot(spec_path):
    """Rebuild the spec into a temp folder and snapshot the result.

    Uses the plain renderer (no QA, no reports) so the comparison stays fast
    and leaves nothing behind: the whole build happens inside a temporary
    directory that is deleted before returning.
    """
    from .deck import build_deck
    from .spec import SpecError, load_spec

    spec_path = Path(spec_path)
    if not spec_path.exists():
        raise FileNotFoundError('spec not found: %s' % spec_path)
    try:
        spec = load_spec(spec_path)
    except SpecError as exc:
        raise ValueError('spec error: %s' % '; '.join(exc.errors)) from exc

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        result = build_deck(spec, out_path=tmp_path / 'expected.pptx',
                            assets_dir=tmp_path / 'assets')
        if not result.get('ok'):
            raise ValueError('reference build failed: %s'
                             % '; '.join(result.get('errors') or ['unknown error']))
        return deck_snapshot(result['out_path'])


def _line_diff(deck_lines, spec_lines):
    """Lines present only in the deck and only in the rebuilt spec deck."""
    deck_set = {line for line in deck_lines if line}
    spec_set = {line for line in spec_lines if line}
    return sorted(deck_set - spec_set), sorted(spec_set - deck_set)


def compare(spec_path, pptx_path):
    """Compare a saved deck with the deck the current spec would produce.

    Returns::

        {'ok': bool,            # in sync, or the drift was acknowledged
         'changed': bool,       # the deck and the spec disagree
         'acknowledged': bool,  # a matching ack file records this deck
         'slides': [{'index': int, 'user_added': [str], 'user_removed': [str]}],
         'notes': [{'index': int, 'user_text': [str], 'spec_text': [str]}],
         'counts': {'deck': int, 'spec': int},
         'errors': [str], 'reason': str}

    ``user_added`` lines exist only in the saved deck - the fingerprint of a
    manual edit. ``user_removed`` lines exist only in the rebuilt spec deck:
    the spec moved on after the build, or the user deleted that text.
    """
    report = {'ok': False, 'changed': False, 'acknowledged': False,
              'slides': [], 'notes': [], 'counts': {'deck': 0, 'spec': 0},
              'errors': [], 'reason': ''}
    try:
        deck = deck_snapshot(pptx_path)
        expected = expected_snapshot(spec_path)
    except (FileNotFoundError, ValueError) as exc:
        report['errors'].append(str(exc))
        report['reason'] = str(exc)
        return report
    except Exception as exc:  # noqa: BLE001 - a comparison must never crash the caller
        message = 'drift comparison failed: %s: %s' % (type(exc).__name__, exc)
        report['errors'].append(message)
        report['reason'] = message
        return report

    report['counts'] = {'deck': deck['count'], 'spec': expected['count']}
    if deck['count'] != expected['count']:
        report['changed'] = True
        report['reason'] = ('slide count differs: deck has %d, spec produces %d'
                            % (deck['count'], expected['count']))

    expected_by_index = {slide['index']: slide for slide in expected['slides']}
    for slide in deck['slides']:
        reference = expected_by_index.get(slide['index'])
        if reference is None:
            report['changed'] = True
            report['slides'].append({'index': slide['index'],
                                     'user_added': list(slide['lines']),
                                     'user_removed': []})
            continue
        added, removed = _line_diff(slide['lines'], reference['lines'])
        notes_added, notes_removed = _line_diff(slide['notes'], reference['notes'])
        if added or removed:
            report['changed'] = True
            report['slides'].append({'index': slide['index'],
                                     'user_added': added, 'user_removed': removed})
        if notes_added or notes_removed:
            report['changed'] = True
            report['notes'].append({'index': slide['index'],
                                    'user_text': notes_added,
                                    'spec_text': notes_removed})

    acknowledged = is_acknowledged(pptx_path)
    report['acknowledged'] = bool(acknowledged)
    report['ok'] = (not report['changed']) or report['acknowledged']
    if not report['changed']:
        report['reason'] = 'deck matches the spec'
    elif report['acknowledged']:
        report['reason'] = ('deck differs from the spec, but the user acknowledged '
                            'the manual edits')
    elif not report['reason']:
        report['reason'] = 'deck differs from the spec: the pptx was edited by hand'
    return report


def ack_path(pptx_path, service_dir=True):
    """Where the acknowledgment of one deck lives.

    ``<stem>_service/drift_ack.json`` by default, next to the deck when
    ``service_dir`` is false (the pre-1.5 flat layout).
    """
    deck = Path(pptx_path)
    if service_dir:
        return deck.parent / (deck.stem + '_service') / ACK_NAME
    return deck.parent / ACK_NAME


def write_ack(pptx_path, service_dir=True):
    """Record that the user accepted the current manual edits of this deck.

    The ack stores the deck's SHA-256, so any later change to the file makes
    it stale and the drift is reported again. Returns the ack path.
    """
    from .fingerprint import sha256_file

    deck = Path(pptx_path)
    if not deck.exists():
        raise FileNotFoundError('deck not found: %s' % deck)
    path = ack_path(deck, service_dir=service_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {'pptx': deck.name, 'artifact_sha256': sha256_file(deck)}
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding='utf-8')
    return path


def is_acknowledged(pptx_path, service_dir=True):
    """True when an ack exists AND still describes this exact deck bytes."""
    from .fingerprint import sha256_file

    deck = Path(pptx_path)
    path = ack_path(deck, service_dir=service_dir)
    if not path.exists() or not deck.exists():
        return False
    try:
        payload = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return False
    expected = str(payload.get('artifact_sha256') or '')
    if not expected:
        return False
    try:
        return sha256_file(deck) == expected
    except OSError:
        return False


def report_markdown(report):
    """Render a drift report as a short markdown block for the user."""
    lines = ['# Deck drift check', '']
    if report.get('errors'):
        lines.append('**Error:** ' + '; '.join(report['errors']))
        return '\n'.join(lines) + '\n'
    if not report.get('changed'):
        lines.append('**In sync:** the deck matches the spec.')
        return '\n'.join(lines) + '\n'
    if report.get('acknowledged'):
        lines.append('**Acknowledged:** the deck was edited by hand and the user '
                     'accepted it as final.')
        return '\n'.join(lines) + '\n'
    lines.append('**Drift:** the deck differs from the spec - the pptx looks '
                 'edited by hand.')
    counts = report.get('counts') or {}
    lines.append('')
    lines.append('- Slides: deck %s, spec %s'
                 % (counts.get('deck'), counts.get('spec')))
    for entry in report.get('slides') or []:
        lines.append('- Slide %s:' % entry['index'])
        for text in entry.get('user_added') or []:
            lines.append('  - only in the deck (manual edit): %s' % text)
        for text in entry.get('user_removed') or []:
            lines.append('  - only in the spec (missing from the deck): %s' % text)
    for entry in report.get('notes') or []:
        lines.append('- Notes of slide %s:' % entry['index'])
        for text in entry.get('user_text') or []:
            lines.append('  - only in the deck: %s' % text)
        for text in entry.get('spec_text') or []:
            lines.append('  - only in the spec: %s' % text)
    return '\n'.join(lines) + '\n'


def main(argv=None):
    """CLI: compare one deck with its spec (0 in sync / 1 drift / 2 error)."""
    parser = argparse.ArgumentParser(
        description='Check whether a saved deck still matches its JSON spec.')
    parser.add_argument('spec_path', help='source lecture.json')
    parser.add_argument('pptx_path', help='saved deck .pptx')
    parser.add_argument('--json', action='store_true', dest='as_json',
                        help='print the raw JSON report')
    parser.add_argument('--ack', action='store_true', default=False,
                        help='record that the manual edits are accepted')
    args = parser.parse_args(argv)

    report = compare(args.spec_path, args.pptx_path)
    if args.ack:
        write_ack(args.pptx_path)
        report = compare(args.spec_path, args.pptx_path)
    if args.as_json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(report_markdown(report), end='')
    if report.get('errors'):
        return 2
    return 0 if report.get('ok') else 1


if __name__ == '__main__':
    sys.exit(main())
