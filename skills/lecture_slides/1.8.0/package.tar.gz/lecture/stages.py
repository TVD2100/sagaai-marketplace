"""Three named QA stages: content / file / visual.

``qa_check.check_deck`` runs these stages and merges their findings into
the QA report with ``[content]`` / ``[file]`` / ``[visual]`` prefixes;
``build_lecture`` writes one report file per stage
(``<stem>_service/qa_<stage>.md``). The split exists so that no single reviewer
can pass their own blind spots to the next stage:

* ``content_stage`` reads the *spec text*: placeholder strings left in,
  layout records out of step with the spec, repeated words (a common
  typo).
* ``file_stage`` reads the *pptx package* as bytes: content types that
  point at missing parts, relationship targets that do not resolve, slides
  without a notes relationship, native charts whose embedded workbook is
  missing or disagrees with the spec, OMML formulas whose slide XML has no
  non-empty ``<m:t>``.
* ``visual_stage`` reads *rasterized pages*: content clipped at the page
  edge and blank pages. Per the skill contract this stage MUST be handed
  to a reviewer other than the deck generator's author - the generator
  sees the intended layout, not the rendered one. Without rendered pages
  the stage reports itself as skipped, never as a silent PASS.

Every stage returns a report dict::

    {'stage': str, 'ok': bool, 'skipped': bool, 'reason': str|None,
     'errors': [str], 'warnings': [str], 'summary': str}

The module is fully offline: it only reads the spec object and the saved
pptx bytes. ``stage_markdown(report)`` renders one stage report as its
standalone document.
"""

from __future__ import annotations

import io
import posixpath
import re
import zipfile
from pathlib import Path

from . import themes
from .spec import strip_markup

STAGE_NAMES = ('content', 'file', 'visual')

FRESH_REVIEWER_NOTE = ('Hand this stage to a reviewer other than the deck '
                       'generator author: the generator sees the intended '
                       'layout, not the rendered one.')

BORDER_PX = 2
EDGE_CROP = 2
INK_THRESHOLD = 8

PLACEHOLDER_PATTERNS = (
    (re.compile(r'\{\{[^{}]*\}\}'), 'template placeholder'),
    (re.compile(r'\bTODO\b|\bTBD\b|\bFIXME\b|\bCHANGEME\b'), 'unfinished marker'),
    (re.compile(r'lorem ipsum', re.IGNORECASE), 'lorem ipsum filler'),
)
# Words for the repeated-word typo check: letters plus digits, so
# official compound names like 'Agent2Agent' or 'GPT4' count as ONE word
# instead of two halves that look like a repetition.
WORD_RE = re.compile('[A-Za-zА-Яа-яЁё0-9]{3,}')
SLIDE_PART_RE = re.compile(r'ppt/slides/slide\d+\.xml')
CHART_PART_RE = re.compile(r'ppt/charts/chart(\d+)\.xml')
REL_TAG_RE = re.compile(r'<Relationship\b[^>]*/?>')
OVERRIDE_TAG_RE = re.compile(r'<Override\b[^>]*/?>')
ROW_RE = re.compile(r'<row\b[^>]*>(.*?)</row>', re.DOTALL)
CELL_RE = re.compile(r'<c\b[^>]*/>|<c\b[^>]*>.*?</c>', re.DOTALL)
SI_RE = re.compile(r'<si>(.*?)</si>', re.DOTALL)
TAG_RE = re.compile(r'<[^>]+>')


# ─────────────────────────────── shared ───────────────────────────────

def _stage_report(name, errors, warnings, skipped=False, reason=None):
    """Assemble one stage report dict (see the module docstring)."""
    errors = [str(message) for message in errors]
    warnings = [str(message) for message in warnings]
    if skipped:
        summary = 'stage %s: SKIPPED (%s)' % (name, reason or 'no reason recorded')
    else:
        summary = ('stage %s: %d error(s), %d warning(s)'
                   % (name, len(errors), len(warnings)))
    return {'stage': name, 'ok': not errors, 'skipped': bool(skipped),
            'reason': reason, 'errors': errors, 'warnings': warnings,
            'summary': summary}


def _attr(tag, name):
    """Value of one XML attribute inside a raw tag string, or None."""
    match = re.search(r'\b%s\s*=\s*"([^"]*)"' % re.escape(name), tag)
    return match.group(1) if match else None


def _as_list(value):
    """Normalize a spec field into a list."""
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


# ────────────────────────────── content ──────────────────────────────

def _iter_texts(slide):
    """Yield the text fragments of one spec slide (formulas/code excluded)."""
    if not isinstance(slide, dict):
        return
    for item in _as_list(slide.get('items')):
        if isinstance(item, dict):
            for key in ('text', 'title', 'label'):
                value = item.get(key)
                if value:
                    yield str(value)
        elif item is not None:
            yield str(item)
    for key in ('header', 'text', 'statement', 'term', 'caption', 'verdict',
                'deadline', 'note'):
        value = slide.get(key)
        if isinstance(value, str) and value.strip():
            yield value
        elif isinstance(value, (list, tuple)):
            for fragment in value:
                if fragment is not None:
                    yield str(fragment)
    for key in ('paragraphs', 'steps'):
        for fragment in _as_list(slide.get(key)):
            if fragment is not None:
                yield str(fragment)
    for side in ('left', 'right'):
        block = slide.get(side)
        if not isinstance(block, dict):
            continue
        for item in _as_list(block.get('items')):
            if isinstance(item, dict):
                for key in ('text', 'title'):
                    value = item.get(key)
                    if value:
                        yield str(value)
            elif item is not None:
                yield str(item)
        if block.get('text'):
            yield str(block['text'])


def content_stage(spec, result):
    """Stage 1 - the spec text: placeholders, record order, repeats."""
    errors = []
    warnings = []
    slides = list(getattr(spec, 'slides', None) or [])
    records = list((result or {}).get('records') or [])
    if len(records) != len(slides):
        errors.append('spec declares %d slide(s) but the build produced %d '
                      'layout record(s)' % (len(slides), len(records)))
    for position, record in enumerate(records, start=1):
        if record.get('index') != position:
            errors.append('layout records are out of order: record %d carries '
                          'slide index %r' % (position, record.get('index')))
            break
    for record in records:
        index = record.get('index')
        if not isinstance(index, int) or not 0 < index <= len(slides):
            continue
        slide = slides[index - 1]
        if not isinstance(slide, dict):
            continue
        where = 'slide %s (%s)' % (index, record.get('type') or slide.get('type'))
        seen_words = set()
        seen_placeholders = set()
        for text in _iter_texts(slide):
            clean = strip_markup(str(text))
            for pattern, label in PLACEHOLDER_PATTERNS:
                match = pattern.search(clean)
                if not match or match.group(0) in seen_placeholders:
                    continue
                seen_placeholders.add(match.group(0))
                errors.append('%s: placeholder %r left in the text (%s); '
                              'replace it before delivery'
                              % (where, match.group(0), label))
            tokens = [token.lower() for token in WORD_RE.findall(clean)]
            for first, second in zip(tokens, tokens[1:]):
                if first != second or first in seen_words:
                    continue
                seen_words.add(first)
                warnings.append("%s: repeated word '%s' - check for a typo"
                                % (where, first))
    return _stage_report('content', errors, warnings)


# ─────────────────────────────── file ────────────────────────────────

def _content_type_errors(archive, names):
    """Overrides in [Content_Types].xml must point at existing parts."""
    errors = []
    if '[Content_Types].xml' not in names:
        return ['content types part [Content_Types].xml is missing']
    text = archive.read('[Content_Types].xml').decode('utf-8', 'replace')
    for tag in OVERRIDE_TAG_RE.findall(text):
        part = _attr(tag, 'PartName')
        if part and part.lstrip('/') not in names:
            errors.append('content types declare %s but the part is missing '
                          'from the package' % part)
    return errors


def _relationship_errors(archive, names):
    """Every internal relationship target must exist inside the package."""
    errors = []
    for rels_name in sorted(name for name in names if name.endswith('.rels')):
        base = posixpath.dirname(rels_name)
        if posixpath.basename(base) == '_rels':
            base = posixpath.dirname(base)
        text = archive.read(rels_name).decode('utf-8', 'replace')
        for tag in REL_TAG_RE.findall(text):
            if _attr(tag, 'TargetMode') == 'External':
                continue
            target = _attr(tag, 'Target') or ''
            if not target or target.startswith('#'):
                continue
            if re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
                continue  # external URI (hyperlink target without TargetMode)
            if target.startswith('/'):
                resolved = target.lstrip('/')
            else:
                resolved = posixpath.normpath(posixpath.join(base, target))
            if resolved not in names:
                errors.append("%s: relationship target '%s' is missing from "
                              'the package' % (rels_name, target))
    return errors


def _notes_errors(archive, names, spec):
    """Slide parts must match the spec and carry a notesSlide link."""
    errors = []
    parts = sorted(name for name in names if SLIDE_PART_RE.fullmatch(name))
    declared = len(getattr(spec, 'slides', None) or [])
    if declared and parts and len(parts) != declared:
        errors.append('the package holds %d slide part(s) but the spec '
                      'declares %d slide(s)' % (len(parts), declared))
    for part in parts:
        rels = 'ppt/slides/_rels/%s.rels' % posixpath.basename(part)
        text = ''
        if rels in names:
            text = archive.read(rels).decode('utf-8', 'replace')
        if 'notesSlide' not in text:
            errors.append('%s: no notesSlide relationship; speaker notes are '
                          'mandatory on every slide' % part)
    return errors


def _spec_charts(spec):
    """Declared charts in spec order as {'categories', 'series'} dicts."""
    charts = []
    for slide in getattr(spec, 'slides', None) or []:
        if not isinstance(slide, dict):
            continue
        sources = []
        if slide.get('type') == 'chart':
            sources.append(slide)
        else:
            for side in ('left', 'right'):
                block = slide.get(side)
                if isinstance(block, dict) and block.get('kind') == 'chart':
                    sources.append(block)
        for source in sources:
            series = []
            for entry in _as_list(source.get('series')):
                if isinstance(entry, dict):
                    series.append([float(value)
                                   for value in _as_list(entry.get('values'))])
            charts.append({
                'categories': [str(value)
                               for value in _as_list(source.get('categories'))],
                'series': series,
            })
    return charts


def _embedded_workbook(archive, names, part):
    """Bytes of the chart's embedded workbook, or None when not reachable."""
    rels = 'ppt/charts/_rels/%s.rels' % posixpath.basename(part)
    if rels not in names:
        return None
    text = archive.read(rels).decode('utf-8', 'replace')
    for tag in REL_TAG_RE.findall(text):
        if _attr(tag, 'TargetMode') == 'External':
            continue
        target = _attr(tag, 'Target') or ''
        if not target.endswith('.xlsx'):
            continue
        resolved = posixpath.normpath(posixpath.join('ppt/charts', target))
        if resolved in names:
            return archive.read(resolved)
    return None


def _shared_strings(workbook):
    """Plain text of xl/sharedStrings.xml entries (empty list when absent)."""
    try:
        text = workbook.read('xl/sharedStrings.xml').decode('utf-8', 'replace')
    except KeyError:
        return []
    strings = []
    for entry in SI_RE.findall(text):
        plain = TAG_RE.sub('', entry)
        plain = (plain.replace('&lt;', '<').replace('&gt;', '>')
                 .replace('&quot;', '"').replace('&apos;', "'")
                 .replace('&amp;', '&'))
        strings.append(plain)
    return strings


def _sheet_rows(workbook, shared):
    """Rows of sheet1 as {column letter: value} dicts (strings or floats)."""
    text = workbook.read('xl/worksheets/sheet1.xml').decode('utf-8', 'replace')
    rows = []
    for row_body in ROW_RE.findall(text):
        cells = {}
        for cell in CELL_RE.findall(row_body):
            ref = _attr(cell, 'r') or ''
            column_match = re.match(r'([A-Z]+)', ref)
            if not column_match:
                continue
            column = column_match.group(1)
            kind = _attr(cell, 't') or 'n'
            value_match = re.search(r'<v[^>]*>(.*?)</v>', cell, re.DOTALL)
            if value_match is None:
                cells[column] = ''
                continue
            raw = value_match.group(1).strip()
            if kind == 's':
                try:
                    index = int(raw)
                except ValueError:
                    cells[column] = ''
                    continue
                cells[column] = shared[index] if 0 <= index < len(shared) else ''
            elif kind == 'str':
                cells[column] = raw
            else:
                try:
                    cells[column] = float(raw)
                except ValueError:
                    cells[column] = raw
        rows.append(cells)
    return rows


def _column_letter(number):
    """1-based column number -> letters ('A', 'B', ..., 'AA')."""
    letters = ''
    while number > 0:
        number, remainder = divmod(number - 1, 26)
        letters = chr(65 + remainder) + letters
    return letters


def _category_text(value):
    """Normalized text of one chart category (numbers lose trailing zeros)."""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _workbook_mismatch(data, chart):
    """Compare workbook numbers with the spec; returns a problem or None."""
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as workbook:
            shared = _shared_strings(workbook)
            rows = _sheet_rows(workbook, shared)
    except (zipfile.BadZipFile, KeyError) as exc:
        return 'the embedded workbook cannot be read: %s' % exc
    categories = [_category_text(row.get('A', '')) for row in rows[1:]]
    expected_categories = [_category_text(value)
                           for value in chart.get('categories') or []]
    if categories != expected_categories:
        return ('the workbook categories %s do not match the spec (%s)'
                % (categories, expected_categories))
    for series_index, values in enumerate(chart.get('series') or []):
        column = _column_letter(2 + series_index)
        seen = [row.get(column) for row in rows[1:]]
        expected = [float(value) for value in values]
        if len(seen) != len(expected):
            return ('series %d has %d point(s) in the workbook, the spec '
                    'declares %d' % (series_index + 1, len(seen), len(expected)))
        for position, (actual, wanted) in enumerate(zip(seen, expected), start=1):
            if not isinstance(actual, float) or abs(actual - wanted) > 1e-6:
                return ('series %d point %d is %r in the workbook, the spec '
                        'declares %s' % (series_index + 1, position, actual, wanted))
    return None


def _chart_errors(archive, names, spec):
    """Native charts must exist and their workbooks must match the spec."""
    errors = []
    expected = _spec_charts(spec)
    if not expected:
        return errors
    parts = [name for name in names if CHART_PART_RE.fullmatch(name)]
    parts.sort(key=lambda name: int(CHART_PART_RE.fullmatch(name).group(1)))
    if len(parts) != len(expected):
        errors.append('the spec declares %d chart(s) but the package holds '
                      '%d chart part(s)' % (len(expected), len(parts)))
        return errors
    for position, (part, chart) in enumerate(zip(parts, expected), start=1):
        data = _embedded_workbook(archive, names, part)
        if data is None:
            errors.append('chart %d (%s): no embedded data workbook; the '
                          'chart data would not be editable' % (position, part))
            continue
        problem = _workbook_mismatch(data, chart)
        if problem:
            errors.append('chart %d (%s): %s' % (position, part, problem))
    return errors


def _omml_errors(archive, names, result):
    """OMML formula boxes must appear in the slide XML with real text."""
    errors = []
    for record in (result or {}).get('records') or []:
        boxes = [box for box in record.get('boxes') or [] if box.get('omml')]
        if not boxes:
            continue
        part = 'ppt/slides/slide%s.xml' % record.get('index')
        if part not in names:
            errors.append('%s: OMML formula slide part is missing' % part)
            continue
        xml = archive.read(part).decode('utf-8', 'replace')
        if '<m:oMath' not in xml:
            errors.append('%s: a formula box is OMML but the slide XML has '
                          'no <m:oMath> element' % part)
            continue
        texts = re.findall(r'<m:t[^>]*>(.*?)</m:t>', xml, re.DOTALL)
        if not any(value.strip() for value in texts):
            errors.append('%s: the OMML elements carry no non-empty <m:t> '
                          'text' % part)
    return errors


def _empty_media_errors(archive, names):
    """Zero-byte media parts mean an asset never made it into the deck."""
    errors = []
    for name in sorted(names):
        if not name.startswith('ppt/media/'):
            continue
        if archive.getinfo(name).file_size == 0:
            errors.append('%s: media part is empty' % name)
    return errors


def file_stage(spec, result):
    """Stage 2 - the saved pptx package: types, rels, charts, OMML."""
    out = (result or {}).get('out_path') or (result or {}).get('pptx')
    path = Path(str(out)) if out else None
    if path is None or not path.exists():
        return _stage_report(
            'file', [], [], skipped=True,
            reason='the deck was not saved to disk; file-stage checks skipped')
    errors = []
    try:
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            errors.extend(_content_type_errors(archive, names))
            errors.extend(_relationship_errors(archive, names))
            errors.extend(_notes_errors(archive, names, spec))
            errors.extend(_chart_errors(archive, names, spec))
            errors.extend(_omml_errors(archive, names, result))
            errors.extend(_empty_media_errors(archive, names))
    except (zipfile.BadZipFile, OSError) as exc:
        errors.append('the deck is not a readable OOXML package: %s' % exc)
    return _stage_report('file', errors, [])


# ────────────────────────────── visual ───────────────────────────────

def _ink_bbox(image):
    """Bounding box of pixels differing from the dominant background color."""
    from PIL import Image, ImageChops
    thumb = image.copy()
    thumb.thumbnail((256, 256))
    colors = thumb.getcolors(maxcolors=1 << 20)
    if not colors:
        return None
    background = max(colors, key=lambda entry: entry[0])[1]
    solid = Image.new('RGB', image.size, background)
    diff = ImageChops.difference(image, solid).convert('L')
    mask = diff.point(lambda value: 255 if value > INK_THRESHOLD else 0)
    return mask.getbbox()


def visual_stage(spec, result, pages=None):
    """Stage 3 - rasterized pages: clipped content and blank pages."""
    errors = []
    warnings = []
    page_list = [str(page) for page in (pages or []) if page]
    records = list((result or {}).get('records') or [])
    if not page_list:
        return _stage_report(
            'visual', [], [], skipped=True,
            reason='no rendered pages supplied; hand this stage to a fresh '
                   'reviewer other than the deck generator author')
    if records and len(page_list) < len(records):
        warnings.append('only %d rendered page(s) for %d slide(s); the visual '
                        'pass is incomplete' % (len(page_list), len(records)))
    expected_ratio = themes.SLIDE_W / themes.SLIDE_H
    for number, page in enumerate(page_list, start=1):
        path = Path(page)
        if not path.exists():
            errors.append('page %d: rendered page not found: %s' % (number, path))
            continue
        try:
            from PIL import Image
            with Image.open(path) as image:
                rgb = image.convert('RGB')
                page_size = rgb.size
                if (page_size[0] > 2 * EDGE_CROP and page_size[1] > 2 * EDGE_CROP):
                    # The rasterizer leaves a one-pixel page seam at the border
                    # (PDF page edge); crop it so the seam is not mistaken for
                    # clipped content. Real clipping still touches the edge of
                    # the cropped image.
                    inner = rgb.crop((EDGE_CROP, EDGE_CROP,
                                      page_size[0] - EDGE_CROP,
                                      page_size[1] - EDGE_CROP))
                else:
                    inner = rgb
                bbox = _ink_bbox(inner)
                size = inner.size
        except Exception as exc:  # noqa: BLE001 - any unreadable page is a finding
            errors.append('page %d: cannot read the rendered page: %s'
                          % (number, exc))
            continue
        if bbox is None:
            errors.append('page %d: the page is blank' % number)
            continue
        if (bbox[0] <= BORDER_PX or bbox[1] <= BORDER_PX
                or bbox[2] >= size[0] - BORDER_PX
                or bbox[3] >= size[1] - BORDER_PX):
            errors.append('page %d: content is clipped at the slide edge '
                          '(overflow); move or shrink it' % number)
        ratio = page_size[0] / float(page_size[1] or 1)
        if abs(ratio - expected_ratio) > 0.05:
            warnings.append('page %d: aspect ratio %.2f differs from the 16:9 '
                            'slide (%.2f)' % (number, ratio, expected_ratio))
    return _stage_report('visual', errors, warnings)


# ─────────────────────────── assembly ───────────────────────────

def run_stages(spec, result, pages=None):
    """Run all three stages; returns {'content'|'file'|'visual': report}."""
    return {
        'content': content_stage(spec, result),
        'file': file_stage(spec, result),
        'visual': visual_stage(spec, result, pages=pages),
    }


def stage_markdown(report):
    """Render one stage report as its standalone markdown document."""
    report = report or {}
    name = str(report.get('stage') or 'stage')
    lines = ['# QA stage report (%s)' % name, '']
    if report.get('skipped'):
        status = 'SKIPPED'
    elif report.get('ok'):
        status = 'OK'
    else:
        status = 'FAILED'
    lines.append('- Status: **%s**' % status)
    if report.get('reason'):
        lines.append('- Reason: %s' % report['reason'])
    if name == 'visual':
        lines.append('- Review rule: %s' % FRESH_REVIEWER_NOTE)
    lines.append('- Findings: %d error(s), %d warning(s)'
                 % (len(report.get('errors') or []),
                    len(report.get('warnings') or [])))
    lines.append('')
    lines.append('## Errors')
    lines.append('')
    if report.get('errors'):
        lines.extend('- ' + str(message) for message in report['errors'])
    else:
        lines.append('None.')
    lines.append('')
    lines.append('## Warnings')
    lines.append('')
    if report.get('warnings'):
        lines.extend('- ' + str(message) for message in report['warnings'])
    else:
        lines.append('None.')
    return '\n'.join(lines) + '\n'
