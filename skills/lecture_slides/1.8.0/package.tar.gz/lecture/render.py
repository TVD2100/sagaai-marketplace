"""Content renderers: formulas (matplotlib mathtext) and code (pygments).

Formulas are rasterized to transparent PNG at 300 dpi so they look identical
in PowerPoint, LibreOffice and PDF handouts. Code is NOT rasterized: it is
highlighted into colored text runs, which stays selectable and editable.

Public API:

- ``render_formula(lines, out_path, color, fontsize)`` -> dict with ``ok``,
  ``path``, ``width_in``, ``height_in``, ``fontsize``. Raises ``RenderError``
  with a clear message for unsupported mathtext (environments like
  ``\\begin{...}``, custom macros).
- ``highlight_code(code, language)`` -> list of lines; each line is a list of
  ``(text, color_hex)`` spans. Raises ``RenderError`` for unknown languages.
- ``normalize_language(language)`` / ``SUPPORTED_LANGUAGES``.
"""

from __future__ import annotations

from pathlib import Path

DPI = 300.0
FORMULA_FONTSIZE = 22.0
FORMULA_FONTSET = 'cm'          # Computer Modern - classic textbook look

SUPPORTED_LANGUAGES = (
    'python', 'c', 'cpp', 'java', 'javascript', 'typescript', 'sql', 'bash',
    'json', 'yaml', 'html', 'css', 'xml', 'text',
)

_LANG_ALIASES = {
    'py': 'python',
    'python3': 'python',
    'c++': 'cpp',
    'cxx': 'cpp',
    'js': 'javascript',
    'ts': 'typescript',
    'sh': 'bash',
    'shell': 'bash',
    'zsh': 'bash',
    'yml': 'yaml',
    'txt': 'text',
    'plain': 'text',
}

_CODE_STYLE = 'friendly'


class RenderError(Exception):
    """Raised when a formula or a code listing cannot be rendered."""

    def __init__(self, errors):
        self.errors = list(errors) or ['render error']
        super().__init__('; '.join(self.errors))


def normalize_language(language):
    """Map user aliases ('py', 'c++', 'sh', ...) to canonical lexer names."""
    lang = str(language or '').strip().lower()
    return _LANG_ALIASES.get(lang, lang)


def clean_formula(line):
    """Strip surrounding math delimiters and outer whitespace from a formula."""
    text = str(line).strip()
    while len(text) > 1 and text.startswith('$') and text.endswith('$'):
        text = text[1:-1].strip()
    return text


def _pyplot():
    """Import matplotlib with the Agg backend (idempotent)."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        matplotlib.rcParams['mathtext.fontset'] = FORMULA_FONTSET
    except Exception:
        matplotlib.rcParams['mathtext.fontset'] = 'dejavusans'
    return plt


def render_formula(lines, out_path, color='#1B2A41', fontsize=FORMULA_FONTSIZE,
                   dpi=DPI, max_width_in=11.4):
    """Render formula lines (mathtext) into a transparent PNG.

    ``lines`` is a string or a list of strings; a list renders as stacked
    centered lines. Returns natural image size in inches at the target dpi.
    """
    if isinstance(lines, str):
        lines = [lines]
    items = [clean_formula(line) for line in lines if str(line).strip()]
    if not items:
        raise RenderError(['formula is empty'])

    plt = _pyplot()
    text = '\n'.join('$' + item + '$' for item in items)
    fig = plt.figure(figsize=(2.0, 2.0), dpi=dpi)
    fig.patch.set_alpha(0.0)
    fig.text(0.0, 0.02, text, fontsize=fontsize, color=color,
             ha='left', va='bottom', linespacing=1.9)

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fig.savefig(str(out_path), dpi=dpi, transparent=True,
                    bbox_inches='tight', pad_inches=0.06)
    except (ValueError, RuntimeError) as exc:
        raise RenderError(['unsupported formula %r: %s' % (text, exc)]) from exc
    finally:
        plt.close(fig)

    from PIL import Image
    with Image.open(out_path) as image:
        px_w, px_h = image.size
    width_in = px_w / dpi
    height_in = px_h / dpi
    scale = 1.0
    if max_width_in and width_in > max_width_in:
        scale = max_width_in / width_in
    return {
        'ok': True,
        'path': str(out_path),
        'width_in': round(width_in * scale, 3),
        'height_in': round(height_in * scale, 3),
        'fontsize': fontsize,
    }


def formula_key(lines, color, fontsize):
    """Stable cache key for a formula image."""
    if isinstance(lines, str):
        lines = [lines]
    body = '\n'.join(clean_formula(line) for line in lines)
    return '%s|%s|%s' % (body, color, fontsize)


def highlight_code(code, language, default_color='#1B2A41', style_name=_CODE_STYLE):
    """Tokenize and highlight code into per-line colored spans.

    Returns a list of lines; each line is a list of ``(text, color_hex)``
    tuples. Tabs are expanded to four spaces. Unknown languages raise
    ``RenderError``.
    """
    from pygments import lex
    from pygments.lexers import get_lexer_by_name
    from pygments.styles import get_style_by_name
    from pygments.util import ClassNotFound

    lang = normalize_language(language) or 'text'
    if lang not in SUPPORTED_LANGUAGES:
        raise RenderError([
            "unsupported code language '%s'; supported: %s"
            % (language, ', '.join(SUPPORTED_LANGUAGES))
        ])
    try:
        lexer = get_lexer_by_name(lang, stripnl=False, ensurenl=False)
    except ClassNotFound as exc:
        raise RenderError([
            "unsupported code language '%s'; supported: %s"
            % (language, ', '.join(SUPPORTED_LANGUAGES))
        ]) from exc

    style = get_style_by_name(style_name)
    text = str(code or '').replace('\t', '    ')
    try:
        tokens = list(lex(text, lexer))
    except Exception as exc:  # noqa: BLE001 - report any lexer failure clearly
        raise RenderError(['cannot tokenize %s code: %s' % (lang, exc)]) from exc

    def color_of(ttype):
        current = ttype
        while current is not None:
            try:
                color = style.style_for_token(current).get('color')
            except KeyError:
                color = None
            if color:
                return '#' + str(color).lstrip('#')
            parent = current.parent
            if parent is None or parent is current:
                break
            current = parent
        return default_color

    lines = [[]]
    for ttype, value in tokens:
        color = color_of(ttype)
        parts = value.split('\n')
        for pos, part in enumerate(parts):
            if pos > 0:
                lines.append([])
            if part:
                lines[-1].append((part, color))
    if text.endswith('\n') and lines and not lines[-1]:
        lines.pop()
    return lines
