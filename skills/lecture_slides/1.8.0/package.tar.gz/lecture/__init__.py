"""lecture-slides helper package.

See ``SKILL.md`` in the skill folder for the workflow. Public surface:

- ``spec`` - load/validate lecture specs (JSON) and inline markup helpers;
- ``themes`` - palettes, typography scale and slide geometry;
- ``textfit`` - PIL text metrics and WCAG contrast helpers;
- ``render`` - formula (matplotlib mathtext) and code (pygments) renderers;
- ``deck`` - ``DeckBuilder`` / ``build_deck`` producing the PPTX;
- ``slides`` - per-type slide renderers (registry ``RENDERERS``);
- ``fingerprint`` - artifact/source SHA-256 digests binding reports to bytes;
- ``baseline`` - heading-level comparison against a previous deck version;
- ``stages`` - three named QA stages (content/file/visual) with separate reports;
- ``drift`` - deck-versus-spec drift: did the user edit the PPTX by hand?
- ``apa`` - APA 7th references for cases, quotes and figures (``[@id]``).
"""

from __future__ import annotations

from . import apa, baseline, drift, fingerprint, omml, stages
from .deck import DeckBuilder, build_deck
from .spec import (
    SLIDE_TYPES,
    Spec,
    SpecError,
    is_safe_link,
    load_spec,
    normalize_dashes,
    split_markup,
    strip_markup,
    validate_spec,
)
from .themes import DEFAULT_THEME, THEMES, TYPE, get_fonts, get_theme, theme_names

__all__ = [
    'DeckBuilder',
    'build_deck',
    'SLIDE_TYPES',
    'Spec',
    'SpecError',
    'load_spec',
    'is_safe_link',
    'normalize_dashes',
    'split_markup',
    'strip_markup',
    'validate_spec',
    'DEFAULT_THEME',
    'THEMES',
    'TYPE',
    'get_fonts',
    'get_theme',
    'theme_names',
    'fingerprint',
    'baseline',
    'omml',
    'stages',
    'drift',
    'apa',
]

__version__ = '1.8.0'
