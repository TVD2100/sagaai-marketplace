"""Image QA: sanity checks for pictures embedded into a deck.

Slide-level QA sees a picture as one opaque box; the defects that actually
embarrass a lecturer live inside the bitmap - a single-color 'image' that is
effectively invisible, a thumbnail scaled to full width, a plot whose labels
are cut off at the edge. ``inspect_image`` opens the PNG, flattens
semi-transparent pixels over white and reports structured findings::

    {'ok': bool, 'path': str, 'width': int, 'height': int,
     'colors': int|None, 'errors': [str], 'warnings': [str]}

Rules (tunable through ``qa`` in the spec):

- missing/unreadable file - error;
- both sides below ``min_image_px`` - error 'too small to read';
- one side below ``min_image_px`` - warning 'small image side';
- exactly one flattened color - error 'single solid color' (a blank plate);
- ink touching the bitmap border - warning (the drawing may be cropped).

Border scanning is shared with ``lecture.figkit`` so both figure scripts and
QA use one implementation. No network access; fails soft on unreadable files.
"""

from __future__ import annotations

from pathlib import Path

from . import figkit

DEFAULT_MIN_PX = 200
_SOLID_COLOR_LIMIT = 2   # PIL getcolors(maxcolors): 1 real color + sentinel


def inspect_image(path, min_px=DEFAULT_MIN_PX, edge_px=3, thresh=200):
    """Inspect one image file; returns a findings dict (never raises)."""
    result = {
        'ok': False, 'path': str(path), 'width': 0, 'height': 0,
        'colors': None, 'errors': [], 'warnings': [],
    }
    resolved = Path(str(path))
    if not resolved.exists():
        result['errors'].append('image file not found: %s' % resolved.name)
        return result
    try:
        from PIL import Image
        with Image.open(str(resolved)) as image:
            flat = figkit.flatten(image)
            width, height = flat.size
            colors = flat.getcolors(maxcolors=_SOLID_COLOR_LIMIT)
    except Exception as exc:  # noqa: BLE001 - unreadable bitmap is a finding, not a crash
        result['errors'].append('cannot read image %s: %s' % (resolved.name, exc))
        return result

    result['width'] = int(width)
    result['height'] = int(height)
    result['colors'] = len(colors) if colors else None
    limit = int(min_px or DEFAULT_MIN_PX)

    if result['colors'] == 1:
        result['errors'].append('image %s is a single solid color (looks blank)'
                                % resolved.name)
    if width < limit and height < limit:
        result['errors'].append('image %s is too small to read on a slide (%dx%d px, min %d)'
                                % (resolved.name, width, height, limit))
    elif width < limit or height < limit:
        result['warnings'].append('image %s has a small side (%dx%d px, min %d)'
                                  % (resolved.name, width, height, limit))

    issue = figkit.check_border(resolved, edge_px=edge_px, thresh=thresh)
    if issue:
        result['warnings'].append('image %s: %s (drawing may be cropped)'
                                  % (resolved.name, issue))

    result['ok'] = not result['errors']
    return result
