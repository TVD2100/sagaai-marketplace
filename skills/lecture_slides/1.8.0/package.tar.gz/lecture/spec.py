"""Spec loading, validation and localization for the lecture-slides bundle.

The lecture spec is a UTF-8 JSON document::

    {"meta": {...}, "slides": [...], "qa": {...}?}

Public API:

- ``load_spec(path)`` - read and validate a spec file, return a ``Spec``.
- ``validate_spec(raw, path)`` - validate an already parsed dict.
- ``SpecError`` - raised on structural problems; ``.errors`` lists them all.
- ``Spec`` - normalized spec: ``meta``, ``slides``, ``qa``, ``warnings``,
  ``base_dir`` and the localized ``label(name, **fmt)`` helper.

Validation policy: problems that prevent rendering (malformed JSON, unknown
slide type, missing required fields) raise ``SpecError``; soft problems
(unknown keys, unknown language) are collected in ``Spec.warnings`` and
reported by the QA step. The optional ``meta.sources`` registry
(``{id, title, url?, kind?, checked_at?}``) backs fact-checking: a slide may
list registry ids in ``source_refs``, and a ``literature`` slide with
``source_refs`` materializes its items from the registry.
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path

from . import apa

SLIDE_TYPES = (
    'title', 'section', 'bullets', 'definition', 'theorem', 'proof',
    'formula', 'code', 'table', 'chart', 'image', 'two_column', 'cards',
    'timeline', 'process', 'compare', 'summary', 'homework', 'literature',
    'steps_grid', 'pillars', 'focus',
)

CHART_TYPES = ('bar', 'line', 'pie')

TYPE_FIELDS = {
    'title': ('title', 'subtitle', 'course', 'lecturer', 'org', 'date', 'footer_left'),
    'section': ('header', 'title', 'number', 'subtitle'),
    'bullets': ('header', 'items'),
    'definition': ('header', 'term', 'text', 'formula', 'caption'),
    'theorem': ('header', 'kind', 'name', 'statement', 'formula', 'caption'),
    'proof': ('header', 'steps', 'formula', 'qed', 'caption'),
    'formula': ('header', 'formula', 'caption', 'numbered'),
    'code': ('header', 'language', 'code', 'caption', 'start_line'),
    'table': ('header', 'columns', 'rows', 'caption', 'col_widths'),
    'chart': ('header', 'chart_type', 'categories', 'series', 'caption'),
    'image': ('header', 'path', 'caption', 'width', 'height'),
    'two_column': ('header', 'left', 'right', 'split'),
    'cards': ('header', 'items', 'columns', 'caption', 'slots'),
    'timeline': ('header', 'items', 'slots'),
    'process': ('header', 'items', 'caption', 'slots'),
    'compare': ('header', 'left', 'right', 'left_label', 'right_label', 'verdict'),
    'summary': ('header', 'items'),
    'homework': ('header', 'items', 'deadline'),
    'literature': ('header', 'items'),
    'steps_grid': ('header', 'items', 'columns', 'caption', 'slots'),
    'pillars': ('header', 'items', 'columns', 'caption', 'slots'),
    'focus': ('header', 'statement', 'supports', 'columns', 'caption'),
}

REQUIRED_FIELDS = {
    'bullets': ('items',),
    'definition': ('term', 'text'),
    'theorem': ('statement',),
    'proof': ('steps',),
    'formula': ('formula',),
    'code': ('language', 'code'),
    'table': ('columns', 'rows'),
    'image': ('path',),
    'two_column': ('left', 'right'),
    'cards': ('items',),
    'timeline': ('items',),
    'process': ('items',),
    'compare': ('left', 'right'),
    'summary': ('items',),
    'homework': ('items',),
    'literature': ('items',),
    'chart': ('categories', 'series'),
    'steps_grid': ('items',),
    'pillars': ('items',),
    'focus': ('statement',),
}

BLOCK_FIELDS = {
    'bullets': ('items', 'text'),
    'paragraphs': ('items', 'text'),
    'formula': ('formula', 'caption'),
    'code': ('language', 'code', 'caption', 'start_line'),
    'image': ('path', 'caption', 'width', 'height'),
    'table': ('columns', 'rows', 'caption', 'col_widths'),
    'chart': ('chart_type', 'categories', 'series', 'caption'),
}

META_KEYS = (
    'course', 'lecture_no', 'title', 'subtitle', 'lecturer', 'org', 'date',
    'lang', 'theme', 'duration_min', 'footer_left', 'labels', 'sources',
    'baseline', 'formula_mode', 'normalize_dashes', 'auto_layout',
)

TOP_KEYS = ('meta', 'slides', 'qa')

QA_KEYS = (
    'min_note_words', 'max_note_words', 'max_bullets', 'max_code_lines',
    'min_body_pt', 'min_margin_in', 'check_images', 'min_image_px',
    'check_glyphs', 'check_density', 'min_slide_words', 'min_column_words',
    'check_lists', 'min_list_items', 'check_overlaps', 'overlap_frac',
    'check_formula_caption', 'check_source_refs', 'check_apa', 'strict',
    'check_duration', 'duration_tolerance', 'min_fill',
    'check_void', 'max_void_in', 'check_dashes', 'check_layout_advice',
)

LABELS = {
    'ru': {
        'lecture': 'Лекция {no}',
        'plan': 'План лекции',
        'definition': 'Определение',
        'theorem': 'Теорема',
        'lemma': 'Лемма',
        'corollary': 'Следствие',
        'statement': 'Утверждение',
        'proof': 'Доказательство',
        'example': 'Пример',
        'formula': 'Формула',
        'summary': 'Итоги',
        'homework': 'Задание',
        'deadline': 'Срок сдачи: {deadline}',
        'literature': 'Литература',
        'series': 'Ряд {no}',
        'slide': 'Слайд',
        'page': '{current} / {total}',
    },
    'en': {
        'lecture': 'Lecture {no}',
        'plan': 'Lecture plan',
        'definition': 'Definition',
        'theorem': 'Theorem',
        'lemma': 'Lemma',
        'corollary': 'Corollary',
        'statement': 'Proposition',
        'proof': 'Proof',
        'example': 'Example',
        'formula': 'Formula',
        'summary': 'Summary',
        'homework': 'Homework',
        'deadline': 'Deadline: {deadline}',
        'literature': 'References',
        'series': 'Series {no}',
        'slide': 'Slide',
        'page': '{current} / {total}',
    },
}


class SpecError(Exception):
    """Raised when a lecture spec cannot be used for rendering."""

    def __init__(self, errors):
        self.errors = list(errors) or ['unknown spec error']
        super().__init__('; '.join(self.errors))


class Spec:
    """Normalized lecture spec with localized label helpers."""

    def __init__(self, meta, slides, qa, path=None, warnings=None):
        self.meta = dict(meta)
        self.slides = list(slides)
        self.qa = dict(qa or {})
        self.path = Path(path) if path else None
        self.base_dir = self.path.parent if self.path else Path('.')
        self.warnings = list(warnings or [])

    # -- meta accessors -------------------------------------------------

    @property
    def lang(self):
        return self.meta.get('lang') or 'ru'

    @property
    def theme(self):
        return str(self.meta.get('theme') or 'academic_blue')

    @property
    def title(self):
        return str(self.meta.get('title') or '')

    @property
    def duration_min(self):
        value = self.meta.get('duration_min') or 0
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0

    def meta_value(self, key, default=''):
        value = self.meta.get(key)
        if value is None:
            return default
        return value

    def label(self, key, **fmt):
        """Return a localized UI label with optional formatting."""
        overrides = self.meta.get('labels')
        text = None
        if isinstance(overrides, dict):
            text = overrides.get(key)
        if text is None:
            table = LABELS.get(self.lang, LABELS['ru'])
            text = table.get(key)
        if text is None:
            text = LABELS['en'].get(key, key)
        if not fmt:
            return text
        try:
            return text.format(**fmt)
        except (KeyError, IndexError):
            return text


# ───────────────────────── validation helpers ──────────────────────────

def as_lines(value):
    """Normalize a text-ish spec value into a list of strings."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple)):
        return [str(item) for item in value if item is not None]
    return [str(value)]


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _validate_items(items, where, errors):
    if not isinstance(items, list) or not items:
        errors.append(where + ": 'items' must be a non-empty list")
        return
    for i, item in enumerate(items):
        if isinstance(item, str):
            if not item.strip():
                errors.append(where + ': item %d is empty' % (i + 1))
        elif isinstance(item, dict):
            text = item.get('text')
            if not isinstance(text, str) or not text.strip():
                errors.append(where + ": item %d must contain a non-empty 'text'" % (i + 1))
            level = item.get('level')
            if level is not None and not isinstance(level, int):
                errors.append(where + ": item %d has a non-integer 'level'" % (i + 1))
        else:
            errors.append(where + ': item %d must be a string or an object with text' % (i + 1))


def _validate_formula(value, where, errors):
    lines = as_lines(value)
    if not lines:
        errors.append(where + ": 'formula' must be a non-empty string or a list of strings")


def _validate_table(data, where, errors):
    columns = data.get('columns')
    rows = data.get('rows')
    if not isinstance(columns, list) or not columns:
        errors.append(where + ": 'columns' must be a non-empty list")
        return
    if not isinstance(rows, list) or not rows:
        errors.append(where + ": 'rows' must be a non-empty list")
        return
    for r, row in enumerate(rows):
        if not isinstance(row, list):
            errors.append(where + ': row %d must be a list' % (r + 1))
            continue
        if len(row) != len(columns):
            errors.append(where + ': row %d has %d cells, expected %d'
                          % (r + 1, len(row), len(columns)))


CHART_SERIES_KEYS = ('name', 'values')


def _validate_chart(data, where, errors, warnings=None):
    """Validate chart fields; normalize chart_type/categories/series."""
    if warnings is None:
        warnings = []
    chart_type = data.get('chart_type')
    if isinstance(chart_type, str) and chart_type.strip().lower() in CHART_TYPES:
        chart_type = chart_type.strip().lower()
    elif chart_type is None:
        chart_type = 'bar'
    else:
        errors.append(where + ": 'chart_type' must be one of %s"
                      % ', '.join(CHART_TYPES))
        chart_type = 'bar'
    data['chart_type'] = chart_type

    categories = data.get('categories')
    if not isinstance(categories, list) or not categories:
        errors.append(where + ": 'categories' must be a non-empty list of strings")
        return
    clean_categories = []
    for index, value in enumerate(categories, start=1):
        text = '' if value is None or isinstance(value, bool) else str(value).strip()
        if not text:
            errors.append(where + ': category %d must be a non-empty string' % index)
            continue
        clean_categories.append(text)
    data['categories'] = clean_categories

    series = data.get('series')
    if not isinstance(series, list) or not series:
        errors.append(where + ": 'series' must be a non-empty list of objects")
        return
    clean_series = []
    for index, entry in enumerate(series, start=1):
        if not isinstance(entry, dict):
            errors.append(where + ': series %d must be an object {name, values}' % index)
            continue
        for key in entry:
            if key not in CHART_SERIES_KEYS:
                warnings.append(where + ": unknown key '%s' in series %d" % (key, index))
        values = entry.get('values')
        if not isinstance(values, list) or not values:
            errors.append(where + ': series %d needs a non-empty list of values' % index)
            continue
        numbers = []
        invalid = False
        for value in values:
            if (isinstance(value, (int, float)) and not isinstance(value, bool)
                    and math.isfinite(float(value))):
                numbers.append(float(value))
            else:
                invalid = True
                break
        if invalid:
            errors.append(where + ': series %d values must be finite numbers' % index)
            continue
        if len(numbers) != len(clean_categories):
            errors.append(where + ': series %d has %d values, expected %d'
                          % (index, len(numbers), len(clean_categories)))
            continue
        item = {'values': numbers}
        name = entry.get('name')
        if isinstance(name, str):
            if name.strip():
                item['name'] = name.strip()
        elif name is not None:
            warnings.append(where + ": series %d 'name' must be a string; ignored" % index)
        clean_series.append(item)
    if chart_type == 'pie' and len(series) > 1:
        errors.append(where + ': pie chart supports exactly one series')
    if (chart_type == 'pie' and clean_series
            and any(value < 0 for value in clean_series[0]['values'])):
        warnings.append(where + ': pie chart series has negative values; '
                        'slices cannot represent them')
    data['series'] = clean_series


def _validate_block(block, where, errors, warnings=None):
    if not isinstance(block, dict):
        errors.append(where + ': block must be an object with a kind')
        return
    kind = block.get('kind')
    if kind not in BLOCK_FIELDS:
        errors.append(where + ": unknown block kind '%s' (expected one of %s)"
                      % (kind, ', '.join(sorted(BLOCK_FIELDS))))
        return
    for key in block:
        if key != 'kind' and key not in BLOCK_FIELDS[kind]:
            errors.append(where + ": unknown key '%s' for block kind '%s'" % (key, kind))
    if kind in ('bullets', 'paragraphs'):
        if 'items' in block:
            _validate_items(block['items'], where, errors)
        elif not isinstance(block.get('text'), str):
            errors.append(where + ": block needs 'items' or 'text'")
    elif kind == 'formula':
        if 'formula' not in block:
            errors.append(where + ": block needs 'formula'")
        else:
            _validate_formula(block['formula'], where, errors)
    elif kind == 'code':
        for key in ('language', 'code'):
            if not block.get(key):
                errors.append(where + ": block needs '%s'" % key)
    elif kind == 'image':
        if not block.get('path'):
            errors.append(where + ": block needs 'path'")
    elif kind == 'table':
        _validate_table(block, where, errors)
    elif kind == 'chart':
        _validate_chart(block, where, errors, warnings)


# ─────────────────────────── main validation ───────────────────────────

def _validate_sources(sources, warnings):
    """Validate ``meta.sources`` entries; returns the normalized list.

    An entry is an object ``{id, title, url?, kind?, checked_at?}``: ``id``
    and ``title`` are required non-empty strings, ``url`` must be a safe
    http(s)/mailto link. Invalid entries are dropped with a warning.
    """
    if sources is None:
        return []
    if not isinstance(sources, list):
        warnings.append('meta.sources must be a list of objects; ignored')
        return []
    normalized = []
    seen = set()
    for index, entry in enumerate(sources, 1):
        where = 'meta.sources[%d]' % index
        if not isinstance(entry, dict):
            warnings.append(where + ': must be an object {id, title, url}; ignored')
            continue
        sid = entry.get('id')
        title = entry.get('title')
        if not isinstance(sid, str) or not sid.strip():
            warnings.append(where + ": missing 'id' (string); ignored")
            continue
        sid = sid.strip()
        if sid in seen:
            warnings.append(where + ": duplicate id '%s'; ignored" % sid)
            continue
        if not isinstance(title, str) or not title.strip():
            warnings.append(where + ": missing 'title' (string); ignored")
            continue
        item = dict(entry)
        item['id'] = sid
        item['title'] = title.strip()
        url = entry.get('url')
        if url is not None:
            if isinstance(url, str) and is_safe_link(url):
                item['url'] = url.strip()
            else:
                warnings.append(where + ": 'url' is not a safe http(s)/mailto link; dropped")
                item.pop('url', None)
        kind = entry.get('kind')
        if kind is not None:
            if isinstance(kind, str) and kind.strip():
                item['kind'] = kind.strip().lower()
            else:
                warnings.append(where + ": 'kind' must be a string; ignored")
                item.pop('kind', None)
        checked = entry.get('checked_at')
        if checked is not None:
            if isinstance(checked, str) and checked.strip():
                item['checked_at'] = checked.strip()
            else:
                warnings.append(where + ": 'checked_at' must be a string; ignored")
                item.pop('checked_at', None)
        item = apa.normalize_entry(item, warnings, where)
        if apa.is_internal(item) and item.get('url'):
            warnings.append(where + ": internal source keeps no url; the audience cannot follow it")
            item.pop('url', None)
        seen.add(sid)
        normalized.append(item)
    return normalized


def _citation_markers(value, key=None):
    """Collect ``[@id]`` markers from the visible text of a slide."""
    if isinstance(value, str):
        if key in apa.EXPAND_SKIP_KEYS:
            return []
        return [match.group(1) for match in apa.CITATION_RE.finditer(value)]
    if isinstance(value, list):
        found = []
        for item in value:
            found.extend(_citation_markers(item, key))
        return found
    if isinstance(value, dict):
        found = []
        for name, item in value.items():
            found.extend(_citation_markers(item, name))
        return found
    return []


def _validate_slide(slide, stype, where, errors, warnings, sources_map=None, lang='ru'):
    """Validate and normalize one slide in place; returns the slide."""
    normalized = dict(slide)
    note = normalized.get('note')
    if note is not None and not isinstance(note, str):
        errors.append(where + ": 'note' must be a string")
    for key in normalized:
        if key not in ('type', 'note', 'source_refs') and key not in TYPE_FIELDS[stype]:
            warnings.append(where + ": unknown key '%s' for type '%s'" % (key, stype))
    refs = normalized.get('source_refs')
    if refs is not None:
        if not isinstance(refs, list) or not all(isinstance(ref, str) for ref in refs):
            warnings.append(where + ": 'source_refs' must be a list of source ids; ignored")
            normalized.pop('source_refs', None)
            refs = None
        else:
            known = dict(sources_map or {})
            for ref in refs:
                if ref not in known:
                    warnings.append(where + ": source_refs id '%s' is not in meta.sources" % ref)
            if stype == 'literature':
                materialized = []
                for ref in refs:
                    entry = known.get(ref)
                    if not entry:
                        continue
                    if apa.has_apa_data(entry):
                        text = apa.format_apa(entry, lang, markup=True)
                    else:
                        text = entry['title']
                    item = {'text': text}
                    link = apa.doi_url(entry)
                    if link:
                        item['url'] = link
                    materialized.append(item)
                if materialized:
                    manual = normalized.get('items') or []
                    normalized['items'] = list(manual) + materialized
    known_sources = dict(sources_map or {})
    for marker_id in _citation_markers(normalized):
        if marker_id not in known_sources:
            warnings.append(where + ": citation marker '@%s' is not in meta.sources"
                            % marker_id)
    for key in REQUIRED_FIELDS.get(stype, ()):
        if normalized.get(key) in (None, '', []):
            errors.append(where + " (%s): missing required field '%s'" % (stype, key))

    if stype == 'section':
        header = normalized.get('header') or normalized.get('title')
        if not header:
            errors.append(where + ": section needs 'header' (or 'title')")
        normalized['header'] = header or ''
    elif stype in ('bullets', 'summary', 'homework', 'literature',
                   'cards', 'timeline', 'process'):
        items = normalized.get('items')
        if isinstance(items, list):
            _validate_items(items, where, errors)
        if stype in ('cards', 'timeline', 'process'):
            slots = normalized.get('slots')
            if slots is not None:
                if (_is_number(slots) and float(slots).is_integer()
                        and 1 <= int(slots) <= 12):
                    count = len(items) if isinstance(items, list) else 0
                    if int(slots) > count:
                        normalized['slots'] = int(slots)
                    else:
                        warnings.append(where + ": 'slots' ignored (%d slots "
                                        'declared for %d items; no empty slot '
                                        'groups)' % (int(slots), count))
                        normalized.pop('slots', None)
                else:
                    warnings.append(where + ": 'slots' ignored (expected an "
                                    'integer 1-12)')
                    normalized.pop('slots', None)
        if stype == 'cards':
            columns = normalized.get('columns')
            if columns is not None:
                if (_is_number(columns) and float(columns).is_integer()
                        and 1 <= int(columns) <= 4):
                    normalized['columns'] = int(columns)
                else:
                    warnings.append(where + ": 'columns' ignored (expected an integer 1-4)")
                    normalized.pop('columns', None)
    elif stype in ('steps_grid', 'pillars'):
        items = normalized.get('items')
        if isinstance(items, list):
            _validate_items(items, where, errors)
            clean = []
            for item in items:
                if isinstance(item, dict):
                    entry = {'text': str(item.get('text') or '').strip()}
                    title = str(item.get('title') or '').strip()
                    if title:
                        entry['title'] = title
                    for key in item:
                        if key not in ('text', 'title', 'level'):
                            warnings.append(where + ": unknown key '%s' in item" % key)
                    clean.append(entry)
                else:
                    clean.append({'text': str(item).strip()})
            normalized['items'] = clean
        slots = normalized.get('slots')
        if slots is not None:
            count = len(items) if isinstance(items, list) else 0
            if (_is_number(slots) and float(slots).is_integer()
                    and 1 <= int(slots) <= 12 and int(slots) > count):
                normalized['slots'] = int(slots)
            else:
                warnings.append(where + ": 'slots' ignored (expected an integer "
                                'above the item count)')
                normalized.pop('slots', None)
        if stype == 'steps_grid':
            columns = normalized.get('columns')
            if columns is not None:
                if (_is_number(columns) and float(columns).is_integer()
                        and 1 <= int(columns) <= 3):
                    normalized['columns'] = int(columns)
                else:
                    warnings.append(where + ": 'columns' ignored (expected an "
                                    'integer 1-3)')
                    normalized.pop('columns', None)
        elif stype == 'pillars':
            columns = normalized.get('columns')
            if columns is not None:
                if (_is_number(columns) and float(columns).is_integer()
                        and 1 <= int(columns) <= 4):
                    normalized['columns'] = int(columns)
                else:
                    warnings.append(where + ": 'columns' ignored (expected an "
                                    'integer 1-4)')
                    normalized.pop('columns', None)
        if normalized.get('caption') is not None and not isinstance(
                normalized.get('caption'), str):
            warnings.append(where + ": 'caption' must be a string; ignored")
            normalized.pop('caption', None)
    elif stype == 'focus':
        statement = normalized.get('statement')
        if not isinstance(statement, str) or not statement.strip():
            errors.append(where + ": 'statement' must be a non-empty string")
        else:
            normalized['statement'] = statement.strip()
        columns = normalized.get('columns')
        if columns is not None:
            if (_is_number(columns) and float(columns).is_integer()
                    and 1 <= int(columns) <= 4):
                normalized['columns'] = int(columns)
            else:
                warnings.append(where + ": 'columns' ignored (expected an "
                                'integer 1-4)')
                normalized.pop('columns', None)
        supports = normalized.get('supports')
        if supports is not None:
            if not isinstance(supports, list) or not supports:
                warnings.append(where + ": 'supports' must be a non-empty list; ignored")
                normalized.pop('supports', None)
            else:
                clean = []
                for index, value in enumerate(supports, 1):
                    # A support may be a plain string or {"text": ...}; the dict
                    # form used to be stringified verbatim, so the slide showed
                    # a literal "{'text': ...}" instead of the support.
                    if isinstance(value, dict):
                        value = value.get('text')
                    text = str(value).strip() if value is not None else ''
                    if not text:
                        warnings.append(where + ': support %d is empty; dropped' % index)
                        continue
                    clean.append(text)
                if clean:
                    normalized['supports'] = clean
                else:
                    normalized.pop('supports', None)
        if normalized.get('caption') is not None and not isinstance(
                normalized.get('caption'), str):
            warnings.append(where + ": 'caption' must be a string; ignored")
            normalized.pop('caption', None)
    elif stype == 'definition':
        normalized['text'] = as_lines(normalized.get('text'))
        if not normalized.get('term'):
            errors.append(where + ": definition needs 'term'")
        if normalized.get('formula') is not None:
            _validate_formula(normalized['formula'], where, errors)
            normalized['formula'] = as_lines(normalized['formula'])
    elif stype == 'theorem':
        normalized['statement'] = as_lines(normalized.get('statement'))
        if normalized.get('formula') is not None:
            _validate_formula(normalized['formula'], where, errors)
            normalized['formula'] = as_lines(normalized['formula'])
    elif stype == 'proof':
        steps = normalized.get('steps')
        if not isinstance(steps, list) or not steps:
            errors.append(where + ": 'steps' must be a non-empty list of strings")
        else:
            normalized['steps'] = [str(step) for step in steps]
        if normalized.get('formula') is not None:
            _validate_formula(normalized['formula'], where, errors)
            normalized['formula'] = as_lines(normalized['formula'])
    elif stype == 'formula':
        _validate_formula(normalized.get('formula'), where, errors)
        normalized['formula'] = as_lines(normalized.get('formula'))
        normalized['numbered'] = bool(normalized.get('numbered'))
    elif stype == 'code':
        code = normalized.get('code')
        if isinstance(code, list):
            normalized['code'] = '\n'.join(str(line) for line in code)
        elif not isinstance(code, str):
            errors.append(where + ": 'code' must be a string or a list of lines")
        language = normalized.get('language')
        if not isinstance(language, str) or not language.strip():
            errors.append(where + ": 'language' must be a non-empty string")
        else:
            normalized['language'] = language.strip().lower()
        start = normalized.get('start_line')
        if start is not None and not isinstance(start, int):
            errors.append(where + ": 'start_line' must be an integer or null")
    elif stype == 'table':
        _validate_table(normalized, where, errors)
        widths = normalized.get('col_widths')
        columns = normalized.get('columns') or []
        if widths is not None:
            if (not isinstance(widths, list) or len(widths) != len(columns)
                    or not all(_is_number(w) and w > 0 for w in widths)):
                warnings.append(where + ": 'col_widths' ignored (need %d positive numbers)"
                                % len(columns))
                normalized.pop('col_widths', None)
    elif stype == 'chart':
        _validate_chart(normalized, where, errors, warnings)
    elif stype == 'image':
        path = normalized.get('path')
        if not isinstance(path, str) or not path.strip():
            errors.append(where + ": 'path' must be a non-empty string")
        for key in ('width', 'height'):
            value = normalized.get(key)
            if value is not None and not _is_number(value):
                errors.append(where + ": '%s' must be a number of inches" % key)
    elif stype == 'two_column':
        _validate_block(normalized.get('left'), where + ' left', errors, warnings)
        _validate_block(normalized.get('right'), where + ' right', errors, warnings)
        split = normalized.get('split')
        if split is None:
            normalized['split'] = 0.48
        elif not _is_number(split):
            errors.append(where + ": 'split' must be a number")
        else:
            split = float(split)
            if not 0.2 <= split <= 0.8:
                warnings.append(where + ': split %s outside 0.2-0.8; clamped' % split)
                split = min(0.8, max(0.2, split))
            normalized['split'] = split
    elif stype == 'compare':
        _validate_block(normalized.get('left'), where + ' left', errors, warnings)
        _validate_block(normalized.get('right'), where + ' right', errors, warnings)
        for key in ('left_label', 'right_label', 'verdict'):
            value = normalized.get(key)
            if value is not None and not isinstance(value, str):
                warnings.append(where + ": '%s' must be a string; ignored" % key)
                normalized.pop(key, None)
    return normalized


def validate_spec(raw, path=None):
    """Validate a parsed spec dict and return a normalized ``Spec``."""
    errors = []
    warnings = []
    if not isinstance(raw, dict):
        raise SpecError(['spec root must be a JSON object'])
    for key in raw:
        if key not in TOP_KEYS:
            warnings.append("top-level: unknown key '%s'" % key)

    meta = raw.get('meta')
    if meta is None:
        meta = {}
    if not isinstance(meta, dict):
        errors.append("'meta' must be an object")
        meta = {}
    meta = dict(meta)
    for key in meta:
        if key not in META_KEYS:
            warnings.append("meta: unknown key '%s'" % key)
    if 'labels' in meta and not isinstance(meta.get('labels'), dict):
        warnings.append("meta.labels must be an object; ignored")
        meta.pop('labels', None)
    baseline_ref = meta.get('baseline')
    if baseline_ref is not None:
        if isinstance(baseline_ref, str) and baseline_ref.strip():
            meta['baseline'] = baseline_ref.strip()
        else:
            warnings.append('meta.baseline must be a non-empty path string; ignored')
            meta.pop('baseline', None)
    meta['sources'] = _validate_sources(meta.get('sources'), warnings)
    sources_map = {entry['id']: entry for entry in meta['sources']}

    lang = str(meta.get('lang') or 'ru').lower()
    if lang not in ('ru', 'en'):
        warnings.append("meta.lang '%s' is not supported; using 'ru'" % meta.get('lang'))
        lang = 'ru'
    meta['lang'] = lang
    if not str(meta.get('theme') or '').strip():
        meta['theme'] = 'academic_blue'

    duration = meta.get('duration_min', 0)
    try:
        duration = int(duration)
    except (TypeError, ValueError):
        warnings.append("meta.duration_min '%s' is not a number; disabled" % duration)
        duration = 0
    meta['duration_min'] = duration if duration > 0 else 0

    formula_mode = str(meta.get('formula_mode') or 'omml').strip().lower()
    if formula_mode not in ('omml', 'image'):
        warnings.append("meta.formula_mode '%s' is not supported; using 'omml'"
                        % meta.get('formula_mode'))
        formula_mode = 'omml'
    meta['formula_mode'] = formula_mode

    normalize = meta.get('normalize_dashes')
    if normalize is None:
        normalize = False
    elif not isinstance(normalize, bool):
        warnings.append('meta.normalize_dashes must be true or false; ignored')
        normalize = False
    meta['normalize_dashes'] = normalize

    auto_layout = meta.get('auto_layout')
    if auto_layout is None:
        auto_layout = False
    elif not isinstance(auto_layout, bool):
        warnings.append('meta.auto_layout must be true or false; ignored')
        auto_layout = False
    meta['auto_layout'] = auto_layout

    slides = raw.get('slides')
    if not isinstance(slides, list) or not slides:
        errors.append("'slides' must be a non-empty list")
        slides = []

    qa = raw.get('qa')
    if qa is None:
        qa = {}
    if not isinstance(qa, dict):
        warnings.append("'qa' must be an object; ignored")
        qa = {}
    for key in qa:
        if key not in QA_KEYS:
            warnings.append("qa: unknown key '%s'" % key)

    normalized_slides = []
    for idx, slide in enumerate(slides):
        where = 'slide %d' % (idx + 1)
        if not isinstance(slide, dict):
            errors.append(where + ': must be an object')
            continue
        stype = slide.get('type')
        if not isinstance(stype, str) or stype not in SLIDE_TYPES:
            errors.append(where + ": unknown slide type '%s' (expected one of %s)"
                          % (stype, ', '.join(SLIDE_TYPES)))
            continue
        normalized_slides.append(_validate_slide(slide, stype, where, errors, warnings,
                                                 sources_map, lang))

    if errors:
        raise SpecError(errors)
    if meta.get('normalize_dashes'):
        normalized_slides = [_normalize_text_dashes(slide) for slide in normalized_slides]
    return Spec(meta=meta, slides=normalized_slides, qa=qa, path=path, warnings=warnings)


def load_spec(path):
    """Load and validate a lecture spec file; returns a ``Spec``."""
    path = Path(path)
    if not path.exists():
        raise SpecError(['spec file not found: %s' % path])
    try:
        raw = json.loads(path.read_text(encoding='utf-8'))
    except json.JSONDecodeError as exc:
        raise SpecError(['invalid JSON in %s: %s' % (path.name, exc)]) from exc
    return validate_spec(raw, path=path)
# ─────────────────────────── inline markup ───────────────────────────

_MARKUP_RE = re.compile(r'(\*\*[^*]+?\*\*|\*[^*\n]+?\*|`[^`\n]+?`|\[[^\]\n]+\]\([^()\s]*(?:\([^()\s]*\)[^()\s]*)*\))')

SAFE_LINK_SCHEMES = ('http://', 'https://', 'mailto:')


def is_safe_link(url):
    """True when a link target may be embedded as a clickable hyperlink."""
    text = str(url or '').strip().lower()
    return text.startswith(SAFE_LINK_SCHEMES)


def split_markup(text):
    """Split text with **bold**, *italic* and `mono` markers into spans.

    Returns a list of ``(text, flags)`` tuples where ``flags`` may contain
    ``bold``, ``italic`` and ``mono`` keys. Plain runs produce empty flags.
    """
    text = str(text or '')
    spans = []
    for part in _MARKUP_RE.split(text):
        if not part:
            continue
        if len(part) > 4 and part.startswith('**') and part.endswith('**'):
            spans.append((part[2:-2], {'bold': True}))
        elif len(part) > 2 and part.startswith('*') and part.endswith('*'):
            spans.append((part[1:-1], {'italic': True}))
        elif len(part) > 2 and part.startswith('`') and part.endswith('`'):
            spans.append((part[1:-1], {'mono': True}))
        elif (len(part) > 4 and part.startswith('[') and part.endswith(')')
              and '](' in part):
            label, url = part[1:-1].split('](', 1)
            if is_safe_link(url):
                for sub_text, sub_flags in split_markup(label):
                    styled = dict(sub_flags)
                    styled['url'] = url.strip()
                    spans.append((sub_text, styled))
            else:
                spans.append((part, {}))
        else:
            spans.append((part, {}))
    if not spans:
        spans = [('', {})]
    return spans


def strip_markup(text):
    """Remove **bold**, *italic* and `mono` markers from text."""
    return ''.join(part for part, _ in split_markup(text))


# ─────────────────────────── dash typography ───────────────────────────

# A hyphen used as a dash: a Cyrillic letter, a spaced hyphen, another
# Cyrillic letter. Quotes, math ('x² - 2'), Latin contexts ('where x - y')
# and bibliographic strings ('. - 3rd ed.') never match, which keeps the
# rewrite safe to run over a whole deck.
_DASH_RE = re.compile(r'(?<=[\u0410-\u044f\u0401\u0451]) - (?=[\u0410-\u044f\u0401\u0451])')

# Keys whose values are not visible prose: notes, code, formulas, links.
DASH_SKIP_KEYS = ('note', 'code', 'formula', 'language', 'path', 'type',
                  'source_refs', 'id')


def normalize_dashes(text):
    """Replace a prose hyphen between Cyrillic words with an em dash.

    Conservative on purpose: only ``' - '`` between two Cyrillic letters
    becomes ``' \u2014 '``; math, Latin text and bibliographic dashes are
    left untouched. Returns the text unchanged when nothing matches.
    """
    return _DASH_RE.sub(' \u2014 ', str(text or ''))


def _normalize_text_dashes(value, key=None):
    """Recursively rewrite prose dashes in the visible text of a slide."""
    if isinstance(value, str):
        return value if key in DASH_SKIP_KEYS else normalize_dashes(value)
    if isinstance(value, list):
        return [_normalize_text_dashes(item, key) for item in value]
    if isinstance(value, dict):
        return {name: _normalize_text_dashes(item, name)
                for name, item in value.items()}
    return value