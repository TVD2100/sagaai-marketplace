# lecture-slides - known limitations

What this skill consciously does not do, and why. The short version of the
same list lives in `SKILL.md` ("Known limitations"); this file is the full
record with the reasoning.

## Formulas

- **LibreOffice does not render OMML.** A `.pptx` with Office Math converts to
  PDF without errors (`missingFonts: []`) but the formula area comes out empty.
  A PDF preview is therefore never evidence about a formula. The skill
  validates formulas **structurally** (file stage: `<m:oMath>` present, `<m:t>`
  non-empty, node counts match the converted LaTeX) and marks the visual stage
  as unreliable for formula areas.
- **Only a bounded LaTeX subset converts to OMML** - the same subset the
  raster renderer supports: `\frac`, `\sqrt`, scripts, sums, integrals,
  limits, Greek letters, relations and `\left(...\right)` pairs. Constructs
  outside it (`\begin{...}` environments, custom macros) are not guessed at:
  in OMML mode the formula falls back to a raster image and records a
  warning; in image mode it is a clear build error.
- **`formula_mode: "image"` exists on purpose** - it keeps the previous
  pixel-identical behaviour available (e.g. for environments where Office
  Math is not rendered at all). It is a supported mode, not dead code.
- **Inline math inside sentences is not supported** (`x^2` mid-paragraph).
  Use Unicode symbols (`x²`, `α`, `≤`) or a separate formula block.

## Drift check

- **The comparison is text-level on purpose.** A `.pptx` is a zip whose member
  timestamps change on every save, so a byte comparison would report drift on
  two identical builds. `drift.compare` therefore compares the visible text
  (shapes, tables, speaker notes) and nothing else: a manual edit that only
  moves a shape, changes a colour, swaps an image or restyles a paragraph is
  **not** detected. The question the skill asks the user is about content.
- **A deck rebuilt in the current session is never checked.** The check exists
  for decks that outlive the session that produced them; a fresh build is in
  sync by construction.
- **The acknowledgment is bound to one exact file.** `drift_ack.json` records
  the deck's SHA-256, so any later save - including an unrelated re-export by
  the user - makes the ack stale and brings the question back. That is
  intentional: a stale ack would silently authorize overwriting new edits.
- **A failed check is an error, not a PASS.** A missing, unreadable or
  unparseable deck, or a spec that no longer builds, comes back in
  `report['errors']`; the agent must report it, never read it as "no drift".

## APA references

- **The generator is a template set, not a full APA-7 engine.** It covers a
  book, a journal article (with or without a DOI), a web page and an internal
  knowledge-base document. A conference paper, a thesis, a dataset or a
  translated book is not generated: put the finished reference into the
  entry's `apa` field and it is used verbatim.
- **The QA rule checks presence and shape, never correctness.** It reports a
  case, a quotation or a figure left without a reference and an entry that
  cannot be formatted at all. Whether the number matches the cited page, or
  the quotation is accurate, is outside the skill's reach - the source is
  never fetched.
- **An APA label is recognised by its shape.** `(Author, year)` and
  `(Author, year, p. N)` count as a reference; a free-form attribution such
  as «по данным исследования ...» does not, and is reported as missing. The
  marker `[@id]` is the reliable way to place a reference.
- **Page numbers are not inferred.** `[@id]` without a page produces the
  author-year label only; a direct quotation must carry the page explicitly
  (`[@id, с. 5]`), otherwise the label is still emitted without it.
- **An internal source never gets a hyperlink.** A `url` on an entry marked
  `internal` is dropped with a spec warning, and the literature slide says
  «Внутренний источник» instead. A reader of the deck cannot follow such a
  reference by design.
- **A hyperlink is a PowerPoint feature.** The build writes a real hyperlink
  run into the shape; whether it is clickable in the reader's viewer is the
  viewer's business. The QA report never opens a URL.
- **The access date is not maintained.** `accessed` / `checked_at` is printed
  as given; nothing refreshes it on a rebuild.

## QA and reports

- **The visual stage cannot run without LibreOffice.** Without it (and a PDF
  rasterizer) the stage reports `skipped` with the reason - never a silent
  PASS. `python preflight.py` names the missing pieces before a build.
- **Text-fit checks are approximate for unknown fonts.** When the theme
  faces are not installed, the measurement widens its safety margin and the
  QA report lists the affected elements. The check stays a warning source,
  not a guarantee.
- **The baseline comparison compares headings only**: it catches a heading
  lost or renamed against the provided previous version; it does not diff
  slide bodies.
- **Density exemptions are explicit.** Title/section/layout types are exempt
  from the frame-fill rule with a recorded reason in the report; an excluded
  slide is marked, not silently passed.
- **The empty-bottom check measures drawn pixels, not the slide.** `check_void`
  compares the lowest drawn content with the frame bottom; a slide whose
  content genuinely needs the whole frame can still be flagged, and the
  title/section/formula/timeline types are exempt by design. The threshold
  (`max_void_in`, default 1.2 in) is a warning, not a hard error.
- **The hyphen/dash check is conservative.** `check_dashes` flags only
  `' - '` between two Cyrillic letters - it deliberately ignores math ranges,
  Latin text and bibliographic dashes, so a genuine ASCII-hyphen typo between
  non-Cyrillic words is not reported.
- **Delivery status is recomputed, not trusted.** `complete` / `delivery_ready`
  / `draft` are derived from the findings each time; a report claiming
  `complete` while carrying warnings is refused (`verify_delivery`).
- **Reports are bound to bytes.** A PASS describes the exact artifact SHA-256
  it was computed on; edit the deck and the old PASS is structurally stale
  (`verify_report`), not merely outdated in wording.

## Environment and scope

- **Fully offline.** No network calls anywhere; pinned by an AST test.
- **No third-party assets.** Fonts, palettes and templates come from the
  skill itself or from the already-used free dependencies.
- **Not a universal deck builder.** Business, pitch and marketing decks are
  out of scope (use a presentation skill for those).
- **No standalone HTML export**: without a canonical content model, an HTML
  view would drift from the pptx; it is a separate feature, not a quick
  export flag.
