# Changelog - lecture-slides skill

All notable changes to this skill package. The spec format stays backward
compatible within a major version.

## 1.8.0 - 2026-10-22

A deck cited its sources only on the final literature slide, so a case, a
quotation or a figure had no reference next to it. This release adds APA 7th
references for such claims, places them inline with a `[@id]` marker, and
distinguishes an external source (a clickable hyperlink) from an internal
knowledge-base document (APA text without a link, because the audience cannot
follow it).

- **APA formatter.** New module `lecture/apa.py`: `format_reference` builds a
  reference from structured fields (book, article with DOI, web page, internal
  document), `in_text` produces the `(Author, year)` and `(Author, year, p. N)`
  labels, `expand_text` / `expand_slide` turn a `[@id]` marker into the label
  plus a hyperlink for an external source and plain text for an internal one,
  `has_apa_caption` / `find_case_markers` back the QA rule. Author rules: one
  surname, two joined with «и» (`&`), three and more - «и др.» (`et al.`); no
  year - «б. г.» (`n.d.`).
- **Registry fields.** `meta.sources` entries accept `authors`, `year`, `title`,
  `container`, `volume`, `issue`, `pages`, `publisher`, `doi`, `url`,
  `accessed`, `internal`, `rag_base` and a ready-made `apa` string that
  replaces the generated reference. `internal: true` makes the entry an
  internal source: a `url` on it is dropped with a spec warning. A `literature`
  slide with `source_refs` materializes APA entries through `format_apa`;
  entries without APA data keep their previous plain `title`.
- **Inline citations.** `[@id]` in any text field (bullets, paragraphs,
  captions, table cells, notes) expands at build time; `[@id, с. 5]` adds the
  page to a direct-quote label. An unknown id is a spec warning, not a build
  failure.
- **QA rule `check_apa`.** New warning-level check (only when `meta.sources`
  is non-empty): a slide with a case, a quotation or a figure and neither
  `source_refs` nor an APA label in the text is reported; a registry entry
  without `authors`, `year` or `apa` is reported once. An internal source is
  exempt from the hyperlink requirement, and the existing `check_source_refs`
  rule now accepts an APA label as a reference.
- **Docs and tests.** `SKILL.md` gained "APA references for cases, quotes and
  figures" and updated the workflow, the `meta.sources` reference, the `qa`
  keys and the QA finding list; the bundle map lists `apa.py`.
  `examples/demo_lecture.json` carries APA fields. New `tests/test_apa.py`
  (48 tests: formatting, in-text rules, marker expansion, the QA rule).
  Suite: 614 tests.

## 1.7.0 - 2026-10-17

A built deck is a file the lecturer can open and edit in PowerPoint, but the
JSON spec stays the source of truth. Nothing detected the divergence: the next
rebuild silently replaced hand-made edits, and a spec change after delivery
went unnoticed. This release adds a drift check, a REQUIRED question to the
user when the two disagree, and an explicit acknowledgement for the case where
the hand-edited deck is final.

- **Drift detection.** New module `lecture/drift.py`: `deck_snapshot` reads the
  text of a saved deck (shapes, tables, notes), `expected_snapshot` rebuilds the
  spec into a temp folder, `compare` diffs the two by TEXT (not bytes - zip
  timestamps differ between identical builds) and returns `user_added` /
  `user_removed` lines per slide and per notes block. CLI
  `python -m lecture.drift <spec> <pptx>` (0 in sync / 1 drift / 2 error).
- **Entry points.** `build_lecture.check_drift(spec, pptx=None,
  service_dir=True)` returns the report plus a ready-to-show `markdown` block
  and the `ack_path`; `build_lecture.acknowledge_manual_edits(pptx)` records
  that the edits are final. CLI flags `--check-drift` and `--ack-manual-edit`
  (both honour `--flat`). Neither writes to the deck or the spec.
- **The required question.** `SKILL.md` gained step 6, "Check an existing deck
  against its spec (drift)": when `changed` is true and `acknowledged` is false
  the agent must stop, show the diff and ask the user directly whether to
  update the sources (yes -> edit the spec, rebuild, re-run the check; no ->
  `acknowledge_manual_edits`; rebuild anyway -> explicit warning). Steps 7/8
  shifted. `docs/limitations.md` names the text-level scope: geometry, colours
  and images are not compared, so an edit that only moves or restyles a shape
  is not detected.
- **Tests.** `tests/test_drift.py` (15), `tests/test_build_lecture_drift.py`
  (11), the guarded wording in `tests/test_skill_docs.py` and the scenario
  suite `tests/scenarios/test_drift_scenarios.py` (4) covering all three
  answers. Suite: 557 tests.

## 1.6.0 - 2026-10-17

A deck folder used to accumulate helper files: the combined QA report, one
report per QA stage, raster formula images and preview pages all landed next to
the `.pptx`, so a folder with three decks held dozens of files that are build
by-products, not deliverables. This release moves every helper into one
`<name>_service/` folder per deck; the deck folder keeps only the `.pptx` and
the `.pdf`. Rendering is unchanged - only the output paths move. The old layout
stays one flag away (`service_dir=False`, CLI `--flat`) for existing scripts.

- **Formula rasters inside the service folder.** `build_deck(...)` gained
  `service_dir=True`: without an explicit `assets_dir` rasters now go to
  `<out_stem>_service/assets/` instead of `<out_stem>_assets/`.
  `service_dir=False` restores the old path. File: lecture/deck.py.
- **QA reports inside the service folder.** `build(...)` writes the combined
  report and the three stage reports into `<out_stem>_service/` with short
  names - `qa.md`, `qa.json`, `qa_content.md`, `qa_file.md`, `qa_visual.md` -
  because the folder is already scoped to one deck. The CLI gained `--flat`.
  Files: build_lecture.py (`_service_dir`, `build`), lecture/deck.py.
- **Preview pages inside the service folder.** `render(...)` and
  `make_contact_sheet(...)` write page PNGs and `contact_sheet.png` to
  `<out_stem>_service/preview/`; the PDF is a delivery artifact and stays next
  to the deck. CLI flag `--flat` keeps `<out_stem>_preview/`. File:
  render_preview.py (`_preview_dir`).
- **Tests and docs.** Updated every test bound to the old paths
  (`test_build_lecture`, `test_stages`, `test_report_binding`,
  `test_delivery_gate`, `test_omml`, `test_render_preview`, the scenario suite)
  and added a scenario that asserts the folder structure end to end:
  `test_scenario_deck_folder_keeps_only_artifacts`. `SKILL.md` documents the
  new Deliverables layout. Suite: 524 tests.

## 1.5.0 - 2026-10-17

The layout defect of 1.4.0 had a second half: stretching item spacing made the
empty bottom visible but did not remove its cause. When a slide carries three
or four SHORT parallel points, no amount of spacing makes a `bullets` list fill
the body frame - the list is simply the wrong shape for the content. This
release adds three visual types for that shape, an advisor that points at them
and a QA warning that catches the case an author misses. Spec format stays
backward compatible; every deck built by 1.4.x renders exactly as before
unless it opts into `meta.auto_layout`.

- **Three visual slide types.** `steps_grid` (numbered tiles in a 2x2 or 3x2
  grid), `pillars` (full-height columns with an accent header band) and `focus`
  (a wide statement banner plus a row of supports). All three fill the body
  frame by construction: tiles and columns span the full frame height, short
  captions are centered in their plate, long ones shrink the font instead of
  overflowing. `steps_grid` accepts `slots` like the other layout types. Cards
  report `content_bottom` so the void metric sees the tiles as drawn content
  instead of reporting a void inside them. Files: lecture/slides.py
  (`render_steps_grid`, `render_pillars`, `render_focus`, helpers
  `_fit_size_by_height` / `_wrap_height`), lecture/spec.py (`SLIDE_TYPES`,
  `TYPE_FIELDS`, `REQUIRED_FIELDS`, validation of `items`, `columns`, `slots`,
  `supports`, `statement`), tests/test_visual_types.py (16 tests). Slide types:
  19 -> 22.
- **Layout advisor.** New module `lecture/layout_advisor.py`:
  `suggest_layout(slide)` returns `None` when a `bullets` list is fine and
  `{suggested_type, reason, replacement}` otherwise;
  `build_replacement(slide, type)` rewrites the slide while keeping `note`,
  `caption` and `source_refs` untouched; `apply_auto_layout(spec)` walks the
  deck. The rule: 1-2 short points -> `focus`, 3-6 short points without titles
  -> `steps_grid`, 3-6 short points with titles -> `pillars`, any long point or
  more than six items -> keep `bullets`. `meta.auto_layout: true` makes the
  builder apply the advice before rendering (every change lands in
  `result["auto_layout"]` and in a build warning, so a rewrite is never
  silent); without the flag the deck is left exactly as written. Files:
  lecture/layout_advisor.py, lecture/deck.py, build_lecture.py, lecture/spec.py
  (`META_KEYS`), tests/test_layout_advisor.py (13 tests).
- **QA advice warning.** `qa.check_layout_advice` (default true) reports a short
  `bullets` slide as a warning with the suggested type and the reason - a
  warning, never an error, because keeping the list may be a deliberate choice.
  Files: qa_check.py, lecture/spec.py (`QA_KEYS`), tests/test_layout_advisor.py.
- **Documented field shapes now match the renderers.** Testing the release on a
  real course deck exposed three places where the docs and the code disagreed.
  (1) `focus.supports` accepted only plain strings: the documented `{text}`
  form was stringified verbatim, so the slide printed a literal `{'text': ...}`.
  (2) `pillars.columns` was documented for 2-4 columns but the spec dropped the
  field and the renderer always produced one flat row, so a two-column request
  still drew four narrow columns. (3) A `focus` slide with a statement and no
  supports left ~4 in of empty frame under the banner (the QA void check
  reported it); the statement now grows to fill the body and the banner follows
  it. `focus.columns` is documented and now implemented as a support grid
  instead of a hard cap of three per row. Files: lecture/spec.py,
  lecture/slides.py, tests/test_visual_types.py (16 tests), SKILL.md.
- **Demo spec moved to the new types.** `examples/demo_lecture.json` now uses
  `steps_grid` for the lecture plan and `process` for the method idea, which is
  what the advisor would suggest; the demo build stays warning-free and keeps
  acting as the end-to-end smoke test. Files: examples/demo_lecture.json,
  tests/test_deck.py, tests/test_guarantees.py (22 types).
- **SKILL.md** documents the three types in the spec table, the advice table
  and the `auto_layout` / `check_layout_advice` switches. Test suite:
  488 -> 519 tests.

## 1.4.1 - 2026-10-12

Documentation fix only; the spec format and the renderer are untouched.

- **Skill self-documentation.** `SKILL.md` never explained how to read the
  skill's OWN files, while the platform's "Available skills" block told the
  agent to use `read_file` for them. `read_file` / `verify_file` are scoped to
  the target project root, so every such call died with
  `Path escapes project root` - the skill folder is always outside the
  workspace. A new step 0 in "Workflow" states the rule: this instruction is
  loaded by `get_skill_prompt`, every other bundle file is read **only** via
  `get_skill_file(<id>, '<path>')`, and `get_skill_folder` serves the
  `run_code` copy step alone. The `CHANGELOG.md` and `docs/limitations.md`
  references follow the same rule. `tests/test_skill_docs.py` freezes the
  wording. Test suite: 484 -> 488 tests.

## 1.4.0 - 2026-10-12

Layout work on real course decks (lessons 2-6): the systematic layout defect
(deep empty bottom of `definition` / `table` / `bullets` slides), two new QA
rules (empty bottom, hyphen-as-dash) and a duration-mode switch. Each change
started as a failing test; the spec format stays backward compatible. Test
suite: 441 -> 484 tests.

- **Empty-bottom QA rule + layout fill.** Content blocks now report
  `content_bottom` (the lowest drawn pixel, not the frame bottom) and the
  renderer stretches the layout to use the frame: list items get extra
  `space_after` (up to `MAX_ITEM_PAD_IN = 0.42 in`), table rows grow (up to
  `MAX_TABLE_ROW_PAD_IN = 0.5 in`), `definition`/`theorem` cards fill and
  center their frame, and `homework` places the due date under the list. QA
  gains `qa.check_void` (default true) with `qa.max_void_in` (default 1.2 in):
  a deeper empty strip under the content emits a warning and a `## Voids`
  report section; title/section/formula/timeline slides are exempt with a
  recorded reason. Measured on the course decks: lesson 5 21 -> 8 voids >= 1 in
  (max 3.18 -> 2.28 in), lesson 3 16 -> 5 (2.68 -> 1.82 in); every remaining
  void is a `section` divider (exempt). Files: lecture/deck.py, slides.py,
  qa_check.py, tests/test_void.py, tests/test_layout_fill.py,
  tests/scenarios/test_layout_scenarios.py.
- **Hyphen-as-dash typography rule.** `qa.check_dashes` (default true) warns
  when a prose hyphen `' - '` sits between two Cyrillic words in the visible
  text; `meta.normalize_dashes: true` rewrites such hyphens to an em dash
  automatically (notes, code, formulas and links are left untouched). Files:
  qa_check.py, lecture/spec.py, tests/test_typography.py.
- **Duration check modes.** `qa.check_duration` accepts `error` (default),
  `warn` and `off` in addition to the legacy booleans; `warn` moves the
  duration finding to warnings, `off` silences it, so a draft deck can be
  inspected without failing on a placeholder `duration_min`. Files:
  qa_check.py, tests/test_qa_duration.py.
- **Visual QA inside the build.** `build(qa_visual=True)` (CLI `--visual`)
  rasterizes the deck and feeds the rendered pages to the visual stage, so one
  call runs all three stages; without a rasterizer the stage reports itself
  skipped with a reason and the build still succeeds. Files:
  build_lecture.py, tests/test_build_lecture.py.
- **Word tokenizer keeps digits.** The repeated-word check now treats tokens
  with digits (`A2A`, `Agent2Agent`, `GPT4`) as single words, removing the
  false positive on `A2A - Agent2Agent`. Files: lecture/stages.py.

## 1.3.0 - 2026-10-11

Eleven measured gaps closed. Each change started as a failing test; the spec
format stays backward compatible - every existing `lecture.json` builds
unchanged. Test suite: 279 -> 441 tests; the demo deck (14 slides) builds in
~0.5 s with the full QA pass on the development host.

- **Editable formulas (OMML).** `meta.formula_mode` defaults to `"omml"`:
  formulas become editable Office Math objects instead of 300-dpi PNGs;
  `lecture/omml.py` converts the supported subset, falls back to raster per
  formula with a warning and validates the structure in QA. LibreOffice does
  not render OMML - documented under "Known limitations"; `"image"` restores
  the legacy path. Files: lecture/omml.py, deck.py, spec.py, qa_check.py,
  lecture/stages.py, tests/test_omml.py.
- **Font metric compatibility.** textfit gains a per-face status table and a
  wider safety margin for unknown faces (1.12 vs 1.04); QA names the elements
  whose text-fit check is approximate instead of a silent PASS. Files:
  lecture/textfit.py, deck.py, qa_check.py, tests/test_font_metrics.py.
- **Baseline deck comparison.** `meta.baseline` compares headings of the new
  deck against the provided previous version; a lost heading is a QA warning,
  structural checks are not suppressed. Files: lecture/baseline.py, spec.py,
  qa_check.py, tests/test_baseline.py.
- **Reports bound to bytes.** QA reports carry the artifact SHA-256 and the
  skill-source fingerprint; `verify_report` marks a PASS stale as soon as the
  deck bytes change. Files: lecture/fingerprint.py, deck.py, build_lecture.py,
  qa_check.py, tests/test_report_binding.py.
- **Symmetric duration check.** Underrun now fails like overrun:
  |estimate - duration_min| > 35% (`duration_tolerance`) is an error naming
  both values and the word delta. Files: qa_check.py, tests/test_qa_duration.py.
- **Native charts.** New `chart` slide type (bar/line/pie) with a real chart
  object and an embedded workbook; QA verifies the chart part and compares the
  workbook numbers with the spec. Files: lecture/slides.py, spec.py, deck.py,
  qa_check.py, lecture/stages.py, tests/test_charts.py.
- **Template slots.** `cards`/`timeline`/`process` accept `slots`; groups
  without data are removed whole (visual + text) and QA reports any orphaned
  decoration. Files: lecture/slides.py, spec.py, qa_check.py,
  tests/test_slots.py.
- **Three QA stages.** One combined report plus `_qa_content.md`,
  `_qa_file.md`, `_qa_visual.md`; the visual stage must go to a reviewer other
  than the generator author. Files: lecture/stages.py (new), qa_check.py,
  build_lecture.py, tests/test_stages.py.
- **Delivery gate.** `complete`/`delivery_ready`/`draft`, with warnings
  travelling forward as caveats; a draft cannot claim `complete`
  (`verify_delivery`). Files: qa_check.py, build_lecture.py,
  tests/test_delivery_gate.py.
- **Density as frame fill.** QA measures the share of the slide covered by
  content boxes (`min_fill`, default 0.15); airy types are exempt with a
  recorded reason; the report gains a Density section. Files: qa_check.py,
  lecture/spec.py, tests/test_density.py.
- **Declared environment requirements.** `compatibility.json` plus the
  stdlib-only `preflight.py`; `python build_lecture.py --check-env` names every
  missing component with an install hint before the build starts. Files:
  compatibility.json, preflight.py, build_lecture.py, tests/test_preflight.py.
- Guard tests (tests/test_guarantees.py) pin the mechanisms of the "keep
  intact" list: notes are errors, renderers cover every slide type, SAFETY,
  the figkit audit contract, CLI exit codes and the no-network AST scan.

## 1.2.0 - 2026-09-18

- Text blocks are now **vertically centered** in their frame: `text_block`
  shifts the content down by `(frame_h - needed_h) / 2` (never above the
  frame top). Short lists no longer hug the top edge of the body; long lists
  are unaffected because the offset clamps to zero. Applies to `bullets`,
  `two_column` list columns, `summary`, `homework` and `literature`.
- Formula slides: the caption height is now measured from the wrapped line
  count instead of a fixed 0.34 in, so multi-line «где … - это …»
  explanations shrink the formula area instead of overflowing the slide.
- Two regression tests added for both fixes (145 tests in total).

## 1.1.0 - 2026-09-17

- Bundled pytest suite: unit tests for spec loading/validation, text metrics
  and contrast, formula/code rendering, deck layout records, the QA rules and
  the CLI entry points (140+ tests, run with `python -m pytest tests/ -q`).
- End-to-end lecturer scenarios in `tests/scenarios/`: full deck build with
  reports, QA fix-and-rebuild loop, broken formula/image recovery, English
  deck with English labels, PDF handout export.
- `render_preview` tests: policy branches plus real PDF export when
  LibreOffice is installed (PNG tests skip when no rasterizer is available).
- Documentation: corrected the bundle map (no `lecture/qa.py`; `slides.py`,
  `examples/demo_plot.png`, `tests/scenarios/` listed) and the QA contract
  wording (overflow slack, tight-margin threshold, duration warning).

## 1.0.0 - 2026-09-17

- Initial release.
- Slide types: title, section, bullets, definition, theorem, proof, formula,
  code, table, image, two_column, summary, homework, literature.
- Speaker notes embedded into every slide (notes pages).
- Formulas rendered with matplotlib mathtext to 300-dpi PNG (no LaTeX needed).
- Code listings highlighted with pygments, auto-fitted fonts, line numbers.
- Four themes (academic_blue, graphite, deep_green, burgundy), Russian and
  English label sets.
- QA: missing/short notes, text overflow, margins, contrast, code length,
  bullet count, speaking-time estimate vs duration_min; Markdown + JSON reports.
- Optional PDF via LibreOffice, optional PNG previews via PyMuPDF/poppler.
