---
name: lecture-slides
description: Use when the user asks for lecture slides, a teaching deck or course materials in PowerPoint - "слайды к лекции", "презентация к занятию/паре", "сделай лекцию в PowerPoint", a seminar deck, or a course unit in .pptx. Builds polished university-style lecture decks from a JSON spec: mandatory speaker notes on every slide, LaTeX-style formulas embedded as editable Office Math (OMML; raster fallback), syntax-highlighted code listings, academic slide types, consistent footers and slide numbers, APA 7 citations for cases, quotes and figures (clickable for an external source, plain text for an internal knowledge-base document), automated QA (missing notes, text overflow, margins, contrast, empty bottom, hyphen-as-dash typography, unreferenced claims, timing) and an optional PDF handout.
---

# Lecture Slides

Build university lecture decks (`.pptx`) from a JSON specification on SagaAI.
The package builds the deck with `python-pptx`, converts formulas into editable
Office Math (OMML; matplotlib mathtext raster fallback, no LaTeX installation
required) and highlights code with `pygments`.

**Use this skill when**

- the user asks for slides / a presentation / a deck for a lecture, class,
  seminar or course unit («слайды к лекции», «презентация к занятию»);
- lecture material (notes, outline, textbook chapter) must become a deck with
  speaker notes;
- formulas and code must look like a textbook (fractions, sums, listings).

**Do not use this skill for** business/executive/pitch decks and generic
marketing presentations (use the presentation-code-interpreter skill), or for
plain text outlines that do not need slides.

## Deliverables

- `<name>.pptx` - the deck (16:9, 13.333 x 7.5 in) with speaker notes embedded
  (the Notes Page of every slide).
- Optional `<name>.pdf` - handout/preview via LibreOffice.
- `<name>_service/` - every helper file of the build, so the deck folder
  itself keeps only the pptx and the pdf:
  - `<name>_service/qa.md` (+ `qa.json` when requested) - combined QA report;
  - `<name>_service/qa_content.md`, `qa_file.md`, `qa_visual.md` - per-stage
    QA reports (see "QA contract");
  - `<name>_service/assets/` - raster formula images (only when
    `formula_mode: image` or an OMML fallback happens);
  - `<name>_service/preview/` - `page_NN.png` pages and `contact_sheet.png`.

  Pass `service_dir=False` (CLI `--flat`) to `build()`, `build_deck()`, `render()`
  or `make_contact_sheet()` for the pre-1.5 flat layout (`<name>_qa.md`,
  `<name>_assets/`, `<name>_preview/` next to the deck).

## Workflow (DevAgent, follow in order)

### 0. Read the skill's own files (never with `read_file`)

This instruction is already in your context - `get_skill_prompt(<id>)` loaded it,
so do not re-read `SKILL.md` with `read_file`. Every OTHER file of this skill
(`CHANGELOG.md`, `docs/limitations.md`, `compatibility.json`, helper modules) is
read **only** through `get_skill_file(<id>, '<relative path>')`. `read_file` and
`verify_file` are scoped to the target project root and reject any path outside
it with `Path escapes project root` - the skill folder always lives outside the
workspace, so those calls always fail. `get_skill_folder(<id>)` returns the
absolute path only so that `run_code` can copy the bundle (step 1); it is not a
path for the file tools.

### 1. Attach the bundle to the working project

The platform never executes skill files in place. Copy the runtime files into
the target project's scratch folder (run with `run_code`; `<SKILL_FOLDER>` is
the absolute path from `get_skill_folder(<id from the Available skills block>)`):

```python
import pathlib, shutil
src = pathlib.Path("<SKILL_FOLDER>")
dst = pathlib.Path(".dev_agent/scratch/skill_lecture-slides")
if dst.exists():
    shutil.rmtree(dst)
shutil.copytree(src, dst, ignore=shutil.ignore_patterns("tests", "__pycache__", "*.pyc"))
print("bundle ready:", dst)
```

All commands below assume the process working directory is the target project
root (the default for `run_code`).

### 2. Collect lecture facts and write the content

Ask for (skip what is already known): course name; lecture number and title;
lecturer and organization; date; audience level; lecture length in minutes;
theme (`academic_blue` default, `graphite`, `deep_green`, `burgundy`); language
(`ru` default).

Write the lecture content yourself from the user's material: 15-25 slides per
45-90 min lecture, one idea per slide, and **real speaker notes for every
slide** - what the lecturer says out loud, 40-120 words, not a copy of the
slide text. Never ship a slide without notes.

Every case, quotation and figure you put on a slide needs a verifiable
reference **next to it** - an APA 7th in-text citation (`[@id]` marker,
see "APA references for cases, quotes and figures"). Collect the sources
into `meta.sources` while writing: `[@id]` expands to a clickable link for
an external source and to plain APA text for an internal RAG source. The
`check_apa` QA rule reports a case, quote or figure left without a
reference; it runs only when `meta.sources` is non-empty, so a deck that
cites nothing keeps its previous QA result.

### 3. Write the spec

Standard location: `lectures/<slug>/lecture.json` in the target project
(write with `propose_file`). Minimal example:

```json
{
  "meta": {
    "course": "Численные методы",
    "lecture_no": 7,
    "title": "Метод Ньютона",
    "lecturer": "И. И. Иванов",
    "org": "Кафедра вычислительной математики",
    "date": "2026-10-03",
    "lang": "ru",
    "theme": "academic_blue",
    "duration_min": 90
  },
  "slides": [
    {"type": "title", "note": "Представьтесь и объявите тему лекции."},
    {"type": "bullets", "header": "План лекции",
     "items": ["Постановка задачи", "**Метод Ньютона**", "Сходимость", "Пример и код"],
     "note": "Кратко пройдитесь по плану..."},
    {"type": "definition", "term": "Квадратичная сходимость",
     "text": "Метод сходится квадратично, если ...",
     "note": "Дайте определение..."}
  ]
}
```

Full field reference - see "Spec reference" below.

### 4. Build

If the target `.pptx` already exists, run the drift check of step 6 first: a
rebuild overwrites the file, and any edit the user made in PowerPoint would be
lost without a word.

```python
import sys
sys.path.insert(0, ".dev_agent/scratch/skill_lecture-slides")
from build_lecture import build
res = build("lectures/newton/lecture.json", "lectures/newton/newton.pptx", qa=True)
print(res["summary"])
```

`build()` returns `{"ok": bool, "pptx": path, "slides": n, "qa": {...},
"summary": str}`. With `qa=True` it validates the built deck immediately and
writes `qa.md` plus one report per QA stage (`qa_content.md`, `qa_file.md`,
`qa_visual.md`) into `<out_stem>_service/` (pass `service_dir=False` for the
older layout next to the deck).

### 5. Fix QA findings and rebuild

Typical fixes: shorten slide text (max 6 bullets, max 2 lines each); split an
overloaded slide; write the missing speaker notes; split a code listing longer
than 22 lines; replace an unsupported formula with supported mathtext (see
"Formulas"). Rebuild until the QA report has **zero errors**. Warnings are
acceptable for a draft but must be reviewed.

### 6. Check an existing deck against its spec (drift)

Run this **before** rebuilding a deck that already exists on disk, and before
delivering a deck you did not just build in this session. The user may have
opened the `.pptx` in PowerPoint and edited it directly; a rebuild from the
spec would silently destroy those edits.

```python
from build_lecture import check_drift
report = check_drift("lectures/newton/lecture.json", "lectures/newton/newton.pptx")
print(report["markdown"])
```

`check_drift` rebuilds the spec into a temporary folder and compares the two
decks **by text** (slide shapes, tables, speaker notes), so two builds that
differ as zip bytes but carry the same text are not reported as drift. It
never writes to the deck, the spec or any ack file. Read the result as:

| field | meaning |
|---|---|
| `changed` | `False` - the deck matches the spec; the rebuild is safe |
| `slides[].user_added` | lines that exist only in the deck - the manual edits |
| `slides[].user_removed` | lines the spec has but the deck lost |
| `notes[].user_text` / `notes[].spec_text` | the same for speaker notes |
| `acknowledged` | the user already accepted these edits as final |
| `ok` | no action needed: in sync, or the drift is acknowledged |
| `errors` | the check itself failed (missing or unreadable file) |

`report["markdown"]` is a ready-to-show block listing the differences per
slide - paste it instead of retelling the diff in your own words.

**When `changed` is true and `acknowledged` is false: do not rebuild, do not
overwrite the pptx, do not edit the spec.** Show the differences and ask the
question directly - this is a required stop, not a suggestion:

> Файл `newton.pptx` отличается от исходника `lecture.json` - похоже, вы
> правили презентацию вручную. Обновить исходники в соответствии с вашими
> правками?

Act on the answer, and only on it:

- **Yes, update the sources** - apply the edits to `lecture.json` itself
  (retitle the slide, fix the items, rewrite the note), rebuild, run QA, then
  re-run `check_drift`: it must report `changed: false`.
- **No, the deck is final** - call
  `build_lecture.acknowledge_manual_edits("lectures/newton/newton.pptx")`. It
  writes `<stem>_service/drift_ack.json` bound to the deck's SHA-256, so the
  question is not asked again for this exact file; any further edit makes the
  ack stale and the question returns. Leave the spec untouched and state in
  the report that the deck is the source of truth.
- **Rebuild from the spec anyway** - warn explicitly that the manual edits
  will be lost, get a confirmation, then rebuild.

A deck built in this session needs no check. When `report["errors"]` is
non-empty, report the error - never read a failed check as "no drift".

### 7. Optional PDF

```python
from render_preview import render
render("lectures/newton/newton.pptx", pdf=True, png=False)
```

PDF export requires LibreOffice (the function finds the standard macOS/Linux
locations automatically). PNG page images additionally require PyMuPDF
(`fitz`) or poppler; when neither is available the function reports
`png: False` - say so honestly instead of claiming previews exist.

### 8. Deliver and self-check

Report: deck path, slide count, estimated speaking time, QA status
(errors/warnings), PDF path if produced, and the drift verdict for a deck you
did not just build (in sync / acknowledged / the user's decision). Keep the
spec - it is the source for future edits; remove the scratch copy during the
usual workspace cleanup.

To smoke-test the bundle itself, build the bundled demo:

```python
res = build(".dev_agent/scratch/skill_lecture-slides/examples/demo_lecture.json",
            ".dev_agent/scratch/demo_out/demo.pptx", qa=True)
```

## Spec reference

Top level: `{"meta": {...}, "slides": [...], "qa": {...}?}`.

`meta` fields: `course`, `lecture_no` (int), `title`, `subtitle`?,
`lecturer`, `org`, `date` (`YYYY-MM-DD`), `lang` (`ru`/`en`), `theme`,
`duration_min` (int), `footer_left` (optional override), `formula_mode` (`omml` default = editable formulas, `image` = legacy raster), `normalize_dashes` (bool, default `false`; rewrite a prose hyphen between Cyrillic words to an em dash in the visible text), `auto_layout` (bool, default `false`; let the layout advisor rewrite flagged `bullets` slides into a visual type - see "Visual layouts"), `baseline`
(path to a previous `.pptx` for the regression comparison), `sources` (the
fact-checking registry of `{id, title, url?, authors?, year?, kind?, doi?,
internal?, rag_base?, ...}` entries - see "Links and sources" and "APA
references for cases, quotes and figures").

Every slide has `type` and `note` (string, required, non-empty). Names of
slide labels default to the language of `meta.lang` / `meta.labels` overrides.

| type | fields |
|---|---|
| `title` | optional overrides of the meta fields; rendered as the cover |
| `section` | `header` (or `title`), `number`? |
| `bullets` | `header`?, `items` (strings or `{text, level}`) |
| `definition` | `header`?, `term`, `text` (string or list), `formula`? |
| `theorem` | `kind`? (Теорема/Лемма/...), `name`?, `statement` (string or list), `formula`? |
| `proof` | `header`?, `steps` (list of strings), `formula`?, `qed`? (default true) |
| `formula` | `header`?, `formula` (string or list of strings = stacked lines), `caption`?, `numbered`? |
| `code` | `header`, `language`, `code`, `caption`?, `start_line`? (default 1; `null` hides numbers) |
| `table` | `header`, `columns`, `rows`, `caption`?, `col_widths`? (relative numbers) |
| `chart` | `header`?, `chart_type`? (`bar`/`line`/`pie`, default `bar`), `categories` (labels), `series` (`{name?, values}` list), `caption`? |
| `image` | `header`?, `path` (relative to the spec file), `caption`?, `width`? (inches) |
| `two_column` | `header`?, `left` + `right` blocks, `split`? (fraction, default 0.48) |
| `cards` | `header`?, `items` (`{title, text}` or strings), `columns`? (1-4, default auto), `slots`? (see "Template slots"), `caption`? |
| `timeline` | `header`?, `items` (`{label, text}`; years make good labels), `slots`? |
| `process` | `header`?, `items` (strings or `{text}`), `slots`?, `caption`? |
| `steps_grid` | `header`?, `items` (strings or `{title, text}`), `columns`? (2-3, default auto), `slots`? |
| `pillars` | `header`?, `items` (`{title, text}` or strings), `columns`? (2-4, default auto) |
| `focus` | `header`?, `statement` (required), `supports`? (list of strings or `{text}`), `columns`? |
| `compare` | `header`?, `left` + `right` blocks, `left_label`?, `right_label`?, `verdict`? |
| `summary` | `header`? (default «Итоги»), `items` |
| `homework` | `header`? (default «Задание»), `items`, `deadline`? |
| `literature` | `header`? (default «Литература»), `items` (strings or `{text, url}`), `source_refs`? (registry ids - see "Links and sources") |

Blocks for `two_column` are objects: `{"kind": "bullets", "items": [...]}`,
`{"kind": "paragraphs", "items": [...]}`,
`{"kind": "formula", "formula": ...}` (also `"code"`, `"image"`, `"table"`, `"chart"`
with the same fields as the standalone types).

### Template slots

A layout slide (`cards`, `timeline`, `process`, `steps_grid`) may declare `slots` - the
number of places its template has. When the data holds fewer elements than
slots, the empty slot groups are removed entirely (no frame, marker or
caption), while the filled elements keep the template grid positions; QA
reports an *orphaned slot decoration* as an error if any decoration is left
without data. `slots` must be an integer 1-12 and greater than the number
of `items` (otherwise it is ignored with a warning).

Inline markup inside any text string: `**bold**`, `*italic*`, `` `code` ``.
Inline math is NOT supported inside sentences - use Unicode (`x²`, `≤`, `α`)
or a separate `formula` / `two_column` block.

`qa` overrides (all optional): `min_note_words` (12), `max_note_words` (260),
`max_bullets` (6), `max_code_lines` (22), `min_body_pt` (16),
`min_margin_in` (0.45), `check_images` (true), `min_image_px` (200),
`check_glyphs` (false), `check_density` (true), `min_slide_words` (20),
`min_column_words` (3), `min_fill` (0.15 - minimum share of the frame
covered by content boxes), `check_lists` (true), `min_list_items` (5),
`check_overlaps` (true), `overlap_frac` (0.25), `check_formula_caption`
(true), `check_source_refs` (true), `check_apa` (true - a case, quote or
figure without an APA reference, only when `meta.sources` is non-empty;
see "APA references for cases, quotes and figures"), `check_layout_advice` (true - report a
short `bullets` slide that a visual type would fill better), `strict` (false -
warnings do not fail).

## Visual layouts

Short parallel points are the main cause of a half-empty slide: three or four
short bullets fill the upper part of the body frame and the lower part stays
blank. Three visual types exist for exactly that shape - all of them fill the
frame by construction:

| type | use for | looks like |
|---|---|---|
| `steps_grid` | 3-6 short parallel points, typical mistakes, a checklist | numbered tiles in a 2x2 or 3x2 grid, each tile fills the frame |
| `pillars` | 2-4 named components with a short description each (marketing mix, criteria, roles) | full-height columns with an accent header band |
| `focus` | one key statement plus up to 4 supports | a wide statement banner and a grid of support blocks |

`bullets` stays correct for real prose: long points of two or more lines, more
than six items, or lists where the wording itself is the content.

Two shapes deserve a note:

- `pillars` and `focus` both honour `columns`: it is the number of grid columns,
  and the items wrap into as many rows as needed (`pillars` 1-4, `steps_grid`
  1-3). Without it the renderer picks a sensible default (`pillars` = one row,
  `focus` = one row of at most three supports).
- `focus` with a statement and NO `supports` grows the statement until it fills
  the body frame instead of leaving a small line in a tall plate. Keep at least
  two supports when you want the banner-plus-cards look.

### Layout advisor

`lecture/layout_advisor.py` applies that rule automatically. `suggest_layout(slide)`
returns `None` when the bullet list is fine, otherwise
`{"suggested_type", "reason", "replacement"}` (shown above);
`build_replacement(slide, type)` produces the rewritten slide and keeps `note`,
`caption` and `source_refs` untouched:

| shape of the `bullets` slide | suggested type |
|---|---|
| 1 short point | `focus` (the point becomes the statement) |
| 2 short points | `focus` (first = statement, second = support) |
| 3-6 short points, all without titles | `steps_grid` |
| 3-6 short points, items carry `title` | `pillars` |
| any long point, or more than 6 items | stay `bullets` |

A point counts as short when it has at most 8 words and fits one line at body
size. With `"auto_layout": true` in `meta` the builder rewrites the flagged
slides before rendering, records every change in `result["auto_layout"]` and
appends a warning to the build result, so an automatic rewrite is never
silent. Without the flag the slides stay as written and QA reports the advice
as a warning (`qa.check_layout_advice`).

## Formulas

`formula` fields accept a LaTeX-style subset shared by both renderers:
`\\frac{a}{b}`, `\\sqrt{x}`, `x^2`, `x_i`, `\\sum_{i=1}^{n}`, `\\int_a^b`,
`\\lim_{x \\to 0}`, Greek letters (`\\alpha`, `\\lambda`, `\\Delta`), `\\cdot`,
`\\times`, `\\pm`, `\\leq`, `\\geq`, `\\neq`, `\\approx`, `\\to`, `\\infty`,
`\\partial`, `\\nabla`, `\\in`, `\\subset`, `\\forall`, `\\exists`,
`\\mathbf{}`, `\\mathrm{}` and `\\left( ... \\right)` pairs. A list of
strings renders as stacked centered lines. Constructs outside this subset
(`\\begin{...}` environments, custom macros) are not supported: OMML mode
falls back to a raster image for that formula and records a warning, image
mode raises a clear build error.

By default (`meta.formula_mode` = `omml`) formulas become **editable Office
Math** (OMML) elements inside the pptx: they stay editable in PowerPoint and
are validated structurally in QA (structure notes appear as warnings). With
`"formula_mode": "image"` formulas are rendered to PNG at 300 dpi into
`<name>_service/assets/` and embedded as images, so they look identical on any
machine.

## Code

Languages: `python`, `c`, `cpp`, `java`, `javascript`, `typescript`, `sql`,
`bash`, `json`, `yaml`, `html`, `css`, `xml`, `text` (aliases: `py`, `js`, `ts`,
`sh`, `c++`). Code is highlighted natively (runs, not images). Font size is
auto-fitted (16 pt down to 11 pt); listings longer than `max_code_lines` are a
QA error - split them. Line numbers are on by default.

## Illustrations (figkit)

`lecture/figkit.py` composes illustrations (schemes, block diagrams, annotated charts) programmatically and audits them **before** they reach a slide:

```python
import sys
sys.path.insert(0, '.dev_agent/scratch/skill_lecture-slides')
from lecture.figkit import Canvas

c = Canvas(6.4, 3.0, theme='academic_blue')   # size in inches, deck theme
c.rect(0.05, 0.50, 0.28, 0.34, fc=c.colors['soft'])
c.boxtext(0.05, 0.50, 0.28, 0.34, 'Данные', fs=12, key='b')
c.arrow(0.35, 0.67, 0.52, 0.67)
c.boxtext(0.55, 0.50, 0.28, 0.34, 'Модель', fs=12, key='b')
problems = c.save('lectures/newton/img/pipeline.png')
assert not problems, problems   # keep this on EVERY illustration
```

Coordinates are axes fractions ((0, 0) - bottom-left, (1, 1) - top-right); font sizes are typographic points. `c.colors` is the palette of the chosen theme (`ink`, `muted`, `accent`, `soft`, `rule`, `card`, `bg` plus chart accents `green`/`orange`/`red`/`violet`); font keys are short roles: `r`/`b` Arial, `g`/`gb` Georgia, `m`/`mb` Courier. Helpers: `rect`, `circ`, `arrow`, `line`, `multiline`, `boxtext` (auto-shrinks the font until the text fits its plate), `label`.

`save(path)` writes the PNG and returns a list of layout problems: text spilling out of its plate, elements leaving the canvas, overlapping captions, ink touching the bitmap border. Slide QA never looks inside a picture, so `assert not problems` is the only protection against a silently broken figure. For hand-made matplotlib charts tag annotations with `set_gid('annot')` and call `audit_fig(fig)` - it checks overlaps between the tagged texts.

Keep pictures in an `img/` folder next to the spec and reference them by relative path (`'path': 'img/pipeline.png'`); the deck QA then inspects every picture of image slides and blocks (`check_images`: size, solid color, border ink).

## Links and sources

Inline markup supports clickable hyperlinks wherever a text string is accepted: `[подпись](https://example.com)` becomes a real PowerPoint hyperlink and stays clickable in the PDF handout. Safe schemes are `http`, `https` and `mailto`; anything else (`javascript:`, `ftp:`, ...) is left as literal text. Bold/italic nests inside the label: `[**теорема**](https://...)`.

Keep references in one registry on the slide deck level and cite them from slides:

```json
"meta": {
  "sources": [
    {"id": "press2007", "kind": "book",
     "authors": ["Press, W. H.", "Teukolsky, S. A."], "year": 2007,
     "title": "Numerical Recipes", "publisher": "Cambridge University Press",
     "url": "https://numerical.recipes/"},
    {"id": "rag1", "kind": "internal", "internal": true, "rag_base": "marketing",
     "authors": ["Петров, П. П."], "year": 2024, "title": "Отчёт об оттоке"},
    {"id": "lms", "kind": "web", "title": "Материалы курса в LMS",
     "url": "https://lms.example.edu/course", "checked_at": "2026-10-01"}
  ]
}
```

- `id` and `title` are required; `url` (a safe link), `kind` (`primary`/`secondary`/`book`/`web`/...) and `checked_at` are optional. Invalid entries are dropped with a spec warning; duplicate ids are ignored.
- Any slide cites registry ids in `source_refs`, e.g. `"source_refs": ["press2007"]`; unknown ids are reported as warnings.
- A `literature` slide with `source_refs` materializes its items from the registry: manual `items`, if present, come first, the registry entries follow with their links attached.

With a non-empty registry the QA pass doubles as a fact-check helper: a content slide with figure facts (percentages, grouped or long numbers) and no `source_refs`/inline link gets a warning, and every cited registry entry without a `url` is flagged. The numbers themselves are never fetched or verified automatically - checking them is the lecturer's job.

### APA references for cases, quotes and figures

Every claim the audience may want to verify carries a reference **right next to it** - in the same bullet, paragraph or caption, not only on the final literature slide. A claim is one of:

| claim | example |
|---|---|
| `case` | «Кейс компании X: выручка удвоилась за год»; `case study` |
| `quote` | «Конкуренция - это процесс созидательного разрушения» |
| `figure` | `47%`, `12 000 клиентов`, `12345 заказов` |

The reference is an **APA 7th in-text citation**: `(Автор, год)`, and `(Автор, год, с. 12)` for a direct quote. The easiest way to place it is the marker `[@id]`, which the builder expands from `meta.sources`:

```json
{"type": "bullets", "header": "Рынок",
 "items": ["Доля рынка выросла до 47% [@smith2019]",
           "«Спрос сместился в онлайн» [@rag1, с. 5]"],
 "note": "..."}
```

`[@smith2019]` becomes a clickable `(Smith, 2019)`; `[@rag1, с. 5]` becomes the plain `(Петров, 2024, с. 5)`. A ready label (`(Smith, 2019)`) or an inline link (`[отчёт](https://...)`) is accepted as well - the QA rule only checks that a reference is present and looks like APA.

**External versus internal sources.** A source taken from the open web (article, book, report, site) is cited with a **hyperlink** to the page where the claim can be checked. A source taken from an internal knowledge base (RAG) keeps the same APA wording but carries **no hyperlink** - the audience cannot follow it; the literature slide marks it as `[Внутренний источник, база знаний «...»]` instead.

```json
"meta": {"sources": [
  {"id": "smith2019", "kind": "article", "authors": ["Smith, J."], "year": 2019,
   "title": "Deep learning in practice", "container": "Journal of AI",
   "volume": "12", "issue": "3", "pages": "45-67", "doi": "10.1000/xyz123"},
  {"id": "rag1", "kind": "internal", "internal": true, "rag_base": "marketing",
   "authors": ["Петров, П. П."], "year": 2024, "title": "Отчёт об оттоке"}
]}
```

APA fields of a registry entry: `authors` (string or list, `Ivanov I. I.` or `Ivanov, I. I.`), `year` (int or string: `2019`, `2019a`, `б. г.`), `title`, `container` (journal or site), `volume`, `issue`, `pages`, `publisher`, `doi`, `url`, `accessed` (retrieval date), `internal` (`true` for a knowledge-base document), `rag_base` (the base slug), `apa` (a ready-made reference that replaces the generated one). `kind` still classifies the source (`book`, `article`, `web`, `internal`, ...).

What the builder generates:

| source | literature slide (APA 7) | in-text label |
|---|---|---|
| book | `Press, W. H. (2007). *Numerical Recipes*. Cambridge University Press. https://...` | `(Press, 2007)` |
| article with DOI | `Smith, J. (2019). Deep learning in practice. *Journal of AI*, *12*(3), 45-67. https://doi.org/...` | `(Smith, 2019)` |
| web page | `Иванов, И. И. (2026, 1 октября). Конспект лекции. https://...` | `(Иванов, 2026)` |
| internal (RAG) | `Петров, П. П. (2024). Отчёт об оттоке. [Внутренний источник, база знаний «marketing»]` | `(Петров, 2024)` |

Rules the generator follows: one author - the surname; two - both surnames joined with «и» (`&` in English); three and more - the first surname plus «и др.» (`et al.`); no author - the short title in double quotes; no year - `б. г.` (`n.d.`); a direct quote adds the page. Initials move after the comma (`Press W. H.` -> `Press, W. H.`). Book titles, journal names and volume numbers are italicised; a journal article never repeats the publisher.

**What QA checks** (`qa.check_apa`, warning level, only when `meta.sources` is non-empty): a slide with a case, a quote or a figure and neither `source_refs` nor an APA label in the text gets a warning; a registry entry without `authors`, `year` or `apa` is flagged once, because the reference cannot be formatted. An internal source is exempt from the hyperlink requirement. The numbers and quotations themselves are never fetched or verified - checking them stays the lecturer's job.

## Slide completeness

A content slide must not be half-empty. The QA pass measures the **frame fill** - the share of the slide area covered by content boxes, counting text boxes by their needed height (a tall frame holding a short formula counts as the formula, not the frame) - and flags slides below `min_fill` (0.15). A formula, table or code listing no longer clears the check by itself. Layout types that are airy by design (`title`, `section`, `cards`, `timeline`, `process`, `compare`) are exempt with a recorded reason, listed in the report's Density section - never a silent PASS. The QA pass also flags empty columns of `two_column`/`compare`; a flat list that reads as a classification (>= 5 items of <= 4 words each) gets a hint to use `cards` or a `table` instead. Overlapping content shapes are an error (> 25% of the smaller box, `overlap_frac`); a standalone formula with 2+ variables needs a caption that explains them («где x - ...»). One idea per slide, filled with real content, remains the main rule.

## Themes and typography

| theme | look |
|---|---|
| `academic_blue` | white background, deep blue accents, serif headers (default) |
| `graphite` | light gray background, graphite accents |
| `deep_green` | white background, dark green accents |
| `burgundy` | white background, burgundy accents |

Typography defaults (pt): cover title 40, section 34, slide header 27, body 20,
sub-bullets 18, code 16-11, captions 14, footer 11. Minimum body size enforced
by QA: 16 pt. One theme per deck.

Text blocks and lists are vertically centered in their content frame: short
lists balance in the middle, long lists stay top-fitted (the offset clamps to
zero). The renderer then uses the remaining room instead of leaving a deep
empty strip: list items gain extra `space_after` (up to 0.42 in), table rows
grow (up to 0.5 in), `definition`/`theorem` cards fill and center their frame,
and `homework` places the due date under the list. This applies to `bullets`,
list columns of `two_column`, `summary`, `homework` and `literature`. Formula
captions may run to several lines - the caption height is measured from the
wrapped text and shrinks the formula area, so «где … - это …» variable
explanations fit on the slide without overflow.

## QA contract

`qa_check.py` / `build(qa=True)` checks the spec and the built deck in
three named stages with separate reports; the combined report merges
their findings with `[content]`/`[file]`/`[visual]` prefixes:

- **content** (`qa_content.md`) - the spec text: leaked placeholders
  (`{{...}}`, `TODO`/`TBD`, lorem ipsum), layout records out of step with
  the spec, repeated words.
- **file** (`qa_file.md`) - the saved pptx package: content types,
  relationships, notes links, native charts whose embedded workbook must
  match the spec, OMML formulas.
- **visual** (`qa_visual.md`) - rasterized pages: content clipped at the
  slide edge, blank pages. Hand this stage to a reviewer **other than the
deck generator author** (the generator sees the intended layout, not the
rendered one); `qa_check.py --visual` runs it (needs LibreOffice). Without
rendered pages the stage reports itself as skipped - never a silent PASS.

Checks applied to the spec and the deck:

- **errors**: missing/too-short speaker notes; text overflow beyond its box
  (slack: `max(0.03 in, 8% of the box)`); shapes outside the safe margins;
  content that failed to render (formula/image error boxes); missing
  formula/image files; empty slides; code longer than the limit; body font
  below the minimum; unreadable or single-color images; the speaking-time
  estimate deviating from `duration_min` by more than `duration_tolerance`
  (default 35%) in either direction - underrun and overrun fail alike;
  overlapping content shapes (more than `overlap_frac` of the smaller box).
- **warnings**: notes too long (> 260 words); tight margins (< 0.45 in);
  low text contrast (WCAG < 4.5); > 6 list items; a small image side (below
  `min_image_px`) or ink touching the image border; a deep empty strip below
  the content (`qa.check_void`): more than `qa.max_void_in` (default
  1.2 in) between the lowest drawn content and the frame bottom - the Voids
  section lists every void and every recorded exemption (title/section/
  formula/timeline slides are airy by design); a hyphen used as an em dash
  between two Cyrillic words (`qa.check_dashes`; `meta.normalize_dashes`
  rewrites them); frame fill below `min_fill` (the share of the slide covered
  by content boxes; the Density section of the report lists every fill
  and every recorded exemption) and empty `two_column`/`compare` columns; a
  flat list that reads as a classification; a formula without a «где ...» caption; figure facts
  without `source_refs`/an APA reference while the sources registry is non-empty; a case or quotation
  without an APA reference; a registry entry that carries no `authors`/`year`/`apa` (`check_apa`); fonts
  that cannot draw some glyphs (`check_glyphs`); approximate text-fit
results when the theme fonts are not installed (see
`textfit.metrics_report`); headings lost against `meta.baseline`;
chart slides without `source_refs` while the sources registry is
non-empty; spec/build warnings.

Exit codes (CLI): `0` = no errors (warnings allowed unless `strict`),
`1` = errors found, `2` = spec/build failure. The report lists every finding
with slide index and suggested fix.

The new rules are configurable through the spec's `qa` object:
`qa.check_void` (default `true`) with `qa.max_void_in` (default `1.2` in),
`qa.check_dashes` (default `true`). `qa.check_duration` selects the timing
rule's severity: `error` (default), `warn` (reported as a warning) or
`off` (no timing finding); the legacy booleans still work (`true` = error,
`false` = off).

Every report is bound to the artifact and to the code that produced it: the
`<stem>_service/qa.md`/`qa.json` header carries the artifact SHA-256 and the skill
source fingerprint. `qa_check.verify_report(report, path)` re-hashes a file
and declares the report stale as soon as its bytes change - a PASS never
describes an edited deck.

Every report also carries a **delivery status**: `complete` - no
errors and no warnings; `delivery_ready` - no errors, but the warnings
travel forward as `caveats` (rendered as the `## Caveats` section);
`draft` - errors block delivery. The status is recomputed from the
findings by `qa_check.delivery_status` and checked with
`qa_check.verify_delivery` - a report that claims `complete` while
carrying warnings is refused, so a draft can never masquerade as a
finished deck. `build()` puts the status into the result summary and the
`<stem>_service/qa.json` payload.

## Known limitations

- **LibreOffice does not render OMML.** A PDF preview shows empty formula
  areas even though the file is valid and edits fine in PowerPoint; formula
  checks are therefore structural (file stage). Never treat a PDF as evidence
  about a formula.
- **The OMML converter covers the documented LaTeX subset only.** Anything
  outside it (`\begin{...}` environments, custom macros) falls back to a
  raster image with a warning in OMML mode; in image mode it is a clear
  build error.
- **The visual QA stage needs LibreOffice** (plus a PDF rasterizer); without
  them it reports `skipped` with the reason - never a silent PASS, and
  `preflight.py` names the missing pieces ahead of time.
- **The drift check compares text only**: a manual edit that just moves,
  restyles or recolours a shape, or swaps an image, is not detected - see
  `docs/limitations.md`. Its `drift_ack.json` is bound to one exact file, so
  any later save brings the question back.
- **Text-fit checks are approximate for unknown fonts**: the safety margin
  is widened and the affected elements are listed in the report.
- **The APA generator covers four source shapes** (book, journal article, web page, internal document); a conference paper, a thesis or a dataset goes into the entry's `apa` field verbatim - see `docs/limitations.md`.
- **The APA QA rule checks presence and shape, never correctness**: it never fetches a source, and a free-form attribution such as «по данным исследования ...» is not recognised as a reference - use `[@id]`.
- **The baseline comparison compares headings only** - it is not a
  body-level diff.
- **The empty-bottom check is a warning, not a proof of good layout**:
  it flags a deep empty strip under the content but leaves airy slide types
  (title/section/formula/timeline) exempt by design.
- **No standalone HTML export** and no third-party assets; the JSON spec
  format is the contract.

Full list with the reasoning: `get_skill_file(<id>, 'docs/limitations.md')`.

## Dependencies

Runtime requirements are declared machine-readably in `compatibility.json`
next to the skill and verified before a build: `python preflight.py` (or
`python build_lecture.py --check-env`) names every missing component with
an install hint, so a host fails with clear text before the build instead
of a traceback in the middle of it. Required: Python 3.10+,
`python-pptx`, `Pillow`, `matplotlib`, `pygments`; system fonts Arial /
Georgia / Courier New (graceful fallback to DejaVu). Optional:
LibreOffice (`soffice`) for PDF; PyMuPDF or poppler for PNG previews. No
network access is used.

## Bundle map

```
lecture-slides/
  SKILL.md             # this file
  CHANGELOG.md
  compatibility.json   # machine-readable environment requirements
  preflight.py         # environment preflight check             [entry]
  build_lecture.py     # spec -> pptx (+ optional QA)   [entry]
  qa_check.py          # spec + pptx -> QA report       [entry]
  render_preview.py    # pptx -> pdf (+ png optional)   [entry]
  lecture/
    __init__.py
    spec.py            # load + validate + label defaults
    apa.py             # APA 7th references and [@id] citations
    themes.py          # palettes and typography
    textfit.py         # text metrics (PIL) and contrast
    render.py          # formulas (matplotlib), code (pygments)
    deck.py            # slide builders, footers, notes
    slides.py          # per-slide-type renderers
    layout_advisor.py  # short bullets -> visual slide type advice
    baseline.py        # heading comparison against a previous deck
    omml.py            # LaTeX -> OMML formulas + structural validator
    fingerprint.py     # artifact/source SHA-256 fingerprints
    drift.py           # deck-versus-spec drift: did the user edit the pptx?
    stages.py          # three QA stages: content / file / visual
  examples/
    demo_lecture.json  # complete demo spec (smoke test)
    demo_plot.png      # demo image used by the spec
  tests/               # pytest self-tests (skill maintenance)
    scenarios/         # end-to-end lecturer scenarios
```

## Contract

Input: one JSON spec path (UTF-8). Output: `.pptx` + `<stem>_service/`
(QA reports, `assets/`, `preview/`, `drift_ack.json` when the user accepts
manual edits); optional `<stem>.pdf`. `check_drift` only reads: it rebuilds
the spec into a temporary folder and never touches the delivered deck or the
spec. Side effects: files are written next to the requested output path only;
no network calls; no destructive operations.

## Maintenance

When updating this skill: read `CHANGELOG.md` (`get_skill_file(<id>, 'CHANGELOG.md')`
- `read_file` cannot reach the skill folder), keep the spec format backward
compatible or bump the major version, and run the bundled tests from the skill
folder: `python -m pytest tests/ -q` (or `run_test` in DevAgent). The suite has
two layers: `tests/` covers the modules (spec, metrics, rendering, deck
records, QA, preview export, CLI); `tests/scenarios/` runs end-to-end lecturer
workflows (build with QA, fix-and-rebuild loop, broken formula/image recovery,
English deck, PDF handout, the output folder layout). Tests that need
LibreOffice or a PDF rasterizer skip automatically when those tools are absent.
