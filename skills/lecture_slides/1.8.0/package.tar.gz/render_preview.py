"""Preview/export helpers: PPTX -> PDF (LibreOffice) and optional PNG pages.

``render(pptx_path, pdf=True, png=False, out_dir=None, dpi=110, timeout=180,
contact_sheet=False, sheet_cols=4)`` returns a result dict::

    {'ok': bool, 'pptx': str, 'pdf': str|None, 'png': list|False,
     'contact_sheet': str|None, 'soffice': str|None, 'png_tool': str|None,
     'errors': [...], 'warnings': [...]}

PDF export converts the deck with headless LibreOffice (``soffice``); the
standard macOS/Linux install locations are checked automatically when the
binary is not on PATH. PNG page images are rasterized from the produced PDF
and require PyMuPDF (``pymupdf``/``fitz``) or poppler's ``pdftoppm``; when
neither is installed the function reports ``png: False`` with a warning
instead of pretending previews exist.

``make_contact_sheet(pdf_path, out_path=None, cols=4, dpi=60, gap=6)``
composes every page of a PDF into ONE PNG grid (PyMuPDF rasterizes, Pillow
tiles) so a whole deck can be reviewed at a glance; a missing dependency is
reported as a warning instead of a crash. ``render(..., contact_sheet=True)``
and the CLI flag ``--contact-sheet`` build it from the exported PDF.

Files are written only inside ``out_dir`` (default: next to the PPTX).
The PDF is a delivery artifact and stays next to the deck as
``<stem>.pdf``; the preview helpers go to ``<stem>_service/preview/``
(``page_NN.png`` pages and ``contact_sheet.png``) so the deck folder holds
only the pptx and the pdf. Pass ``service_dir=False`` to ``render`` /
``make_contact_sheet`` (or CLI ``--flat``) for the older ``<stem>_preview/``
layout. No network access.
CLI exit codes: 0 - exported, 2 - failure.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import tempfile
from pathlib import Path

SOFFICE_CANDIDATES = (
    '/Applications/LibreOffice.app/Contents/MacOS/soffice',
    '/usr/bin/soffice',
    '/usr/local/bin/soffice',
    '/opt/homebrew/bin/soffice',
    '/usr/bin/libreoffice',
    '/snap/bin/libreoffice',
)

PNG_MODULES = ('pymupdf', 'fitz')


def find_soffice():
    """Return the LibreOffice executable path, or None when not installed."""
    found = shutil.which('soffice') or shutil.which('libreoffice')
    if found:
        return found
    for candidate in SOFFICE_CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return None


def find_pdf_to_png():
    """Return the rasterizer to use ('pymupdf'/'fitz'/'pdftoppm') or None."""
    for module in PNG_MODULES:
        try:
            __import__(module)
            return module
        except Exception:  # noqa: BLE001 - any import failure means 'not available'
            continue
    if shutil.which('pdftoppm'):
        return 'pdftoppm'
    return None


def _convert_pdf(pptx, out_dir, soffice, timeout):
    """Convert one PPTX to PDF; returns (pdf_path_or_None, error_or_None).

    Paths are resolved before the call: the spawned LibreOffice process does
    not inherit this process's logical view of relative paths.
    """
    pptx = Path(pptx).resolve()
    out_dir = Path(out_dir).resolve()
    profile = Path(tempfile.mkdtemp(prefix='lo_profile_'))
    try:
        proc = subprocess.run(
            [soffice, '--headless', '--norestore',
             '-env:UserInstallation=%s' % profile.as_uri(),
             '--convert-to', 'pdf', '--outdir', str(out_dir), str(pptx)],
            capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, 'LibreOffice timed out after %ss' % timeout
    finally:
        shutil.rmtree(profile, ignore_errors=True)
    pdf_path = out_dir / (pptx.stem + '.pdf')
    if proc.returncode != 0 or not pdf_path.exists():
        details = (proc.stderr or proc.stdout or '').strip()
        return None, 'LibreOffice export failed: %s' % (details or 'no output file')
    return str(pdf_path), None


def _rasterize(pdf_path, png_dir, tool, dpi, timeout):
    """Rasterize a PDF into page PNGs; returns (page_paths, error_or_None)."""
    png_dir.mkdir(parents=True, exist_ok=True)
    if tool == 'pdftoppm':
        proc = subprocess.run(
            ['pdftoppm', '-png', '-r', str(dpi), str(pdf_path), str(png_dir / 'page')],
            capture_output=True, text=True, timeout=timeout)
        if proc.returncode != 0:
            details = (proc.stderr or proc.stdout or '').strip()
            return [], 'pdftoppm failed: %s' % (details or 'unknown error')
        return [str(path) for path in sorted(png_dir.glob('page-*.png'))], None

    module = __import__(tool)
    pages = []
    try:
        document = module.open(str(pdf_path))
        try:
            for index, page in enumerate(document, start=1):
                pixmap = page.get_pixmap(dpi=dpi)
                out = png_dir / ('page_%02d.png' % index)
                pixmap.save(str(out))
                pages.append(str(out))
        finally:
            document.close()
    except Exception as exc:  # noqa: BLE001 - report any rasterizer failure
        return pages, '%s rasterization failed: %s' % (tool, exc)
    return pages, None


def make_contact_sheet(pdf_path, out_path=None, cols=4, dpi=60, gap=6, timeout=180,
                       service_dir=True):
    """Compose every PDF page into ONE PNG grid; returns (path, error) pair.

    Rasterizes the pages with the available PDF tool (PyMuPDF or pdftoppm)
    into a temporary folder, then tiles the thumbnails with Pillow: ``cols``
    columns, ``gap`` px spacing, uniform cells (smaller pages are centered).
    ``out_path`` defaults to ``<pdf parent>/<stem>_service/preview/contact_sheet.png``
    (``<stem>_preview/contact_sheet.png`` when ``service_dir`` is false).
    """
    pdf = Path(pdf_path)
    if not pdf.exists():
        return None, 'pdf not found: %s' % pdf
    tool = find_pdf_to_png()
    if tool is None:
        return None, 'no PDF rasterizer (PyMuPDF/poppler); contact sheet skipped'
    target = (Path(out_path) if out_path
              else _preview_dir(pdf, pdf.parent, service_dir) / 'contact_sheet.png')
    cols = max(1, int(cols))
    gap = max(0, int(gap))
    try:
        from PIL import Image
    except Exception as exc:  # noqa: BLE001 - Pillow is required for tiling
        return None, 'Pillow is required for the contact sheet: %s' % exc
    with tempfile.TemporaryDirectory(prefix='sheet_pages_') as tmp:
        pages, error = _rasterize(pdf, Path(tmp), tool, dpi, timeout)
        if error or not pages:
            return None, error or 'no pages rasterized for the contact sheet'
        thumbs = []
        try:
            for page_path in pages:
                with Image.open(page_path) as img:
                    thumbs.append(img.convert('RGB'))
            cell_w = max(img.width for img in thumbs)
            cell_h = max(img.height for img in thumbs)
            rows = (len(thumbs) + cols - 1) // cols
            sheet = Image.new('RGB', (cols * cell_w + (cols + 1) * gap,
                                      rows * cell_h + (rows + 1) * gap), 'white')
            for index, img in enumerate(thumbs):
                row, col = divmod(index, cols)
                x = gap + col * (cell_w + gap) + (cell_w - img.width) // 2
                y = gap + row * (cell_h + gap) + (cell_h - img.height) // 2
                sheet.paste(img, (x, y))
            target.parent.mkdir(parents=True, exist_ok=True)
            sheet.save(str(target))
        except Exception as exc:  # noqa: BLE001 - report any tiling failure
            return None, 'contact sheet failed: %s' % exc
        finally:
            for img in thumbs:
                img.close()
    return str(target), None


def _preview_dir(pptx, target_dir, service_dir):
    """Folder for the preview helpers of one deck.

    ``<stem>_service/preview/`` when ``service_dir`` is true (the deck folder
    keeps only the pptx and the pdf), otherwise the older ``<stem>_preview/``.
    """
    stem = Path(pptx).stem
    base = Path(target_dir)
    if service_dir:
        return base / (stem + '_service') / 'preview'
    return base / (stem + '_preview')


def render(pptx_path, pdf=True, png=False, out_dir=None, dpi=110, timeout=180,
           contact_sheet=False, sheet_cols=4, service_dir=True):
    """Export a deck: PPTX -> PDF (LibreOffice) -> PNG pages / contact sheet.

    The PDF stays next to the deck (delivery artifact); page PNGs and the
    contact sheet go to ``<stem>_service/preview/`` unless ``service_dir`` is
    false (then the older ``<stem>_preview/`` layout is used).
    """
    pptx = Path(pptx_path)
    target_dir = Path(out_dir) if out_dir else pptx.parent
    preview_dir = _preview_dir(pptx, target_dir, service_dir)
    result = {
        'ok': False, 'pptx': str(pptx), 'pdf': None, 'png': False,
        'contact_sheet': None, 'soffice': None, 'png_tool': None,
        'errors': [], 'warnings': [],
    }
    if not pptx.exists():
        result['errors'].append('pptx not found: %s' % pptx)
        return result
    target_dir.mkdir(parents=True, exist_ok=True)

    if pdf:
        soffice = find_soffice()
        result['soffice'] = soffice
        if soffice is None:
            result['warnings'].append('LibreOffice (soffice) not found; PDF export skipped')
        else:
            pdf_path, error = _convert_pdf(pptx, target_dir, soffice, timeout)
            if error:
                result['errors'].append(error)
            else:
                result['pdf'] = pdf_path
                result['ok'] = True

    if png:
        tool = find_pdf_to_png()
        result['png_tool'] = tool
        pdf_for_png = result['pdf']
        if pdf_for_png is None:
            existing = target_dir / (pptx.stem + '.pdf')
            if existing.exists():
                pdf_for_png = str(existing)
        if tool is None:
            result['warnings'].append('no PDF rasterizer (PyMuPDF/poppler); png: False')
        elif not pdf_for_png:
            result['warnings'].append('PNG export needs the PDF; run with pdf=True')
        else:
            pages, error = _rasterize(pdf_for_png, preview_dir,
                                      tool, dpi, timeout)
            if error:
                result['errors'].append(error)
            if pages:
                result['png'] = pages
            result['ok'] = bool(pages) and not error

    if contact_sheet:
        sheet_pdf = result['pdf']
        if sheet_pdf is None:
            existing = target_dir / (pptx.stem + '.pdf')
            if existing.exists():
                sheet_pdf = str(existing)
        if find_pdf_to_png() is None:
            result['warnings'].append('no PDF rasterizer (PyMuPDF/poppler); contact sheet skipped')
        elif not sheet_pdf:
            result['warnings'].append('contact sheet needs the PDF; run with pdf=True')
        else:
            sheet_path, error = make_contact_sheet(
                sheet_pdf, preview_dir / 'contact_sheet.png',
                cols=sheet_cols)
            if error:
                result['errors'].append(error)
            if sheet_path:
                result['contact_sheet'] = sheet_path
            result['ok'] = bool(sheet_path) and not error

    if not pdf and not png and not contact_sheet:
        result['warnings'].append('nothing to export: pdf=False and png=False')
    return result


def main(argv=None):
    """CLI: export a deck and print the summary (exit 0 ok / 2 failure)."""
    parser = argparse.ArgumentParser(
        description='Export a lecture deck: PPTX -> PDF (+ optional PNG pages).')
    parser.add_argument('pptx_path', help='source .pptx')
    parser.add_argument('--no-pdf', action='store_true', help='skip the PDF step')
    parser.add_argument('--png', action='store_true', help='also rasterize PDF pages')
    parser.add_argument('--contact-sheet', action='store_true', dest='contact_sheet',
                        help='compose one PNG grid of all PDF pages')
    parser.add_argument('--sheet-cols', type=int, default=4,
                        help='contact sheet columns (default 4)')
    parser.add_argument('--out-dir', help='output directory (default: next to the pptx)')
    parser.add_argument('--dpi', type=int, default=110, help='PNG resolution (default 110)')
    parser.add_argument('--flat', action='store_true', default=False,
                        help='keep the older <stem>_preview/ layout for preview files')
    args = parser.parse_args(argv)

    res = render(args.pptx_path, pdf=not args.no_pdf, png=args.png,
                 out_dir=args.out_dir, dpi=args.dpi,
                 contact_sheet=args.contact_sheet, sheet_cols=args.sheet_cols,
                 service_dir=False if args.flat else True)
    pages = len(res['png']) if res['png'] else 'False'
    sheet = res['contact_sheet'] or 'none'
    print('preview: %s | pdf: %s | png: %s | sheet: %s'
          % ('OK' if res['ok'] else 'FAILED', res['pdf'] or 'none', pages, sheet))
    for message in res['errors']:
        print('ERROR: ' + message)
    for message in res['warnings']:
        print('WARNING: ' + message)
    return 0 if result_ok(res) else 2


def result_ok(res):
    """True when the export succeeded (helper kept for a single exit policy)."""
    return bool(res.get('ok'))


if __name__ == '__main__':
    raise SystemExit(main())
