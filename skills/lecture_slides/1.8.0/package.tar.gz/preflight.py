"""Preflight check for the lecture-slides environment - stdlib only.

The bundle's runtime requirements are declared machine-readably in
``compatibility.json`` next to this file: every entry carries probes
(python imports, executables, fonts, the interpreter version), a severity
and an install hint. This module turns that declaration into a report a
host can run BEFORE the build starts:

    python preflight.py                     # human-readable report
    python build_lecture.py --check-env     # same, from the build entry

The module imports only the standard library on purpose: it must run on a
host that is missing the very packages it checks (``python-pptx`` cannot
be imported to report itself missing). Missing *optional* components
(LibreOffice, PyMuPDF, poppler, theme fonts) are named as unmet
preconditions together with their consequences; missing *required*
components fail the check with exit code 2 and an install hint - clear
text instead of a traceback in the middle of a build. No network access
is used.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import platform
import shutil
from pathlib import Path

PROBE_KINDS = ('import', 'executable', 'font', 'python')
COMPATIBILITY_FILE = 'compatibility.json'

FONT_DIRS = (
    Path.home() / 'Library' / 'Fonts',
    Path('/Library/Fonts'),
    Path('/System/Library/Fonts'),
    Path('/usr/share/fonts'),
    Path('/usr/local/share/fonts'),
    Path('C:/Windows/Fonts'),
)
FONT_SUFFIXES = ('.ttf', '.otf', '.ttc', '.dfont', '.pfb')


# --------------------------------- probes ----------------------------------

def _default_which(name):
    """Return the executable path for ``name`` or None (real PATH lookup)."""
    return shutil.which(name)


def _default_find_spec(name):
    """Return the import spec of a python module, or None when it is absent."""
    try:
        return importlib.util.find_spec(name)
    except (ImportError, ValueError):
        return None


def _normalize_name(value):
    """Lower-case a font/executable name and drop punctuation for matching."""
    return ''.join(ch for ch in str(value).lower() if ch.isalnum())


def _default_font_lookup(family):
    """Return the path of an installed font file matching ``family``, or None."""
    wanted = _normalize_name(family)
    if not wanted:
        return None
    for base in FONT_DIRS:
        if not base.is_dir():
            continue
        try:
            candidates = sorted(base.rglob('*'))
        except OSError:
            continue
        for path in candidates:
            if path.suffix.lower() not in FONT_SUFFIXES or not path.is_file():
                continue
            if wanted in _normalize_name(path.stem):
                return str(path)
    return None


def _run_probe(probe, which, find_spec, font_lookup):
    """Run one probe; returns a problem description or None when it passes."""
    kind = probe.get('kind')
    target = probe.get('target')
    if kind == 'import':
        if not find_spec(target):
            return "module '%s' is not importable" % target
        return None
    if kind == 'executable':
        names = list(target) if isinstance(target, (list, tuple)) else [target]
        for name in names:
            if which(name):
                return None
        return 'not found in PATH (looked for %s)' % ', '.join(str(n) for n in names)
    if kind == 'font':
        if not font_lookup(target):
            return "font '%s' is not installed" % target
        return None
    if kind == 'python':
        try:
            current = tuple(int(part) for part in platform.python_version_tuple()[:2])
            minimum = tuple(int(part) for part in str(target).split('.')[:2])
        except ValueError:
            return "cannot parse the declared python version '%s'" % target
        if current < minimum:
            return ('python %s is older than the declared minimum %s'
                    % (platform.python_version(), target))
        return None
    return "unknown probe kind '%s'" % kind


# -------------------------------- reporting --------------------------------

def load_requirements(root=None):
    """Load the machine-readable requirement declaration (``compatibility.json``)."""
    base = Path(root) if root is not None else Path(__file__).resolve().parent
    data = json.loads((base / COMPATIBILITY_FILE).read_text(encoding='utf-8'))
    data.setdefault('requirements', [])
    return data


def check_environment(which=None, find_spec=None, font_lookup=None, root=None):
    """Run every declared probe and build the preflight report.

    ``which``/``find_spec``/``font_lookup`` override the host lookups (used
    by tests to simulate a broken host); they default to the real ones.
    Returns ``{ok, summary, requirements, missing_required, missing_optional}``
    where ``ok`` is True when every *required* component is present.
    """
    declaration = load_requirements(root)
    which = which if which is not None else _default_which
    find_spec = find_spec if find_spec is not None else _default_find_spec
    font_lookup = font_lookup if font_lookup is not None else _default_font_lookup

    entries = []
    for requirement in declaration.get('requirements') or []:
        problems = []
        for probe in requirement.get('probes') or []:
            problem = _run_probe(probe, which, find_spec, font_lookup)
            if problem:
                problems.append(problem)
        entries.append({
            'id': requirement.get('id'),
            'kind': requirement.get('kind'),
            'severity': requirement.get('severity') or 'required',
            'why': requirement.get('why') or '',
            'ok': not problems,
            'detail': '; '.join(problems),
            'hint': requirement.get('hint') or requirement.get('missing_note') or '',
        })

    missing_required = [entry['id'] for entry in entries
                        if not entry['ok'] and entry['severity'] == 'required']
    missing_optional = [entry['id'] for entry in entries
                        if not entry['ok'] and entry['severity'] != 'required']
    if missing_required:
        summary = ('%d missing required components: %s'
                   % (len(missing_required), ', '.join(missing_required)))
    else:
        summary = 'all required components present'
    return {
        'ok': not missing_required,
        'summary': summary,
        'requirements': entries,
        'missing_required': missing_required,
        'missing_optional': missing_optional,
    }


def _entry_line(entry):
    """One report line: marker, id, severity, problem and install hint."""
    marker = '[OK]' if entry.get('ok') else '[MISSING]'
    line = '%s %s (%s)' % (marker, entry.get('id'), entry.get('severity'))
    if entry.get('detail'):
        line += ' - ' + entry['detail']
    if not entry.get('ok') and entry.get('hint'):
        line += '; ' + entry['hint']
    return line


def report_text(report):
    """Render the preflight report as plain text (no traceback paths)."""
    lines = ['Environment check for lecture-slides', '']
    for entry in report.get('requirements') or []:
        lines.append(_entry_line(entry))
    lines.append('')
    lines.append('Result: %s' % report.get('summary'))
    if report.get('missing_optional'):
        lines.append('Optional components unavailable: %s'
                     % ', '.join(report['missing_optional']))
    return '\n'.join(lines)


def main(argv=None):
    """CLI entry: print the report; exit 0 when required components are present."""
    parser = argparse.ArgumentParser(
        description='Preflight check for the lecture-slides environment.')
    parser.add_argument('--json', action='store_true',
                        help='print the report as JSON instead of plain text')
    parser.add_argument('--root', default=None,
                        help='folder with compatibility.json (default: next to preflight.py)')
    args = parser.parse_args(argv)

    report = check_environment(root=args.root)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(report_text(report))
    return 0 if report['ok'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
