"""Tests for the three-stage QA split: content / file / visual.

The QA pass is split into three explicitly named stages with different
tools and separate reports:

* ``content`` - spec text: placeholder leakage, record/spec order, typos;
* ``file``    - the pptx package: content types, relationships, notes
  links, charts, OMML formulas;
* ``visual``  - rasterized pages: clipped overflow, blank pages; the
  report must say the stage is reviewed by someone other than the deck
  generator's author.

A seeded defect of each class must be caught by its own stage, and an
overflow the record-based checks cannot see must be caught by the visual
stage. Written BEFORE the split existed: ``lecture.stages`` did not exist
and ``build()`` wrote two reports, so every test here failed.
"""

from __future__ import annotations

import zipfile
from pathlib import Path

import pytest

from lecture import build_deck, validate_spec

NOTE = ('Заметка достаточной длины для порога качества проверки материала '
        'на этой лекции курса.')


def _spec(slides):
    """Validated spec for the stage tests."""
    return validate_spec({'meta': {'course': 'Курс', 'title': 'Этапы QA', 'lang': 'ru'},
                          'slides': slides})


def _slide(items=None, header='План'):
    """Minimal valid bullets slide."""
    return {'type': 'bullets', 'header': header,
            'items': items or ['Первый пункт', 'Второй пункт'], 'note': NOTE}


def _result(records=None):
    """Minimal build result: one aligned bullets record by default."""
    recs = records if records is not None else [
        {'index': 1, 'type': 'bullets', 'note_words': 50, 'bullets': 2,
         'code_lines': 0, 'boxes': [], 'empty': False}]
    return {'records': recs, 'errors': [], 'warnings': [], 'ok': True}


def _build(spec, path):
    result = build_deck(spec, out_path=path, assets_dir=path.parent / 'assets')
    assert result['ok'] is True, result['errors']
    return result


def _page(path, rect=None, size=(1600, 900)):
    """Synthesize one rendered page (white background, optional dark block)."""
    from PIL import Image, ImageDraw
    img = Image.new('RGB', size, 'white')
    if rect is not None:
        ImageDraw.Draw(img).rectangle(list(rect), fill=(20, 20, 20))
    img.save(str(path))
    return str(path)


def _rewrite_part(source, target, part, transform):
    """Copy a pptx, replacing one text part through ``transform``."""
    with zipfile.ZipFile(source) as src, zipfile.ZipFile(target, 'w',
                                                         zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            data = src.read(item.filename)
            if item.filename == part:
                data = transform(data.decode('utf-8')).encode('utf-8')
            dst.writestr(item, data)
    return target


# ------------------------------ stage reports ------------------------------

def test_build_writes_three_stage_reports(tmp_path, demo_spec_path):
    from build_lecture import build
    res = build(demo_spec_path, tmp_path / 'demo.pptx', qa=True, qa_json=True)
    assert res['ok'] is True
    names = sorted(Path(p).name for p in res['qa_reports'])
    assert names == ['qa.json', 'qa.md', 'qa_content.md',
                     'qa_file.md', 'qa_visual.md']
    service = tmp_path / 'demo_service'
    combined = (service / 'qa.md').read_text(encoding='utf-8')
    assert '## Stages' in combined
    for stage in ('content', 'file', 'visual'):
        text = (service / ('qa_%s.md' % stage)).read_text(encoding='utf-8')
        assert 'QA stage report (%s)' % stage in text
    assert res['qa']['stages']['content']['ok'] is True
    assert res['qa']['stages']['file']['ok'] is True
    assert res['qa']['stages']['visual']['skipped'] is True


def test_stage_markdown_keeps_fresh_reviewer_note(tmp_path):
    from lecture import stages
    report = stages.visual_stage(_spec([_slide()]), _result(), pages=None)
    text = stages.stage_markdown(report)
    assert 'other than the deck generator' in text
    assert 'SKIPPED' in text


# --------------------------------- content ---------------------------------

def test_content_stage_flags_placeholder_leak():
    from lecture import stages
    bad = stages.content_stage(_spec([_slide(['Первый пункт', 'TODO: вставить данные'])]),
                               _result())
    assert bad['ok'] is False
    assert any('placeholder' in e.lower() for e in bad['errors'])
    clean = stages.content_stage(_spec([_slide()]), _result())
    assert clean['ok'] is True and clean['errors'] == []


def test_content_stage_flags_repeated_word_typo():
    from lecture import stages
    report = stages.content_stage(
        _spec([_slide(['Метод метод сходится за три шага'])]), _result())
    assert report['ok'] is True
    assert any("repeated word 'метод'" in w.lower() for w in report['warnings'])
    clean = stages.content_stage(_spec([_slide()]), _result())
    assert clean['warnings'] == []


def test_content_stage_checks_record_order():
    from lecture import stages
    spec = _spec([_slide(), _slide(header='Второй')])
    partial = _result([{'index': 1, 'type': 'bullets', 'note_words': 50}])
    report = stages.content_stage(spec, partial)
    assert any('spec declares' in e for e in report['errors'])
    swapped = _result([{'index': 2, 'type': 'bullets', 'note_words': 50},
                       {'index': 1, 'type': 'bullets', 'note_words': 50}])
    report2 = stages.content_stage(spec, swapped)
    assert any('out of order' in e for e in report2['errors'])
    aligned = _result([{'index': 1, 'type': 'bullets', 'note_words': 50},
                       {'index': 2, 'type': 'bullets', 'note_words': 50}])
    assert stages.content_stage(spec, aligned)['ok'] is True


# ---------------------------------- file -----------------------------------

def test_file_stage_accepts_clean_package(tmp_path):
    from lecture import stages
    spec = _spec([_slide()])
    result = _build(spec, tmp_path / 'clean.pptx')
    report = stages.file_stage(spec, result)
    assert report['skipped'] is False
    assert report['ok'] is True
    assert report['errors'] == []


def test_file_stage_flags_broken_content_types(tmp_path):
    from lecture import stages
    spec = _spec([_slide()])
    result = _build(spec, tmp_path / 'ct.pptx')
    bad = _rewrite_part(
        result['out_path'], tmp_path / 'ct_bad.pptx', '[Content_Types].xml',
        lambda text: text.replace(
            '</Types>',
            '<Override PartName="/ppt/charts/chart9.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>'
            '</Types>'))
    report = stages.file_stage(spec, dict(result, out_path=str(bad)))
    assert report['ok'] is False
    assert any('content types' in e.lower() for e in report['errors'])


def test_file_stage_flags_missing_relationship_target(tmp_path):
    from lecture import stages
    spec = _spec([_slide()])
    result = _build(spec, tmp_path / 'rel.pptx')
    bad = _rewrite_part(
        result['out_path'], tmp_path / 'rel_bad.pptx',
        'ppt/slides/_rels/slide1.xml.rels',
        lambda text: text.replace(
            '</Relationships>',
            '<Relationship Id="rId99" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" '
            'Target="../media/missing.png"/></Relationships>'))
    report = stages.file_stage(spec, dict(result, out_path=str(bad)))
    assert report['ok'] is False
    assert any('missing.png' in e for e in report['errors'])


def test_file_stage_skips_without_saved_deck():
    from lecture import stages
    report = stages.file_stage(_spec([_slide()]), {'records': []})
    assert report['skipped'] is True and report['ok'] is True


# --------------------------------- visual ----------------------------------

def test_visual_stage_flags_clipped_overflow(tmp_path):
    from lecture import stages
    spec = _spec([_slide()])
    clean_page = _page(tmp_path / 'clean.png', (200, 200, 1400, 700))
    clipped_page = _page(tmp_path / 'clipped.png', (200, 200, 1599, 700))
    clean = stages.visual_stage(spec, _result(), pages=[clean_page])
    assert clean['ok'] is True and clean['errors'] == []
    clipped = stages.visual_stage(spec, _result(), pages=[clipped_page])
    assert clipped['ok'] is False
    assert any('clipped' in e for e in clipped['errors'])


def test_visual_stage_flags_blank_page(tmp_path):
    from lecture import stages
    blank = _page(tmp_path / 'blank.png', None)
    report = stages.visual_stage(_spec([_slide()]), _result(), pages=[blank])
    assert report['ok'] is False
    assert any('blank' in e for e in report['errors'])


def test_visual_stage_skips_without_pages():
    from lecture import stages
    report = stages.visual_stage(_spec([_slide()]), _result(), pages=None)
    assert report['skipped'] is True and report['ok'] is True
    assert 'reviewer' in (report['reason'] or '')


# ------------------------------ merged report ------------------------------

def test_check_deck_merges_stage_findings():
    from qa_check import check_deck
    spec = _spec([_slide(['TODO: вставить данные'])])
    report = check_deck(spec, _result())
    assert report['ok'] is False
    assert any(e.startswith('[content]') for e in report['errors'])
    assert report['stages']['content']['ok'] is False


def test_overflow_is_caught_by_the_visual_stage_not_the_structure(tmp_path):
    from qa_check import check_deck
    spec = _spec([_slide()])
    result = _result()          # records carry no overflow information at all
    clipped_page = _page(tmp_path / 'clipped.png', (0, 200, 1400, 700))
    report = check_deck(spec, result, pages=[clipped_page])
    assert any(e.startswith('[visual]') and 'clipped' in e for e in report['errors'])
    assert not any('overflow' in e and not e.startswith('[visual]')
                   for e in report['errors'])


def test_build_stage_reports_catch_seeded_content_defect(tmp_path):
    """A seeded placeholder must fail the build and land in the content report."""
    import json
    from build_lecture import build
    payload = {'meta': {'title': 'Этапы QA', 'lang': 'ru'},
               'slides': [{'type': 'bullets', 'header': 'План',
                           'items': ['Первый пункт', 'TODO: вставить данные'],
                           'note': NOTE}]}
    spec_path = tmp_path / 'lecture.json'
    spec_path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    res = build(spec_path, tmp_path / 'lecture.pptx', qa=True)
    assert res['ok'] is False
    assert any(e.startswith('[content]') for e in res['qa']['errors'])
    text = (tmp_path / 'lecture_service' / 'qa_content.md').read_text(encoding='utf-8')
    assert 'placeholder' in text and 'TODO' in text
    assert res['qa']['stages']['file']['ok'] is True
