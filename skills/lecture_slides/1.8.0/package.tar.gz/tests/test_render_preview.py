"""Unit tests for render_preview: discovery helpers and export policy."""

from __future__ import annotations

from pathlib import Path

import pytest

import render_preview


# ─────────────────────────── discovery ───────────────────────────

def test_find_soffice_absolute_or_none():
    path = render_preview.find_soffice()
    assert path is None or Path(path).is_absolute()


def test_find_pdf_to_png_known_values():
    tool = render_preview.find_pdf_to_png()
    assert tool in (None, 'pymupdf', 'fitz', 'pdftoppm')


# ─────────────────────────── policy branches ───────────────────────────

def test_render_missing_file(tmp_path):
    res = render_preview.render(tmp_path / 'nope.pptx')
    assert res['ok'] is False
    assert res['pdf'] is None and res['png'] is False
    assert any('not found' in e for e in res['errors'])


def test_render_without_soffice_warns(tmp_path, monkeypatch):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    monkeypatch.setattr(render_preview, 'find_soffice', lambda: None)
    res = render_preview.render(pptx, pdf=True)
    assert res['ok'] is False and res['pdf'] is None
    assert any('LibreOffice' in w for w in res['warnings'])


def test_render_png_without_rasterizer_is_honest(tmp_path, monkeypatch):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    monkeypatch.setattr(render_preview, 'find_pdf_to_png', lambda: None)
    res = render_preview.render(pptx, pdf=False, png=True)
    assert res['png'] is False
    assert res['png_tool'] is None
    assert any('rasterizer' in w for w in res['warnings'])


def test_render_png_needs_the_pdf(tmp_path, monkeypatch):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    monkeypatch.setattr(render_preview, 'find_pdf_to_png', lambda: 'pdftoppm')
    res = render_preview.render(pptx, pdf=False, png=True)
    assert res['png'] is False
    assert any('needs the PDF' in w for w in res['warnings'])


def test_render_nothing_requested_warns(tmp_path):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    res = render_preview.render(pptx, pdf=False, png=False)
    assert res['ok'] is False
    assert any('nothing to export' in w for w in res['warnings'])


# ─────────────────────────── real export ───────────────────────────

needs_soffice = pytest.mark.skipif(render_preview.find_soffice() is None,
                                   reason='LibreOffice is not installed')
needs_rasterizer = pytest.mark.skipif(render_preview.find_pdf_to_png() is None,
                                      reason='no PDF rasterizer available')


@needs_soffice
def test_render_pdf_from_built_deck(tmp_path, demo_spec_path):
    from build_lecture import build
    out = tmp_path / 'deck.pptx'
    assert build(demo_spec_path, out, qa=False)['ok']
    res = render_preview.render(out, pdf=True)
    assert res['ok'] is True
    pdf = Path(res['pdf'])
    assert pdf.exists() and pdf.parent == tmp_path
    assert pdf.read_bytes()[:5] == b'%PDF-'


@needs_soffice
@needs_rasterizer
def test_render_png_pages(tmp_path, demo_spec_path):
    from build_lecture import build
    out = tmp_path / 'deck.pptx'
    build(demo_spec_path, out, qa=False)
    res = render_preview.render(out, pdf=True, png=True)
    assert res['ok'] is True
    assert isinstance(res['png'], list) and len(res['png']) >= 14
    preview_dir = tmp_path / 'deck_service' / 'preview'
    for page in res['png']:
        assert Path(page).exists()
        assert Path(page).parent == preview_dir
    # PDF is a delivery artifact: it stays next to the deck.
    assert Path(res['pdf']).parent == tmp_path


# ─────────────────────────── CLI ───────────────────────────

def test_cli_missing_file_exit_2(tmp_path):
    assert render_preview.main([str(tmp_path / 'nope.pptx')]) == 2


def test_cli_no_export_exit_2(tmp_path):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    assert render_preview.main([str(pptx), '--no-pdf']) == 2


@needs_soffice
def test_cli_export_exit_0(tmp_path, demo_spec_path):
    from build_lecture import build
    out = tmp_path / 'cli.pptx'
    build(demo_spec_path, out, qa=False)
    assert render_preview.main([str(out)]) == 0
    assert (tmp_path / 'cli.pdf').exists()


# ─────────────────────────── contact sheet ───────────────────────────

def _write_pdf(path, pages=3):
    """Create a small PDF via PyMuPDF; False when the tool is unavailable."""
    tool = render_preview.find_pdf_to_png()
    if tool not in ('pymupdf', 'fitz'):
        return False
    try:
        import pymupdf as fitz
    except ImportError:
        import fitz
    doc = fitz.open()
    for index in range(pages):
        page = doc.new_page()
        page.insert_text((72, 72), 'Page %d' % (index + 1))
    doc.save(str(path))
    doc.close()
    return True


def test_contact_sheet_missing_pdf(tmp_path):
    sheet, error = render_preview.make_contact_sheet(tmp_path / 'nope.pdf')
    assert sheet is None
    assert 'not found' in error


def test_contact_sheet_without_rasterizer(tmp_path, monkeypatch):
    pdf = tmp_path / 'deck.pdf'
    pdf.write_bytes(b'%PDF-1.4')
    monkeypatch.setattr(render_preview, 'find_pdf_to_png', lambda: None)
    sheet, error = render_preview.make_contact_sheet(pdf)
    assert sheet is None
    assert 'rasterizer' in error


def test_contact_sheet_grid_from_pdf(tmp_path):
    pdf = tmp_path / 'deck.pdf'
    if not _write_pdf(pdf, pages=5):
        pytest.skip('PyMuPDF is not installed')
    sheet, error = render_preview.make_contact_sheet(pdf, cols=2, dpi=40)
    assert error is None
    from PIL import Image
    sheet_path = Path(sheet)
    assert sheet_path.name == 'contact_sheet.png'
    assert sheet_path.parent.name == 'preview'
    assert sheet_path.parent.parent.name == 'deck_service'
    with Image.open(sheet_path) as img:
        assert img.height > img.width  # 2 columns x 3 rows
        assert img.width > 100 and img.height > 100


def test_contact_sheet_flat_layout(tmp_path):
    """``service_dir=False`` keeps the older ``<stem>_preview/`` folder."""
    pdf = tmp_path / 'deck.pdf'
    if not _write_pdf(pdf, pages=2):
        pytest.skip('PyMuPDF is not installed')
    sheet, error = render_preview.make_contact_sheet(pdf, cols=2, dpi=30,
                                                    service_dir=False)
    assert error is None
    sheet_path = Path(sheet)
    assert sheet_path.parent.name == 'deck_preview'
    assert not (tmp_path / 'deck_service').exists()


def test_render_contact_sheet_without_rasterizer_warns(tmp_path, monkeypatch):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    monkeypatch.setattr(render_preview, 'find_pdf_to_png', lambda: None)
    res = render_preview.render(pptx, pdf=True, contact_sheet=True)
    assert res['contact_sheet'] is None
    assert any('contact sheet skipped' in w for w in res['warnings'])


def test_render_contact_sheet_needs_the_pdf(tmp_path, monkeypatch):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    monkeypatch.setattr(render_preview, 'find_soffice', lambda: None)
    monkeypatch.setattr(render_preview, 'find_pdf_to_png', lambda: 'pdftoppm')
    res = render_preview.render(pptx, pdf=True, contact_sheet=True)
    assert res['contact_sheet'] is None
    assert any('needs the PDF' in w for w in res['warnings'])


@needs_soffice
@needs_rasterizer
def test_render_contact_sheet_from_built_deck(tmp_path, demo_spec_path):
    from build_lecture import build
    out = tmp_path / 'deck.pptx'
    assert build(demo_spec_path, out, qa=False)['ok']
    res = render_preview.render(out, pdf=True, contact_sheet=True, sheet_cols=3)
    assert res['ok'] is True
    assert res['contact_sheet'] and Path(res['contact_sheet']).exists()


def test_cli_contact_sheet_reports_sheet(tmp_path, monkeypatch, capsys):
    pptx = tmp_path / 'deck.pptx'
    pptx.write_bytes(b'PK')
    monkeypatch.setattr(render_preview, 'find_pdf_to_png', lambda: None)
    code = render_preview.main([str(pptx), '--no-pdf', '--contact-sheet'])
    assert code == 2
    assert 'sheet:' in capsys.readouterr().out
