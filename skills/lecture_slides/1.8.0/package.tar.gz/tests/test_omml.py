"""Tests for editable OMML formulas.

The default formula mode embeds Office Math (`a14:m` / `m:oMathPara` /
`m:oMath`) into the slide text body, so formulas stay editable in
PowerPoint; the raster mode (`meta.formula_mode: "image"`) keeps the old
300-dpi PNG path, and a formula the OMML converter cannot express falls
back to that raster path with a warning.

Written BEFORE the feature existed: on the the earlier code there was no
``lecture.omml`` module at all, so every test here failed with
ImportError/feature mismatch.
"""

from __future__ import annotations

import zipfile
from pathlib import Path

import pytest
from pptx import Presentation

from lecture import build_deck, omml, validate_spec
from lecture.omml import M_NS, OmmlError, latex_to_omml, omml_paragraph, validate_omml

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества проверки материала лекции.')
FRACTION = 'x_{n+1} = x_n - \\frac{f(x_n)}{f^{\\prime}(x_n)}'


def _tag(name):
    return '{%s}%s' % (M_NS, name)


def _text(element):
    """Concatenated text of every ``m:t`` under the element."""
    return ''.join(node.text or '' for node in element.iter(_tag('t')))


def _spec(formula, theme='academic_blue', **meta):
    meta.setdefault('course', 'Курс')
    meta.setdefault('title', 'Формулы')
    meta.setdefault('lang', 'ru')
    meta.setdefault('theme', theme)
    return validate_spec({'meta': meta, 'slides': [
        {'type': 'formula', 'header': 'Формула', 'formula': formula,
         'caption': 'где x - значение признака.', 'note': NOTE},
    ]})


def _build(spec, path):
    result = build_deck(spec, out_path=path, assets_dir=path.parent / 'assets')
    assert result['ok'] is True, result['errors']
    return result


def _slide_xml(path):
    with zipfile.ZipFile(path) as archive:
        return archive.read('ppt/slides/slide1.xml').decode('utf-8')


# ------------------------------- converter -------------------------------

def test_fraction_builds_m_fraction():
    element = latex_to_omml('\\frac{a}{b}')
    fraction = element.find(_tag('f'))
    assert fraction is not None
    assert _text(fraction.find(_tag('num'))) == 'a'
    assert _text(fraction.find(_tag('den'))) == 'b'


def test_superscript_builds_m_s_sup():
    element = latex_to_omml('x^2')
    sup = element.find(_tag('sSup'))
    assert sup is not None
    assert _text(sup.find(_tag('e'))) == 'x'
    assert _text(sup.find(_tag('sup'))) == '2'


def test_subscript_builds_m_s_sub():
    element = latex_to_omml('x_n')
    sub = element.find(_tag('sSub'))
    assert sub is not None
    assert _text(sub.find(_tag('sub'))) == 'n'


def test_sub_and_sup_combined():
    element = latex_to_omml('x_n^2')
    both = element.find(_tag('sSubSup'))
    assert both is not None
    assert _text(both.find(_tag('sub'))) == 'n'
    assert _text(both.find(_tag('sup'))) == '2'


def test_sqrt_builds_m_radical():
    element = latex_to_omml('\\sqrt{x+1}')
    radical = element.find(_tag('rad'))
    assert radical is not None
    assert _text(radical.find(_tag('e'))) == 'x+1'


def test_sqrt_with_index_keeps_degree():
    radical = latex_to_omml('\\sqrt[3]{x}').find(_tag('rad'))
    assert _text(radical.find(_tag('deg'))) == '3'
    assert _text(radical.find(_tag('e'))) == 'x'


def test_overline_builds_m_bar():
    bar = latex_to_omml('\\overline{x}').find(_tag('bar'))
    assert bar is not None
    assert _text(bar.find(_tag('e'))) == 'x'


def test_accent_builds_m_acc():
    acc = latex_to_omml('\\vec{v}').find(_tag('acc'))
    assert acc is not None
    assert _text(acc.find(_tag('e'))) == 'v'


def test_sum_builds_nary_with_limits():
    nary = latex_to_omml('\\sum_{i=1}^{n} x_i').find(_tag('nary'))
    assert nary is not None
    assert _text(nary.find(_tag('sub'))) == 'i=1'
    assert _text(nary.find(_tag('sup'))) == 'n'


def test_integral_builds_nary():
    nary = latex_to_omml('\\int_a^b f(x)').find(_tag('nary'))
    assert nary is not None
    assert _text(nary.find(_tag('e'))) == 'f(x)' 


def test_left_right_builds_m_delimiter():
    delim = latex_to_omml('\\left( x \\right)').find(_tag('d'))
    assert delim is not None
    props = delim.find(_tag('dPr'))
    assert props.find(_tag('begChr')).get(_tag('val')) == '('
    assert props.find(_tag('endChr')).get(_tag('val')) == ')'


def test_greek_letters_and_symbols():
    element = latex_to_omml('\\alpha \\leq \\beta \\cdot \\infty')
    assert _text(element) == 'α≤β⋅∞'


def test_unknown_command_raises():
    with pytest.raises(OmmlError) as exc:
        latex_to_omml('\\unknownmacro{x}')
    assert 'unknownmacro' in str(exc.value)


def test_begin_environment_raises():
    with pytest.raises(OmmlError) as exc:
        latex_to_omml('\\begin{cases} x & x>0 \\\\ -x & x<0 \\end{cases}')
    assert 'begin' in str(exc.value)


def test_unbalanced_group_raises():
    with pytest.raises(OmmlError):
        latex_to_omml('\\frac{a}{b')


def test_text_command_is_not_supported_and_raises():
    with pytest.raises(OmmlError):
        latex_to_omml('\\text{const}')


# -------------------------- structural validation -------------------------- 

def test_validate_omml_accepts_a_built_paragraph():
    element = omml_paragraph(['x^2'], 24.0)
    assert validate_omml(element) == []


def test_validate_omml_flags_a_bare_o_math():
    bare = latex_to_omml('x')
    problems = validate_omml(bare)
    assert problems and any('a14' in message for message in problems)


def test_validate_omml_flags_missing_text():
    element = omml_paragraph(['x'], 24.0)
    for node in element.iter(_tag('t')):
        node.text = ''
    problems = validate_omml(element)
    assert any('empty' in message for message in problems)


def test_omml_paragraph_has_font_size_and_centering():
    element = omml_paragraph(['x'], 24.0)
    assert element.tag == '{%s}m' % omml.A14_NS
    para = element.find(_tag('oMathPara'))
    assert para is not None
    assert para.find(_tag('oMath')) is not None
    run_pr = para.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}rPr')
    assert run_pr.get('sz') == '2400'


# ------------------------------- deck ----------------------------------- 

def test_formula_slide_embeds_omml_by_default(tmp_path):
    spec = _spec(FRACTION)
    out = tmp_path / 'omml.pptx'
    result = _build(spec, out)
    xml = _slide_xml(out)
    assert 'a14:m' in xml and 'oMathPara' in xml and 'm:oMath' in xml
    assert 'sz="2700"' in xml
    boxes = result['records'][0]['boxes']
    assert any(box.get('omml') for box in boxes)
    assert result['assets'] == [], 'OMML mode must not rasterize formulas'


def test_formula_mode_image_keeps_raster_assets(tmp_path):
    spec = _spec(FRACTION, formula_mode='image')
    out = tmp_path / 'image.pptx'
    result = _build(spec, out)
    assert result['assets'] and all(p.endswith('.png') for p in result['assets'])
    assert 'oMath' not in _slide_xml(out)


def test_unsupported_formula_falls_back_to_raster_with_warning(tmp_path):
    spec = _spec('\\text{const} + x')
    out = tmp_path / 'fallback.pptx'
    result = _build(spec, out)
    assert any('fell back to a raster image' in w for w in result['warnings'])
    assert result['assets'] and all(p.endswith('.png') for p in result['assets'])
    assert 'oMath' not in _slide_xml(out)


def test_invalid_formula_mode_warns_and_uses_omml(tmp_path):
    spec = _spec(FRACTION, formula_mode='vector')
    assert any('formula_mode' in w for w in spec.warnings)
    result = _build(spec, tmp_path / 'wrong.pptx')
    assert result['formula_modes']['omml'] == 1
    assert result['formula_modes']['image'] == 0


def test_meta_formula_mode_default_is_omml():
    spec = _spec('x^2')
    assert spec.meta.get('formula_mode') == 'omml'


# ───────────────── service folder for helper files ─────────────────

def test_raster_assets_default_to_the_service_folder(tmp_path):
    """Without an explicit ``assets_dir`` formula rasters go to
    ``<stem>_service/assets/`` so the deck folder keeps only artifacts."""
    spec = _spec(FRACTION, formula_mode='image')
    out = tmp_path / 'serviced.pptx'
    result = build_deck(spec, out_path=out)
    assert result['ok'] is True, result['errors']
    assert result['assets'], 'image mode must rasterize the formula'
    expected = tmp_path / 'serviced_service' / 'assets'
    for asset in result['assets']:
        assert Path(asset).parent == expected, asset
    assert not (tmp_path / 'serviced_assets').exists()


def test_service_dir_false_restores_the_flat_layout(tmp_path):
    """``service_dir=False`` keeps the pre-1.5 ``<stem>_assets/`` layout."""
    spec = _spec(FRACTION, formula_mode='image')
    out = tmp_path / 'flat.pptx'
    result = build_deck(spec, out_path=out, service_dir=False)
    assert result['ok'] is True, result['errors']
    expected = tmp_path / 'flat_assets'
    for asset in result['assets']:
        assert Path(asset).parent == expected, asset
    assert not (tmp_path / 'flat_service').exists()


def test_formula_keeps_numbering_in_omml_mode(tmp_path):
    spec = validate_spec({
        'meta': {'course': 'К', 'title': 'Т', 'lang': 'ru'},
        'slides': [{'type': 'formula', 'header': 'Ф', 'formula': 'x^2',
                    'numbered': True, 'note': NOTE}],
    })
    out = tmp_path / 'numbered.pptx'
    _build(spec, out)
    prs = Presentation(str(out))
    joined = ' '.join(shape.text_frame.text for shape in prs.slides[0].shapes
                      if shape.has_text_frame)
    assert '(1)' in joined


def test_demo_build_has_no_formula_png(demo_build):
    spec, result, pptx = demo_build
    assert result['assets'] == []
    assert result['formula_modes']['omml'] >= 4
    prs = Presentation(str(pptx))
    assert len(prs.slides) == 14


# --------------------------------- QA ------------------------------------ 

def test_qa_report_records_formula_mode(tmp_path):
    from qa_check import check_deck, report_markdown
    spec = _spec(FRACTION)
    result = _build(spec, tmp_path / 'qa.pptx')
    report = check_deck(spec, result)
    assert report['formula_mode'] == 'omml'
    assert report['formula_modes'] == {'omml': 1, 'image': 0}
    text = report_markdown(report, spec=spec)
    assert 'Formula mode' in text


def test_qa_flags_omml_structure_problems(tmp_path):
    from qa_check import check_deck
    spec = _spec('x^2')
    result = _build(spec, tmp_path / 'qa2.pptx')
    for box in result['records'][0]['boxes']:
        if box.get('omml'):
            box['omml_problems'] = ['broken structure']
    report = check_deck(spec, result)
    assert any('formula structure' in w for w in report['warnings'])
