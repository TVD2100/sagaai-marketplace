"""Tests for evidence binding: the QA report is tied to artifact hashes.

Every report carries the SHA-256 of the PPTX it examined (``artifact_sha256``)
and the fingerprint of the skill sources that produced it
(``skill_fingerprint``). ``qa_check.verify_report(report, path)`` re-reads the
artifact and declares the report stale (structurally unusable, not merely
"outdated") as soon as the bytes change; an untouched artifact keeps the
report valid. A report without a recorded hash is refused explicitly.

These tests were written BEFORE the feature existed and failed on the
the earlier code: the report had no artifact hash, ``verify_report`` and
``lecture.fingerprint`` did not exist, and nothing tied a build to the
version of the skill that produced it.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import qa_check
from build_lecture import build
from lecture import fingerprint


# ---------------------------- helpers ----------------------------

def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _build_demo(tmp_path, demo_spec_path):
    out = tmp_path / 'demo.pptx'
    res = build(demo_spec_path, out, qa=True, qa_json=True)
    assert res['ok'] is True, res['errors']
    return out, res


# ---------------------------- artifact binding ----------------------------

def test_build_report_carries_artifact_hash(tmp_path, demo_spec_path):
    out, res = _build_demo(tmp_path, demo_spec_path)
    assert res['qa']['artifact_sha256'] == _sha256(out)
    payload = json.loads((tmp_path / 'demo_service' / 'qa.json').read_text(encoding='utf-8'))
    assert payload['artifact_sha256'] == _sha256(out)


def test_qa_markdown_shows_artifact_hash(tmp_path, demo_spec_path):
    out, res = _build_demo(tmp_path, demo_spec_path)
    text = (tmp_path / 'demo_service' / 'qa.md').read_text(encoding='utf-8')
    assert res['qa']['artifact_sha256'] in text


def test_verify_report_accepts_untouched_artifact(tmp_path, demo_spec_path):
    out, res = _build_demo(tmp_path, demo_spec_path)
    verdict = qa_check.verify_report(res['qa'], out)
    assert verdict['valid'] is True


def test_verify_report_rejects_edited_artifact(tmp_path, demo_spec_path):
    out, res = _build_demo(tmp_path, demo_spec_path)
    with open(out, 'ab') as handle:          # any byte change invalidates the PASS
        handle.write(b'x')
    verdict = qa_check.verify_report(res['qa'], out)
    assert verdict['valid'] is False
    assert verdict['expected'] == res['qa']['artifact_sha256']
    assert verdict['actual'] == _sha256(out)
    assert verdict['expected'] != verdict['actual']


def test_verify_report_refuses_missing_hash(tmp_path, demo_spec_path):
    out, res = _build_demo(tmp_path, demo_spec_path)
    report = dict(res['qa'])
    report.pop('artifact_sha256', None)
    verdict = qa_check.verify_report(report, out)
    assert verdict['valid'] is False
    assert 'no artifact hash' in verdict['reason']


def test_verify_report_missing_file(tmp_path):
    verdict = qa_check.verify_report({'artifact_sha256': 'abc'}, tmp_path / 'nope.pptx')
    assert verdict['valid'] is False
    assert 'not found' in verdict['reason']


def test_qa_cli_binds_artifact(tmp_path, demo_spec_path):
    report_path = tmp_path / 'qa.json'
    code = qa_check.main([str(demo_spec_path), '--report', str(report_path), '--json'])
    assert code == 0
    payload = json.loads(report_path.with_suffix('.json').read_text(encoding='utf-8'))
    assert len(payload['artifact_sha256']) == 64


# ---------------------------- skill fingerprint ----------------------------

def test_skill_fingerprint_is_a_full_sha256():
    value = fingerprint.source_fingerprint()
    assert isinstance(value, str)
    assert len(value) == 64
    int(value, 16)


def test_skill_fingerprint_is_stable():
    assert fingerprint.source_fingerprint() == fingerprint.source_fingerprint()


def test_fingerprint_covers_the_runtime_sources():
    names = {path.name for path in fingerprint.source_files()}
    for expected in ('build_lecture.py', 'qa_check.py', 'deck.py', 'slides.py',
                     'textfit.py', 'spec.py'):
        assert expected in names, expected


def test_build_result_carries_skill_fingerprint(tmp_path, demo_spec_path):
    out, res = _build_demo(tmp_path, demo_spec_path)
    assert res['skill_fingerprint'] == fingerprint.source_fingerprint()
    assert res['qa']['skill_fingerprint'] == res['skill_fingerprint']
    text = (tmp_path / 'demo_service' / 'qa.md').read_text(encoding='utf-8')
    assert res['skill_fingerprint'] in text


def test_fingerprint_changes_when_a_source_changes(tmp_path, monkeypatch):
    original = fingerprint.source_fingerprint()
    file_path = Path(fingerprint.source_files()[0])
    monkeypatch.setattr(fingerprint, 'source_files',
                        lambda root=None: [file_path, tmp_path / 'extra.py'])
    (tmp_path / 'extra.py').write_text('x = 1\n', encoding='utf-8')
    assert fingerprint.source_fingerprint() != original
