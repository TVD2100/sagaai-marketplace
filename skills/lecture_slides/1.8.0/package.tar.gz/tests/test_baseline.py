"""Tests for baseline-deck regression checks.

``lecture.baseline`` extracts the dominant heading of every slide and
compares a new deck against a previous one supplied through ``meta.baseline``:
headings present in the baseline but gone in the candidate become QA
warnings (failing only under ``strict``). Section numbers (60 pt digits) must
not be mistaken for headings, and matching is whitespace/case-insensitive
with containment tolerance ("Введение" matches "Введение в анализ").

These tests were written BEFORE the feature existed and failed on the pre-
code: ``lecture.baseline`` did not exist, ``meta.baseline`` was an unknown
meta key and the QA report carried no baseline comparison.
"""

from __future__ import annotations

import qa_check
from pptx import Presentation

from lecture import baseline, build_deck, validate_spec

NOTE = ('Заметка достаточной длины для прохождения минимального порога '
        'качества проверки материала на этой лекции.')


def _bullets(header, items=('Первый пункт', 'Второй пункт', 'Третий пункт')):
    return {'type': 'bullets', 'header': header, 'items': list(items), 'note': NOTE}


def _spec(slides, path=None, **meta):
    meta.setdefault('title', 'Baseline')
    return validate_spec({'meta': meta, 'slides': slides}, path=path)


def _build(spec, path):
    result = build_deck(spec, out_path=path)
    assert result['ok'] is True, result['errors']
    return result


def _titles(path):
    presentation = Presentation(str(path))
    return [baseline.slide_title(slide) for slide in presentation.slides]


# ---------------------------- heading extraction ----------------------------

def test_slide_titles_pick_the_dominant_text(tmp_path):
    spec = _spec([
        {'type': 'title', 'note': NOTE},
        _bullets('План лекции'),
        {'type': 'section', 'number': 1, 'header': 'Введение', 'note': NOTE},
    ])
    _build(spec, tmp_path / 'deck.pptx')
    titles = _titles(tmp_path / 'deck.pptx')
    assert titles[0] == 'Baseline'
    assert titles[1] == 'План лекции'
    assert titles[2] == 'Введение'  # the 60 pt section number must not win


def test_deck_titles_covers_every_slide(tmp_path):
    spec = _spec([_bullets('Альфа'), _bullets('Бета')])
    _build(spec, tmp_path / 'two.pptx')
    assert len(baseline.deck_titles(tmp_path / 'two.pptx')) == 2


# ---------------------------- comparison ----------------------------

def test_compare_decks_reports_missing_heading(tmp_path):
    _build(_spec([_bullets('Альфа'), _bullets('Бета'), _bullets('Гамма')]),
           tmp_path / 'baseline.pptx')
    _build(_spec([_bullets('Альфа'), _bullets('Гамма')]),
           tmp_path / 'candidate.pptx')
    comparison = baseline.compare_decks(tmp_path / 'baseline.pptx',
                                        tmp_path / 'candidate.pptx')
    assert comparison['ok'] is False
    assert comparison['missing'] == ['Бета']
    assert comparison['added'] == []
    assert comparison['baseline_slides'] == 3
    assert comparison['candidate_slides'] == 2


def test_compare_decks_ok_when_headings_survive(tmp_path):
    _build(_spec([_bullets('Введение в анализ'), _bullets('Итоги')]),
           tmp_path / 'baseline.pptx')
    _build(_spec([_bullets('Введение'), _bullets('Итоги'), _bullets('Приложение')]),
           tmp_path / 'candidate.pptx')
    comparison = baseline.compare_decks(tmp_path / 'baseline.pptx',
                                        tmp_path / 'candidate.pptx')
    assert comparison['ok'] is True
    assert comparison['missing'] == []
    assert comparison['added'] == ['Приложение']


# ---------------------------- QA wiring ----------------------------

def test_qa_reports_baseline_comparison(tmp_path):
    _build(_spec([_bullets('Альфа'), _bullets('Бета')]), tmp_path / 'baseline.pptx')
    cand_spec = _spec([_bullets('Альфа')], path=tmp_path / 'lecture.json',
                      baseline='baseline.pptx')
    cand_result = _build(cand_spec, tmp_path / 'candidate.pptx')
    report = qa_check.check_deck(cand_spec, cand_result)
    assert report['baseline']['missing'] == ['Бета']
    assert report['baseline']['ok'] is False
    assert any('Бета' in warning for warning in report['warnings'])
    assert report['ok'] is True  # a missing heading is a warning in normal mode


def test_qa_baseline_strict_mode_fails(tmp_path):
    _build(_spec([_bullets('Альфа'), _bullets('Бета')]), tmp_path / 'baseline.pptx')
    cand_spec = _spec([_bullets('Альфа')], path=tmp_path / 'lecture.json',
                      baseline='baseline.pptx')
    cand_result = _build(cand_spec, tmp_path / 'candidate.pptx')
    report = qa_check.check_deck(cand_spec, cand_result, strict=True)
    assert report['ok'] is False
    assert report['baseline']['missing'] == ['Бета']


def test_qa_baseline_missing_file_warns_only(tmp_path):
    spec = _spec([_bullets('Альфа')], path=tmp_path / 'lecture.json',
                 baseline='ghost.pptx')
    result = _build(spec, tmp_path / 'candidate.pptx')
    report = qa_check.check_deck(spec, result)
    assert report['baseline']['missing'] == []
    assert any('not found' in warning for warning in report['baseline']['warnings'])
    assert report['ok'] is True


def test_qa_without_baseline_key_skips(tmp_path):
    spec = _spec([_bullets('Альфа')])
    result = _build(spec, tmp_path / 'deck.pptx')
    report = qa_check.check_deck(spec, result)
    assert report['baseline'] is None


# ---------------------------- spec validation ----------------------------

def test_meta_baseline_accepted_as_path_string():
    spec = _spec([_bullets('Альфа')], baseline='old.pptx')
    assert spec.meta['baseline'] == 'old.pptx'
    assert not any('baseline' in warning for warning in spec.warnings)


def test_meta_baseline_non_string_is_dropped():
    spec = _spec([_bullets('Альфа')], baseline=42)
    assert 'baseline' not in spec.meta
    assert any('baseline' in warning for warning in spec.warnings)
