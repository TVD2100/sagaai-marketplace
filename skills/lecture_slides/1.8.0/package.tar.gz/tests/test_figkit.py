"""Tests for lecture.figkit - the self-auditing figure layout kit.

Covered: palette construction from deck themes, measured text fitting,
the three audit channels of Canvas.save() (text out of its box, out of the
canvas margin, overlapping elements), border-ink detection on the saved
bitmap and the audit of hand-made matplotlib charts (audit_fig).
"""

from __future__ import annotations

import pytest

from lecture import figkit
from lecture.figkit import Canvas, audit_fig, check_border, palette, text_width


def test_palette_matches_theme():
    """Palette keys mirror the deck theme and add figure-specific accents."""
    colors = palette('deep_green')
    assert colors['accent'] == '#1E6B45'
    assert colors['bg'] == '#FFFFFF'
    assert colors['soft'] == colors['accent_soft']
    for key in ('green', 'orange', 'red', 'violet', 'white'):
        assert colors[key].startswith('#')
    assert palette('no_such_theme') == palette('academic_blue')


def test_text_width_scales_with_size():
    """Measured width grows with the font size and is positive."""
    small = text_width('Проверка ширины', 'r', 10)
    large = text_width('Проверка ширины', 'r', 20)
    assert 0 < small < large


def test_clean_canvas_has_no_problems(tmp_path):
    """A well-fitted card with text inside reports no problems."""
    canvas = Canvas(4.0, 3.0)
    canvas.rect(0.08, 0.08, 0.84, 0.84, fc=canvas.colors['card'], ec=canvas.colors['rule'])
    canvas.boxtext(0.10, 0.10, 0.80, 0.80, 'Короткая подпись', fs=12)
    problems = canvas.save(tmp_path / 'clean.png')
    assert problems == []
    assert (tmp_path / 'clean.png').exists()


def test_text_outside_bounds_is_reported(tmp_path):
    """A text block that cannot fit its declared box records a problem."""
    canvas = Canvas(4.0, 3.0)
    canvas.multiline(0.5, 0.5, ['Длинная строка, которая явно не поместится'], 16,
                     bounds=(0.45, 0.45, 0.02, 0.02))
    problems = canvas.save(tmp_path / 'overflow.png')
    assert any('overflows box' in problem for problem in problems)


def test_overlapping_labels_are_reported(tmp_path):
    """Two labels drawn on top of each other are flagged as overlapping."""
    canvas = Canvas(4.0, 3.0)
    canvas.label(0.5, 0.5, 'Первая подпись', fs=14)
    canvas.label(0.502, 0.5, 'Вторая подпись', fs=14)
    problems = canvas.save(tmp_path / 'overlap.png')
    assert any('overlap' in problem for problem in problems)


def test_boxtext_shrinks_to_fit():
    """Long text in a small plate is fitted by reducing the font size."""
    canvas = Canvas(4.0, 3.0)
    size = canvas.boxtext(0.1, 0.1, 0.25, 0.15, 'Большой объём текста для маленькой плашки', fs=16)
    assert 7.0 <= size < 16.0


def test_border_ink_detected(tmp_path):
    """A dark fill touching the canvas edge is caught by the bitmap scan."""
    canvas = Canvas(4.0, 3.0)
    canvas.rect(0, 0, 1, 1, fc=canvas.colors['ink'])
    problems = canvas.save(tmp_path / 'dark.png')
    assert any('border ink' in problem for problem in problems)


def test_check_border_clean_and_dirty(tmp_path):
    """check_border: None for a blank bitmap, a message otherwise."""
    from PIL import Image

    clean = tmp_path / 'white.png'
    Image.new('RGB', (80, 60), (255, 255, 255)).save(clean)
    assert check_border(clean) is None

    dirty = tmp_path / 'dirty.png'
    image = Image.new('RGB', (80, 60), (255, 255, 255))
    for x in range(80):
        image.putpixel((x, 0), (0, 0, 0))
    image.save(dirty)
    assert 'border ink' in check_border(dirty)


def test_audit_fig_only_checks_tagged_texts():
    """audit_fig reports overlaps of gid='annot' texts and skips others."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(4, 3))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    first = ax.text(0.5, 0.5, 'A', fontsize=20)
    second = ax.text(0.51, 0.5, 'B', fontsize=20)
    untagged = ax.text(0.5, 0.5, 'C', fontsize=20)
    assert audit_fig(fig) == []          # nothing is tagged yet
    first.set_gid('annot')
    second.set_gid('annot')
    untagged.set_gid('plain')
    problems = audit_fig(fig)
    plt.close(fig)
    assert any('overlap' in problem for problem in problems)


def test_audit_fig_clean_when_separated():
    """Well-separated tagged texts produce no findings."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(4, 3))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    for x, text in ((0.15, 'Первый'), (0.5, 'Второй'), (0.85, 'Третий')):
        artist = ax.text(x, 0.5, text, fontsize=12)
        artist.set_gid('annot')
    assert audit_fig(fig) == []
    plt.close(fig)


def test_font_roles_are_mapped():
    """Every documented short font key resolves to a textfit role."""
    assert set(figkit.FONT_ROLES) == {'r', 'b', 'g', 'gb', 'm', 'mb'}
    for key, role in figkit.FONT_ROLES.items():
        assert role in ('arial', 'arial_bold', 'georgia', 'georgia_bold',
                        'courier', 'courier_bold')
