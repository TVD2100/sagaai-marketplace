"""Unit tests for lecture.spec: validation, warnings, labels, markup."""

from __future__ import annotations

import json

import pytest

from lecture import SpecError, load_spec, validate_spec
from lecture.spec import as_lines, split_markup, strip_markup


# ─────────────────────────── loading ───────────────────────────

def _write(tmp_path, payload):
    path = tmp_path / 'spec.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    return path


def _minimal(**meta_overrides):
    meta = {'course': 'Test', 'title': 'T', 'lang': 'ru', 'theme': 'academic_blue'}
    meta.update(meta_overrides)
    return {'meta': meta, 'slides': [{'type': 'title', 'note': 'Заметка к титульному слайду, достаточная по длине.'}]}


def test_load_spec_minimal(tmp_path):
    spec = load_spec(_write(tmp_path, _minimal()))
    assert spec.title == 'T'
    assert spec.lang == 'ru'
    assert spec.theme == 'academic_blue'
    assert len(spec.slides) == 1
    assert spec.slides[0]['type'] == 'title'
    assert spec.base_dir == tmp_path


def test_load_spec_missing_file(tmp_path):
    with pytest.raises(SpecError) as exc:
        load_spec(tmp_path / 'nope.json')
    assert 'not found' in str(exc.value)


def test_load_spec_invalid_json(tmp_path):
    path = tmp_path / 'bad.json'
    path.write_text('{not json', encoding='utf-8')
    with pytest.raises(SpecError) as exc:
        load_spec(path)
    assert 'invalid JSON' in str(exc.value)


def test_defaults_applied():
    spec = validate_spec({'slides': [{'type': 'title', 'note': 'x'}]})
    assert spec.lang == 'ru'
    assert spec.theme == 'academic_blue'
    assert spec.duration_min == 0


def test_empty_spec_errors():
    with pytest.raises(SpecError):
        validate_spec({'slides': []})


def test_unknown_slide_type():
    with pytest.raises(SpecError) as exc:
        validate_spec({'slides': [{'type': 'webinar', 'note': 'x'}]})
    assert 'unknown slide type' in str(exc.value)


def test_unknown_keys_warn_not_raise():
    spec = validate_spec({
        'meta': {'title': 'T', 'mystery': 1},
        'slides': [{'type': 'title', 'note': 'x'}],
        'extra_top': True,
    })
    joined = ' '.join(spec.warnings)
    assert 'mystery' in joined
    assert 'extra_top' in joined


# ─────────────────────── per-type validation ───────────────────────

def test_bullets_require_items():
    with pytest.raises(SpecError) as exc:
        validate_spec({'slides': [{'type': 'bullets', 'note': 'x'}]})
    assert "missing required field 'items'" in str(exc.value)


def test_bullets_empty_item_rejected():
    with pytest.raises(SpecError):
        validate_spec({'slides': [{'type': 'bullets', 'items': ['ok', '   '], 'note': 'x'}]})


def test_definition_normalizes_text_to_list():
    spec = validate_spec({'slides': [{
        'type': 'definition', 'term': 'Term', 'text': 'single string', 'note': 'x'}]})
    assert spec.slides[0]['text'] == ['single string']


def test_code_joins_lines_and_lowercases_language():
    spec = validate_spec({'slides': [{
        'type': 'code', 'language': 'PY', 'code': ['a = 1', 'b = 2'], 'note': 'x'}]})
    slide = spec.slides[0]
    assert slide['code'] == 'a = 1\nb = 2'
    assert slide['language'] == 'py'


def test_code_rejects_non_string_language():
    with pytest.raises(SpecError):
        validate_spec({'slides': [{'type': 'code', 'language': 1, 'code': 'x', 'note': 'n'}]})


def test_table_row_width_mismatch():
    with pytest.raises(SpecError) as exc:
        validate_spec({'slides': [{
            'type': 'table', 'columns': ['a', 'b'], 'rows': [['1', '2'], ['3']], 'note': 'x'}]})
    assert 'row 2 has 1 cells, expected 2' in str(exc.value)


def test_table_bad_col_widths_warn_and_drop():
    spec = validate_spec({'slides': [{
        'type': 'table', 'columns': ['a', 'b'], 'rows': [['1', '2']],
        'col_widths': [1], 'note': 'x'}]})
    assert 'col_widths' not in spec.slides[0]
    assert any('col_widths' in w for w in spec.warnings)


def test_two_column_split_clamped():
    spec = validate_spec({'slides': [{
        'type': 'two_column', 'split': 0.95, 'note': 'x',
        'left': {'kind': 'bullets', 'items': ['a']},
        'right': {'kind': 'paragraphs', 'text': 'b'}}]})
    assert spec.slides[0]['split'] == 0.8
    assert any('split' in w for w in spec.warnings)


def test_two_column_unknown_block_kind():
    with pytest.raises(SpecError) as exc:
        validate_spec({'slides': [{
            'type': 'two_column', 'note': 'x',
            'left': {'kind': 'video'}, 'right': {'kind': 'bullets', 'items': ['a']}}]})
    assert 'unknown block kind' in str(exc.value)


def test_section_accepts_title_as_header():
    spec = validate_spec({'slides': [{'type': 'section', 'title': 'Part I', 'note': 'x'}]})
    assert spec.slides[0]['header'] == 'Part I'


def test_formula_numbered_coerced_to_bool():
    spec = validate_spec({'slides': [{'type': 'formula', 'formula': 'x^2', 'numbered': 1, 'note': 'x'}]})
    assert spec.slides[0]['numbered'] is True


# ───────────────────────── localization ─────────────────────────

def test_labels_russian_default():
    spec = validate_spec({'slides': [{'type': 'title', 'note': 'x'}]})
    assert spec.label('definition') == 'Определение'
    assert spec.label('lecture', no=7) == 'Лекция 7'
    assert spec.label('page', current=2, total=9) == '2 / 9'


def test_labels_english():
    spec = validate_spec({'meta': {'lang': 'en'},
                          'slides': [{'type': 'title', 'note': 'x'}]})
    assert spec.label('definition') == 'Definition'
    assert spec.label('lecture', no=3) == 'Lecture 3'


def test_label_overrides_win():
    spec = validate_spec({'meta': {'lang': 'ru', 'labels': {'definition': 'Дефиниция'}},
                          'slides': [{'type': 'title', 'note': 'x'}]})
    assert spec.label('definition') == 'Дефиниция'


def test_unknown_lang_warns_and_falls_back():
    spec = validate_spec({'meta': {'lang': 'de'}, 'slides': [{'type': 'title', 'note': 'x'}]})
    assert spec.lang == 'ru'
    assert any('de' in w for w in spec.warnings)


def test_missing_label_format_keys_keeps_template():
    spec = validate_spec({'slides': [{'type': 'title', 'note': 'x'}]})
    assert spec.label('lecture') == 'Лекция {no}'


# ─────────────────────────── markup ───────────────────────────

def test_split_markup_flags():
    spans = split_markup('plain **bold** *it* `code`')
    flags = {text: dict(flag) for text, flag in spans}
    assert flags['bold'] == {'bold': True}
    assert flags['it'] == {'italic': True}
    assert flags['code'] == {'mono': True}
    assert flags['plain '] == {}


def test_strip_markup_removes_markers():
    assert strip_markup('a **b** *c* `d`') == 'a b c d'


def test_split_markup_empty_text():
    assert split_markup('') == [('', {})]


def test_as_lines_normalizes():
    assert as_lines(None) == []
    assert as_lines('x') == ['x']
    assert as_lines(['a', None, 'b']) == ['a', 'b']
    assert as_lines(5) == ['5']
