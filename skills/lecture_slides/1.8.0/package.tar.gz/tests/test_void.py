"""Tests for the empty-bottom QA check (check_void).

The visual audit of the course decks measured the distance between the
lowest content element and the footer hairline: 21 of 56 slides of one
lesson kept 1.0-3.2 in empty. The density metric (``min_fill``) could not
see the defect: a tall empty frame still counts as some ink. ``check_void``
measures the recorded ``content_bottom`` of every box (the bottom of the
drawn content, not of the frame) and warns when more than ``max_void_in``
inches stay empty above the content frame bottom.

Airy-by-design types (cover, section, centered display formula, timeline
spine) are exempt with a recorded reason, never silently skipped.

Written BEFORE the feature existed: on the the earlier code ``check_void`` and
``max_void_in`` were unknown spec keys, ``_void_in`` did not exist and no
warning could be produced, so every test below failed.
"""

from __future__ import annotations

import pytest

import qa_check
from lecture import build_deck, themes, validate_spec

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')

BODY_BOTTOM = themes.SLIDE_H - themes.MARGIN_BOTTOM

SLIDE = [{'type': 'bullets', 'header': 'План', 'items': ['Первый пункт плана'],
          'note': NOTE}]


# ─────────────────────────── helpers ───────────────────────────

def _spec(slides, qa=None):
    payload = {'meta': {'title': 'Void QA', 'lang': 'ru'}, 'slides': slides}
    if qa is not None:
        payload['qa'] = qa
    return validate_spec(payload)


def _rec(index=1, stype='bullets', boxes=None, empty=False):
    return {'index': index, 'type': stype, 'note_words': 50, 'bullets': 0,
            'code_lines': 0, 'boxes': list(boxes or []), 'empty': empty}


def _box(content_bottom=None, need_h=None, y=1.5, h=3.0, kind='text'):
    box = {'kind': kind, 'x': 1.0, 'y': y, 'w': 6.0, 'h': h}
    if content_bottom is not None:
        box['content_bottom'] = content_bottom
    if need_h is not None:
        box['need_h'] = need_h
    return box


def _result(records):
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': 5.0}


def _void_warnings(report):
    return [w for w in report['warnings'] if 'empty space under the content' in w]


def _build(spec, tmp_path, name):
    out = tmp_path / (name + '.pptx')
    result = build_deck(spec, out_path=out, assets_dir=tmp_path / (name + '_assets'))
    assert result['ok'] is True, result['errors']
    return result


# ─────────────────────────── metric ───────────────────────────

def test_void_in_uses_the_recorded_content_bottom():
    rec = _rec(boxes=[_box(content_bottom=3.5)])
    assert qa_check._void_in(rec) == pytest.approx(BODY_BOTTOM - 3.5)


def test_void_in_falls_back_to_the_needed_height():
    rec = _rec(boxes=[_box(need_h=2.0, y=1.0, h=5.0)])
    assert qa_check._void_in(rec) == pytest.approx(BODY_BOTTOM - 3.0)


def test_void_in_ignores_slot_markers_and_missing_geometry():
    marker = _box(content_bottom=6.0, kind='slot_marker')
    assert qa_check._void_in(_rec(boxes=[marker])) is None
    assert qa_check._void_in(_rec()) is None


# ─────────────────────────── measured defect ───────────────────────────

def test_deep_empty_bottom_warns():
    rec = _rec(boxes=[_box(content_bottom=3.5)])
    report = qa_check.check_deck(_spec(SLIDE), _result([rec]))
    warnings = _void_warnings(report)
    assert warnings and 'slide 1 (bullets)' in warnings[0]
    assert '3.30' in warnings[0]


def test_void_within_threshold_is_quiet():
    rec = _rec(boxes=[_box(content_bottom=BODY_BOTTOM - 1.0)])
    report = qa_check.check_deck(_spec(SLIDE), _result([rec]))
    assert report['ok'] is True
    assert _void_warnings(report) == []


def test_threshold_is_configurable():
    rec = _rec(boxes=[_box(content_bottom=BODY_BOTTOM - 1.0)])
    spec = _spec(SLIDE, qa={'max_void_in': 0.5})
    report = qa_check.check_deck(spec, _result([rec]))
    assert report['settings']['max_void_in'] == 0.5
    assert _void_warnings(report)


def test_check_void_can_be_disabled():
    rec = _rec(boxes=[_box(content_bottom=3.5)])
    spec = _spec(SLIDE, qa={'check_void': False})
    report = qa_check.check_deck(spec, _result([rec]))
    assert report['settings']['check_void'] is False
    assert _void_warnings(report) == []


# ─────────────────────────── exemptions ───────────────────────────

def test_title_section_formula_and_timeline_are_exempt():
    slides = [
        {'type': 'title', 'note': NOTE},
        {'type': 'section', 'header': 'Часть 1', 'note': NOTE},
        {'type': 'formula', 'header': 'Формула', 'formula': 'x^2 = 4', 'note': NOTE},
        {'type': 'timeline', 'header': 'Этапы', 'note': NOTE,
         'items': [{'label': '2021', 'text': 'Первый этап проекта.'}]},
    ]
    records = [_rec(1, 'title', [_box(content_bottom=3.5)]),
               _rec(2, 'section', [_box(content_bottom=3.5)]),
               _rec(3, 'formula', [_box(content_bottom=3.5)]),
               _rec(4, 'timeline', [_box(content_bottom=3.5)])]
    report = qa_check.check_deck(_spec(slides), _result(records))
    assert _void_warnings(report) == []
    rows = {row['index']: row for row in report['slide_rows']}
    for index in (1, 2, 3, 4):
        reason = rows[index]['void_exempt']
        assert reason and 'airy' in reason, (index, reason)


def test_slide_rows_carry_void_values():
    rec = _rec(boxes=[_box(content_bottom=5.0)])
    report = qa_check.check_deck(_spec(SLIDE), _result([rec]))
    rows = report['slide_rows']
    assert rows[0]['void'] == pytest.approx(BODY_BOTTOM - 5.0)
    assert rows[0]['void_exempt'] is None


# ─────────────────────────── end to end ───────────────────────────

def test_built_definition_slide_leaves_no_deep_void(tmp_path):
    slides = [{'type': 'definition', 'header': 'Термины',
               'term': 'Мультиагентная система',
               'text': ['Первое пояснение определения.', 'Второе пояснение.'],
               'note': NOTE}]
    spec = _spec(slides)
    result = _build(spec, tmp_path, 'definition')
    report = qa_check.check_deck(spec, result)
    assert _void_warnings(report) == []
    assert report['slide_rows'][0]['void'] <= 1.2
    text = qa_check.report_markdown(report, spec=spec)
    assert '## Voids' in text
    assert 'slide 1 (definition)' in text


def test_built_short_two_column_lists_warn_about_the_void(tmp_path):
    slides = [{'type': 'two_column', 'header': 'Половины',
               'left': {'kind': 'bullets', 'items': ['Один пункт']},
               'right': {'kind': 'paragraphs', 'text': 'Короткий абзац.'},
               'note': NOTE}]
    spec = _spec(slides)
    result = _build(spec, tmp_path, 'twocol')
    report = qa_check.check_deck(spec, result)
    assert _void_warnings(report)
