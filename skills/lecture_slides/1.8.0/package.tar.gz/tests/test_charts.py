"""Tests for native chart slides.

A ``chart`` slide - or a ``chart`` block inside ``two_column`` - renders a
real PowerPoint chart through ``shapes.add_chart``: an editable chart object
whose data workbook travels inside the .pptx. The tests read the deck back:
chart type enum, categories, series names and values, the embedded ``.xlsx``
part, and the QA verdict.

Written BEFORE the feature existed: ``chart`` was an unknown slide type on
the the earlier code, so every test here failed.
"""

from __future__ import annotations

import zipfile

import pytest
from pptx import Presentation
from pptx.enum.chart import XL_CHART_TYPE

from lecture import build_deck
from lecture.spec import SpecError, validate_spec

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества проверки материала диаграммы.')

EXPECTED_TYPES = {
    'bar': XL_CHART_TYPE.COLUMN_CLUSTERED,
    'line': XL_CHART_TYPE.LINE_MARKERS,
    'pie': XL_CHART_TYPE.PIE,
}


def _chart_slide(chart_type='bar'):
    return {
        'type': 'chart',
        'header': 'Динамика показателя',
        'chart_type': chart_type,
        'categories': ['2019', '2020', '2021'],
        'series': [{'name': 'Выручка', 'values': [4.2, 5.1, 6.4]}],
        'caption': 'Источник: внутренние данные.',
        'note': NOTE,
    }


def _spec(slides, theme='academic_blue', **meta):
    meta.setdefault('course', 'Курс')
    meta.setdefault('title', 'Диаграммы')
    meta.setdefault('lang', 'ru')
    meta.setdefault('theme', theme)
    return validate_spec({'meta': meta, 'slides': slides})


def _build(spec, path):
    result = build_deck(spec, out_path=path, assets_dir=path.parent / 'assets')
    assert result['ok'] is True, result['errors']
    return result


def _charts(path):
    prs = Presentation(str(path))
    return [shape.chart for shape in prs.slides[0].shapes
            if getattr(shape, 'has_chart', False)]


# ---------------------------- spec validation ----------------------------

def test_chart_type_defaults_to_bar():
    slide = _chart_slide()
    del slide['chart_type']
    spec = _spec([slide])
    assert spec.slides[0]['chart_type'] == 'bar'


def test_chart_values_normalized_to_floats():
    slide = _chart_slide()
    slide['series'] = [{'name': 'Продажи', 'values': [10, 20, 30]}]
    spec = _spec([slide])
    assert spec.slides[0]['series'][0]['values'] == [10.0, 20.0, 30.0]


def test_unknown_chart_type_raises():
    with pytest.raises(SpecError) as exc:
        _spec([_chart_slide('donut')])
    assert "'chart_type' must be one of" in str(exc.value)


def test_chart_requires_categories_and_series():
    slide = _chart_slide()
    del slide['categories']
    del slide['series']
    with pytest.raises(SpecError) as exc:
        _spec([slide])
    message = str(exc.value)
    assert "missing required field 'categories'" in message
    assert "missing required field 'series'" in message


def test_series_length_must_match_categories():
    slide = _chart_slide()
    slide['series'] = [{'name': 'Выручка', 'values': [1.0, 2.0]}]
    with pytest.raises(SpecError) as exc:
        _spec([slide])
    assert '2 values, expected 3' in str(exc.value)


def test_series_values_must_be_numbers():
    slide = _chart_slide()
    slide['series'] = [{'name': 'Выручка', 'values': [1.0, 'много', 3.0]}]
    with pytest.raises(SpecError) as exc:
        _spec([slide])
    assert 'values must be finite numbers' in str(exc.value)


def test_pie_rejects_multiple_series():
    slide = _chart_slide('pie')
    slide['series'] = [
        {'name': 'Первый', 'values': [1.0, 2.0, 3.0]},
        {'name': 'Второй', 'values': [3.0, 2.0, 1.0]},
    ]
    with pytest.raises(SpecError) as exc:
        _spec([slide])
    assert 'pie chart supports exactly one series' in str(exc.value)


def test_pie_negative_values_warn():
    slide = _chart_slide('pie')
    slide['series'] = [{'name': 'Доли', 'values': [-1.0, 2.0, 3.0]}]
    spec = _spec([slide])
    assert any('negative values' in warning for warning in spec.warnings)


def test_series_unknown_key_warns():
    slide = _chart_slide()
    slide['series'] = [{'name': 'Выручка', 'values': [1.0, 2.0, 3.0], 'color': 'red'}]
    spec = _spec([slide])
    assert any("unknown key 'color' in series 1" in w for w in spec.warnings)


# ------------------------------ pptx readback -----------------------------

@pytest.mark.parametrize('chart_type', sorted(EXPECTED_TYPES))
def test_chart_types_render_native_charts(tmp_path, chart_type):
    spec = _spec([_chart_slide(chart_type)])
    out = tmp_path / (chart_type + '.pptx')
    result = _build(spec, out)
    charts = _charts(out)
    assert len(charts) == 1
    chart = charts[0]
    assert chart.chart_type == EXPECTED_TYPES[chart_type]
    plot = chart.plots[0]
    assert list(plot.categories) == ['2019', '2020', '2021']
    series = plot.series[0]
    assert series.name == 'Выручка'
    assert list(series.values) == pytest.approx([4.2, 5.1, 6.4])
    boxes = result['records'][0]['boxes']
    assert any(box['kind'] == 'chart' for box in boxes)
    with zipfile.ZipFile(out) as archive:
        embedded = [name for name in archive.namelist()
                    if name.startswith('ppt/embeddings/') and name.endswith('.xlsx')]
    assert embedded, 'no embedded data workbook in the pptx'


def test_chart_caption_rendered(tmp_path):
    spec = _spec([_chart_slide()])
    out = tmp_path / 'caption.pptx'
    _build(spec, out)
    prs = Presentation(str(out))
    texts = ' '.join(shape.text_frame.text for shape in prs.slides[0].shapes
                     if shape.has_text_frame)
    assert 'внутренние данные' in texts


def test_series_without_name_gets_localized_default(tmp_path):
    slide = _chart_slide()
    slide['series'] = [{'values': [4.2, 5.1, 6.4]}]
    spec = _spec([slide])
    out = tmp_path / 'noname.pptx'
    _build(spec, out)
    series = _charts(out)[0].plots[0].series[0]
    assert series.name == 'Ряд 1'


def test_chart_block_inside_two_column(tmp_path):
    spec = _spec([{
        'type': 'two_column', 'header': 'Показатели', 'split': 0.6,
        'left': {'kind': 'chart', 'categories': ['A', 'B'],
                 'series': [{'name': 'Ряд', 'values': [1.0, 2.0]}]},
        'right': {'kind': 'bullets', 'items': ['Первый пункт', 'Второй пункт']},
        'note': NOTE,
    }])
    out = tmp_path / 'block.pptx'
    _build(spec, out)
    assert list(_charts(out)[0].plots[0].categories) == ['A', 'B']


# --------------------------------- QA ------------------------------------

def test_chart_slide_passes_qa(tmp_path):
    from qa_check import check_deck
    spec = _spec([_chart_slide()])
    result = _build(spec, tmp_path / 'qa.pptx')
    report = check_deck(spec, result)
    assert report['errors'] == [], report['errors']
    assert not any('sparse' in warning for warning in report['warnings'])


def test_chart_without_source_warns_when_registry_present(tmp_path):
    from qa_check import check_deck
    sources = [{'id': 'src1', 'title': 'Отчёт',
                'url': 'https://example.com/report'}]
    spec = _spec([_chart_slide()], sources=sources)
    result = _build(spec, tmp_path / 'fact.pptx')
    report = check_deck(spec, result)
    assert any('chart data without a source' in w for w in report['warnings'])
    referenced = dict(_chart_slide(), source_refs=['src1'])
    spec2 = _spec([referenced], sources=sources)
    result2 = _build(spec2, tmp_path / 'fact2.pptx')
    report2 = check_deck(spec2, result2)
    assert not any('chart data without a source' in w for w in report2['warnings'])


@pytest.mark.parametrize('chart_type', sorted(EXPECTED_TYPES))
def test_chart_builds_in_alternate_theme(tmp_path, chart_type):
    spec = _spec([_chart_slide(chart_type)], theme='graphite')
    out = tmp_path / ('%s_graphite.pptx' % chart_type)
    result = _build(spec, out)
    assert result['slides'] == 1
    assert not result['records'][0]['empty']
