"""Tests for the layout advisor: short bullet lists suggest a visual type.

The advisor is the counterweight of the three visual types: without it the
author keeps writing ``bullets`` slides with three or four short points,
which is exactly the shape that leaves the lower part of the frame empty.

On the 1.4.x code the module did not exist, so every test failed with an
import error; the assertions below describe the intended advice.
"""

from __future__ import annotations

from lecture import layout_advisor
from lecture.layout_advisor import (apply_auto_layout, build_replacement,
                                    suggest_layout)
from lecture.spec import validate_spec

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')


def _slide(**fields):
    """A bullets slide with sensible defaults."""
    slide = {'type': 'bullets', 'header': 'Заголовок'}
    slide.update(fields)
    return slide


def test_single_short_point_suggests_focus():
    """One short point cannot fill the frame: a focus slide fits it."""
    advice = suggest_layout(_slide(items=['Один короткий тезис']))
    assert advice is not None
    assert advice['suggested_type'] == 'focus'
    assert advice['replacement']['statement'] == 'Один короткий тезис'


def test_two_points_suggest_focus_with_one_support():
    """Two points: statement plus a single support block."""
    advice = suggest_layout(_slide(items=['Главный тезис', 'Опора к тезису']))
    assert advice['suggested_type'] == 'focus'
    assert advice['replacement']['statement'] == 'Главный тезис'
    assert advice['replacement']['supports'] == ['Опора к тезису']


def test_four_short_points_suggest_steps_grid():
    """Four short parallel points map onto a tile grid."""
    items = ['Первый пункт', 'Второй пункт', 'Третий пункт', 'Четвёртый пункт']
    advice = suggest_layout(_slide(items=items))
    assert advice['suggested_type'] == 'steps_grid'
    assert [item['text'] for item in advice['replacement']['items']] == items


def test_titled_components_suggest_pillars():
    """Items that carry their own title read as full-height columns."""
    items = [{'title': 'Реклама', 'text': 'Платное обращение'},
             {'title': 'PR', 'text': 'Репутация'},
             {'title': 'Личные продажи', 'text': 'Прямой контакт'}]
    advice = suggest_layout(_slide(items=items))
    assert advice['suggested_type'] == 'pillars'
    assert [item['title'] for item in advice['replacement']['items']] == [
        'Реклама', 'PR', 'Личные продажи']


def test_long_points_keep_the_bullet_list():
    """Full sentences are real prose: the advisor must not touch them."""
    items = ['Длинное пояснение, которое занимает несколько строк и раскрывает '
             'причину, следствие и ограничение подхода',
             'Второе столь же длинное пояснение с примером из практики']
    assert suggest_layout(_slide(items=items)) is None


def test_seven_short_points_keep_the_bullet_list():
    """Above six points a list is the right shape (or a table)."""
    items = ['Пункт %d' % index for index in range(1, 8)]
    assert suggest_layout(_slide(items=items)) is None


def test_non_bullet_types_are_never_advised():
    """Only ``bullets`` is rewritten; summary and homework stay lists."""
    for stype in ('summary', 'homework', 'cards'):
        assert suggest_layout({'type': stype, 'items': ['Один пункт']}) is None


def test_replacement_keeps_note_caption_and_refs():
    """The advice only changes the layout fields, never the author's text."""
    slide = _slide(items=['Тезис'], note=NOTE, caption='Подпись',
                   source_refs=['src1'])
    replacement = build_replacement(slide, 'focus')
    assert replacement['note'] == NOTE
    assert replacement['caption'] == 'Подпись'
    assert replacement['source_refs'] == ['src1']


def test_auto_layout_rewrites_flagged_slides_only():
    """``meta.auto_layout`` rewrites the flagged slides and reports them."""
    spec = validate_spec({'meta': {'title': 'Курс', 'lang': 'ru',
                                   'auto_layout': True},
                          'slides': [
                              {'type': 'title', 'title': 'Тема'},
                              {'type': 'bullets', 'header': 'Один',
                               'items': ['Короткий тезис'], 'note': NOTE},
                              {'type': 'bullets', 'header': 'Длинные',
                               'items': ['Полное предложение с пояснением, '
                                         'которое явно длиннее одной плитки и '
                                         'потому остаётся списком'],
                               'note': NOTE},
                          ]})
    changes = apply_auto_layout(spec)
    assert len(changes) == 1, changes
    assert changes[0]['index'] == 2
    assert changes[0]['from'] == 'bullets'
    assert changes[0]['to'] == 'focus'
    assert spec.slides[1]['type'] == 'focus'
    assert spec.slides[2]['type'] == 'bullets'


def test_auto_layout_off_by_default():
    """Without ``meta.auto_layout`` the builder leaves bullets untouched."""
    from lecture import build_deck

    spec = validate_spec({'meta': {'title': 'Курс', 'lang': 'ru'},
                          'slides': [{'type': 'bullets', 'header': 'Один',
                                      'items': ['Короткий тезис'], 'note': NOTE}]})
    result = build_deck(spec)
    assert result['auto_layout'] == []
    assert [rec['type'] for rec in result['records']] == ['bullets']


def test_builder_applies_auto_layout_when_enabled():
    """With ``meta.auto_layout`` the builder rewrites and reports the slides."""
    from lecture import build_deck

    spec = validate_spec({'meta': {'title': 'Курс', 'lang': 'ru',
                                   'auto_layout': True},
                          'slides': [{'type': 'bullets', 'header': 'Один',
                                      'items': ['Короткий тезис'], 'note': NOTE}]})
    result = build_deck(spec)
    assert [rec['type'] for rec in result['records']] == ['focus']
    assert result['auto_layout'][0]['to'] == 'focus'
    assert any('auto-layout' in message for message in result['warnings'])


def test_qa_warns_about_a_short_bullet_list():
    """Without the flag QA reports the advice as a warning, never an error."""
    import qa_check

    from lecture import build_deck

    spec = validate_spec({'meta': {'title': 'Курс', 'lang': 'ru'},
                          'slides': [{'type': 'bullets', 'header': 'Один',
                                      'items': ['Короткий тезис'], 'note': NOTE}]})
    report = qa_check.check_deck(spec, build_deck(spec))
    assert report['errors'] == [], report['errors']
    advice = [w for w in report['warnings'] if 'suggested type' in w]
    assert len(advice) == 1, report['warnings']
    assert "'focus'" in advice[0]


def test_qa_advice_can_be_disabled():
    """``qa.check_layout_advice: false`` silences the advice warning."""
    import qa_check

    from lecture import build_deck

    spec = validate_spec({'meta': {'title': 'Курс', 'lang': 'ru'},
                          'qa': {'check_layout_advice': False},
                          'slides': [{'type': 'bullets', 'header': 'Один',
                                      'items': ['Короткий тезис'], 'note': NOTE}]})
    report = qa_check.check_deck(spec, build_deck(spec))
    assert not [w for w in report['warnings'] if 'suggested type' in w]
