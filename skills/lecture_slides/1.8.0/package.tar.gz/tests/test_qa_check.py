"""Unit tests for qa_check: check_deck rules, report_markdown, CLI policy."""

from __future__ import annotations

import json

import pytest

import qa_check
from lecture import validate_spec


# ─────────────────────────── helpers ───────────────────────────

def _spec(**meta):
    payload = {'meta': dict(meta) if meta else {'title': 'QA Test'},
               'slides': [{'type': 'title', 'note': 'x'}]}
    if 'qa' in payload['meta']:
        payload['qa'] = payload['meta'].pop('qa')
    return validate_spec(payload)


def _box(kind='text', x=1.0, y=1.0, w=6.0, h=2.0, need_h=None, font_pt=None, error=None):
    box = {'kind': kind, 'x': x, 'y': y, 'w': w, 'h': h}
    if need_h is not None:
        box['need_h'] = need_h
    if font_pt is not None:
        box['font_pt'] = font_pt
    if error is not None:
        box['error'] = error
    return box


def _rec(index=1, stype='bullets', note_words=50, bullets=4, code_lines=0, boxes=None, empty=False):
    return {
        'index': index, 'type': stype, 'note_words': note_words,
        'bullets': bullets, 'code_lines': code_lines,
        'boxes': list(boxes if boxes is not None else []),
        'empty': empty,
    }


def _result(records, **extra):
    base = {
        'ok': True, 'records': records, 'errors': [], 'warnings': [],
        'note_words': sum(r['note_words'] for r in records),
        'duration_est_min': 5.0,
    }
    base.update(extra)
    return base


# ─────────────────────────── notes ───────────────────────────

def test_clean_result_passes():
    report = qa_check.check_deck(_spec(), _result([_rec()]))
    assert report['ok'] is True
    assert report['errors'] == []
    assert report['slides'] == 1


def test_missing_notes_is_error():
    report = qa_check.check_deck(_spec(), _result([_rec(note_words=0)]))
    assert not report['ok']
    assert any('speaker notes missing' in e for e in report['errors'])


def test_short_notes_is_error():
    report = qa_check.check_deck(_spec(), _result([_rec(note_words=5)]))
    assert any('too short (5 words, min 12)' in e for e in report['errors'])


def test_long_notes_is_warning_not_error():
    report = qa_check.check_deck(_spec(), _result([_rec(note_words=300)]))
    assert report['ok'] is True
    assert any('too long (300 words, max 260)' in w for w in report['warnings'])


def test_min_note_words_override():
    spec = validate_spec({'meta': {'title': 'T'}, 'qa': {'min_note_words': 3},
                          'slides': [{'type': 'title', 'note': 'x'}]})
    report = qa_check.check_deck(spec, _result([_rec(note_words=5)]))
    assert report['ok'] is True
    assert report['settings']['min_note_words'] == 3


# ─────────────────────────── structural ───────────────────────────

def test_empty_slide_is_error():
    report = qa_check.check_deck(_spec(), _result([_rec(empty=True)]))
    assert any('no content drawn' in e for e in report['errors'])


def test_build_errors_become_qa_errors():
    report = qa_check.check_deck(_spec(), _result([_rec()], errors=['image not found: x.png']))
    assert not report['ok']
    assert 'image not found: x.png' in report['errors']


def test_build_warnings_become_qa_warnings():
    report = qa_check.check_deck(_spec(), _result([_rec()], warnings=['meta: unknown key'] ))
    assert report['ok'] is True
    assert 'meta: unknown key' in report['warnings']


def test_bullets_over_limit_is_warning():
    report = qa_check.check_deck(_spec(), _result([_rec(bullets=8)]))
    assert report['ok'] is True
    assert any('8 list items (max 6)' in w for w in report['warnings'])


def test_code_lines_over_limit_is_error():
    report = qa_check.check_deck(_spec(), _result([_rec(code_lines=30)]))
    assert any('code listing has 30 lines (max 22)' in e for e in report['errors'])


# ─────────────────────────── boxes ───────────────────────────

def test_error_box_is_error():
    box = _box(error='ParseFatalException')
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert any('text content failed to render' in e for e in report['errors'])


def test_overflow_box_beyond_slack_is_error():
    box = _box(h=2.0, need_h=3.0)
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert any('overflows its box' in e for e in report['errors'])


def test_overflow_within_slack_is_clean():
    box = _box(h=2.0, need_h=2.1)   # 8% of 2.0 = 0.16 slack
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert report['ok'] is True
    assert not any('overflows' in e for e in report['errors'])


def test_font_below_minimum_is_error():
    box = _box(font_pt=12.0)
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert any('body font 12.0 pt below the minimum 16.0 pt' in e for e in report['errors'])


def test_font_caption_not_checked():
    box = _box(kind='caption', font_pt=11.0)
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert not any('body font' in e for e in report['errors'])


def test_box_outside_margins_is_error():
    box = _box(x=-0.2, y=1.0, w=6.0, h=2.0)
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert any('outside the safe margins' in e for e in report['errors'])


def test_tight_margin_is_warning():
    # right edge: 13.333 - (x + w) = 0.3 -> below the 0.45 default
    box = _box(x=1.0, y=1.0, w=12.033, h=2.0)
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert report['ok'] is True
    assert any('tight right margin' in w for w in report['warnings'])


def test_cover_kind_skips_margin_checks():
    box = _box(kind='cover', x=0.0, y=0.0, w=13.333, h=7.5)
    report = qa_check.check_deck(_spec(), _result([_rec(boxes=[box])]))
    assert report['ok'] is True


# ─────────────────────────── theme contrast ───────────────────────────

def test_all_stock_themes_meet_contrast():
    from lecture import themes
    for name in themes.theme_names():
        spec = validate_spec({'meta': {'title': 'T', 'theme': name},
                              'slides': [{'type': 'title', 'note': 'x'}]})
        report = qa_check.check_deck(spec, _result([_rec()]))
        assert not any('low text contrast' in w for w in report['warnings']), (name, report['warnings'])


# ─────────────────────────── duration ───────────────────────────

def test_duration_overrun_is_error():
    spec = validate_spec({'meta': {'title': 'T', 'duration_min': 10},
                          'slides': [{'type': 'title', 'note': 'x'}]})
    result = _result([_rec()])
    result['duration_est_min'] = 20.0
    report = qa_check.check_deck(spec, result)
    assert report['ok'] is False
    assert any('overrun' in e for e in report['errors'])


def test_duration_underrun_is_error():
    spec = validate_spec({'meta': {'title': 'T', 'duration_min': 90},
                          'slides': [{'type': 'title', 'note': 'x'}]})
    report = qa_check.check_deck(spec, _result([_rec()]))
    assert report['ok'] is False
    assert any('underrun' in e for e in report['errors'])


# ─────────────────────────── strict mode ───────────────────────────

def test_strict_turns_warnings_into_failure():
    report = qa_check.check_deck(_spec(), _result([_rec(bullets=9)]), strict=True)
    assert report['ok'] is False
    assert report['errors'] == []
    assert report['warnings']


def test_strict_from_spec_qa_block():
    spec = validate_spec({'meta': {'title': 'T'}, 'qa': {'strict': True},
                          'slides': [{'type': 'title', 'note': 'x'}]})
    report = qa_check.check_deck(spec, _result([_rec(bullets=9)]))
    assert report['ok'] is False


def test_invalid_qa_values_fall_back_to_defaults():
    spec = validate_spec({'meta': {'title': 'T'},
                          'qa': {'min_note_words': 'abc', 'max_bullets': None},
                          'slides': [{'type': 'title', 'note': 'x'}]})
    report = qa_check.check_deck(spec, _result([_rec()]))
    assert report['settings']['min_note_words'] == 12
    assert report['settings']['max_bullets'] == 6


# ─────────────────────────── report ───────────────────────────

def test_report_dict_shape():
    report = qa_check.check_deck(_spec(), _result([_rec(index=1), _rec(index=2)]))
    for key in ('ok', 'errors', 'warnings', 'slides', 'note_words',
                'duration_est_min', 'duration_target_min', 'theme',
                'settings', 'slide_rows', 'summary'):
        assert key in report
    assert len(report['slide_rows']) == 2
    assert report['slide_rows'][0]['index'] == 1


def test_report_markdown_sections():
    spec = _spec(title='Метод Ньютона')
    report = qa_check.check_deck(spec, _result([_rec(note_words=0)]))
    text = qa_check.report_markdown(report, spec=spec)
    assert text.startswith('# QA report: Метод Ньютона')
    assert '**FAIL**' in text
    assert '## Errors' in text and 'speaker notes missing' in text
    assert '## Warnings' in text and 'None.' in text
    assert '| # | type | note (words) | list items | code lines |' in text
    assert text.endswith('\n')


def test_report_markdown_pass_status():
    spec = _spec()
    report = qa_check.check_deck(spec, _result([_rec()]))
    text = qa_check.report_markdown(report, spec=spec)
    assert '**PASS**' in text
    assert 'None.' in text


# ─────────────────────────── CLI ───────────────────────────

def test_cli_clean_demo(tmp_path, demo_spec_path):
    report_path = tmp_path / 'qa.md'
    code = qa_check.main([str(demo_spec_path), '--report', str(report_path)])
    assert code == 0
    assert report_path.exists()
    assert '**PASS**' in report_path.read_text(encoding='utf-8')


def test_cli_json_report(tmp_path, demo_spec_path):
    report_path = tmp_path / 'qa.md'
    code = qa_check.main([str(demo_spec_path), '--report', str(report_path), '--json'])
    assert code == 0
    payload = json.loads(report_path.with_suffix('.json').read_text(encoding='utf-8'))
    assert payload['ok'] is True
    assert payload['slides'] == 14


def test_cli_spec_failure_exit_2(tmp_path):
    bad = tmp_path / 'bad.json'
    bad.write_text('{oops', encoding='utf-8')
    assert qa_check.main([str(bad)]) == 2


def test_cli_missing_file_exit_2(tmp_path):
    assert qa_check.main([str(tmp_path / 'nope.json')]) == 2


def test_cli_broken_spec_exit_1(tmp_path):
    spec = {'meta': {'title': 'Broken'},
            'slides': [{'type': 'bullets', 'header': 'H', 'items': ['a'], 'note': 'short'}]}
    path = tmp_path / 'broken.json'
    path.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    report_path = tmp_path / 'broken_qa.md'
    code = qa_check.main([str(path), '--report', str(report_path)])
    assert code == 1
    text = report_path.read_text(encoding='utf-8')
    assert 'speaker notes too short' in text
