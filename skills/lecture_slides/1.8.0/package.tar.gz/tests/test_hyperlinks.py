"""Tests for native hyperlinks: [label](url) markup and literature URLs.

Covered: parse-level behaviour of ``split_markup`` (link spans, inner
bold, unsafe schemes left as plain text, mailto, balanced parentheses) and
the end-to-end path - a built deck is reopened with python-pptx and every
hyperlink relationship is inspected, including the literature slide that
accepts ``{text, url}`` items and the underline applied to linked runs.
"""

from __future__ import annotations

import json

from lecture import is_safe_link, split_markup, strip_markup
from lecture.deck import build_deck
from lecture.spec import load_spec


# ─────────────────────────── helpers ───────────────────────────

NOTE = ('Раскройте слайд по шагам: что изображено, какие выводы следуют '
        'и как это связано с предыдущим материалом лекции.')


def _compact(spans):
    """Readable view of spans for assertions."""
    return [(text, sorted(flags)) for text, flags in spans]


def _lecture_spec(tmp_path, slides, qa=None):
    payload = {
        'meta': {'title': 'Links demo', 'duration_min': 45},
        'slides': [{'type': 'title', 'note': NOTE}] + slides,
    }
    if qa is not None:
        payload['qa'] = qa
    spec_path = tmp_path / 'lecture.json'
    spec_path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    return load_spec(spec_path)


def _hyperlinks(pptx_path):
    """Collect (run text, address, underline) of every linked run."""
    from pptx import Presentation
    found = []
    prs = Presentation(str(pptx_path))
    for slide in prs.slides:
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    address = run.hyperlink.address
                    if address:
                        found.append((run.text, address, bool(run.font.underline)))
    return found


# ─────────────────────────── markup parsing ───────────────────────────

def test_plain_link_parses_into_url_span():
    spans = split_markup('См. [курс](https://example.com/course) дальше')
    assert _compact(spans) == [('См. ', []), ('курс', ['url']),
                               (' дальше', [])]
    assert spans[1][1]['url'] == 'https://example.com/course'


def test_bold_label_inside_link_keeps_both_flags():
    spans = split_markup('[**методичка**](https://example.com/m) тут')
    assert spans[0][0] == 'методичка'
    assert spans[0][1] == {'bold': True, 'url': 'https://example.com/m'}


def test_mailto_link_is_allowed():
    assert is_safe_link('mailto:lecturer@example.com')
    spans = split_markup('[написать](mailto:lecturer@example.com)')
    assert spans[0][1].get('url') == 'mailto:lecturer@example.com'


def test_uppercase_scheme_is_allowed():
    spans = split_markup('[сайт](HTTPS://EXAMPLE.COM)')
    assert spans[0][1].get('url') == 'HTTPS://EXAMPLE.COM'


def test_url_with_balanced_parentheses_parses():
    spans = split_markup('[статья](https://ru.wikipedia.org/wiki/Метод_(наука))')
    assert spans[0][1].get('url') == 'https://ru.wikipedia.org/wiki/Метод_(наука)'


def test_unsafe_scheme_stays_plain_text():
    text = '[клик](javascript:alert(1))'
    spans = split_markup(text)
    assert spans == [(text, {})]
    assert strip_markup(text) == text


def test_strip_markup_removes_link_but_keeps_label():
    assert strip_markup('см. [курс](https://example.com) - там всё') == 'см. курс - там всё'


def test_is_safe_link_rejects_relative_and_unknown():
    for bad in ('ftp://example.com', '//example.com', '/local/file.html',
                'data:text/html,x', ''):
        assert not is_safe_link(bad), bad


# ─────────────────────────── built deck ───────────────────────────

def test_bullets_link_becomes_native_hyperlink(tmp_path):
    spec = _lecture_spec(tmp_path, [
        {'type': 'bullets', 'header': 'Материалы',
         'items': ['Откройте [курс](https://example.com/course) в браузере',
                   'Домашнее задание в [системе](https://example.com/hw)'],
         'note': NOTE},
    ])
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    assert result['ok'] is True
    links = _hyperlinks(tmp_path / 'deck.pptx')
    assert ('курс', 'https://example.com/course', True) in links
    assert ('системе', 'https://example.com/hw', True) in links


def test_literature_item_url_becomes_native_hyperlink(tmp_path):
    spec = _lecture_spec(tmp_path, [
        {'type': 'literature', 'header': 'Литература',
         'items': [{'text': 'Хасти и др. - Введение в статистическое обучение',
                    'url': 'https://example.com/book'},
                   'Блог без ссылки'],
         'note': NOTE},
    ])
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    assert result['ok'] is True
    links = _hyperlinks(tmp_path / 'deck.pptx')
    assert ('Хасти и др. - Введение в статистическое обучение',
            'https://example.com/book', True) in links
    assert all('Блог' not in text for text, _, _ in links)


def test_literature_unsafe_url_renders_as_plain_text(tmp_path):
    spec = _lecture_spec(tmp_path, [
        {'type': 'literature', 'header': 'Литература',
         'items': [{'text': 'Подозрительный источник', 'url': 'javascript:alert(1)'}],
         'note': NOTE},
    ])
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    assert result['ok'] is True
    assert _hyperlinks(tmp_path / 'deck.pptx') == []


def test_unsafe_link_in_bullets_draws_literal_text(tmp_path):
    spec = _lecture_spec(tmp_path, [
        {'type': 'bullets', 'header': 'Ссылки',
         'items': ['Безопасный [вариант](https://example.com) и небезопасный [вариант](javascript:x)'],
         'note': NOTE},
    ])
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    assert result['ok'] is True
    links = _hyperlinks(tmp_path / 'deck.pptx')
    assert len(links) == 1
    assert links[0][1] == 'https://example.com'
