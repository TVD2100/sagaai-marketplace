"""Duration policy tests for the QA pass: underrun is a failure.

Covered: the speaking-time estimate is compared with ``meta.duration_min``
in BOTH directions with a configurable tolerance
(``qa.duration_tolerance``, default 0.35). A deck whose speaker notes are
far too short for the target fails with an actionable 'underrun' message
(both values, the shortfall in percent, the number of words to add); an
ever-long notes set fails with an 'overrun' message; decks inside the
tolerance band stay clean; ``qa.check_duration: false`` disables the rule.

These tests were written BEFORE the rule existed and failed on the pre-
code: the estimate was checked for overrun only, as a warning, and an
underrun was not reported at all (a deck of ~4 min of notes against a
20 min target passed). That failure is the point of the improvement.
"""

from __future__ import annotations

import json

import qa_check
from build_lecture import build
from lecture.spec import validate_spec

# 17 words: above the default min_note_words (12) for every slide.
NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')


# ─────────────────────────── helpers ───────────────────────────

def _spec(duration=0, qa=None):
    """Validate a minimal spec with the given duration target and qa block."""
    payload = {'meta': {'title': 'Duration QA', 'lang': 'ru',
                        'duration_min': duration},
               'slides': [{'type': 'title', 'note': NOTE}]}
    if qa is not None:
        payload['qa'] = qa
    return validate_spec(payload)


def _rec(index=1):
    return {'index': index, 'type': 'bullets', 'note_words': 50, 'bullets': 0,
            'code_lines': 0, 'boxes': [], 'empty': False}


def _result(est):
    """Result stub with a controlled speaking-time estimate (minutes)."""
    records = [_rec(1)]
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': est}


def _messages(report, keyword):
    return ' | '.join(e for e in report['errors'] if keyword in e)


# ─────────────────────────── underrun ───────────────────────────

def test_underrun_is_error():
    report = qa_check.check_deck(_spec(20), _result(4.0))
    assert report['ok'] is False
    assert any('underrun' in e for e in report['errors'])


def test_underrun_message_is_actionable():
    report = qa_check.check_deck(_spec(20), _result(4.0))
    message = _messages(report, 'underrun')
    # both quantities are named
    assert '4.0' in message and '20 min target' in message
    # the shortfall is quantified
    assert '80% short' in message
    # and the fix is concrete: words to add
    assert 'add about' in message and 'words' in message


def test_underrun_inside_tolerance_is_clean():
    spec = _spec(20)
    for est in (14.0, 26.0):
        report = qa_check.check_deck(spec, _result(est))
        assert report['ok'] is True, (est, report['errors'])
        assert report['errors'] == []


def test_tolerance_boundaries():
    spec = _spec(20)          # tolerance 0.35 -> band [13.0, 27.0]
    for est, expected in ((13.0, True), (27.0, True),
                          (12.9, False), (27.1, False)):
        report = qa_check.check_deck(spec, _result(est))
        assert (report['ok'] is expected), (est, report['errors'])


def test_tolerance_is_configurable():
    spec = _spec(20, qa={'duration_tolerance': 0.6})
    assert qa_check.check_deck(spec, _result(10.0))['ok'] is True
    under = qa_check.check_deck(spec, _result(7.9))
    assert under['ok'] is False
    assert any('underrun' in e for e in under['errors'])
    assert under['settings']['duration_tolerance'] == 0.6


def test_check_duration_can_be_disabled():
    spec = _spec(20, qa={'check_duration': False})
    report = qa_check.check_deck(spec, _result(1.0))
    assert report['ok'] is True
    assert report['errors'] == []
    assert report['settings']['check_duration'] is False


def test_zero_duration_is_not_checked():
    report = qa_check.check_deck(_spec(0), _result(1.0))
    assert report['errors'] == []


# ─────────────────────────── overrun (kept, now symmetric) ───────────

def test_overrun_is_error():
    report = qa_check.check_deck(_spec(20), _result(30.0))
    assert report['ok'] is False
    assert any('overrun' in e for e in report['errors'])


def test_overrun_message_suggests_trim():
    report = qa_check.check_deck(_spec(20), _result(30.0))
    message = _messages(report, 'overrun')
    assert '30.0' in message and '20 min target' in message
    assert '50% over' in message
    assert 'trim about' in message and 'words' in message


# ─────────────────────────── settings plumbing ───────────────────────

def test_settings_types_resolved():
    spec = _spec(20, qa={'duration_tolerance': '0.5', 'check_duration': True})
    report = qa_check.check_deck(spec, _result(10.0))
    assert report['settings']['duration_tolerance'] == 0.5
    assert report['settings']['check_duration'] is True


def test_new_qa_keys_accepted_by_spec():
    spec = _spec(20, qa={'check_duration': True, 'duration_tolerance': 0.4})
    assert not any('unknown key' in w for w in spec.warnings)


# ─────────────────────────── end to end ───────────────────────────

def test_build_flags_underrun_end_to_end(tmp_path):
    """A real build with ~0.3 min of notes against a 20 min target fails QA."""
    payload = {
        'meta': {'title': 'Underrun', 'duration_min': 20, 'lang': 'ru'},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'План', 'items': ['Первый шаг', 'Второй шаг'],
             'note': NOTE},
        ],
    }
    spec_path = tmp_path / 'lecture.json'
    spec_path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    res = build(spec_path, tmp_path / 'deck.pptx', qa=True)
    assert res['ok'] is False
    assert any('underrun' in e for e in res['qa']['errors'])


# ───────────────────── modes: error / warn / off ─────────────────────

def test_duration_warn_mode_is_a_warning():
    spec = _spec(20, qa={'check_duration': 'warn'})
    report = qa_check.check_deck(spec, _result(4.0))
    assert report['ok'] is True
    assert report['errors'] == []
    assert any('underrun' in w for w in report['warnings'])
    assert report['settings']['check_duration'] == 'warn'


def test_duration_warn_mode_flags_overrun_too():
    spec = _spec(20, qa={'check_duration': 'warn'})
    report = qa_check.check_deck(spec, _result(30.0))
    assert report['ok'] is True
    assert any('overrun' in w for w in report['warnings'])


def test_duration_off_mode_is_silent():
    spec = _spec(20, qa={'check_duration': 'off'})
    report = qa_check.check_deck(spec, _result(1.0))
    assert report['ok'] is True
    assert not any('underrun' in w or 'overrun' in w for w in report['warnings'])
    assert report['settings']['check_duration'] == 'off'


def test_duration_error_mode_stays_an_error():
    spec = _spec(20, qa={'check_duration': 'error'})
    report = qa_check.check_deck(spec, _result(4.0))
    assert report['ok'] is False
    assert any('underrun' in e for e in report['errors'])


def test_duration_boolean_modes_keep_backward_behaviour():
    enabled = qa_check.check_deck(_spec(20, qa={'check_duration': True}), _result(4.0))
    assert enabled['settings']['check_duration'] is True
    assert enabled['ok'] is False
    disabled = qa_check.check_deck(_spec(20, qa={'check_duration': False}), _result(4.0))
    assert disabled['settings']['check_duration'] is False
    assert disabled['ok'] is True


def test_duration_invalid_mode_falls_back_to_error():
    spec = _spec(20, qa={'check_duration': 'maybe'})
    report = qa_check.check_deck(spec, _result(4.0))
    assert report['settings']['check_duration'] is True
    assert report['ok'] is False
