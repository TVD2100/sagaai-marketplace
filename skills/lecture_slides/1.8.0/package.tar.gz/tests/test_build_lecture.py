"""Unit tests for build_lecture: build() results, QA wiring, CLI exit codes."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from build_lecture import build, main


# ─────────────────────────── build() ───────────────────────────

def test_build_demo_without_qa(tmp_path, demo_spec_path):
    out = tmp_path / 'demo.pptx'
    res = build(demo_spec_path, out, qa=False)
    assert res['ok'] is True
    assert res['pptx'] == str(out)
    assert res['slides'] == 14
    assert res['errors'] == []
    assert res['qa'] is None
    assert res['qa_reports'] == []
    assert out.exists()
    assert res['assets'] == []
    assert res['formula_modes']['omml'] >= 4
    assert res['formula_modes']['image'] == 0
    assert res['missing_images'] == []
    assert 'OK' in res['summary']


def test_build_demo_with_qa_writes_reports(tmp_path, demo_spec_path):
    out = tmp_path / 'demo.pptx'
    res = build(demo_spec_path, out, qa=True, qa_json=True)
    assert res['ok'] is True
    assert res['qa'] is not None and res['qa']['ok'] is True
    names = sorted(Path(p).name for p in res['qa_reports'])
    assert names == ['qa.json', 'qa.md', 'qa_content.md',
                     'qa_file.md', 'qa_visual.md']
    service = tmp_path / 'demo_service'
    assert all(Path(p).parent == service for p in res['qa_reports'])
    report = service / 'qa.md'
    assert report.exists()
    assert '**PASS**' in report.read_text(encoding='utf-8')
    payload = json.loads((service / 'qa.json').read_text(encoding='utf-8'))
    assert payload['slides'] == 14 and payload['errors'] == []
    assert 'QA: 0 errors, 0 warnings' in res['summary']


def test_build_default_output_next_to_spec(tmp_path):
    spec = {'meta': {'title': 'T'},
            'slides': [{'type': 'title', 'note': 'Заметка достаточной длины для порога качества проверки знаний студентов на сегодняшней лекции курса по численным методам.'}]}
    spec_path = tmp_path / 'lecture.json'
    spec_path.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    res = build(spec_path, qa=True)
    assert res['ok'] is True
    assert res['pptx'] == str(tmp_path / 'lecture.pptx')
    assert (tmp_path / 'lecture.pptx').exists()
    assert (tmp_path / 'lecture_service' / 'qa.md').exists()
    # The deck folder itself must keep only artifacts.
    assert not (tmp_path / 'lecture_qa.md').exists()


def test_build_reports_spec_error_cleanly(tmp_path):
    bad = tmp_path / 'bad.json'
    bad.write_text('{nope', encoding='utf-8')
    res = build(bad, qa=True)
    assert res['ok'] is False
    assert res['pptx'] is None
    assert res['slides'] == 0
    assert res['qa'] is None
    assert res['errors'] and 'invalid JSON' in res['errors'][0]
    assert 'spec error' in res['summary']


def test_build_strict_turns_warning_into_failure(tmp_path):
    spec = {'meta': {'course': 'C', 'title': 'T', 'lang': 'ru'},
            'slides': [
                {'type': 'bullets', 'header': 'Много',
                 'items': ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
                 'note': 'Заметка достаточной длины для порога качества проверки знаний студентов на сегодняшней лекции курса по численным методам.'},
            ]}
    path = tmp_path / 'many.json'
    path.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    lax = build(path, tmp_path / 'lax.pptx', qa=True)
    assert lax['ok'] is True
    assert any('7 list items' in w for w in lax['qa']['warnings'])
    strict = build(path, tmp_path / 'strict.pptx', qa=True, strict=True)
    assert strict['ok'] is False
    assert strict['qa']['errors'] == []
    assert strict['qa']['settings']['strict'] is True


def test_build_missing_image_errors_but_deck_built(tmp_path):
    spec = {'meta': {'title': 'T'},
            'slides': [{'type': 'image', 'header': 'H', 'path': 'nope.png',
                        'note': 'Заметка про картинку, достаточной длины для порога качества проверки знаний студентов на лекции.'}]}
    path = tmp_path / 'img.json'
    path.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    res = build(path, tmp_path / 'img.pptx', qa=True)
    assert res['ok'] is False
    assert 'nope.png' in res['missing_images']
    assert any('image not found' in e for e in res['errors'])
    assert any('image content failed to render' in e for e in res['qa']['errors'])
    # the deck itself is still produced with the error placeholder
    assert (tmp_path / 'img.pptx').exists()


# ───────────────────── build(qa_visual=True) ─────────────────────

def _ink_page(path):
    """Save a page image with real ink well inside the borders."""
    from PIL import Image, ImageDraw
    image = Image.new('RGB', (640, 360), 'white')
    ImageDraw.Draw(image).rectangle([200, 120, 440, 240], fill=(0, 0, 0))
    image.save(path)
    return str(path)


def test_build_qa_visual_feeds_rendered_pages(tmp_path, monkeypatch, demo_spec_path):
    import render_preview
    pages = [_ink_page(tmp_path / 'page_01.png')]
    monkeypatch.setattr(render_preview, 'render',
                        lambda pptx, **kwargs: {'ok': True, 'png': pages, 'warnings': []})
    res = build(demo_spec_path, tmp_path / 'demo.pptx', qa=True, qa_visual=True)
    stage = res['qa']['stages']['visual']
    # pages reached the visual stage: it ran instead of reporting itself skipped
    assert stage['skipped'] is False
    # QA warnings keep their stage prefix, so the source of each is explicit
    assert any(w.startswith('[visual]') for w in res['qa']['warnings'])


def test_build_qa_visual_skips_without_rasterizer(tmp_path, monkeypatch, demo_spec_path):
    import render_preview
    monkeypatch.setattr(render_preview, 'render',
                        lambda pptx, **kwargs: {'ok': False, 'png': False,
                                                'warnings': ['LibreOffice not found']})
    res = build(demo_spec_path, tmp_path / 'demo.pptx', qa=True, qa_visual=True)
    assert res['ok'] is True
    assert res['qa']['stages']['visual']['skipped'] is True
    assert any('visual QA skipped' in w for w in res['warnings'])


def test_build_qa_visual_survives_rasterizer_crash(tmp_path, monkeypatch, demo_spec_path):
    import render_preview

    def boom(*args, **kwargs):
        raise RuntimeError('soffice exploded')

    monkeypatch.setattr(render_preview, 'render', boom)
    res = build(demo_spec_path, tmp_path / 'demo.pptx', qa=True, qa_visual=True)
    assert res['ok'] is True
    assert any('rasterization failed' in w for w in res['warnings'])


def test_cli_visual_flag_is_accepted(tmp_path, monkeypatch, demo_spec_path):
    import render_preview
    monkeypatch.setattr(render_preview, 'render',
                        lambda pptx, **kwargs: {'ok': False, 'png': False, 'warnings': []})
    code = main([str(demo_spec_path), str(tmp_path / 'vis.pptx'), '--qa', '--visual'])
    assert code == 0


# ─────────────────────────── CLI ───────────────────────────

def test_cli_success_exit_0(tmp_path, demo_spec_path):
    out = tmp_path / 'cli.pptx'
    assert main([str(demo_spec_path), str(out), '--qa']) == 0
    assert out.exists()
    assert (tmp_path / 'cli_service' / 'qa.md').exists()


def test_cli_flat_keeps_the_old_flat_layout(tmp_path, demo_spec_path):
    """``--flat`` writes the QA report next to the deck (pre-1.5 layout)."""
    out = tmp_path / 'flat.pptx'
    assert main([str(demo_spec_path), str(out), '--qa', '--flat']) == 0
    assert (tmp_path / 'flat_qa.md').exists()
    assert not (tmp_path / 'flat_service').exists()


def test_cli_qa_error_exit_1(tmp_path):
    spec = {'meta': {'title': 'T'},
            'slides': [{'type': 'bullets', 'items': ['a'], 'note': 'коротко'}]}
    path = tmp_path / 'short.json'
    path.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    assert main([str(path), str(tmp_path / 'short.pptx'), '--qa']) == 1


def test_cli_spec_error_exit_2(tmp_path):
    bad = tmp_path / 'bad.json'
    bad.write_text('{nope', encoding='utf-8')
    assert main([str(bad), str(tmp_path / 'bad.pptx')]) == 2


def test_cli_strict_exit_1_on_warning_only(tmp_path):
    spec = {'meta': {'title': 'T'},
            'slides': [{'type': 'bullets', 'header': 'H',
                        'items': ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
                        'note': 'Заметка достаточной длины для порога качества проверки знаний студентов на сегодняшней лекции курса.'}]}
    path = tmp_path / 'many.json'
    path.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    assert main([str(path), str(tmp_path / 'many.pptx'), '--qa']) == 0
    assert main([str(path), str(tmp_path / 'many.pptx'), '--qa', '--strict']) == 1
