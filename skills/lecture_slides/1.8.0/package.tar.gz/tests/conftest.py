"""Shared fixtures for the lecture-slides test suite.

The bundle root is appended to ``sys.path`` so tests can import ``lecture``,
``build_lecture`` and ``render_preview`` no matter which directory pytest is
invoked from. The bundled demo deck is built once per session and reused by
the read-only assertions.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

DEMO_SPEC = ROOT / 'examples' / 'demo_lecture.json'
DEMO_PLOT = ROOT / 'examples' / 'demo_plot.png'


@pytest.fixture(scope='session')
def bundle_root():
    """Absolute path of the lecture-slides bundle."""
    return ROOT


@pytest.fixture(scope='session')
def demo_spec_path():
    """Path of the bundled demo spec."""
    return DEMO_SPEC


@pytest.fixture(scope='session')
def demo_plot_path():
    """Path of the plot image used by the demo two_column slide."""
    return DEMO_PLOT


@pytest.fixture(scope='session')
def demo_spec(demo_spec_path):
    """Validated demo spec (loaded once per session)."""
    from lecture import load_spec
    return load_spec(demo_spec_path)


@pytest.fixture(scope='session')
def demo_build(demo_spec, tmp_path_factory):
    """Build the demo deck once; returns ``(spec, result, pptx_path)``."""
    from lecture import build_deck
    out_dir = tmp_path_factory.mktemp('demo_build')
    pptx_path = out_dir / 'demo.pptx'
    result = build_deck(demo_spec, out_path=pptx_path, assets_dir=out_dir / 'assets')
    return demo_spec, result, pptx_path
