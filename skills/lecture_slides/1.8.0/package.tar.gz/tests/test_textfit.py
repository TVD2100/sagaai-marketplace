"""Unit tests for lecture.textfit: metrics, wrapping, fitting, contrast."""

from __future__ import annotations

import pytest

from lecture import textfit


# ─────────────────────────── measurement ───────────────────────────

def test_measure_in_positive_and_monotonic():
    short = textfit.measure_in('i', 'arial', 20)
    long = textfit.measure_in('mmmmmmmmmm', 'arial', 20)
    assert short > 0 and long > short


def test_measure_in_empty_is_zero():
    assert textfit.measure_in('', 'arial', 20) == 0.0


def test_measure_scales_with_size():
    small = textfit.measure_in('Hello, world', 'arial', 12)
    big = textfit.measure_in('Hello, world', 'arial', 24)
    assert big > small * 1.7


def test_line_height_positive_and_scales():
    h20 = textfit.line_height_in('arial', 20)
    h40 = textfit.line_height_in('arial', 40)
    assert h20 > 0
    assert h40 > h20 * 1.8


def test_height_in_zero_lines():
    assert textfit.height_in(0, 'arial', 20) == 0.0
    assert textfit.height_in(-3, 'arial', 20) == 0.0


def test_height_in_linear():
    one = textfit.height_in(1, 'arial', 20)
    three = textfit.height_in(3, 'arial', 20)
    assert three == pytest.approx(one * 3, rel=1e-9)


def test_font_roles_resolve_to_something():
    """Every role must resolve (real font or DejaVu fallback - matplotlib present)."""
    fonts = textfit.resolved_fonts()
    assert fonts
    for role, path in fonts.items():
        assert path, 'no font resolved for role %s' % role


# ───────────────────────────── wrapping ─────────────────────────────

def test_wrap_empty():
    assert textfit.wrap('', 'arial', 20, 5.0) == []
    assert textfit.wrap('   ', 'arial', 20, 5.0) == []


def test_wrap_short_text_single_line():
    lines = textfit.wrap('short text', 'arial', 20, 20.0)
    assert lines == ['short text']


def test_wrap_splits_long_text():
    text = 'word ' * 40
    lines = textfit.wrap(text.strip(), 'arial', 20, 2.0)
    assert len(lines) > 1
    for line in lines:
        assert textfit.measure_in(line, 'arial', 20) <= 2.0 + 1e-9


def test_wrap_hard_breaks_long_word():
    word = 'A' * 120
    lines = textfit.wrap(word, 'arial', 20, 2.0)
    assert len(lines) > 1
    assert ''.join(lines) == word
    for line in lines:
        assert textfit.measure_in(line, 'arial', 20) <= 2.0 + 1e-9


def test_n_lines_basics():
    assert textfit.n_lines('', 'arial', 20, 5.0) == 0
    assert textfit.n_lines('a', 'arial', 20, 5.0) == 1
    assert textfit.n_lines('word ' * 60, 'arial', 20, 1.5) > 2


# ───────────────────────────── fit_size ─────────────────────────────

def test_fit_size_returns_base_when_fits():
    size = textfit.fit_size(['short'], 'arial', 20, 10.0, 3.0, 10.0)
    assert size == 20


def test_fit_size_shrinks_to_fit_height():
    texts = ['line one two three', 'line four five six', 'line seven eight']
    size = textfit.fit_size(texts, 'arial', 40, 8.0, 1.2, 10.0)
    assert 10.0 <= size < 40
    total = sum(textfit.height_in(textfit.n_lines(t, 'arial', size, 8.0), 'arial', size)
                for t in texts)
    assert total <= 1.2 + 1e-6 or size == 10.0


def test_fit_size_never_below_min():
    texts = ['word ' * 200]
    size = textfit.fit_size(texts, 'arial', 40, 1.0, 0.2, 12.0)
    assert size == 12.0


# ─────────────────────────── overflow helper ───────────────────────────

def test_overflow_none_never_overflows():
    assert textfit.overflow(None, 1.0) is False


def test_overflow_small_excess_within_slack():
    # 3% slack on a 1\'\' box -> 0.03\'\' grace
    assert textfit.overflow(1.034, 1.0) is False
    assert textfit.overflow(1.12, 1.0) is True


def test_overflow_slack_scales_with_box():
    # 8% of a 4\'\' box -> 0.32\'\' grace, larger than the fixed 0.03
    assert textfit.overflow(4.2, 4.0) is False
    assert textfit.overflow(4.5, 4.0) is True


def test_overflow_zero_box_uses_min_slack():
    assert textfit.overflow(0.02, 0.0) is False
    assert textfit.overflow(0.05, 0.0) is True


# ─────────────────────────── WCAG contrast ───────────────────────────

def test_hex_to_rgb_variants():
    assert textfit.hex_to_rgb('#FF0000') == (255, 0, 0)
    assert textfit.hex_to_rgb('00ff00') == (0, 255, 0)
    assert textfit.hex_to_rgb('#00f') == (0, 0, 255)
    assert textfit.hex_to_rgb('bogus') == (0, 0, 0)


def test_contrast_ratio_extremes():
    assert textfit.contrast_ratio('#000000', '#FFFFFF') == pytest.approx(21.0, abs=0.01)
    assert textfit.contrast_ratio('#777777', '#777777') == pytest.approx(1.0, abs=0.001)


def test_contrast_ratio_symmetric():
    first = textfit.contrast_ratio('#1B2A41', '#FFFFFF')
    second = textfit.contrast_ratio('#FFFFFF', '#1B2A41')
    assert first == pytest.approx(second, rel=1e-9)


def test_relative_luminance_bounds():
    assert textfit.relative_luminance('#000000') == pytest.approx(0.0, abs=1e-6)
    assert textfit.relative_luminance('#FFFFFF') == pytest.approx(1.0, abs=1e-6)
