"""Regression pins for the mechanisms this skill must never lose.

Each test guards one row of the 'what to keep' contract of the skill (the
mechanisms that earned its engineering score): mandatory speaker notes as
ERRORS, the full 18-type slide table, the proactive text-fit safety factor,
the self-auditing illustration composer, source-registry materialization,
the QA exit-code policy and the fully offline runtime.

These pins are written to pass on the current code; breaking a mechanism
must turn the matching pin red (verified once by a deliberate mutation of
``textfit.SAFETY`` during development).
"""

from __future__ import annotations

import ast
import json
from pathlib import Path

import pytest

import qa_check
from build_lecture import build
from lecture import SLIDE_TYPES, figkit, slides, textfit, validate_spec

ROOT = Path(__file__).resolve().parents[1]
NOTE = ('Заметка достаточной длины для прохождения минимального порога '
        'качества проверки материала на этой лекции.')


def _spec(slides_data=None, **meta):
    payload = {'meta': dict(meta) if meta else {'title': 'Guarantees'},
               'slides': slides_data or [{'type': 'title', 'note': NOTE}]}
    return validate_spec(payload)


def _rec(index=1, stype='bullets', note_words=50, boxes=None, empty=False):
    return {'index': index, 'type': stype, 'note_words': note_words,
            'bullets': 0, 'code_lines': 0, 'boxes': list(boxes or []),
            'empty': empty}


def _result(records):
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': 5.0}


# ------------------- mandatory speaker notes are errors -------------------

def test_missing_speaker_notes_is_an_error():
    report = qa_check.check_deck(_spec(), _result([_rec(note_words=0)]))
    assert report['ok'] is False
    assert any('speaker notes missing' in e for e in report['errors'])


def test_notes_never_degrade_to_warning():
    report = qa_check.check_deck(_spec(), _result([_rec(note_words=0)]))
    assert not any('speaker notes missing' in w for w in report['warnings'])


# ------------------- the full 19-type slide table -------------------

# 18 original types + 'chart' + 'steps_grid'/'pillars'/'focus'.
def test_twentytwo_slide_types_registered():
    assert len(SLIDE_TYPES) == 22
    assert set(slides.RENDERERS) == set(SLIDE_TYPES), (
        set(SLIDE_TYPES) ^ set(slides.RENDERERS))


def test_every_slide_type_has_a_renderer_callable():
    for stype, renderer in slides.RENDERERS.items():
        assert callable(renderer), stype


# ------------------- proactive text-fit safety factor -------------------

def test_text_fit_safety_factor_is_pinned():
    assert textfit.SAFETY == 1.04
    assert textfit.SAFETY_APPROX >= textfit.SAFETY


# ------------------- self-auditing illustration composer -------------------

def test_figkit_save_returns_problem_list(tmp_path):
    canvas = figkit.Canvas(4.0, 2.0, theme='academic_blue')
    canvas.rect(0.10, 0.30, 0.30, 0.40, fc=canvas.colors['soft'], track=True)
    problems = canvas.save(tmp_path / 'clean.png')
    assert isinstance(problems, list)
    assert problems == []
    assert hasattr(figkit, 'audit_fig')


def test_figkit_reports_element_out_of_canvas(tmp_path):
    canvas = figkit.Canvas(4.0, 2.0, theme='academic_blue')
    canvas.rect(0.90, 0.30, 0.30, 0.40, fc=canvas.colors['soft'], track=True)
    problems = canvas.save(tmp_path / 'broken.png')
    assert problems, 'out-of-canvas rect was not reported'


# ------------------- source registry materialization -------------------

def test_literature_materializes_registry_entries():
    spec = validate_spec({
        'meta': {'title': 'Sources', 'sources': [
            {'id': 'press2007', 'kind': 'book', 'title': 'Press, Numerical Recipes',
             'url': 'https://numerical.recipes/'},
        ]},
        'slides': [{'type': 'literature', 'source_refs': ['press2007'], 'note': NOTE}],
    })
    items = spec.slides[0]['items']
    assert any('Press, Numerical Recipes' in str(item) for item in items)
    entry = [item for item in items if isinstance(item, dict)][0]
    assert entry.get('url') == 'https://numerical.recipes/'


def test_unknown_source_ref_is_warned_not_fatal():
    spec = validate_spec({
        'meta': {'title': 'Sources'},
        'slides': [{'type': 'bullets', 'items': ['a'], 'source_refs': ['ghost'],
                    'note': NOTE}],
    })
    assert any('ghost' in w for w in spec.warnings)


# ------------------- QA exit-code policy -------------------

def test_cli_clean_exit_0(tmp_path, demo_spec_path):
    assert qa_check.main([str(demo_spec_path), '--report', str(tmp_path / 'qa.md')]) == 0


def test_cli_qa_error_exit_1(tmp_path):
    spec = {'meta': {'title': 'T'},
            'slides': [{'type': 'bullets', 'items': ['a'], 'note': 'коротко'}]}
    path = tmp_path / 'short.json'
    path.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    assert qa_check.main([str(path), '--report', str(tmp_path / 'qa.md')]) == 1


def test_cli_spec_failure_exit_2(tmp_path):
    bad = tmp_path / 'bad.json'
    bad.write_text('{oops', encoding='utf-8')
    assert qa_check.main([str(bad), '--report', str(tmp_path / 'qa.md')]) == 2


# ------------------- fully offline runtime -------------------

FORBIDDEN_MODULES = {'socket', 'urllib', 'urllib3', 'requests', 'httpx',
                     'aiohttp', 'ftplib', 'smtplib', 'telnetlib', 'webbrowser'}
FORBIDDEN_CALL_SNIPPETS = ('urlopen(', 'requests.get(', 'requests.post(',
                           'socket.socket(')


def _runtime_files():
    files = [ROOT / 'build_lecture.py', ROOT / 'qa_check.py', ROOT / 'render_preview.py']
    files.extend(sorted((ROOT / 'lecture').glob('*.py')))
    return [path for path in files if path.exists()]


def test_runtime_imports_no_network_modules():
    offenders = []
    for path in _runtime_files():
        tree = ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [node.module or '']
            else:
                continue
            for name in names:
                root = str(name).split('.')[0]
                if root in FORBIDDEN_MODULES:
                    offenders.append('%s imports %s' % (path.name, name))
    assert offenders == [], offenders


def test_runtime_source_has_no_network_calls():
    offenders = []
    for path in _runtime_files():
        source = path.read_text(encoding='utf-8')
        for snippet in FORBIDDEN_CALL_SNIPPETS:
            if snippet in source:
                offenders.append('%s contains %s' % (path.name, snippet))
    assert offenders == [], offenders


# ------------------- build() keeps the documented result keys -------------------

def test_build_result_keeps_documented_keys(tmp_path, demo_spec_path):
    res = build(demo_spec_path, tmp_path / 'demo.pptx', qa=True)
    for key in ('ok', 'pptx', 'slides', 'qa', 'errors', 'warnings',
                'note_words', 'duration_est_min', 'assets', 'missing_images',
                'missing_glyphs', 'qa_reports', 'summary'):
        assert key in res, key
    assert res['ok'] is True
    assert res['slides'] == 14
