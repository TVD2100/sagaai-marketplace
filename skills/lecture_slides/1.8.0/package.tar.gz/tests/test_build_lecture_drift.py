"""Tests for the drift entry points of build_lecture.

``build_lecture.check_drift`` is the function the skill instructions tell the
agent to call before rebuilding a deck, and ``--check-drift`` /
``--ack-manual-edit`` are its CLI mirrors. These tests pin the contract: the
wrapper never writes anything, reports the manual edits, exposes the markdown
for the user, and the CLI exit codes match the three outcomes.
"""

from __future__ import annotations

import json

from pptx import Presentation

import build_lecture
from build_lecture import acknowledge_manual_edits, check_drift

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества проверки материала лекции для студентов.')


def _build(tmp_path, name='deck'):
    payload = {'meta': {'course': 'Численные методы', 'title': 'Дрейф', 'lang': 'ru'},
               'slides': [
                   {'type': 'bullets', 'header': 'План',
                    'items': ['Первый пункт', 'Второй пункт'], 'note': NOTE},
                   {'type': 'definition', 'term': 'Сходимость',
                    'text': 'Погрешность убывает на каждой итерации.', 'note': NOTE},
               ]}
    spec_path = tmp_path / 'lecture.json'
    spec_path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    out = tmp_path / (name + '.pptx')
    assert build_lecture.build(spec_path, out, qa=False)['ok'] is True
    return spec_path, out


def _edit(pptx_path, new_text):
    presentation = Presentation(str(pptx_path))
    for shape in presentation.slides[0].shapes:
        if getattr(shape, 'has_text_frame', False) and shape.text_frame.paragraphs:
            runs = shape.text_frame.paragraphs[0].runs
            if runs:
                runs[0].text = new_text
                presentation.save(str(pptx_path))
                return
    raise AssertionError('no editable run on slide 1')


def test_check_drift_defaults_to_the_sibling_pptx(tmp_path):
    spec_path, out = _build(tmp_path, name='lecture')
    assert out.name == 'lecture.pptx'
    report = check_drift(spec_path)
    assert report['changed'] is False
    assert report['ok'] is True
    assert 'markdown' in report and 'In sync' in report['markdown']


def test_check_drift_default_path_absent_is_an_error(tmp_path):
    spec_path, _ = _build(tmp_path, name='deck')
    report = check_drift(spec_path)
    assert report['ok'] is False
    assert report['errors'] and 'deck not found' in report['errors'][0]


def test_check_drift_reports_a_manual_edit(tmp_path):
    spec_path, out = _build(tmp_path)
    _edit(out, 'ПРАВКА ВРУЧНУЮ')
    report = check_drift(spec_path, out)
    assert report['changed'] is True
    assert report['ok'] is False
    assert 'ПРАВКА ВРУЧНУЮ' in report['markdown']
    assert any('ПРАВКА ВРУЧНУЮ' in text
               for entry in report['slides'] for text in entry['user_added'])


def test_check_drift_exposes_the_ack_path(tmp_path):
    spec_path, out = _build(tmp_path)
    report = check_drift(spec_path, out)
    assert report['ack_path'].endswith('deck_service/drift_ack.json')
    flat = check_drift(spec_path, out, service_dir=False)
    assert flat['ack_path'].endswith('drift_ack.json')
    assert 'deck_service' not in flat['ack_path']


def test_check_drift_does_not_touch_the_deck(tmp_path):
    spec_path, out = _build(tmp_path)
    before = out.read_bytes()
    check_drift(spec_path, out)
    assert out.read_bytes() == before
    assert not (tmp_path / 'deck_service').exists()


def test_acknowledge_manual_edits_writes_the_ack(tmp_path):
    spec_path, out = _build(tmp_path)
    _edit(out, 'ФИНАЛЬНАЯ РЕДАКЦИЯ')
    ack = acknowledge_manual_edits(out)
    assert ack.endswith('deck_service/drift_ack.json')
    report = check_drift(spec_path, out)
    assert report['acknowledged'] is True
    assert report['ok'] is True
    assert 'Acknowledged' in report['markdown']


def test_cli_check_drift_exit_codes(tmp_path, capsys):
    spec_path, out = _build(tmp_path)
    assert build_lecture.main([str(spec_path), str(out), '--check-drift']) == 0
    assert 'In sync' in capsys.readouterr().out

    _edit(out, 'ПРАВКА ЧЕРЕЗ CLI')
    assert build_lecture.main([str(spec_path), str(out), '--check-drift']) == 1
    assert 'Drift' in capsys.readouterr().out


def test_cli_ack_manual_edit_clears_the_drift(tmp_path, capsys):
    spec_path, out = _build(tmp_path)
    _edit(out, 'ПРАВКА ЧЕРЕЗ CLI')
    assert build_lecture.main([str(spec_path), str(out), '--ack-manual-edit']) == 0
    assert 'acknowledged:' in capsys.readouterr().out
    assert build_lecture.main([str(spec_path), str(out), '--check-drift']) == 0


def test_cli_check_drift_missing_deck_is_an_error(tmp_path):
    spec_path, _ = _build(tmp_path)
    code = build_lecture.main([str(spec_path), str(tmp_path / 'gone.pptx'),
                               '--check-drift'])
    assert code == 2


def test_cli_flat_layout_ack_sits_next_to_the_deck(tmp_path):
    spec_path, out = _build(tmp_path)
    _edit(out, 'FLAT')
    assert build_lecture.main([str(spec_path), str(out), '--ack-manual-edit',
                               '--flat']) == 0
    assert (tmp_path / 'drift_ack.json').exists()
    assert not (tmp_path / 'deck_service').exists()


def test_cli_check_drift_builds_nothing(tmp_path):
    """The drift check must not rebuild the deck it is inspecting."""
    spec_path, out = _build(tmp_path)
    before = out.read_bytes()
    build_lecture.main([str(spec_path), str(out), '--check-drift'])
    assert out.read_bytes() == before
