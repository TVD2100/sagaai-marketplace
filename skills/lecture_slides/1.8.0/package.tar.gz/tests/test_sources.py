"""Tests for the sources registry and the fact-checking QA rules (C1).

Covered: ``meta.sources`` normalization (``_validate_sources``), the
``source_refs`` slide field, materialization of ``literature`` items from
the registry (including the rendered hyperlink) and the
``check_source_refs`` QA rules - figures without a source on a slide and
sources slides without hyperlinks. Most specs are validated but not
built: the rules only need a validated spec aligned with fabricated
layout records.
"""

from __future__ import annotations

import pytest

import qa_check
from lecture import SpecError, build_deck, validate_spec

# 17 words: above the default min_note_words (12) for every slide.
NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')

SOURCE_A = {'id': 'handbook', 'title': 'Справочник по анализу данных',
            'url': 'https://example.com/handbook', 'kind': 'book',
            'checked_at': '2026-01-15'}
SOURCE_B = {'id': 'survey', 'title': 'Обзор рынка аналитики'}


def _spec(slides, sources=None, qa=None):
    """Validate a minimal RU spec with the given slides, sources and qa."""
    meta = {'title': 'Sources QA', 'lang': 'ru'}
    if sources is not None:
        meta['sources'] = sources
    payload = {'meta': meta, 'slides': slides}
    if qa:
        payload['qa'] = qa
    return validate_spec(payload)


def _rec(index, stype, boxes=None, empty=False):
    """Fabricated layout record matching the build output shape."""
    return {'index': index, 'type': stype, 'note_words': 50, 'bullets': 0,
            'code_lines': 0, 'boxes': list(boxes or []), 'empty': empty}


def _result(records):
    """Build-result stub carrying only the fields the QA rules read."""
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': 5.0}


def _figures_warnings(report):
    """QA warnings about slides whose figures carry no source."""
    return [w for w in report['warnings'] if 'without a source' in w]


# ─────────────────────────── registry (spec) ───────────────────────────

def test_sources_default_to_empty_list():
    spec = _spec([{'type': 'title', 'note': NOTE}])
    assert spec.meta['sources'] == []


def test_sources_registry_is_normalized():
    spec = _spec([{'type': 'title', 'note': NOTE}], sources=[SOURCE_A])
    assert spec.meta['sources'] == [SOURCE_A]
    assert spec.warnings == []


def test_invalid_sources_entries_are_dropped_with_warnings():
    spec = _spec([{'type': 'title', 'note': NOTE}], sources=[
        'not-an-object',
        {'title': 'No id'},
        {'id': 'no_title'},
        {'id': 'bad_url', 'title': 'Bad', 'url': 'javascript:alert(1)'},
        {'id': 'bad_kind', 'title': 'Kind', 'kind': 5},
        {'id': 'bad_checked', 'title': 'Checked', 'checked_at': 7},
        SOURCE_A,
        dict(SOURCE_A),
    ])
    ids = [entry['id'] for entry in spec.meta['sources']]
    assert ids == ['bad_url', 'bad_kind', 'bad_checked', 'handbook']
    assert 'url' not in spec.meta['sources'][0]
    warnings = ' '.join(spec.warnings)
    assert 'must be an object' in warnings
    assert "missing 'id'" in warnings
    assert "missing 'title'" in warnings
    assert 'not a safe http(s)/mailto link' in warnings
    assert "'kind' must be a string" in warnings
    assert "'checked_at' must be a string" in warnings
    assert 'duplicate id' in warnings


def test_sources_must_be_a_list():
    spec = _spec([{'type': 'title', 'note': NOTE}], sources='nope')
    assert spec.meta['sources'] == []
    assert any('meta.sources must be a list' in w for w in spec.warnings)


def test_source_refs_kept_and_unknown_ref_warns():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Доля рынка выросла до 47% за год'],
                   'source_refs': ['handbook', 'ghost'], 'note': NOTE}],
                 sources=[SOURCE_A])
    assert spec.slides[0]['source_refs'] == ['handbook', 'ghost']
    assert any("source_refs id 'ghost'" in w for w in spec.warnings)


def test_source_refs_with_bad_type_are_ignored():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Доля рынка выросла до 47% за год'],
                   'source_refs': [1, 2], 'note': NOTE}],
                 sources=[SOURCE_A])
    assert 'source_refs' not in spec.slides[0]
    assert any("'source_refs' must be a list of source ids" in w
               for w in spec.warnings)


def test_literature_materializes_entries_from_registry():
    spec = _spec([{'type': 'literature',
                   'source_refs': ['handbook', 'survey'], 'note': NOTE}],
                 sources=[SOURCE_A, SOURCE_B])
    assert spec.slides[0]['items'] == [
        {'text': 'Справочник по анализу данных',
         'url': 'https://example.com/handbook'},
        {'text': 'Обзор рынка аналитики'},
    ]


def test_literature_appends_materialized_entries_after_manual_items():
    spec = _spec([{'type': 'literature', 'items': ['Своя книга'],
                   'source_refs': ['survey'], 'note': NOTE}],
                 sources=[SOURCE_B])
    items = spec.slides[0]['items']
    assert items[0] == 'Своя книга'
    assert items[1] == {'text': 'Обзор рынка аналитики'}


def test_unknown_source_refs_are_not_materialized():
    spec = _spec([{'type': 'literature', 'items': ['Своя книга'],
                   'source_refs': ['ghost'], 'note': NOTE}],
                 sources=[SOURCE_B])
    assert spec.slides[0]['items'] == ['Своя книга']
    assert any("source_refs id 'ghost'" in w for w in spec.warnings)


def test_literature_without_items_or_resolvable_refs_is_an_error():
    with pytest.raises(SpecError):
        _spec([{'type': 'literature', 'source_refs': ['ghost'],
                'note': NOTE}], sources=[SOURCE_B])


def test_materialized_literature_renders_hyperlinks(tmp_path):
    from pptx import Presentation
    spec = _spec([
        {'type': 'title', 'note': NOTE},
        {'type': 'literature', 'source_refs': ['handbook'], 'note': NOTE},
    ], sources=[SOURCE_A])
    out = tmp_path / 'sources.pptx'
    result = build_deck(spec, out_path=out)
    assert result['ok'] and out.exists()
    prs = Presentation(str(out))
    texts = []
    addresses = []
    for slide in prs.slides:
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            texts.append(shape.text_frame.text)
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    address = run.hyperlink.address
                    if address:
                        addresses.append(address)
    assert 'Справочник по анализу данных' in ' '.join(texts)
    assert 'https://example.com/handbook' in addresses


# ─────────────────────────── fact-checking (QA) ───────────────────────────

def test_figures_without_source_warn():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Доля рынка выросла до 47% за год'],
                   'note': NOTE}], sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert any('figures (47%) without a source' in w
               for w in report['warnings'])


def test_figures_with_source_ref_are_clean():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Доля рынка выросла до 47% за год'],
                   'source_refs': ['handbook'], 'note': NOTE}],
                 sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _figures_warnings(report)


def test_figures_with_inline_link_are_clean():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['[Отчёт](https://example.com/report): рост 47%'],
                   'note': NOTE}], sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _figures_warnings(report)


def test_fact_check_requires_a_registry():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Доля рынка выросла до 47% за год'],
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _figures_warnings(report)


def test_years_and_decimals_are_not_figures():
    spec = _spec([{'type': 'bullets', 'header': 'История',
                   'items': ['В 2015 году вышло три статьи',
                             'Значение 1.41421356 известно всем'],
                   'note': NOTE}], sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _figures_warnings(report)


def test_grouped_and_long_numbers_are_figures():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['12 000 клиентов оформили 12345 заказов'],
                   'note': NOTE}], sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    warnings = _figures_warnings(report)
    assert warnings
    assert '12 000' in warnings[0] and '12345' in warnings[0]


def test_many_figures_are_truncated_in_the_warning():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Рост 10% и 20% и 30% и 40% и 50% и 60%'],
                   'note': NOTE}], sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    warnings = _figures_warnings(report)
    assert warnings and '(+2 more)' in warnings[0]


def test_exempt_slide_types_skip_the_figure_check():
    spec = _spec([{'type': 'homework',
                   'items': ['Разобрать пример с числом 12345'],
                   'note': NOTE}], sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'homework')]))
    assert not _figures_warnings(report)


def test_literature_without_urls_warns():
    spec = _spec([{'type': 'literature', 'source_refs': ['survey'],
                   'note': NOTE}], sources=[SOURCE_B])
    report = qa_check.check_deck(spec, _result([_rec(1, 'literature')]))
    assert any('sources slide has no hyperlinks' in w
               for w in report['warnings'])
    assert any("source 'survey' has no url" in w for w in report['warnings'])


def test_literature_with_urls_is_clean():
    spec = _spec([{'type': 'literature', 'source_refs': ['handbook'],
                   'note': NOTE}], sources=[SOURCE_A])
    report = qa_check.check_deck(spec, _result([_rec(1, 'literature')]))
    assert not any('has no hyperlinks' in w for w in report['warnings'])
    assert not any('has no url' in w for w in report['warnings'])


def test_check_source_refs_can_be_disabled():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Доля рынка выросла до 47% за год'],
                   'note': NOTE}], sources=[SOURCE_A],
                 qa={'check_source_refs': False})
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _figures_warnings(report)


def test_check_source_refs_is_a_known_qa_key():
    spec = _spec([{'type': 'title', 'note': NOTE}],
                 qa={'check_source_refs': False})
    assert not any('unknown key' in w for w in spec.warnings)
    report = qa_check.check_deck(spec, _result([_rec(1, 'title')]))
    assert report['settings']['check_source_refs'] is False


# ─────────────────────── APA registry fields (C2) ───────────────────────

APA_BOOK = {'id': 'apa_book', 'kind': 'book', 'authors': 'Иванов И. И.',
            'year': 2020, 'title': 'Численные методы',
            'publisher': 'Наука', 'url': 'https://example.com/book'}

APA_INTERNAL = {'id': 'apa_rag', 'kind': 'internal',
                'authors': ['Петров, П. П.'], 'year': 2024,
                'title': 'Внутренний отчёт', 'internal': True,
                'url': 'https://internal.example/doc/7'}


def test_apa_fields_are_normalized():
    spec = _spec([{'type': 'title', 'note': NOTE}], sources=[APA_BOOK])
    entry = spec.meta['sources'][0]
    assert entry['authors'] == ['Иванов И. И.']
    assert entry['year'] == '2020'
    assert spec.warnings == []


def test_internal_source_loses_its_url_with_a_warning():
    spec = _spec([{'type': 'title', 'note': NOTE}], sources=[APA_INTERNAL])
    entry = spec.meta['sources'][0]
    assert 'url' not in entry
    assert any('internal source keeps no url' in w for w in spec.warnings)


def test_literature_uses_apa_when_the_registry_has_apa_data():
    spec = _spec([{'type': 'literature', 'source_refs': ['apa_book'],
                   'note': NOTE}], sources=[APA_BOOK])
    text = spec.slides[0]['items'][0]['text']
    assert text.startswith('Иванов, И. И. (2020).')
    assert '*Численные методы*' in text
    assert text.endswith('https://example.com/book')


def test_literature_keeps_the_title_for_legacy_entries():
    spec = _spec([{'type': 'literature', 'source_refs': ['survey'],
                   'note': NOTE}], sources=[SOURCE_B])
    assert spec.slides[0]['items'][0] == {'text': 'Обзор рынка аналитики'}


def test_internal_literature_entry_has_no_hyperlink():
    spec = _spec([{'type': 'literature', 'source_refs': ['apa_rag'],
                   'note': NOTE}], sources=[APA_INTERNAL])
    item = spec.slides[0]['items'][0]
    assert item['text'].startswith('Петров, П. П. (2024).')
    assert 'url' not in item


def test_known_citation_marker_is_accepted():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Рост 47% [@handbook]'], 'note': NOTE}],
                 sources=[SOURCE_A])
    assert not any('citation marker' in w for w in spec.warnings)


def test_unknown_citation_marker_warns():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Рост 47% [@ghost]'], 'note': NOTE}],
                 sources=[SOURCE_A])
    assert any("citation marker '@ghost' is not in meta.sources" in w
               for w in spec.warnings)


def test_citation_markers_in_notes_are_ignored():
    spec = _spec([{'type': 'title', 'note': NOTE + ' [@ghost]'}])
    assert not any('citation marker' in w for w in spec.warnings)


def test_check_apa_is_a_known_qa_key():
    spec = _spec([{'type': 'title', 'note': NOTE}], qa={'check_apa': False})
    assert not any('unknown key' in w for w in spec.warnings)
