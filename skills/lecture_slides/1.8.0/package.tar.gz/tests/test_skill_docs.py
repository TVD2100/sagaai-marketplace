"""Docs contract: the skill must tell the agent how to read its own files.

``SKILL.md`` reaches the agent through ``get_skill_prompt()``, but every OTHER
file of the bundle (``CHANGELOG.md``, ``docs/limitations.md``, the helper
modules) lives OUTSIDE the target workspace. ``read_file`` / ``verify_file``
are scoped to the workspace root and reject such a path with "Path escapes
project root" - real dialogs showed the agent retrying ``read_file`` on
``SKILL.md`` and on the bundle files, wasting a whole loop cycle each time.
The only reliable reader is ``get_skill_file``, so the instruction has to say
so explicitly. These tests freeze that wording: a future edit must not drop
it silently.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _skill_text() -> str:
    return (ROOT / 'SKILL.md').read_text(encoding='utf-8')


def test_skill_md_names_the_only_reader_that_works():
    text = _skill_text()
    assert 'get_skill_file' in text


def test_skill_md_warns_about_read_file_scope():
    """The instruction must name the failure and the tool domain."""
    text = _skill_text()
    assert 'Path escapes project root' in text
    assert 'read_file' in text


def test_reading_section_precedes_the_copy_step():
    """The rule is read BEFORE the bundle is copied into the project."""
    text = _skill_text()
    read_at = text.index("Read the skill's own files")
    copy_at = text.index('Attach the bundle to the working project')
    assert read_at < copy_at


def test_other_bundle_files_point_at_get_skill_file():
    """CHANGELOG and docs must be reachable through the documented tool."""
    text = _skill_text()
    assert "get_skill_file(<id>, 'docs/limitations.md')" in text
    assert "get_skill_file(<id>, 'CHANGELOG.md')" in text


def test_skill_md_documents_the_drift_check():
    """The agent must know to check an existing deck before rebuilding it."""
    text = _skill_text()
    assert 'check_drift' in text
    assert 'drift' in text.lower()


def test_skill_md_requires_a_direct_question_to_the_user():
    """A hand-edited deck must never be overwritten silently."""
    text = _skill_text()
    flat = ' '.join(line.lstrip('> ').strip() for line in text.splitlines())
    flat = ' '.join(flat.split())
    assert 'Обновить исходники в соответствии с вашими правками' in flat
    assert 'acknowledge_manual_edits' in text
    question_at = text.index('Обновить исходники в соответствии')
    deliver_at = text.index('Deliver and self-check')
    assert question_at < deliver_at, 'the drift rule belongs before delivery'


def test_skill_md_names_the_ack_file():
    text = _skill_text()
    assert 'drift_ack.json' in text
