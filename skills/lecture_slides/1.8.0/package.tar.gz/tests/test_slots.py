"""Tests for template slots: fewer data elements than template slots.

A layout slide (``cards`` / ``timeline`` / ``process``) may declare
``slots`` - the number of places its template has. When the data holds
fewer elements, the empty slot groups must be removed entirely (no frame,
no marker, no caption), while the filled elements keep the template grid
positions; QA reports orphaned slot decorations as errors.

Written BEFORE the feature existed: on the the earlier code ``slots`` was an
unknown spec key and no slot bookkeeping existed, so every test here
failed with a feature mismatch.
"""

from __future__ import annotations

import pytest

from lecture import build_deck, themes, validate_spec

NOTE = ('Слоты шаблона: пустые группы не рисуются, заполненные элементы '
        'сохраняют позиции сетки, а осиротевшая графика блокирует поставку.')

ITEMS4 = [
    {'title': 'A', 'text': 'Первый элемент данных для проверки слотов.'},
    {'title': 'B', 'text': 'Второй элемент данных для проверки слотов.'},
    {'title': 'C', 'text': 'Третий элемент данных для проверки слотов.'},
    {'title': 'D', 'text': 'Четвёртый элемент данных для проверки слотов.'},
]

TIMELINE3 = [
    {'label': '2021', 'text': 'Первый этап проекта.'},
    {'label': '2022', 'text': 'Второй этап проекта.'},
    {'label': '2023', 'text': 'Третий этап проекта.'},
]


def _spec(slide):
    slide = dict(slide)
    slide.setdefault('note', NOTE)
    return validate_spec({'meta': {'course': 'Курс', 'title': 'Слоты', 'lang': 'ru'},
                          'slides': [slide]})


def _build(spec, tmp_path, name):
    result = build_deck(spec, out_path=tmp_path / (name + '.pptx'),
                        assets_dir=tmp_path / (name + '_assets'))
    assert result['ok'] is True, result['errors']
    return result


# ------------------------------ spec level -------------------------------

def test_spec_keeps_valid_slots_and_drops_useless_ones():
    kept = _spec({'type': 'cards', 'header': 'Команда', 'slots': 4,
                  'columns': 2, 'items': ITEMS4[:3]})
    assert kept.slides[0].get('slots') == 4
    assert not [w for w in kept.warnings if 'slots' in w]

    useless = _spec({'type': 'cards', 'header': 'Команда', 'slots': 3,
                     'columns': 2, 'items': ITEMS4[:3]})
    assert 'slots' not in useless.slides[0]
    assert any("'slots' ignored" in w for w in useless.warnings)


def test_spec_rejects_invalid_slot_values():
    for bad in (0, 13, 'много', 2.5):
        spec = _spec({'type': 'timeline', 'header': 'Хронология', 'slots': bad,
                      'items': TIMELINE3[:1]})
        assert 'slots' not in spec.slides[0], bad
        assert any("'slots' ignored" in w for w in spec.warnings), bad


# ------------------------------- geometry --------------------------------

def test_cards_keep_template_positions_and_drop_empty_groups(tmp_path):
    spec = _spec({'type': 'cards', 'header': 'Команда проекта', 'slots': 6,
                  'columns': 2, 'items': ITEMS4})
    result = _build(spec, tmp_path, 'cards_slots')
    x, y = themes.MARGIN_X, themes.BODY_TOP
    w = themes.CONTENT_W
    area_h = themes.BODY_H
    gap = 0.28
    cell_w = (w - gap) / 2
    cell_h = (area_h - 2 * gap) / 3
    cards = [b for b in result['records'][0]['boxes'] if b['kind'] == 'card']
    assert [b['slot'] for b in cards] == [0, 1, 2, 3]
    for index, box in enumerate(cards):
        row, col = divmod(index, 2)
        assert box['x'] == pytest.approx(x + col * (cell_w + gap), abs=0.01)
        assert box['y'] == pytest.approx(y + row * (cell_h + gap), abs=0.01)
        assert box['w'] == pytest.approx(cell_w, abs=0.01)
        assert box['h'] == pytest.approx(cell_h, abs=0.01)
    assert result['records'][0]['slots'] == {'declared': 6, 'filled': 4, 'removed': 2}


def test_timeline_markers_stay_on_the_template_grid(tmp_path):
    spec = _spec({'type': 'timeline', 'header': 'Хронология', 'slots': 4,
                  'items': TIMELINE3})
    result = _build(spec, tmp_path, 'timeline_slots')
    x, y = themes.MARGIN_X, themes.BODY_TOP
    w = themes.CONTENT_W
    h = themes.BODY_H
    col_w = w / 4
    radius = 0.085
    line_y = y + 0.30 * h
    markers = [b for b in result['records'][0]['boxes'] if b['kind'] == 'slot_marker']
    assert [b['slot'] for b in markers] == [0, 1, 2]
    for index, box in enumerate(markers):
        center = x + col_w * (index + 0.5)
        assert box['x'] == pytest.approx(center - radius, abs=0.01)
        assert box['y'] == pytest.approx(line_y - radius, abs=0.01)
    assert result['records'][0]['slots'] == {'declared': 4, 'filled': 3, 'removed': 1}


def test_process_steps_stay_on_the_template_grid(tmp_path):
    spec = _spec({'type': 'process', 'header': 'Порядок разбора', 'slots': 5,
                  'items': ['Подготовка', 'Основной шаг', 'Проверка']})
    result = _build(spec, tmp_path, 'process_slots')
    x, y = themes.MARGIN_X, themes.BODY_TOP
    h = themes.BODY_H
    gap = 0.14
    circle = 0.40
    step_h = (h - gap * 4) / 5
    markers = [b for b in result['records'][0]['boxes'] if b['kind'] == 'slot_marker']
    assert [b['slot'] for b in markers] == [0, 1, 2]
    for index, box in enumerate(markers):
        assert box['x'] == pytest.approx(x, abs=0.01)
        assert box['y'] == pytest.approx(y + index * (step_h + gap), abs=0.01)
        assert box['w'] == pytest.approx(circle, abs=0.01)
    assert result['records'][0]['slots'] == {'declared': 5, 'filled': 3, 'removed': 2}


# --------------------------------- QA ------------------------------------

def test_qa_flags_orphaned_slot_decoration(tmp_path):
    from qa_check import check_deck
    spec = _spec({'type': 'cards', 'header': 'Команда проекта', 'slots': 6,
                  'columns': 2, 'items': ITEMS4})
    result = _build(spec, tmp_path, 'qa_orphan')
    result['records'][0]['boxes'].append({
        'kind': 'card', 'slot': 5, 'x': 1.0, 'y': 1.0, 'w': 1.0, 'h': 1.0,
        'need_h': None, 'overflow': False, 'font_pt': None, 'error': False,
    })
    report = check_deck(spec, result)
    assert any('orphaned slot' in e for e in report['errors'])


def test_qa_requires_slot_bookkeeping(tmp_path):
    from qa_check import check_deck
    spec = _spec({'type': 'cards', 'header': 'Команда проекта', 'slots': 6,
                  'columns': 2, 'items': ITEMS4})
    result = _build(spec, tmp_path, 'qa_book')
    del result['records'][0]['slots']
    report = check_deck(spec, result)
    assert any('slot bookkeeping' in e for e in report['errors'])


def test_qa_clean_deck_has_no_slot_errors(tmp_path):
    from qa_check import check_deck
    spec = _spec({'type': 'cards', 'header': 'Команда проекта', 'slots': 6,
                  'columns': 2, 'items': ITEMS4})
    result = _build(spec, tmp_path, 'qa_clean')
    report = check_deck(spec, result)
    assert not [e for e in report['errors'] if 'slot' in e.lower()]


def test_full_deck_with_slots_has_no_orphaned_graphics(tmp_path):
    from qa_check import check_deck
    spec = validate_spec({'meta': {'course': 'Курс', 'title': 'Слоты', 'lang': 'ru'},
                          'slides': [
                              {'type': 'cards', 'header': 'Команда', 'slots': 6,
                               'columns': 2, 'items': ITEMS4, 'note': NOTE},
                              {'type': 'timeline', 'header': 'Хронология', 'slots': 4,
                               'items': TIMELINE3, 'note': NOTE},
                              {'type': 'process', 'header': 'Порядок', 'slots': 5,
                               'items': ['Подготовка', 'Основной шаг', 'Проверка'],
                               'note': NOTE},
                          ]})
    result = _build(spec, tmp_path, 'slots_deck')
    books = [rec.get('slots') for rec in result['records']]
    assert [b['removed'] for b in books] == [2, 1, 2]
    report = check_deck(spec, result)
    assert not [e for e in report['errors'] if 'slot' in e.lower()]
