"""Tests for the declared environment requirements.

The runtime requirements used to live only as prose in ``SKILL.md``: a host
could not check them ahead of time and hit the failure in the middle of a
build. They are now declared machine-readably in ``compatibility.json``
(required/optional python imports, executables, fonts, python version) and
a standard-library-only preflight command names every missing component -
with an install hint - before the build starts. A missing optional
component (LibreOffice) is reported as an unmet precondition with clear
text, never a traceback; a missing required component exits with code 2.

Written BEFORE the feature existed and failed on the the earlier code: there
was no ``compatibility.json``, no ``preflight`` entry point and no
``--check-env`` flag, so ``import preflight`` raised ModuleNotFoundError.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import preflight
from build_lecture import main as build_main

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_IDS = ('python-pptx', 'Pillow', 'matplotlib', 'pygments')


# ------------------------------ declaration ------------------------------

def test_declaration_is_machine_readable():
    data = preflight.load_requirements()
    by_id = {requirement['id']: requirement for requirement in data['requirements']}
    for req_id in REQUIRED_IDS:
        assert by_id[req_id]['severity'] == 'required', req_id
    assert by_id['LibreOffice']['severity'] == 'optional'
    for requirement in data['requirements']:
        assert requirement['why'] and requirement['probes'], requirement['id']
        for probe in requirement['probes']:
            assert probe['kind'] in preflight.PROBE_KINDS, (requirement['id'], probe)


def test_declaration_ids_appear_in_the_documentation():
    data = preflight.load_requirements()
    text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
    for requirement in data['requirements']:
        assert requirement['id'] in text, requirement['id']


def test_preflight_bootstraps_without_third_party_imports():
    """Module-level imports stay stdlib-only: the check must run on a broken host."""
    import ast
    tree = ast.parse(Path(preflight.__file__).read_text(encoding='utf-8'))
    allowed = {'__future__', 'argparse', 'importlib', 'json', 'platform',
               'shutil', 'sys', 'pathlib'}
    for node in tree.body:
        if isinstance(node, ast.Import):
            names = [alias.name for alias in node.names]
        elif isinstance(node, ast.ImportFrom):
            names = [node.module or '']
        else:
            continue
        for name in names:
            assert name.split('.')[0] in allowed, name


# ------------------------------- host check ------------------------------

def test_check_environment_passes_on_this_host():
    report = preflight.check_environment()
    assert report['ok'] is True
    by_id = {entry['id']: entry for entry in report['requirements']}
    for req_id in REQUIRED_IDS:
        assert by_id[req_id]['ok'] is True, (req_id, by_id[req_id]['detail'])


def test_missing_libreoffice_is_a_named_precondition():
    report = preflight.check_environment(which=lambda name: None)
    assert report['ok'] is True                    # optional: does not block the build
    assert 'LibreOffice' in report['missing_optional']
    entry = next(e for e in report['requirements'] if e['id'] == 'LibreOffice')
    assert entry['severity'] == 'optional' and entry['ok'] is False
    assert 'not found' in entry['detail']
    text = preflight.report_text(report)
    assert '[MISSING] LibreOffice (optional)' in text
    assert 'PDF' in text
    assert 'unavailable' in text


def test_missing_required_component_fails_with_names_and_hints():
    report = preflight.check_environment(find_spec=lambda name: False)
    assert report['ok'] is False
    assert set(report['missing_required']) == set(REQUIRED_IDS)
    assert 'missing required components' in report['summary']
    text = preflight.report_text(report)
    assert '[MISSING] python-pptx (required)' in text
    assert 'pip install python-pptx' in text


# -------------------------------- CLI paths ------------------------------

def test_build_cli_check_env_passes_on_this_host(capsys):
    code = build_main(['--check-env'])
    out = capsys.readouterr().out
    assert code == 0
    assert 'Environment check for lecture-slides' in out
    assert '[OK] python-pptx' in out


def test_build_cli_check_env_reports_missing_libreoffice(capsys, monkeypatch):
    monkeypatch.setattr(preflight, '_default_which', lambda name: None)
    code = build_main(['--check-env'])
    out = capsys.readouterr().out
    assert code == 0
    assert '[MISSING] LibreOffice' in out
    assert 'unavailable' in out


def test_build_cli_check_env_fails_when_required_missing(capsys, monkeypatch):
    monkeypatch.setattr(preflight, '_default_find_spec', lambda name: False)
    code = build_main(['--check-env'])
    out = capsys.readouterr().out
    assert code == 2
    assert '[MISSING] python-pptx' in out


def test_build_cli_without_spec_or_flag_still_errors():
    with pytest.raises(SystemExit):
        build_main([])


def test_preflight_has_its_own_cli_entry(capsys):
    assert preflight.main([]) == 0
    out = capsys.readouterr().out
    assert 'Environment check for lecture-slides' in out
