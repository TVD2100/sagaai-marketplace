"""Tests for the A5 glyph-coverage audit (textfit -> deck -> QA wiring)."""

from __future__ import annotations

import pytest

import qa_check
from lecture import build_deck, textfit, validate_spec

MISSING = chr(0xE000)  # Private Use Area: XML-valid, unmapped by real fonts (audit sentinel)
NOTE = 'Заметка достаточной длины для прохождения порога качества.'


def _spec(**qa):
    """Minimal valid spec with the given qa.* overrides."""
    return validate_spec({
        'meta': {'title': 'Glyphs'},
        'qa': dict(qa),
        'slides': [{'type': 'title', 'note': 'x'}],
    })


def _result(missing):
    """Build result stub with one clean slide and the given glyph report."""
    return {
        'ok': True, 'errors': [], 'warnings': [],
        'records': [{'index': 1, 'type': 'bullets', 'note_words': 50,
                     'bullets': 3, 'code_lines': 0, 'boxes': [], 'empty': False}],
        'note_words': 50, 'duration_est_min': 5.0,
        'missing_glyphs': missing,
    }


# ---------------------------- textfit level ----------------------------

def test_clean_text_reports_nothing():
    assert textfit.missing_glyphs('Hello, world! 42 - Привет, мир.', 'arial') == []


def test_missing_glyph_is_reported():
    assert textfit.missing_glyphs('a %s b' % MISSING, 'arial') == [MISSING]


def test_whitespace_and_duplicates_are_skipped():
    text = '   ' + MISSING + ' ' + MISSING
    assert textfit.missing_glyphs(text, 'arial') == [MISSING]


@pytest.mark.parametrize('role', ['arial', 'georgia', 'courier'])
def test_every_text_role_reports_the_private_use_char(role):
    assert textfit.missing_glyphs('x' + MISSING, role) == [MISSING]


# ---------------------------- build level ----------------------------

def test_build_result_carries_missing_glyphs(tmp_path):
    spec = validate_spec({
        'meta': {'course': 'QA', 'title': 'Glyphs'},
        'slides': [{'type': 'bullets', 'header': 'Тест',
                    'items': ['плохой символ ' + MISSING], 'note': NOTE}],
    })
    result = build_deck(spec, out_path=tmp_path / 'glyphs.pptx')
    assert result['ok'] is True
    assert MISSING in result['missing_glyphs'].get('Arial', [])


def test_build_result_clean_for_plain_text(tmp_path):
    spec = validate_spec({
        'meta': {'course': 'QA', 'title': 'Glyphs'},
        'slides': [{'type': 'bullets', 'header': 'Тест',
                    'items': ['обычный текст без экзотики'], 'note': NOTE}],
    })
    result = build_deck(spec, out_path=tmp_path / 'plain.pptx')
    assert result['ok'] is True
    assert result['missing_glyphs'] == {}


# ---------------------------- QA wiring ----------------------------

def test_glyph_check_off_by_default():
    report = qa_check.check_deck(_spec(), _result({'Arial': [MISSING]}))
    assert report['ok'] is True
    assert not any('cannot draw' in w for w in report['warnings'])


def test_glyph_check_reports_when_enabled():
    report = qa_check.check_deck(_spec(check_glyphs=True), _result({'Arial': [MISSING]}))
    assert report['ok'] is True
    assert any("font 'Arial' cannot draw 1 character(s)" in w for w in report['warnings'])


def test_glyph_check_clean_when_nothing_missing():
    report = qa_check.check_deck(_spec(check_glyphs=True), _result({}))
    assert not any('cannot draw' in w for w in report['warnings'])


def test_glyph_warning_truncates_long_lists():
    chars = [chr(0xE000 + index) for index in range(15)]
    lines = qa_check._glyph_warnings({'Arial': chars})
    assert len(lines) == 1
    assert '15 character(s)' in lines[0]
    assert '(+3 more)' in lines[0]


def test_spec_accepts_check_glyphs_key():
    spec = _spec(check_glyphs=True)
    assert not any('check_glyphs' in w for w in spec.warnings)
