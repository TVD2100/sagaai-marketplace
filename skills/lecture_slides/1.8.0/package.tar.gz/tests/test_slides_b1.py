"""Tests for the B1 slide types: cards, timeline, process, compare.

Covers spec validation, the renderer registry invariant, per-theme smoke
builds of every new type and the text actually placed into the PPTX.
"""

from __future__ import annotations

import pytest

from lecture import slides as slides_module
from lecture import build_deck
from lecture.spec import SLIDE_TYPES, SpecError, validate_spec

THEMES = ('academic_blue', 'graphite', 'deep_green', 'burgundy')
NEW_TYPES = ('cards', 'timeline', 'process', 'compare')

NOTE = 'Заметка достаточной длины для прохождения порога качества.'
NOTE_QA = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
           'порог качества и не вызвать ошибок на этапе проверки.')


def _slide(stype, note=NOTE):
    """Return a minimal valid slide of the given new type."""
    if stype == 'cards':
        return {
            'type': 'cards', 'header': 'Три подхода', 'columns': 3,
            'caption': 'Карточки-акценты.',
            'items': [
                {'title': 'Первый', 'text': 'Краткое описание первого подхода.'},
                {'title': 'Второй', 'text': 'Краткое описание второго подхода.'},
                {'title': 'Третий', 'text': 'Краткое описание третьего подхода.'},
            ],
            'note': note,
        }
    if stype == 'timeline':
        return {
            'type': 'timeline', 'header': 'Этапы проекта',
            'items': [
                {'label': 'Этап 1', 'text': 'Сбор данных и постановка задачи.'},
                {'label': 'Этап 2', 'text': 'Обучение базовой модели.'},
                {'label': 'Этап 3', 'text': 'Оценка качества и внедрение.'},
            ],
            'note': note,
        }
    if stype == 'process':
        return {
            'type': 'process', 'header': 'Пайплайн', 'caption': 'Четыре шага обработки.',
            'items': ['Сбор данных из источников.', 'Очистка и подготовка признаков.',
                      'Обучение модели.', 'Валидация и внедрение.'],
            'note': note,
        }
    if stype == 'compare':
        return {
            'type': 'compare', 'header': 'Сравнение подходов',
            'left_label': 'Классический ML', 'right_label': 'Нейросети',
            'left': {'kind': 'bullets', 'items': ['Мало данных для обучения.',
                                                  'Прозрачные признаки.']},
            'right': {'kind': 'bullets', 'items': ['Нужны большие выборки.',
                                                   'Сложно интерпретировать.']},
            'verdict': 'Начните с классических моделей и усложняйте при необходимости.',
            'note': note,
        }
    raise AssertionError('unknown new type: %s' % stype)


def _spec(stype, theme='academic_blue', note=NOTE):
    return validate_spec({
        'meta': {'course': 'Курс', 'title': 'Тема', 'lang': 'ru', 'theme': theme},
        'slides': [_slide(stype, note=note)],
    })


# ────────────────────────── registry & validation ──────────────────────────

def test_renderers_cover_every_slide_type():
    assert set(slides_module.RENDERERS) == set(SLIDE_TYPES)


def test_new_types_are_in_slide_types():
    for stype in NEW_TYPES:
        assert stype in SLIDE_TYPES


def test_cards_valid_columns_kept():
    spec = _spec('cards')
    assert spec.slides[0]['columns'] == 3


def test_cards_invalid_columns_warns_and_ignores():
    spec = validate_spec({
        'meta': {'lang': 'ru'},
        'slides': [{'type': 'cards', 'items': ['Один вариант'], 'columns': 7,
                    'note': NOTE}],
    })
    assert 'columns' not in spec.slides[0]
    assert any("'columns' ignored" in w for w in spec.warnings)


def test_cards_item_without_text_raises():
    with pytest.raises(SpecError) as exc:
        validate_spec({'slides': [{'type': 'cards', 'items': [{'title': 'Без текста'}],
                                   'note': NOTE}]})
    assert "non-empty 'text'" in str(exc.value)


def test_timeline_unknown_key_warns():
    spec = validate_spec({'slides': [{'type': 'timeline', 'items': ['Текст'],
                                      'foo': 1, 'note': NOTE}]})
    assert any("unknown key 'foo'" in w for w in spec.warnings)


def test_compare_requires_both_sides():
    with pytest.raises(SpecError) as exc:
        validate_spec({'slides': [{'type': 'compare',
                                   'left': {'kind': 'bullets', 'items': ['a']},
                                   'note': NOTE}]})
    assert "missing required field 'right'" in str(exc.value)


def test_compare_unknown_block_kind_raises():
    with pytest.raises(SpecError) as exc:
        validate_spec({'slides': [{'type': 'compare', 'left': {'kind': 'video'},
                                   'right': {'kind': 'bullets', 'items': ['a']},
                                   'note': NOTE}]})
    assert 'unknown block kind' in str(exc.value)


def test_compare_non_string_verdict_warns():
    spec = validate_spec({'slides': [{'type': 'compare',
                                      'left': {'kind': 'bullets', 'items': ['a']},
                                      'right': {'kind': 'bullets', 'items': ['b']},
                                      'verdict': 5, 'note': NOTE}]})
    assert 'verdict' not in spec.slides[0]
    assert any("'verdict' must be a string" in w for w in spec.warnings)


# ─────────────────────────────── smoke builds ─────────────────────────────

@pytest.mark.parametrize('theme', THEMES)
@pytest.mark.parametrize('stype', NEW_TYPES)
def test_new_type_builds_in_every_theme(tmp_path, stype, theme):
    spec = _spec(stype, theme=theme)
    out = tmp_path / ('%s_%s.pptx' % (stype, theme))
    result = build_deck(spec, out_path=out, assets_dir=tmp_path / 'assets')
    assert result['errors'] == []
    assert result['ok'] is True
    assert result['slides'] == 1
    assert not result['records'][0]['empty']
    assert out.exists() and out.stat().st_size > 10000


@pytest.mark.parametrize('columns', [1, 2, 3, 4])
def test_cards_column_variants_build(tmp_path, columns):
    slide = _slide('cards')
    slide['columns'] = columns
    spec = validate_spec({
        'meta': {'course': 'Курс', 'title': 'Тема', 'lang': 'ru'},
        'slides': [slide],
    })
    out = tmp_path / ('cards_%d.pptx' % columns)
    result = build_deck(spec, out_path=out, assets_dir=tmp_path / 'assets')
    assert result['ok'] is True
    assert not result['records'][0]['empty']


def test_new_types_texts_visible_in_pptx(tmp_path):
    from pptx import Presentation
    expected = {
        'cards': ('Три подхода', 'Первый', 'описание третьего'),
        'timeline': ('Этапы проекта', 'Этап 2', 'Обучение базовой модели'),
        'process': ('Пайплайн', 'Очистка', 'Валидация'),
        'compare': ('Сравнение подходов', 'Классический ML', 'Начните'),
    }
    for stype, needles in expected.items():
        spec = _spec(stype)
        out = tmp_path / (stype + '.pptx')
        build_deck(spec, out_path=out, assets_dir=tmp_path / 'assets')
        prs = Presentation(str(out))
        joined = ' '.join(sh.text_frame.text for sh in prs.slides[0].shapes
                          if sh.has_text_frame)
        for needle in needles:
            assert needle in joined, (stype, needle)


def test_qa_pass_for_new_types(tmp_path):
    from qa_check import check_deck
    for stype in NEW_TYPES:
        spec = _spec(stype, note=NOTE_QA)
        out = tmp_path / (stype + '_qa.pptx')
        result = build_deck(spec, out_path=out, assets_dir=tmp_path / 'assets')
        report = check_deck(spec, result)
        assert report['errors'] == [], (stype, report['errors'])
        assert report['warnings'] == [], (stype, report['warnings'])
