"""Tests for renderer metric compatibility.

``textfit`` measures text with PIL against the font file that happens to be
installed, while PowerPoint renders the face named in the theme. The font
table declares per role whether those two agree (``textfit.metric_status``
and ``textfit.metrics_report``); roles that resolve to a non-compatible
fallback (DejaVu) get a larger width margin AND a QA warning saying the
text-fit check is approximate - never a silent PASS. The warning names the
affected roles (their font files and statuses), so the report shows which
elements were checked approximately.

These tests were written BEFORE the feature existed and failed on the
the earlier code: ``metric_status``/``safety_factor`` did not exist, the build
result carried no ``font_metrics``, and the QA report never mentioned
approximate text checks.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import qa_check
from lecture import build_deck, textfit, validate_spec

# 15 words: above the default min_note_words (12).
NOTE = ('Заметка достаточной длины для прохождения минимального порога '
        'качества проверки материала на этой лекции.')


def _dejavu(key):
    """Absolute path of a matplotlib DejaVu fallback font (always present)."""
    path = textfit._fallback_paths().get(key)
    assert path and Path(path).exists(), key
    return str(path)


def _spec():
    """Validated two-slide spec: header (Georgia) + bullets (Arial)."""
    return validate_spec({
        'meta': {'title': 'Font metrics', 'lang': 'ru'},
        'slides': [
            {'type': 'bullets', 'header': 'План лекции',
             'items': ['Постановка задачи о поиске корней уравнения',
                       'Идея линеаризации функции касательной прямой',
                       'Итерационная формула и скорость сходимости метода'],
             'note': NOTE},
        ],
    })


def _build(tmp_path):
    """Build the spec deck once; returns ``(spec, result)``."""
    spec = _spec()
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx',
                        assets_dir=tmp_path / 'assets')
    assert result['ok'] is True, result['errors']
    return spec, result


# ---------------------------- table level ----------------------------

def test_every_role_reports_a_known_status():
    report = textfit.metrics_report()
    assert set(report) == set(textfit.resolved_fonts())
    for role, info in report.items():
        assert info['status'] in ('yes', 'no', 'unknown'), (role, info)
        assert info['font'], role


def test_theme_fonts_are_metric_compatible_on_this_host():
    """With the real theme fonts installed every role resolves to 'yes'."""
    report = textfit.metrics_report()
    for role, path in textfit.resolved_fonts().items():
        name = Path(path).name.lower() if path else ''
        if 'dejavu' in name or 'liberationserif' in name:
            pytest.skip('fallback fonts active on this host: %s' % name)
        assert report[role]['status'] == 'yes', (role, path)


def test_dejavu_fallback_is_incompatible(monkeypatch):
    monkeypatch.setitem(textfit._PATH_CACHE, 'georgia', _dejavu('serif'))
    monkeypatch.setitem(textfit._PATH_CACHE, 'georgia_bold', _dejavu('serif_bold'))
    assert textfit.metric_status('georgia') == 'no'
    assert textfit.metric_status('georgia_bold') == 'no'


def test_unknown_local_face_is_unknown(monkeypatch):
    monkeypatch.setitem(textfit._PATH_CACHE, 'arial', '/fonts/MysteryFace.ttf')
    assert textfit.metric_status('arial') == 'unknown'


def test_incompatible_role_gets_a_larger_safety_margin(monkeypatch):
    exact = textfit.safety_factor('georgia')
    monkeypatch.setitem(textfit._PATH_CACHE, 'georgia', _dejavu('serif'))
    assert textfit.metric_status('georgia') == 'no'
    assert textfit.safety_factor('georgia') > exact


def test_measure_in_uses_the_safety_factor(monkeypatch):
    before = textfit.measure_in('abc', 'arial', 20)
    factor = textfit.safety_factor('arial')
    monkeypatch.setattr(textfit, 'safety_factor', lambda role: factor * 2.0)
    after = textfit.measure_in('abc', 'arial', 20)
    assert after == pytest.approx(before * 2.0)


# ---------------------------- build level ----------------------------

def test_build_result_carries_font_metrics(tmp_path):
    _, result = _build(tmp_path)
    metrics = result['font_metrics']
    assert set(metrics) == set(textfit.resolved_fonts())
    for info in metrics.values():
        assert info['status'] in ('yes', 'no', 'unknown')


def test_clean_build_has_no_approximate_warning(tmp_path):
    spec, result = _build(tmp_path)
    statuses = {info['status'] for info in result['font_metrics'].values()}
    if statuses != {'yes'}:
        pytest.skip('fallback fonts active on this host')
    report = qa_check.check_deck(spec, result)
    assert not any('approximate' in w for w in report['warnings'])


def test_fallback_fonts_produce_an_approximate_warning(tmp_path, monkeypatch):
    monkeypatch.setattr(textfit, '_FONT_CACHE', {})
    monkeypatch.setitem(textfit._PATH_CACHE, 'georgia', _dejavu('serif'))
    monkeypatch.setitem(textfit._PATH_CACHE, 'georgia_bold', _dejavu('serif_bold'))
    spec, result = _build(tmp_path)
    assert result['font_metrics']['georgia']['status'] == 'no'
    assert result['font_metrics']['georgia_bold']['status'] == 'no'
    report = qa_check.check_deck(spec, result)
    joined = ' | '.join(report['warnings'])
    assert 'approximate' in joined
    assert 'Georgia' in joined and 'Georgia Bold' in joined


def test_metrics_warning_respects_strict_mode(tmp_path, monkeypatch):
    monkeypatch.setitem(textfit._PATH_CACHE, 'georgia', _dejavu('serif'))
    spec, result = _build(tmp_path)
    report = qa_check.check_deck(spec, result, strict=True)
    assert report['ok'] is False
    assert any('approximate' in w for w in report['warnings'])


def test_missing_metrics_field_is_tolerated():
    """Older build results without ``font_metrics`` keep validating."""
    spec = _spec()
    result = {'ok': True, 'errors': [], 'warnings': [], 'note_words': 15,
              'duration_est_min': 0.1,
              'records': [{'index': 1, 'type': 'bullets', 'note_words': 15,
                           'bullets': 3, 'code_lines': 0, 'boxes': [],
                           'empty': False}]}
    report = qa_check.check_deck(spec, result)
    assert not any('approximate' in w for w in report['warnings'])
