"""Tests for the delivery gate: complete / delivery_ready / draft.

The QA verdict alone (``ok``) does not tell a finished deck from a draft
shipped with known caveats. Every report carries a delivery ``status``:

* ``complete`` - no errors and no warnings;
* ``delivery_ready`` - no errors, but the warnings travel forward as
  ``caveats``;
* ``draft`` - errors block delivery.

The status is derived, never trusted: ``qa_check.delivery_status``
recomputes it from the findings, ``verify_delivery`` refuses a report that
records ``complete`` while carrying warnings, and ``report_markdown``
renders the recomputed status - a draft cannot call itself complete.

Written BEFORE the feature existed and failed on the the earlier code: reports
carried no ``status``/``caveats`` keys and ``delivery_status`` /
``verify_delivery`` did not exist, so a deck with warnings could not be
told apart from a finished one.
"""

from __future__ import annotations

import json

import qa_check
from build_lecture import build
from lecture.spec import validate_spec

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')


def _spec():
    """Validated minimal spec: one title slide."""
    return validate_spec({'meta': {'title': 'Delivery gate', 'lang': 'ru'},
                          'slides': [{'type': 'title', 'note': NOTE}]})


def _rec(note_words=50, bullets=4):
    """Fabricated layout record matching the build output shape."""
    return {'index': 1, 'type': 'bullets', 'note_words': note_words,
            'bullets': bullets, 'code_lines': 0, 'boxes': [], 'empty': False}


def _result(records):
    """Build-result stub carrying only the fields the QA rules read."""
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': 5.0}


# -------------------------------- statuses --------------------------------

def test_clean_report_is_complete():
    report = qa_check.check_deck(_spec(), _result([_rec()]))
    assert report['ok'] is True
    assert report['status'] == 'complete'
    assert report['caveats'] == []
    assert qa_check.verify_delivery(report)['ok'] is True


def test_warning_report_is_delivery_ready_with_caveats():
    report = qa_check.check_deck(_spec(), _result([_rec(bullets=8)]))
    assert report['ok'] is True               # warnings do not block delivery
    assert report['status'] == 'delivery_ready'
    assert report['caveats'] == report['warnings']
    assert any('8 list items' in caveat for caveat in report['caveats'])
    assert qa_check.verify_delivery(report)['ok'] is True


def test_error_report_is_draft():
    report = qa_check.check_deck(_spec(), _result([_rec(note_words=0)]))
    assert report['ok'] is False
    assert report['status'] == 'draft'
    assert qa_check.delivery_status(report) == 'draft'


# ------------------------------ anti-forgery ------------------------------

def test_forged_complete_status_is_refused():
    report = qa_check.check_deck(_spec(), _result([_rec(bullets=8)]))
    forged = dict(report, status='complete')  # edit the field by hand
    verdict = qa_check.verify_delivery(forged)
    assert verdict['ok'] is False
    assert verdict['recorded'] == 'complete'
    assert verdict['recomputed'] == 'delivery_ready'
    assert 'does not match' in verdict['reason']


def test_verify_delivery_refuses_a_report_without_status():
    verdict = qa_check.verify_delivery({'errors': [], 'warnings': []})
    assert verdict['ok'] is False
    assert 'no delivery status' in verdict['reason']


# --------------------------------- report ---------------------------------

def test_markdown_shows_complete():
    spec = _spec()
    report = qa_check.check_deck(spec, _result([_rec()]))
    text = qa_check.report_markdown(report, spec=spec)
    assert '- Delivery status: **complete**' in text


def test_markdown_carries_caveats_for_delivery_ready():
    spec = _spec()
    report = qa_check.check_deck(spec, _result([_rec(bullets=8)]))
    text = qa_check.report_markdown(report, spec=spec)
    assert '- Delivery status: **delivery_ready**' in text
    assert '## Caveats' in text
    assert '8 list items' in text


def test_markdown_ignores_a_forged_status():
    spec = _spec()
    report = qa_check.check_deck(spec, _result([_rec(bullets=8)]))
    forged = dict(report, status='complete')
    text = qa_check.report_markdown(forged, spec=spec)
    assert '- Delivery status: **delivery_ready**' in text
    assert '- Delivery status: **complete**' not in text


# ---------------------------------- build ----------------------------------

def test_build_reports_status_end_to_end(tmp_path, demo_spec_path):
    clean = build(demo_spec_path, tmp_path / 'demo.pptx', qa=True, qa_json=True)
    assert clean['qa']['status'] == 'complete'
    payload = json.loads((tmp_path / 'demo_service' / 'qa.json').read_text(encoding='utf-8'))
    assert payload['status'] == 'complete'
    assert payload['caveats'] == []

    dirty = {'meta': {'course': 'C', 'title': 'T', 'lang': 'ru'},
             'slides': [{'type': 'bullets', 'header': 'Много',
                         'items': ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
                         'note': NOTE}]}
    path = tmp_path / 'many.json'
    path.write_text(json.dumps(dirty, ensure_ascii=False), encoding='utf-8')
    res = build(path, tmp_path / 'many.pptx', qa=True)
    assert res['ok'] is True
    assert res['qa']['status'] == 'delivery_ready'
    assert any('7 list items' in caveat for caveat in res['qa']['caveats'])
    text = (tmp_path / 'many_service' / 'qa.md').read_text(encoding='utf-8')
    assert 'delivery_ready' in text and '## Caveats' in text
