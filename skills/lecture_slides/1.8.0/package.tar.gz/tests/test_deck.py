"""Unit tests for lecture.deck: demo build, records, notes, footer."""

from __future__ import annotations

from lecture import textfit, themes

EXPECTED_TYPES = [
    'title', 'steps_grid', 'definition', 'process', 'formula', 'theorem',
    'proof', 'two_column', 'section', 'code', 'table', 'summary',
    'homework', 'literature',
]


def test_demo_build_ok(demo_build):
    spec, result, pptx = demo_build
    assert result['ok'] is True
    assert result['errors'] == []
    assert result['slides'] == 14
    assert pptx.exists() and pptx.stat().st_size > 20000


def test_records_cover_every_slide_in_order(demo_build):
    spec, result, pptx = demo_build
    records = result['records']
    assert [rec['type'] for rec in records] == EXPECTED_TYPES
    assert [rec['index'] for rec in records] == list(range(1, 15))


def test_every_slide_has_real_notes(demo_build):
    spec, result, pptx = demo_build
    for rec in result['records']:
        assert rec['note_words'] >= 12, 'slide %s: %s words' % (rec['index'], rec['note_words'])


def test_notes_present_in_pptx_xml(demo_build):
    """The Notes Page carries UTF-8 Cyrillic text, not just placeholder shapes."""
    from pptx import Presentation
    spec, result, pptx = demo_build
    prs = Presentation(str(pptx))
    seen = 0
    for slide in prs.slides:
        assert slide.has_notes_slide
        text = slide.notes_slide.notes_text_frame.text.strip()
        assert text, 'empty notes on a slide'
        seen += 1
    assert seen == 14
    joined = ' '.join(slide.notes_slide.notes_text_frame.text for slide in prs.slides)
    assert 'Ньютон' in joined or 'касательн' in joined


def test_duration_estimate_plausible(demo_build):
    spec, result, pptx = demo_build
    assert 3.0 <= result['duration_est_min'] <= 25.0
    assert result['note_words'] == sum(rec['note_words'] for rec in result['records'])


def test_layout_records_have_boxes_within_slide(demo_build):
    spec, result, pptx = demo_build
    for rec in result['records']:
        for box in rec['boxes']:
            if box['kind'] in ('cover', 'section'):
                continue
            assert box['x'] >= -0.02, box
            assert box['y'] >= -0.02, box
            assert box['x'] + box['w'] <= themes.SLIDE_W + 0.02, box
            assert box['y'] + box['h'] <= themes.SLIDE_H + 0.02, box


def test_no_recorded_overflow_in_demo(demo_build):
    spec, result, pptx = demo_build
    for rec in result['records']:
        for box in rec['boxes']:
            assert not textfit.overflow(box.get('need_h'), box['h']), (rec['index'], box)
            assert not box.get('error'), (rec['index'], box)


def test_empty_slides_not_reported(demo_build):
    spec, result, pptx = demo_build
    assert all(not rec['empty'] for rec in result['records'])


def test_formulas_are_editable_omml_not_raster(demo_build):
    """the default mode embeds OMML and rasterizes no formula pictures."""
    spec, result, pptx = demo_build
    assert result['assets'] == []
    assert result['formula_modes']['omml'] >= 4
    assert result['formula_modes']['image'] == 0
    assert result['missing_images'] == []


def test_code_slide_counts_lines(demo_build):
    spec, result, pptx = demo_build
    code_recs = [rec for rec in result['records'] if rec['type'] == 'code']
    assert len(code_recs) == 1
    assert code_recs[0]['code_lines'] == 17


def test_bullets_counted_for_qa(demo_build):
    """List-like slides report their item counts; standalone blocks report zero."""
    spec, result, pptx = demo_build
    by_index = {rec['index']: rec for rec in result['records']}
    assert by_index[2]['bullets'] == 0    # steps_grid is a tile grid, not a list
    assert by_index[4]['bullets'] == 0    # process is a numbered spine
    assert by_index[7]['bullets'] == 5    # proof steps count as list items
    assert by_index[8]['bullets'] == 5    # two_column left block
    assert by_index[5]['bullets'] == 0    # formula slide
    assert by_index[3]['bullets'] == 0    # definition slide


def test_footer_present_on_content_slides(demo_build):
    """Content slides carry footer text shapes; the cover does not."""
    from pptx import Presentation
    from pptx.util import Emu
    spec, result, pptx = demo_build
    prs = Presentation(str(pptx))
    footer_y = themes.FOOTER_Y
    for i, slide in enumerate(prs.slides, start=1):
        texts = [shape.text_frame.text for shape in slide.shapes
                 if shape.has_text_frame and shape.text_frame.text.strip()]
        if i == 1:
            continue  # cover draws its own meta block
        low = [shape for shape in slide.shapes
               if shape.has_text_frame and shape.top is not None
               and shape.top >= Emu(int(footer_y * 914400)) - Emu(9144)]
        assert low, 'no footer text shape on slide %d' % i


def test_footers_use_footer_left_override(tmp_path):
    """meta.footer_left lands in the rendered footer text."""
    from pptx import Presentation
    from lecture import build_deck, validate_spec
    spec = validate_spec({
        'meta': {'course': 'Курс', 'title': 'Тема', 'lang': 'ru',
                 'footer_left': 'Спецкурс «Анализ»'},
        'slides': [{'type': 'bullets', 'header': 'План', 'items': ['Один пункт'],
                    'note': 'Заметка достаточной длины для порога качества.'}],
    })
    out = tmp_path / 'footer.pptx'
    result = build_deck(spec, out_path=out)
    assert result['ok'] and out.exists()
    prs = Presentation(str(out))
    pages = [shape.text_frame.text for shape in prs.slides[0].shapes
             if shape.has_text_frame]
    assert any('Спецкурс' in t for t in pages)


def test_lang_en_uses_english_labels(tmp_path):
    from pptx import Presentation
    from lecture import build_deck, validate_spec
    spec = validate_spec({
        'meta': {'course': 'Course', 'title': 'Topic', 'lang': 'en'},
        'slides': [{'type': 'definition', 'term': 'Root', 'text': 'A point where f(x)=0.',
                    'note': 'Explain the definition of a root to the audience carefully.'}],
    })
    out = tmp_path / 'en.pptx'
    result = build_deck(spec, out_path=out)
    assert result['ok'] and out.exists()
    prs = Presentation(str(out))
    texts = [shape.text_frame.text for shape in prs.slides[0].shapes
             if shape.has_text_frame]
    joined = ' '.join(texts)
    assert 'Definition' in joined and 'Определение' not in joined


def test_short_bullet_list_is_vertically_centered(tmp_path):
    """A short list is vertically centered in its body frame, not top-hugging."""
    from pptx import Presentation
    from lecture import build_deck, validate_spec, themes
    spec = validate_spec({
        'meta': {'course': 'Курс', 'title': 'Тема', 'lang': 'ru'},
        'slides': [{'type': 'bullets', 'header': 'План', 'items': ['Один пункт'],
                    'note': 'Заметка достаточной длины для порога качества.'}],
    })
    out = tmp_path / 'centered.pptx'
    result = build_deck(spec, out_path=out)
    assert result['ok'] and out.exists()
    prs = Presentation(str(out))
    boxes = [sh for sh in prs.slides[0].shapes
             if sh.has_text_frame and 'Один пункт' in sh.text_frame.text]
    assert len(boxes) == 1
    top_in = boxes[0].top / 914400.0
    assert top_in > themes.BODY_TOP + 0.5, 'list is not centered (top=%.2f)' % top_in


def test_formula_slide_long_caption_does_not_overflow(tmp_path):
    """A multi-line 'where ...' caption shrinks the formula area instead of overflowing."""
    from lecture import build_deck, validate_spec
    spec = validate_spec({
        'meta': {'course': 'Курс', 'title': 'Тема', 'lang': 'ru'},
        'slides': [{'type': 'formula', 'header': 'Формула', 'formula': ['y = a x + b'],
                    'caption': ('где x - значение признака; y - целевая переменная; '
                                'a - коэффициент наклона; b - свободный член.'),
                    'note': 'Заметка достаточной длины для порога качества.'}],
    })
    out = tmp_path / 'formula_caption.pptx'
    result = build_deck(spec, out_path=out)
    assert result['ok'] and out.exists()
    for rec in result['records']:
        for box in rec['boxes']:
            assert not box['overflow'], box

