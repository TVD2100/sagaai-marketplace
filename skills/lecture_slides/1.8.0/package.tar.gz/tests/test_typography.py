"""Tests for the typography (dash) QA rule.

The audit of the course decks found hyphens used as em dashes in the
visible Russian text ('слово - слово' instead of 'слово \u2014 слово'):
up to 52 occurrences in one lesson. The QA pass now flags them
(``qa.check_dashes``, on by default) and can rewrite the visible text
(``meta.normalize_dashes``, off by default).

The rule is deliberately conservative: only a hyphen between two Cyrillic
letters is a dash. Math expressions ('x\u00b2 - 2 = 0'), Latin contexts
('where x - the value') and bibliographic strings ('. - 3rd ed.') are left
alone - a typography check that flags correct math is worse than none.
Notes, code and formulas are never scanned or rewritten.

Written BEFORE the feature existed: on the the earlier code ``check_dashes``
and ``meta.normalize_dashes`` were unknown keys, no warning was produced
and no text was rewritten, so every test below failed.
"""

from __future__ import annotations

import qa_check
from lecture import build_deck, validate_spec
from lecture.spec import normalize_dashes

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')


# ─────────────────────────── helpers ───────────────────────────

def _spec(slides, qa=None, **meta):
    meta.setdefault('title', 'Typography')
    meta.setdefault('lang', 'ru')
    payload = {'meta': meta, 'slides': slides}
    if qa is not None:
        payload['qa'] = qa
    return validate_spec(payload)


def _rec(index=1, stype='bullets'):
    return {'index': index, 'type': stype, 'note_words': 50, 'bullets': 0,
            'code_lines': 0, 'boxes': [], 'empty': False}


def _result(records=None):
    records = records or [_rec()]
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': 5.0}


def _dash_warnings(report):
    return [w for w in report['warnings'] if 'hyphen used as a dash' in w]


# ─────────────────────────── rewrite helper ───────────────────────────

def test_normalize_replaces_a_prose_dash():
    assert normalize_dashes('Первый вопрос - второй ответ') == 'Первый вопрос \u2014 второй ответ'


def test_normalize_keeps_math_and_latin():
    assert normalize_dashes('Уравнение x\u00b2 - 2 = 0') == 'Уравнение x\u00b2 - 2 = 0'
    assert normalize_dashes('where x - the value') == 'where x - the value'


def test_normalize_keeps_existing_em_dash():
    assert normalize_dashes('Слово \u2014 слово') == 'Слово \u2014 слово'


# ─────────────────────────── detection ───────────────────────────

def test_prose_hyphen_is_flagged():
    spec = _spec([{'type': 'bullets', 'header': 'План',
                   'items': ['Первый вопрос - второй ответ'], 'note': NOTE}])
    report = qa_check.check_deck(spec, _result())
    warnings = _dash_warnings(report)
    assert warnings and 'slide 1 (bullets)' in warnings[0]
    assert 'use an em dash' in warnings[0]


def test_em_dash_is_clean():
    spec = _spec([{'type': 'bullets', 'header': 'План',
                   'items': ['Первый вопрос \u2014 второй ответ'], 'note': NOTE}])
    report = qa_check.check_deck(spec, _result())
    assert _dash_warnings(report) == []


def test_math_and_latin_contexts_are_not_flagged():
    spec = _spec([{'type': 'bullets', 'header': 'План',
                   'items': ['Уравнение x\u00b2 - 2 = 0', 'where x - the value'],
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result())
    assert _dash_warnings(report) == []


def test_notes_code_and_formulas_are_not_scanned():
    slides = [
        {'type': 'bullets', 'header': 'План', 'items': ['Нормальный пункт'],
         'note': 'Заметка с дефисом - как в этом примере, но её не сканируем.'},
        {'type': 'code', 'header': 'Код', 'language': 'python',
         'code': 'a = b - c', 'note': NOTE},
        {'type': 'formula', 'header': 'Формула', 'formula': 'x_{n+1} = x_n',
         'note': NOTE},
    ]
    report = qa_check.check_deck(spec := _spec(slides),
                                 _result([_rec(1), _rec(2, 'code'), _rec(3, 'formula')]))
    assert _dash_warnings(report) == []
    del spec


def test_check_dashes_can_be_disabled():
    spec = _spec([{'type': 'bullets', 'header': 'План',
                   'items': ['Первый вопрос - второй ответ'], 'note': NOTE}],
                 qa={'check_dashes': False})
    report = qa_check.check_deck(spec, _result())
    assert report['settings']['check_dashes'] is False
    assert _dash_warnings(report) == []


def test_slide_rows_carry_the_dash_count():
    spec = _spec([{'type': 'bullets', 'header': 'План',
                   'items': ['Первый вопрос - второй ответ',
                             'Второй вопрос - третий ответ'], 'note': NOTE}])
    report = qa_check.check_deck(spec, _result())
    assert report['slide_rows'][0]['dashes'] == 2


def test_spec_accepts_the_dash_keys():
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': ['Ок'],
                   'note': NOTE}], qa={'check_dashes': False},
                 normalize_dashes=True)
    assert not any('unknown key' in w for w in spec.warnings)
    assert spec.meta.get('normalize_dashes') is True


# ─────────────────────────── normalization ───────────────────────────

def test_normalize_dashes_rewrites_visible_text():
    spec = _spec([{'type': 'bullets', 'header': 'План',
                   'items': ['Первый вопрос - второй ответ'], 'note': NOTE}],
                 normalize_dashes=True)
    assert spec.slides[0]['items'][0] == 'Первый вопрос \u2014 второй ответ'
    report = qa_check.check_deck(spec, _result())
    assert _dash_warnings(report) == []


def test_normalize_dashes_leaves_code_notes_and_formulas():
    payload = {
        'meta': {'title': 'T', 'lang': 'ru', 'normalize_dashes': True},
        'slides': [
            {'type': 'code', 'header': 'Код', 'language': 'python', 'code': 'a = b - c',
             'note': 'Заметка - с дефисом.'},
            {'type': 'formula', 'header': 'Ф', 'formula': 'x_{n} = y_{n}', 'note': NOTE},
        ],
    }
    spec = validate_spec(payload)
    assert spec.slides[0]['code'] == 'a = b - c'
    assert spec.slides[0]['note'] == 'Заметка - с дефисом.'
    assert spec.slides[1]['formula'] == ['x_{n} = y_{n}']


def test_normalized_deck_text_uses_em_dash(tmp_path):
    from pptx import Presentation
    spec = _spec([{'type': 'bullets', 'header': 'План',
                   'items': ['Первый вопрос - второй ответ'], 'note': NOTE}],
                 normalize_dashes=True)
    out = tmp_path / 'dash.pptx'
    result = build_deck(spec, out_path=out, assets_dir=tmp_path / 'assets')
    assert result['ok'] is True, result['errors']
    prs = Presentation(str(out))
    joined = ' '.join(shape.text_frame.text for shape in prs.slides[0].shapes
                      if shape.has_text_frame)
    assert '\u2014' in joined
    assert ' - ' not in joined
