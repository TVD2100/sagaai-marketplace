"""Tests for the APA 7th reference module (C2).

A lecture deck must let the audience verify every case, quote and figure:
the claim carries an APA in-text citation in the same bullet, and an
external source makes that citation clickable. A source taken from an
internal knowledge base keeps the APA wording but carries no link,
because the audience cannot follow one.

Covered: entry normalisation, author/year handling, the full reference for
books, journal articles, web pages and internal sources, the in-text
label, clickable citation markup, ``[@id]`` expansion and the QA
predicates (quote and case detection, APA-looking captions).
"""

from __future__ import annotations

import qa_check
from lecture import apa
from lecture import validate_spec

BOOK = {
    'id': 'press2007', 'kind': 'book',
    'authors': ['Press W. H.', 'Teukolsky S. A.'], 'year': 2007,
    'title': 'Numerical Recipes', 'publisher': 'Cambridge University Press',
    'url': 'https://numerical.recipes/',
}
ARTICLE = {
    'id': 'smith2019', 'kind': 'article', 'authors': ['Smith, J.'],
    'year': 2019, 'title': 'Deep learning in practice',
    'container': 'Journal of AI', 'volume': '12', 'issue': '3',
    'pages': '45-67', 'doi': '10.1000/xyz123',
}
WEB = {
    'id': 'lms', 'kind': 'web', 'authors': ['Иванов, И. И.'],
    'year': 2026, 'title': 'Конспект лекции', 'date': '2026-10-01',
    'url': 'https://lms.example.edu/x',
}
INTERNAL = {
    'id': 'rag1', 'kind': 'internal', 'authors': ['Петров, П. П.'],
    'year': 2024, 'title': 'Внутренний отчёт о рынке', 'internal': True,
    'rag_base': 'marketing', 'url': 'https://internal.example/doc/42',
}
NO_AUTHOR = {'id': 'anon', 'title': 'Отчёт о рынке', 'year': 2021,
             'url': 'https://example.com/report'}
NO_DATE = {'id': 'gost', 'kind': 'web', 'authors': ['ГОСТ'],
           'title': 'Стандарт оформления', 'url': 'https://example.com/gost'}


# ─────────────────────────── normalisation ───────────────────────────

def test_authors_accept_a_string_and_a_list():
    assert apa.normalize_entry({'authors': 'Иванов, И. И.'})['authors'] == ['Иванов, И. И.']
    assert apa.normalize_entry({'authors': ['A', 'B']})['authors'] == ['A', 'B']


def test_bad_author_shapes_warn_and_are_dropped():
    warnings = []
    clean = apa.normalize_entry({'id': 'x', 'authors': 5}, warnings, 'meta.sources[1]')
    assert 'authors' not in clean
    assert any("'authors' must be a string or a list" in w for w in warnings)


def test_year_is_normalised_to_a_string():
    assert apa.normalize_entry({'year': 2020})['year'] == '2020'
    assert apa.normalize_entry({'year': '2020a'})['year'] == '2020a'
    assert 'year' not in apa.normalize_entry({'year': True})


def test_apa_fields_are_trimmed_and_empties_dropped():
    clean = apa.normalize_entry({'container': '  Journal  ', 'pages': '   ', 'doi': ' 10.1/x '})
    assert clean == {'container': 'Journal', 'doi': '10.1/x'}


def test_normalize_keeps_unknown_keys():
    clean = apa.normalize_entry({'id': 'x', 'title': 'T', 'custom': 42})
    assert clean['custom'] == 42


# ─────────────────────────── author helpers ───────────────────────────

def test_author_initials_move_after_the_comma():
    assert apa.apa_author('Press W. H.') == 'Press, W. H.'
    assert apa.apa_author('van der Berg J.') == 'van der Berg, J.'
    assert apa.apa_author('Иванов, И. И.') == 'Иванов, И. И.'
    assert apa.apa_author('ГОСТ') == 'ГОСТ'


# ─────────────────────────── full references ───────────────────────────

def test_book_reference_carries_publisher_and_url():
    text = apa.format_apa(BOOK, 'en')
    assert text.startswith('Press, W. H., & Teukolsky, S. A. (2007).')
    assert 'Numerical Recipes' in text
    assert 'Cambridge University Press' in text
    assert text.endswith('https://numerical.recipes/')


def test_article_reference_uses_volume_issue_pages_and_doi():
    text = apa.format_apa(ARTICLE, 'en')
    assert text.startswith('Smith, J. (2019).')
    assert 'Journal of AI, 12(3), 45-67' in text
    assert text.endswith('https://doi.org/10.1000/xyz123')


def test_article_markup_italicises_title_journal_and_volume_only():
    text = apa.format_apa(ARTICLE, 'en', markup=True)
    assert '*Deep learning in practice*' in text
    assert '*Journal of AI*' in text
    assert '*12*(3)' in text
    assert '45-67' in text


def test_web_reference_carries_the_calendar_date():
    text = apa.format_apa(WEB, 'ru')
    assert text.startswith('Иванов, И. И. (2026, 1 октября).')
    assert text.endswith('https://lms.example.edu/x')


def test_internal_source_keeps_apa_but_has_no_link():
    text = apa.format_apa(INTERNAL, 'ru')
    assert text.startswith('Петров, П. П. (2024).')
    assert 'Внутренний отчёт о рынке' in text
    assert 'https://internal.example/doc/42' not in text
    assert '[Внутренний источник, база знаний «marketing»]' in text


def test_internal_source_without_base_gets_the_short_note():
    entry = dict(INTERNAL)
    entry.pop('rag_base')
    assert '[Внутренний источник]' in apa.format_apa(entry, 'ru')


def test_reference_without_author_moves_the_title_forward():
    text = apa.format_apa(NO_AUTHOR, 'ru')
    assert text.startswith('Отчёт о рынке (2021).')


def test_reference_without_a_year_uses_the_no_date_marker():
    assert apa.format_apa(NO_DATE, 'ru').startswith('ГОСТ (б. г.).')
    assert apa.format_apa(NO_DATE, 'en').startswith('ГОСТ (n.d.).')


def test_ready_made_apa_text_wins():
    entry = {'id': 'x', 'title': 'T', 'apa': 'Готовое описание источника.'}
    assert apa.format_apa(entry) == 'Готовое описание источника.'


def test_has_apa_data_separates_legacy_entries():
    assert apa.has_apa_data(BOOK) is True
    assert apa.has_apa_data({'id': 'x', 'title': 'T', 'url': 'https://e.com'}) is False


# ─────────────────────────── in-text labels ───────────────────────────

def test_intext_one_author_uses_the_surname_and_year():
    assert apa.intext(ARTICLE, 'en') == '(Smith, 2019)'
    assert apa.intext(BOOK, 'en') == '(Press & Teukolsky, 2007)'


def test_intext_russian_joins_two_authors_with_i():
    assert apa.intext(BOOK, 'ru') == '(Press и Teukolsky, 2007)'


def test_intext_three_authors_use_et_al():
    entry = {'authors': ['A, A.', 'B, B.', 'C, C.'], 'year': 2020}
    assert apa.intext(entry, 'en') == '(A et al., 2020)'
    assert apa.intext(entry, 'ru') == '(A и др., 2020)'


def test_intext_page_suffix_follows_the_language():
    assert apa.intext(BOOK, 'ru', page='12') == '(Press и Teukolsky, 2007, с. 12)'
    assert apa.intext(ARTICLE, 'en', page='p. 7') == '(Smith, 2019, p. 7)'


def test_intext_without_authors_uses_the_short_title():
    assert apa.intext(NO_AUTHOR, 'ru') == '("Отчёт о рынке", 2021)'


def test_intext_without_a_year_uses_the_no_date_marker():
    assert apa.intext(NO_DATE, 'en') == '(ГОСТ, n.d.)'


# ─────────────────────────── clickable citations ───────────────────────────

def test_external_source_becomes_clickable_markup():
    markup = apa.citation_markup(ARTICLE, 'en')
    assert markup == '[(Smith, 2019)](https://doi.org/10.1000/xyz123)'


def test_internal_source_stays_plain_text():
    assert apa.citation_markup(INTERNAL, 'ru') == '(Петров, 2024)'


def test_url_is_used_before_the_doi():
    entry = dict(ARTICLE, url='https://example.com/paper')
    assert apa.doi_url(entry) == 'https://example.com/paper'


def test_unsafe_url_is_ignored():
    entry = {'id': 'x', 'title': 'T', 'url': 'javascript:alert(1)'}
    assert apa.doi_url(entry) == ''


# ─────────────────────────── marker expansion ───────────────────────────

def test_marker_expands_to_a_clickable_citation():
    text = apa.expand_citations('Рост 47% [@smith2019].', [ARTICLE], 'en')
    assert text == 'Рост 47% [(Smith, 2019)](https://doi.org/10.1000/xyz123).'


def test_marker_with_a_page_keeps_the_page():
    text = apa.expand_citations('Цитата [@press2007, с. 12]', [BOOK], 'ru')
    assert '(Press и Teukolsky, 2007, с. 12)' in text


def test_internal_marker_expands_without_a_link():
    text = apa.expand_citations('Кейс [@rag1]', [INTERNAL], 'ru')
    assert text == 'Кейс (Петров, 2024)'


def test_unknown_marker_is_left_for_the_spec_validation():
    assert apa.expand_citations('Текст [@ghost]', [BOOK], 'ru') == 'Текст [@ghost]'


def test_expand_slide_skips_notes_code_and_formulas():
    slide = {
        'type': 'bullets', 'header': 'Рынок [@smith2019]',
        'items': ['Рост [@smith2019]'], 'note': 'Заметка [@smith2019]',
        'code': 'x = "[@smith2019]"', 'formula': '[@smith2019]',
        'caption': 'Данные [@smith2019]',
    }
    out = apa.expand_slide(slide, [ARTICLE], 'en')
    assert 'https://doi.org' in out['header']
    assert 'https://doi.org' in out['items'][0]
    assert out['note'] == 'Заметка [@smith2019]'
    assert out['code'] == 'x = "[@smith2019]"'
    assert out['formula'] == '[@smith2019]'
    assert 'https://doi.org' in out['caption']


def test_expand_slide_walks_two_column_blocks():
    slide = {'type': 'two_column', 'note': 'n',
             'left': {'kind': 'bullets', 'items': ['Цифра [@smith2019]']},
             'right': {'kind': 'paragraphs', 'items': ['Абзац [@smith2019]']}}
    out = apa.expand_slide(slide, [ARTICLE], 'en')
    assert 'https://doi.org' in out['left']['items'][0]
    assert 'https://doi.org' in out['right']['items'][0]


# ─────────────────────────── QA predicates ───────────────────────────

def test_apa_caption_recognises_a_year_in_parentheses():
    assert apa.has_apa_caption('Рост 47% (Smith, 2019).') is True
    assert apa.has_apa_caption('Рост 47% (Smith, 2019, p. 12).') is True
    assert apa.has_apa_caption('Рост 47% (Smith, б. г.).') is True
    assert apa.has_apa_caption('Уравнение (x, y) и точка (5, 7).') is False


def test_quote_detection_handles_both_bracket_styles():
    assert apa.find_quotes('Он сказал «это важно» и "that too"') == [
        '«это важно»', '"that too"']
    assert apa.find_quotes('Без кавычек') == []


def test_case_detection_ignores_plain_examples():
    assert apa.find_case_markers('Кейс компании X') == ['кейс']
    assert apa.find_case_markers('Case study: рынок') == ['case study']
    assert apa.find_case_markers('Пример: вычисление корня') == []


def test_reference_text_requires_a_year_in_parentheses():
    assert apa.is_reference_text('Press, W. H. (2007). Numerical Recipes.') is True
    assert apa.is_reference_text('Просто название книги') is False


# ─────────────────────── rendered deck (C2) ───────────────────────

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')

EXTERNAL = {'id': 'src', 'kind': 'article', 'authors': ['Иванов, И. И.'],
            'year': 2020, 'title': 'Рост рынка', 'container': 'Экономика',
            'url': 'https://example.com/paper'}

RAG = {'id': 'rag', 'kind': 'internal', 'authors': ['Петров, П. П.'],
       'year': 2024, 'title': 'Внутренний отчёт', 'internal': True}


def _build(spec, out):
    """Validate and build a minimal RU spec; returns the pptx path."""
    from lecture import build_deck, validate_spec
    validated = validate_spec(spec)
    result = build_deck(validated, out_path=out)
    assert result['ok'] is True, result['errors']
    return out


def _slide_links(path):
    """Texts and hyperlink addresses of every run on every slide."""
    from pptx import Presentation
    prs = Presentation(str(path))
    texts, links = [], []
    for slide in prs.slides:
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            texts.append(shape.text_frame.text)
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if run.hyperlink.address:
                        links.append(run.hyperlink.address)
    return ' '.join(texts), links


def test_external_marker_renders_a_clickable_apa_citation(tmp_path):
    path = _build({'meta': {'title': 'T', 'lang': 'ru', 'sources': [EXTERNAL]},
                   'slides': [{'type': 'bullets', 'header': 'Рынок',
                               'items': ['Рост 47% [@src]'], 'note': NOTE}]},
                  tmp_path / 'external.pptx')
    text, links = _slide_links(path)
    assert '(Иванов, 2020)' in text
    assert '[@' not in text
    assert 'https://example.com/paper' in links


def test_internal_marker_renders_a_plain_apa_citation(tmp_path):
    path = _build({'meta': {'title': 'T', 'lang': 'ru', 'sources': [RAG]},
                   'slides': [{'type': 'bullets', 'header': 'Кейс',
                               'items': ['Кейс компании [@rag]'], 'note': NOTE}]},
                  tmp_path / 'internal.pptx')
    text, links = _slide_links(path)
    assert '(Петров, 2024)' in text
    assert links == []


def test_literature_slide_renders_apa_and_its_link(tmp_path):
    path = _build({'meta': {'title': 'T', 'lang': 'ru', 'sources': [EXTERNAL]},
                   'slides': [{'type': 'literature', 'source_refs': ['src'],
                               'note': NOTE}]},
                  tmp_path / 'lit.pptx')
    text, links = _slide_links(path)
    assert 'Иванов, И. И. (2020).' in text
    assert 'Рост рынка' in text
    assert 'https://example.com/paper' in links


# ─────────────────────── APA QA rule (C2) ───────────────────────

APA_SOURCE = {'id': 'apa', 'kind': 'article', 'authors': ['Иванов, И. И.'],
              'year': 2020, 'title': 'Рост рынка',
              'url': 'https://example.com/paper'}

RAG_SOURCE = {'id': 'rag', 'kind': 'internal', 'authors': ['Петров, П. П.'],
              'year': 2024, 'title': 'Внутренний отчёт', 'internal': True}


def _apa_warnings(report):
    """QA warnings produced by the APA reference rule only."""
    return [w for w in report['warnings']
            if 'APA reference' in w or 'has no APA data' in w]


SOURCE_B = {'id': 'survey', 'title': 'Обзор рынка аналитики'}


def _spec(slides, sources=None, qa=None):
    """Validate a minimal RU spec with the given slides and sources."""
    meta = {'title': 'APA QA', 'lang': 'ru'}
    if sources is not None:
        meta['sources'] = sources
    payload = {'meta': meta, 'slides': slides}
    if qa:
        payload['qa'] = qa
    return validate_spec(payload)


def _rec(index, stype):
    """Fabricated layout record matching the build output shape."""
    return {'index': index, 'type': stype, 'note_words': 50, 'bullets': 0,
            'code_lines': 0, 'boxes': [], 'empty': False}


def _result(records):
    """Build-result stub carrying only the fields the QA rules read."""
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': 5.0}


def test_quote_without_a_reference_warns():
    spec = _spec([{'type': 'bullets', 'header': 'Мнение',
                   'items': ['Эксперт заметил «рынок растёт быстро»'],
                   'note': NOTE}], sources=[APA_SOURCE])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert any('quote' in w for w in _apa_warnings(report))


def test_quote_with_source_refs_is_clean():
    spec = _spec([{'type': 'bullets', 'header': 'Мнение',
                   'items': ['Эксперт заметил «рынок растёт быстро»'],
                   'source_refs': ['apa'], 'note': NOTE}], sources=[APA_SOURCE])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _apa_warnings(report)


def test_case_without_a_reference_warns():
    spec = _spec([{'type': 'cards', 'header': 'Практика',
                   'items': [{'title': 'Кейс', 'text': 'Компания выросла втрое'}],
                   'note': NOTE}], sources=[APA_SOURCE])
    report = qa_check.check_deck(spec, _result([_rec(1, 'cards')]))
    assert any('case' in w for w in _apa_warnings(report))


def test_inline_apa_caption_replaces_the_nag():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Рост 47% (Иванов, 2020)'], 'note': NOTE}],
                 sources=[APA_SOURCE])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _apa_warnings(report)


def test_internal_quote_with_a_caption_is_clean():
    spec = _spec([{'type': 'bullets', 'header': 'Кейс',
                   'items': ['«Рост втрое» (Петров, 2024)'], 'note': NOTE}],
                 sources=[RAG_SOURCE])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _apa_warnings(report)


def test_source_without_apa_data_warns_once():
    spec = _spec([{'type': 'title', 'note': NOTE}], sources=[SOURCE_B])
    report = qa_check.check_deck(spec, _result([_rec(1, 'title')]))
    assert any("source 'survey' has no APA data" in w
               for w in _apa_warnings(report))


def test_apa_rule_is_silent_without_a_registry():
    spec = _spec([{'type': 'bullets', 'header': 'Мнение',
                   'items': ['Эксперт заметил «рынок растёт»'], 'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _apa_warnings(report)


def test_apa_rule_can_be_disabled():
    spec = _spec([{'type': 'bullets', 'header': 'Мнение',
                   'items': ['Эксперт заметил «рынок растёт»'], 'note': NOTE}],
                 sources=[APA_SOURCE], qa={'check_apa': False})
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not _apa_warnings(report)


def test_marker_citation_satisfies_the_source_ref_rule():
    spec = _spec([{'type': 'bullets', 'header': 'Рынок',
                   'items': ['Доля выросла до 47% [@apa]'], 'note': NOTE}],
                 sources=[APA_SOURCE])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not any('without a source' in w for w in report['warnings'])
    assert not _apa_warnings(report)


def test_internal_literature_source_needs_no_url():
    spec = _spec([{'type': 'literature', 'source_refs': ['rag'],
                   'note': NOTE}], sources=[RAG_SOURCE])
    report = qa_check.check_deck(spec, _result([_rec(1, 'literature')]))
    assert not any('has no url' in w for w in report['warnings'])
    assert not any('has no hyperlinks' in w for w in report['warnings'])
