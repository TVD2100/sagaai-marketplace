"""Tests for the visual slide types added in 1.5.0.

The audited course decks kept short parallel points on ``bullets`` slides:
the text filled the upper part of the body frame and the lower third stayed
empty. Stretching item spacing only made the defect visible, so three visual
types are added instead - ``steps_grid`` (numbered tiles), ``pillars``
(full-height columns) and ``focus`` (statement banner plus supports).

Every test measures the built pptx and the recorded layout boxes, so it
describes rendered geometry rather than the intent. Written before the
renderers existed: on the 1.4.x code the spec rejected all three types, so
every test below failed.
"""

from __future__ import annotations

import pytest
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE

from lecture import build_deck, themes, validate_spec
from lecture.slides import RENDERERS

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')

FOUR_SHORT = ['Смешивают GRP и TRP', 'Считают охват без частоты',
              'Бюджет от возможностей', 'Нет контроля до старта']

THREE_TITLED = [{'title': 'Реклама', 'text': 'Платное неличное обращение'},
                {'title': 'PR', 'text': 'Репутация и доверие'},
                {'title': 'Личные продажи', 'text': 'Прямой контакт'}]


def _spec(slides, **meta):
    """Validate a minimal RU spec with the given slides and meta overrides."""
    meta.setdefault('course', 'Курс')
    meta.setdefault('title', 'Макет')
    meta.setdefault('lang', 'ru')
    return validate_spec({'meta': meta, 'slides': slides})


def _build(spec, tmp_path, name):
    """Build the spec into ``<name>.pptx``; returns the build result."""
    out = tmp_path / (name + '.pptx')
    result = build_deck(spec, out_path=out, assets_dir=tmp_path / (name + '_assets'))
    assert result['ok'] is True, result['errors']
    return result


def _boxes(record, kind=None):
    """Layout boxes of a record, optionally filtered by kind."""
    boxes = list(record['boxes'])
    if kind is None:
        return boxes
    return [box for box in boxes if box['kind'] == kind]


def _cards(shape_list):
    """Heights (inches) of the rounded rectangles drawn on a slide."""
    heights = []
    for shape in shape_list:
        try:
            kind = shape.auto_shape_type
        except (ValueError, AttributeError):
            continue
        if kind == MSO_SHAPE.ROUNDED_RECTANGLE:
            heights.append(shape.height / 914400.0)
    return heights


# ──────────────────────── registry and validation ────────────────────────

def test_new_types_are_registered_and_valid():
    """Every new type has a renderer and passes spec validation."""
    for stype in ('steps_grid', 'pillars', 'focus'):
        assert stype in RENDERERS, stype
    spec = _spec([
        {'type': 'steps_grid', 'header': 'Сетка', 'items': FOUR_SHORT, 'note': NOTE},
        {'type': 'pillars', 'header': 'Колонны', 'items': THREE_TITLED, 'note': NOTE},
        {'type': 'focus', 'header': 'Тезис', 'statement': 'Главный тезис',
         'supports': ['Опора один', 'Опора два'], 'note': NOTE},
    ])
    assert [slide['type'] for slide in spec.slides] == ['steps_grid', 'pillars', 'focus']


def test_missing_required_fields_are_rejected():
    """Each new type names its required field in the error."""
    with pytest.raises(Exception) as exc:
        _spec([{'type': 'focus', 'header': 'Тезис'}])
    assert 'statement' in ' '.join(str(e) for e in exc.value.errors)
    with pytest.raises(Exception) as exc:
        _spec([{'type': 'steps_grid', 'header': 'Сетка'}])
    assert 'items' in ' '.join(str(e) for e in exc.value.errors)


def test_slots_keep_the_template_grid():
    """``slots`` above the item count is kept; a smaller value is dropped."""
    spec = _spec([{'type': 'steps_grid', 'header': 'Сетка', 'items': FOUR_SHORT,
                   'slots': 6, 'note': NOTE},
                  {'type': 'steps_grid', 'header': 'Вторая', 'items': FOUR_SHORT,
                   'slots': 2, 'note': NOTE}])
    assert spec.slides[0]['slots'] == 6
    assert 'slots' not in spec.slides[1]
    assert any('slots' in message for message in spec.warnings)


# ────────────────────────────── steps_grid ──────────────────────────────

def test_steps_grid_fills_the_body_frame(tmp_path):
    """Four short points become a 2x2 tile grid reaching the frame bottom."""
    spec = _spec([{'type': 'steps_grid', 'header': 'Ошибки медиаплана',
                   'items': FOUR_SHORT, 'note': NOTE}])
    result = _build(spec, tmp_path, 'grid')
    cards = _boxes(result['records'][0], 'card')
    assert len(cards) == 4, cards
    bottom = max(box['content_bottom'] for box in cards)
    assert bottom >= themes.BODY_TOP + 0.9 * themes.BODY_H, bottom
    heights = _cards(Presentation(str(tmp_path / 'grid.pptx')).slides[0].shapes)
    assert heights and min(heights) >= 1.6, heights


def test_steps_grid_picks_three_columns_for_many_tiles(tmp_path):
    """Six points fall into a 3x2 grid; four stay in a 2x2 grid."""
    six = FOUR_SHORT + ['Нет медиамикса', 'Игнорируют сезонность']
    spec = _spec([{'type': 'steps_grid', 'header': 'Шесть', 'items': six, 'note': NOTE},
                  {'type': 'steps_grid', 'header': 'Четыре', 'items': FOUR_SHORT,
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'gridcols')
    first = _boxes(result['records'][0], 'card')
    second = _boxes(result['records'][1], 'card')
    assert len({box['y'] for box in first}) == 2, first
    assert len({box['y'] for box in second}) == 2, second
    # Three columns are narrower than two.
    assert first[0]['w'] < second[0]['w'], (first[0]['w'], second[0]['w'])


def test_steps_grid_never_overflows(tmp_path):
    """Long tile captions shrink instead of overflowing their box."""
    long_items = ['Длинный пункт про смешение метрик охвата и частоты контакта',
                  'Второй длинный пункт про бюджет, который считают от возможностей',
                  'Третий пункт про отсутствие контроля до старта кампании',
                  'Четвёртый пункт про перенос бюджета без анализа результата']
    spec = _spec([{'type': 'steps_grid', 'header': 'Длинные', 'items': long_items,
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'gridlong')
    for box in _boxes(result['records'][0]):
        if box['need_h'] is not None:
            assert box['need_h'] <= box['h'] + 0.02, box


# ─────────────────────────────── pillars ───────────────────────────────

def test_pillars_columns_reach_the_frame_bottom(tmp_path):
    """Every column is a full-height card with a header band on top."""
    spec = _spec([{'type': 'pillars', 'header': 'Элементы комплекса',
                   'items': THREE_TITLED, 'note': NOTE}])
    result = _build(spec, tmp_path, 'pillars')
    cards = _boxes(result['records'][0], 'card')
    assert len(cards) == 3, cards
    for box in cards:
        assert box['content_bottom'] >= themes.BODY_TOP + 0.95 * themes.BODY_H, box
    heights = _cards(Presentation(str(tmp_path / 'pillars.pptx')).slides[0].shapes)
    tall = [height for height in heights if height >= 2.0]
    assert len(tall) == 3 and min(tall) >= 4.6, heights


def test_pillars_header_band_keeps_one_line(tmp_path):
    """A long column title shrinks to a single line instead of breaking."""
    items = [{'title': 'Стимулирование сбыта', 'text': 'Краткосрочный эффект'},
             {'title': 'Прямой маркетинг', 'text': 'Адресное обращение'},
             {'title': 'Связи с общественностью', 'text': 'Репутация'},
             {'title': 'Личные продажи', 'text': 'Прямой контакт'}]
    spec = _spec([{'type': 'pillars', 'header': 'Комплекс', 'items': items, 'note': NOTE}])
    result = _build(spec, tmp_path, 'pillarslong')
    heads = _boxes(result['records'][0], 'card_head')
    assert len(heads) == 4, heads
    for box in heads:
        assert box['font_pt'] >= 11.0, box
        assert box['need_h'] <= box['h'] + 0.02, box


# ──────────────────────────────── focus ────────────────────────────────

def test_focus_renders_banner_and_supports(tmp_path):
    """The statement gets a wide banner, the supports a row of cards."""
    spec = _spec([{'type': 'focus', 'header': 'Сверка с источником',
                   'statement': 'Каждый тезис деки опирается на конкретный источник',
                   'supports': ['Убирает утверждения из воздуха', 'Даёт APA-ссылку',
                                'Позволяет проверить атрибуцию'],
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'focus')
    cards = _boxes(result['records'][0], 'card')
    assert len(cards) == 4, cards          # banner + three supports
    banner = max(cards, key=lambda box: box['w'])
    assert banner['w'] >= 0.9 * themes.CONTENT_W, banner
    supports = [box for box in cards if box is not banner]
    assert len(supports) == 3, cards
    assert len({box['w'] for box in supports}) == 1, supports


def test_focus_without_supports_keeps_the_banner(tmp_path):
    """A statement-only focus slide is legal and draws no support cards."""
    spec = _spec([{'type': 'focus', 'header': 'Тезис',
                   'statement': 'Один главный тезис без опор', 'note': NOTE}])
    result = _build(spec, tmp_path, 'focusonly')
    cards = _boxes(result['records'][0], 'card')
    assert len(cards) == 1, cards


# ───────────────────────── QA metrics of new types ─────────────────────────

def test_new_types_pass_the_frame_fill_and_void_checks(tmp_path):
    """No empty-space and no frame-fill warning for the three new types."""
    import qa_check

    spec = _spec([
        {'type': 'steps_grid', 'header': 'Сетка', 'items': FOUR_SHORT, 'note': NOTE},
        {'type': 'pillars', 'header': 'Колонны', 'items': THREE_TITLED, 'note': NOTE},
        {'type': 'focus', 'header': 'Тезис',
         'statement': 'Каждый тезис опирается на конкретный источник',
         'supports': ['Убирает утверждения из воздуха', 'Даёт APA-ссылку'],
         'note': NOTE},
    ])
    result = _build(spec, tmp_path, 'metrics')
    report = qa_check.check_deck(spec, result)
    assert report['errors'] == [], report['errors']
    assert report['warnings'] == [], report['warnings']


# ─────────────────── documented field shapes actually work ────────────────

def test_focus_supports_accept_the_documented_dict_shape(tmp_path):
    """``supports`` given as {text} must render the text, not a Python repr.

    SKILL.md documents ``supports`` as a list of strings or ``{text}``; the
    dict form used to be stringified verbatim, so the slide showed a literal
    "{'text': ...}" instead of the support.
    """
    spec = _spec([{'type': 'focus', 'header': 'Тезис',
                   'statement': 'Тезис опирается на источник',
                   'supports': [{'text': 'Убирает утверждения из воздуха'},
                                {'text': 'Даёт APA-ссылку'}], 'note': NOTE}])
    assert spec.slides[0]['supports'] == ['Убирает утверждения из воздуха',
                                          'Даёт APA-ссылку']
    result = _build(spec, tmp_path, 'focusdict')
    prs = Presentation(str(tmp_path / 'focusdict.pptx'))
    texts = ' '.join(shape.text_frame.text for shape in prs.slides[0].shapes
                     if shape.has_text_frame)
    assert 'Убирает утверждения из воздуха' in texts
    assert "{'text'" not in texts


def test_pillars_columns_build_a_grid_instead_of_one_row(tmp_path):
    """``columns`` (documented 2-4) wraps pillars into rows; it used to be
    accepted by the spec and silently ignored by the renderer, which always
    put every item into one flat row."""
    items = [{'title': 'Реклама', 'text': 'Платное обращение'},
             {'title': 'PR', 'text': 'Репутация'},
             {'title': 'Личные продажи', 'text': 'Прямой контакт'},
             {'title': 'Стимулирование', 'text': 'Краткосрочный эффект'}]
    spec = _spec([{'type': 'pillars', 'header': 'Комплекс', 'columns': 2,
                   'items': items, 'note': NOTE}])
    result = _build(spec, tmp_path, 'pillarscols')
    cards = _boxes(result['records'][0], 'card')
    assert len(cards) == 4, cards
    top_row = [box for box in cards if abs(box['y'] - cards[0]['y']) < 0.01]
    bottom_row = [box for box in cards if box['y'] > cards[0]['y'] + 0.01]
    assert len(top_row) == 2 and len(bottom_row) == 2, cards
    for box in cards:
        assert box['h'] > 0.5, box


def test_focus_columns_wrap_supports_into_a_grid(tmp_path):
    """``columns`` on a focus slide wraps the supports into rows.

    SKILL.md documented ``columns`` for ``focus`` while the spec rejected the
    field and the renderer hard-capped the supports at three per row.
    """
    spec = _spec([{'type': 'focus', 'header': 'Тезис',
                   'statement': 'Тезис опирается на источники',
                   'columns': 2,
                   'supports': ['Первый довод', 'Второй довод',
                                'Третий довод', 'Четвёртый довод'], 'note': NOTE}])
    assert spec.slides[0]['columns'] == 2
    result = _build(spec, tmp_path, 'focuscols')
    supports = [box for box in _boxes(result['records'][0], 'card')
                if box.get('slot') is not None]
    assert len(supports) == 4, supports
    first = supports[0]
    same_row = [b for b in supports if abs(b['y'] - first['y']) < 0.01]
    lower = [b for b in supports if b['y'] > first['y'] + 0.01]
    assert len(same_row) == 2 and len(lower) == 2, supports


def test_focus_without_supports_leaves_no_deep_void(tmp_path):
    """A statement-only focus slide must not leave empty space under the
    banner: the QA void metric used to report ~4 in for it."""
    import qa_check

    spec = _spec([{'type': 'focus', 'header': 'Главный тезис',
                   'statement': 'Медиаплан проверяем: каждое число имеет источник',
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'focusvoid')
    report = qa_check.check_deck(spec, result)
    void_warnings = [w for w in report['warnings'] if 'empty space' in w]
    assert void_warnings == [], void_warnings


def test_pillars_invalid_columns_is_ignored_with_a_warning(tmp_path):
    """An out-of-range ``columns`` value is dropped with a warning, not kept."""
    spec = _spec([{'type': 'pillars', 'header': 'Колонны', 'columns': 7,
                   'items': THREE_TITLED, 'note': NOTE}])
    assert 'columns' not in spec.slides[0]
    assert any("'columns' ignored" in w for w in spec.warnings), spec.warnings
