"""Tests for lecture.drift: spotting a PPTX edited by hand.

The deck is generated from a spec, but the lecturer may open the pptx and
edit it in PowerPoint. The spec then stops describing the file and the next
rebuild would destroy those edits silently. ``drift.compare`` rebuilds the
spec in a temp folder and compares the decks by text, so these tests cover
the three outcomes the agent must distinguish: in sync, drifted, and drifted
but explicitly acknowledged by the user.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pptx import Presentation

from build_lecture import build
from lecture import drift

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества проверки материала лекции для студентов.')


def _payload():
    return {'meta': {'course': 'Численные методы', 'title': 'Дрейф', 'lang': 'ru'},
            'slides': [
                {'type': 'bullets', 'header': 'План',
                 'items': ['Первый пункт', 'Второй пункт'], 'note': NOTE},
                {'type': 'definition', 'term': 'Сходимость',
                 'text': 'Погрешность убывает на каждой итерации.', 'note': NOTE},
            ]}


def _build(tmp_path, name='deck'):
    spec_path = tmp_path / 'lecture.json'
    spec_path.write_text(json.dumps(_payload(), ensure_ascii=False), encoding='utf-8')
    out = tmp_path / (name + '.pptx')
    result = build(spec_path, out, qa=False)
    assert result['ok'] is True, result['errors']
    return spec_path, out


def _edit_first_bullet(pptx_path, new_text):
    """Rewrite the first text run of slide 1, like a human edit in PowerPoint."""
    presentation = Presentation(str(pptx_path))
    for shape in presentation.slides[0].shapes:
        if not getattr(shape, 'has_text_frame', False):
            continue
        for paragraph in shape.text_frame.paragraphs:
            if paragraph.runs:
                paragraph.runs[0].text = new_text
                presentation.save(str(pptx_path))
                return new_text
    raise AssertionError('no text run found on slide 1')


def _edit_first_note(pptx_path, extra):
    """Append a sentence to the speaker notes of slide 1."""
    presentation = Presentation(str(pptx_path))
    notes = presentation.slides[0].notes_slide.notes_text_frame
    notes.paragraphs[0].text = (notes.paragraphs[0].text or '') + ' ' + extra
    presentation.save(str(pptx_path))
    return extra


# ------------------------------ in sync ------------------------------

def test_fresh_build_is_in_sync(tmp_path):
    spec_path, out = _build(tmp_path)
    report = drift.compare(spec_path, out)
    assert report['errors'] == []
    assert report['changed'] is False
    assert report['ok'] is True
    assert report['slides'] == [] and report['notes'] == []
    assert report['counts']['deck'] == report['counts']['spec'] == 2


def test_rebuilding_twice_does_not_report_drift(tmp_path):
    """Two builds of one spec differ as zip bytes but carry the same text."""
    spec_path, first = _build(tmp_path, 'a')
    second = tmp_path / 'b.pptx'
    assert build(spec_path, second, qa=False)['ok'] is True
    for deck in (first, second):
        assert drift.compare(spec_path, deck)['changed'] is False


# -------------------------------- drift --------------------------------

def test_edited_slide_text_is_reported(tmp_path):
    spec_path, out = _build(tmp_path)
    marker = 'ПРАВКА ВРУЧНУЮ'
    _edit_first_bullet(out, marker)
    report = drift.compare(spec_path, out)
    assert report['changed'] is True
    assert report['ok'] is False
    added = [text for entry in report['slides'] for text in entry['user_added']]
    assert any(marker in text for text in added)
    assert report['slides'][0]['index'] >= 1


def test_edited_notes_are_reported(tmp_path):
    spec_path, out = _build(tmp_path)
    marker = 'добавлено вручную в заметки'
    _edit_first_note(out, marker)
    report = drift.compare(spec_path, out)
    assert report['changed'] is True
    assert report['notes'], 'a notes edit must land in the notes section'
    texts = [text for entry in report['notes'] for text in entry['user_text']]
    assert any(marker in text for text in texts)


def test_spec_change_after_build_is_reported(tmp_path):
    """The spec moved on: the rebuilt deck has text the saved deck lacks."""
    spec_path, out = _build(tmp_path)
    payload = _payload()
    payload['slides'][0]['items'].append('Третий пункт')
    spec_path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    report = drift.compare(spec_path, out)
    assert report['changed'] is True
    removed = [text for entry in report['slides'] for text in entry['user_removed']]
    assert any('Третий пункт' in text for text in removed)


def test_extra_slide_in_the_deck_is_reported(tmp_path):
    spec_path, out = _build(tmp_path)
    presentation = Presentation(str(out))
    blank = presentation.slide_layouts[6]
    presentation.slides.add_slide(blank)
    presentation.save(str(out))
    report = drift.compare(spec_path, out)
    assert report['changed'] is True
    assert report['counts']['deck'] == report['counts']['spec'] + 1
    assert 'slide count differs' in report['reason']


# ---------------------------- acknowledgment ----------------------------

def test_ack_makes_an_edited_deck_acceptable(tmp_path):
    spec_path, out = _build(tmp_path)
    _edit_first_bullet(out, 'ФИНАЛЬНАЯ РЕДАКЦИЯ')
    assert drift.compare(spec_path, out)['ok'] is False

    ack_file = drift.write_ack(out)
    assert Path(ack_file).exists()
    assert Path(ack_file).parent.name == 'deck_service'

    report = drift.compare(spec_path, out)
    assert report['changed'] is True
    assert report['acknowledged'] is True
    assert report['ok'] is True


def test_ack_goes_stale_after_another_edit(tmp_path):
    spec_path, out = _build(tmp_path)
    _edit_first_bullet(out, 'ПЕРВАЯ РЕДАКЦИЯ')
    drift.write_ack(out)
    assert drift.compare(spec_path, out)['acknowledged'] is True

    _edit_first_bullet(out, 'ВТОРАЯ РЕДАКЦИЯ')
    report = drift.compare(spec_path, out)
    assert report['acknowledged'] is False
    assert report['ok'] is False


def test_ack_for_a_missing_deck_is_ignored(tmp_path):
    assert drift.is_acknowledged(tmp_path / 'nope.pptx') is False
    with pytest.raises(FileNotFoundError):
        drift.write_ack(tmp_path / 'nope.pptx')


def test_flat_layout_keeps_the_ack_next_to_the_deck(tmp_path):
    spec_path, out = _build(tmp_path)
    ack_file = drift.write_ack(out, service_dir=False)
    assert Path(ack_file).parent == tmp_path
    assert drift.is_acknowledged(out, service_dir=False) is True


# -------------------------------- errors --------------------------------

def test_missing_deck_reports_an_error(tmp_path):
    spec_path, _ = _build(tmp_path)
    report = drift.compare(spec_path, tmp_path / 'gone.pptx')
    assert report['ok'] is False
    assert report['errors'] and 'deck not found' in report['errors'][0]


def test_unreadable_deck_reports_an_error(tmp_path):
    spec_path, _ = _build(tmp_path)
    broken = tmp_path / 'broken.pptx'
    broken.write_bytes(b'not a pptx')
    report = drift.compare(spec_path, broken)
    assert report['errors'] and 'not a readable pptx' in report['errors'][0]


def test_broken_spec_reports_an_error(tmp_path):
    _, out = _build(tmp_path)
    bad = tmp_path / 'bad.json'
    bad.write_text('{nope', encoding='utf-8')
    report = drift.compare(bad, out)
    assert report['errors']
    assert report['changed'] is False


# ------------------------------- reporting -------------------------------

def test_markdown_says_in_sync_or_drifted(tmp_path):
    spec_path, out = _build(tmp_path)
    text = drift.report_markdown(drift.compare(spec_path, out))
    assert 'In sync' in text

    _edit_first_bullet(out, 'РУЧНАЯ ПРАВКА')
    text = drift.report_markdown(drift.compare(spec_path, out))
    assert 'Drift' in text and 'РУЧНАЯ ПРАВКА' in text


def test_cli_exit_codes(tmp_path, capsys):
    spec_path, out = _build(tmp_path)
    assert drift.main([str(spec_path), str(out)]) == 0

    _edit_first_bullet(out, 'ПРАВКА ЧЕРЕЗ CLI')
    assert drift.main([str(spec_path), str(out)]) == 1

    assert drift.main([str(spec_path), str(out), '--ack']) == 0
    assert drift.compare(spec_path, out)['acknowledged'] is True

    assert drift.main([str(spec_path), str(tmp_path / 'gone.pptx')]) == 2
