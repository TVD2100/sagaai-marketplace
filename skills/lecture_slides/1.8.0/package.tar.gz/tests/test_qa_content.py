"""Tests for the content-completeness QA rules (B2, E1-E3).

Covered: sparse content slides and empty columns (``check_density``),
uniform short lists that read as a classification (``check_lists``),
standalone formulas without an explained caption
(``check_formula_caption``) and overlapping content shapes
(``check_overlaps``). Specs are validated but not built: the rules only
need a validated spec aligned with fabricated layout records.
"""

from __future__ import annotations

import qa_check
from lecture.spec import validate_spec

# 17 words: above the default min_note_words (12) for every slide.
NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')

DENSE_ITEMS = [
    'Постановка задачи о поиске корней уравнения',
    'Идея линеаризации функции касательной прямой',
    'Итерационная формула и скорость сходимости метода',
    'Практический пример вычисления квадратного корня',
    'Реализация на языке Python и домашнее задание',
]

FORMULA = "x_{n+1} = x_n - \\frac{f(x_n)}{f'(x_n)}"


def _spec(slides, qa=None):
    """Validate a minimal RU spec with the given slides and qa overrides."""
    payload = {'meta': {'title': 'Content QA', 'lang': 'ru'}, 'slides': slides}
    if qa:
        payload['qa'] = qa
    return validate_spec(payload)


def _rec(index, stype, boxes=None, empty=False):
    """Fabricated layout record matching the build output shape."""
    return {'index': index, 'type': stype, 'note_words': 50, 'bullets': 0,
            'code_lines': 0, 'boxes': list(boxes or []), 'empty': empty}


def _result(records):
    """Build-result stub carrying only the fields the QA rules read."""
    return {'ok': True, 'errors': [], 'warnings': [], 'records': records,
            'note_words': sum(r['note_words'] for r in records),
            'duration_est_min': 5.0}


def _box(kind, x=1.0, y=1.5, w=4.0, h=2.0):
    return {'kind': kind, 'x': x, 'y': y, 'w': w, 'h': h}


# ─────────────────────────── density (B2) ───────────────────────────

def test_sparse_bullets_slide_warns():
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': ['Коротко'],
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert report['ok'] is True
    assert any('sparse content' in w for w in report['warnings'])


def test_dense_bullets_slide_is_clean():
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': DENSE_ITEMS,
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert report['ok'] is True
    assert not any('sparse content' in w for w in report['warnings'])


def test_slide_with_visual_is_not_sparse():
    spec = _spec([{'type': 'image', 'header': 'Схема', 'path': 'scheme.png',
                   'note': NOTE}])
    boxes = [_box('image', x=1.0, y=1.5, w=6.0, h=4.0)]
    report = qa_check.check_deck(spec, _result([_rec(1, 'image', boxes)]))
    assert not any('sparse content' in w for w in report['warnings'])


def test_layout_slide_is_exempt_from_density():
    spec = _spec([{'type': 'cards', 'header': 'Подходы',
                   'items': [{'title': 'Первый', 'text': 'Коротко'}],
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'cards')]))
    assert not any('sparse content' in w for w in report['warnings'])


def test_title_and_section_are_density_exempt():
    spec = _spec([
        {'type': 'title', 'note': NOTE},
        {'type': 'section', 'header': 'Часть', 'note': NOTE},
    ])
    report = qa_check.check_deck(spec, _result([_rec(1, 'title'), _rec(2, 'section')]))
    assert not any('sparse content' in w for w in report['warnings'])


def test_density_check_can_be_disabled():
    spec = _spec([{'type': 'bullets', 'items': ['Коротко'], 'note': NOTE}],
                 qa={'check_density': False})
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not any('sparse content' in w for w in report['warnings'])


# ─────────────────────────── empty columns (B2) ───────────────────────────

def test_empty_column_warns():
    spec = _spec([{'type': 'two_column', 'header': 'Сравнение',
                   'left': {'kind': 'paragraphs', 'text': ''},
                   'right': {'kind': 'bullets', 'items': [
                       'Первая строка с достаточным количеством слов',
                       'Вторая строка тоже содержит много слов',
                       'Третья строка добавляет ещё несколько слов',
                       'Четвёртая строка завершает описание',
                   ]},
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'two_column')]))
    assert any('left column appears empty' in w for w in report['warnings'])
    assert not any('right column appears empty' in w for w in report['warnings'])
    assert not any('sparse content' in w for w in report['warnings'])


def test_compare_short_columns_warn():
    spec = _spec([{'type': 'compare', 'header': 'Сравнение',
                   'left': {'kind': 'bullets', 'items': ['Один']},
                   'right': {'kind': 'bullets', 'items': ['Два']},
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'compare')]))
    assert any('left column appears empty' in w for w in report['warnings'])
    assert any('right column appears empty' in w for w in report['warnings'])


# ─────────────────────────── lists (E3) ───────────────────────────

def test_uniform_short_list_warns_classification():
    items = ['Первый', 'Второй', 'Третий', 'Четвёртый', 'Пятый']
    spec = _spec([{'type': 'bullets', 'header': 'Виды', 'items': items,
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert any('uniform short items' in w for w in report['warnings'])


def test_short_list_below_min_count_not_flagged():
    items = ['Первый', 'Второй', 'Третий', 'Четвёртый']
    spec = _spec([{'type': 'bullets', 'header': 'Виды', 'items': items,
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not any('uniform short items' in w for w in report['warnings'])


def test_list_with_long_items_not_flagged():
    items = ['Первый', 'Второй', 'Третий', 'Четвёртый',
             'Постановка задачи о поиске корней уравнения',
             'Итерационная формула и скорость сходимости метода']
    spec = _spec([{'type': 'bullets', 'header': 'Виды', 'items': items,
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert not any('uniform short items' in w for w in report['warnings'])


def test_min_list_items_override():
    items = ['Первый', 'Второй', 'Третий']
    spec = _spec([{'type': 'bullets', 'header': 'Виды', 'items': items,
                   'note': NOTE}], qa={'min_list_items': 3})
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets')]))
    assert any('uniform short items' in w for w in report['warnings'])


# ─────────────────────────── formulas (E1) ───────────────────────────

def _formula_rec(index=1):
    boxes = [_box('formula', x=1.0, y=1.5, w=11.0, h=4.0)]
    return _rec(index, 'formula', boxes)


def test_formula_without_caption_warns():
    spec = _spec([{'type': 'formula', 'header': 'Итерация', 'formula': FORMULA,
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_formula_rec()]))
    assert any('formula variables' in w for w in report['warnings'])


def test_formula_with_explained_caption_is_clean():
    spec = _spec([{'type': 'formula', 'header': 'Итерация', 'formula': FORMULA,
                   'caption': 'Формула Ньютона, где xₙ - текущее приближение',
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_formula_rec()]))
    assert report['errors'] == []
    assert not any('formula variables' in w for w in report['warnings'])


def test_single_variable_formula_not_flagged():
    spec = _spec([{'type': 'formula', 'header': 'Корень', 'formula': 'x^2 = 4',
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_formula_rec()]))
    assert not any('formula variables' in w for w in report['warnings'])


def test_formula_caption_check_can_be_disabled():
    spec = _spec([{'type': 'formula', 'header': 'Итерация', 'formula': FORMULA,
                   'note': NOTE}], qa={'check_formula_caption': False})
    report = qa_check.check_deck(spec, _result([_formula_rec()]))
    assert not any('formula variables' in w for w in report['warnings'])


# ─────────────────────────── overlaps (E2) ───────────────────────────

def test_overlapping_text_boxes_are_error():
    boxes = [_box('text', x=1.0, y=1.5, w=4.0, h=2.0),
             _box('text', x=1.5, y=2.0, w=4.0, h=2.0)]
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': DENSE_ITEMS,
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets', boxes)]))
    assert report['ok'] is False
    assert any('shapes overlap' in e for e in report['errors'])


def test_overlap_below_threshold_is_clean():
    boxes = [_box('text', x=1.0, y=1.5, w=4.0, h=2.0),
             _box('text', x=4.8, y=1.5, w=4.0, h=2.0)]
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': DENSE_ITEMS,
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets', boxes)]))
    assert report['ok'] is True
    assert not any('shapes overlap' in e for e in report['errors'])


def test_overlap_frac_override():
    boxes = [_box('text', x=1.0, y=1.5, w=4.0, h=2.0),
             _box('text', x=1.5, y=2.0, w=4.0, h=2.0)]
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': DENSE_ITEMS,
                   'note': NOTE}], qa={'overlap_frac': 0.9})
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets', boxes)]))
    assert not any('shapes overlap' in e for e in report['errors'])


def test_overlap_check_can_be_disabled():
    boxes = [_box('text', x=1.0, y=1.5, w=4.0, h=2.0),
             _box('text', x=1.5, y=2.0, w=4.0, h=2.0)]
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': DENSE_ITEMS,
                   'note': NOTE}], qa={'check_overlaps': False})
    report = qa_check.check_deck(spec, _result([_rec(1, 'bullets', boxes)]))
    assert not any('shapes overlap' in e for e in report['errors'])


def test_card_container_overlap_is_not_flagged():
    boxes = [_box('card', x=1.0, y=1.5, w=5.0, h=3.0),
             _box('text', x=1.2, y=1.9, w=4.0, h=2.0)]
    spec = _spec([{'type': 'cards', 'header': 'Подходы',
                   'items': [{'title': 'Первый',
                              'text': 'Описание подхода достаточно длинное'}],
                   'note': NOTE}])
    report = qa_check.check_deck(spec, _result([_rec(1, 'cards', boxes)]))
    assert report['ok'] is True
    assert not any('shapes overlap' in e for e in report['errors'])


# ─────────────────────────── settings plumbing ───────────────────────────

def test_spec_accepts_new_qa_keys():
    spec = _spec([{'type': 'title', 'note': NOTE}], qa={
        'check_density': False, 'min_slide_words': 10, 'min_column_words': 2,
        'check_lists': False, 'min_list_items': 4, 'check_overlaps': False,
        'overlap_frac': 0.5, 'check_formula_caption': False})
    assert not any('unknown key' in w for w in spec.warnings)


def test_new_settings_resolve_types():
    spec = _spec([{'type': 'title', 'note': NOTE}],
                 qa={'overlap_frac': 0.4, 'min_slide_words': '25'})
    report = qa_check.check_deck(spec, _result([_rec(1, 'title')]))
    settings = report['settings']
    assert settings['overlap_frac'] == 0.4
    assert settings['min_slide_words'] == 25
    assert settings['check_density'] is True
