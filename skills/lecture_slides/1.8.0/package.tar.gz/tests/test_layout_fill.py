"""Tests for frame-filling layout: lists, cards, tables, homework.

The visual audit of the course decks found one systemic defect: slides of
the types ``definition`` and ``table`` and short bullet lists kept their
content in the upper part of the body frame, leaving the lower third to
half empty (up to 3.2 in between the content bottom and the footer
hairline). The layout now fills the frame: short multi-item lists stretch
their paragraph spacing (bounded), definition/theorem cards grow to the
frame and center their content, tables grow their rows and center
vertically, and the homework deadline sits right under the task list.

Every measurement goes through the recorded layout boxes (``need_h`` and
the new ``content_bottom``) and the built pptx, so the tests describe the
rendered geometry, not the intent. Written BEFORE the feature existed:
on the the earlier code the card height equalled the content height, list
spacing was never stretched, table rows kept their minimal heights and no
``content_bottom`` was recorded, so every measurement below failed.
"""

from __future__ import annotations

from pptx import Presentation

from lecture import build_deck, themes, validate_spec

NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')

FIVE_ITEMS = ['Первый пункт плана', 'Второй пункт плана', 'Третий пункт плана',
              'Четвёртый пункт плана', 'Пятый пункт плана']


# ─────────────────────────── helpers ───────────────────────────

def _spec(slides, **meta):
    """Validate a minimal RU spec with the given slides and meta overrides."""
    meta.setdefault('course', 'Курс')
    meta.setdefault('title', 'Макет')
    meta.setdefault('lang', 'ru')
    return validate_spec({'meta': meta, 'slides': slides})


def _build(spec, tmp_path, name):
    """Build the spec into ``<name>.pptx``; returns the build result."""
    out = tmp_path / (name + '.pptx')
    result = build_deck(spec, out_path=out, assets_dir=tmp_path / (name + '_assets'))
    assert result['ok'] is True, result['errors']
    return result


def _boxes(record, kind=None):
    """Layout boxes of a record, optionally filtered by kind."""
    boxes = list(record['boxes'])
    if kind is None:
        return boxes
    return [box for box in boxes if box['kind'] == kind]


def _bottom(box):
    """Recorded content bottom of a box (fails loudly when not recorded)."""
    value = box.get('content_bottom')
    assert value is not None, 'content_bottom is not recorded: %r' % (box,)
    return float(value)


# ─────────────────────────────── lists ───────────────────────────────

def test_short_bullet_list_stretches_to_fill_the_frame(tmp_path):
    """Five one-line bullets grow their paragraph spacing instead of
    hugging the top third of the frame."""
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': FIVE_ITEMS,
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'stretch')
    box = _boxes(result['records'][0], 'text')[0]
    assert box['need_h'] <= box['h'] + 0.02
    assert box['need_h'] >= 0.6 * box['h'], box
    assert _bottom(box) >= box['y'] + 0.65 * box['h']


def test_single_item_list_is_centered_not_stretched(tmp_path):
    """A one-line list cannot grow gaps between items: it stays centered
    and keeps its natural height (no fake stretching)."""
    spec = _spec([{'type': 'bullets', 'header': 'План', 'items': ['Один пункт'],
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'center')
    box = _boxes(result['records'][0], 'text')[0]
    assert box['need_h'] <= 0.35 * box['h'], box


def test_two_column_left_list_stretches(tmp_path):
    """Both columns of a two_column slide keep the stretch behaviour."""
    spec = _spec([{'type': 'two_column', 'header': 'Половины',
                   'left': {'kind': 'bullets', 'items': FIVE_ITEMS},
                   'right': {'kind': 'paragraphs',
                             'text': 'Короткий поясняющий абзац справа.'},
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'twocol')
    ratios = [box['need_h'] / box['h']
              for box in _boxes(result['records'][0], 'text')]
    assert ratios and max(ratios) >= 0.6, ratios


# ────────────────────────────── cards ───────────────────────────────

def test_definition_card_fills_the_body_frame(tmp_path):
    """The definition card grows to the frame instead of stopping at its
    text height, and the drawn shape reaches the lower part of the slide."""
    spec = _spec([{'type': 'definition', 'header': 'Термины',
                   'term': 'Мультиагентная система',
                   'text': ['Первое пояснение определения.',
                            'Второе пояснение с примером.'],
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'card')
    box = _boxes(result['records'][0], 'card')[0]
    assert _bottom(box) >= themes.FOOTER_RULE_Y - 0.75, box
    from pptx.enum.shapes import MSO_SHAPE
    prs = Presentation(str(tmp_path / 'card.pptx'))

    def _auto_type(shape):
        try:
            return shape.auto_shape_type
        except (ValueError, AttributeError):
            return None

    tall = [shape.height / 914400.0 for shape in prs.slides[0].shapes
            if _auto_type(shape) == MSO_SHAPE.ROUNDED_RECTANGLE]
    assert tall and max(tall) >= 4.6, tall


# ────────────────────────────── tables ──────────────────────────────

def test_table_grows_rows_and_centers_vertically(tmp_path):
    """A short table grows its row heights (up to a cap) and centers in
    the frame instead of sitting at the top."""
    spec = _spec([{'type': 'table', 'header': 'Сравнение',
                   'columns': ['Критерий', 'Первый', 'Второй', 'Третий'],
                   'rows': [['Скорость', 'высокая', 'средняя', 'низкая'],
                            ['Цена', 'высокая', 'средняя', 'низкая'],
                            ['Точность', 'высокая', 'высокая', 'средняя'],
                            ['Риск', 'низкий', 'средний', 'высокий'],
                            ['Итог', 'подходит', 'возможно', 'нет']],
                   'caption': 'Условные оценки для примера.',
                   'note': NOTE}])
    result = _build(spec, tmp_path, 'table')
    prs = Presentation(str(tmp_path / 'table.pptx'))
    frames = [shape for shape in prs.slides[0].shapes
              if getattr(shape, 'has_table', False)]
    assert frames, 'no table shape on the slide'
    frame = frames[0]
    top = frame.top / 914400.0
    height = frame.height / 914400.0
    avail = themes.BODY_H - 0.36            # caption strip
    assert height >= 0.65 * avail, height
    assert top >= themes.BODY_TOP - 0.02
    assert top + height <= themes.FOOTER_RULE_Y + 0.02


# ───────────────────────────── homework ─────────────────────────────

def test_homework_deadline_sits_next_to_the_task_list(tmp_path):
    """The deadline line follows the visible bottom of the task list
    instead of being pinned far below it."""
    spec = _spec([{'type': 'homework', 'header': 'Задание',
                   'items': ['Первый пункт задания', 'Второй пункт задания',
                             'Третий пункт задания', 'Четвёртый пункт задания'],
                   'deadline': 'до семинара 12 октября', 'note': NOTE}])
    result = _build(spec, tmp_path, 'homework')
    boxes = _boxes(result['records'][0])
    items = [box for box in boxes if box['kind'] == 'text' and not box.get('deadline')]
    deadlines = [box for box in boxes if box.get('deadline')]
    assert items and deadlines, boxes
    item = items[0]
    visible_bottom = item['y'] + (item['h'] + item['need_h']) / 2.0
    gap = deadlines[0]['y'] - visible_bottom
    assert -0.05 <= gap <= 0.6, gap
