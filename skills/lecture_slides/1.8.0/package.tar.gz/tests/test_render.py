"""Unit tests for lecture.render: mathtext formulas and pygments listings."""

from __future__ import annotations

import pytest

from lecture import render


# ─────────────────────────── languages ───────────────────────────

def test_normalize_language_aliases():
    assert render.normalize_language('py') == 'python'
    assert render.normalize_language('C++') == 'cpp'
    assert render.normalize_language('js') == 'javascript'
    assert render.normalize_language('sh') == 'bash'
    assert render.normalize_language('YML') == 'yaml'
    assert render.normalize_language('txt') == 'text'
    assert render.normalize_language('') == ''


def test_all_documented_languages_and_aliases_highlight():
    for lang in ('python', 'py', 'c', 'cpp', 'c++', 'java', 'javascript', 'js',
                 'typescript', 'ts', 'sql', 'bash', 'sh', 'json', 'yaml',
                 'html', 'css', 'xml', 'text'):
        lines = render.highlight_code('x = 1', lang)
        assert lines and lines[0], 'empty highlight for %s' % lang


def test_unknown_language_raises_render_error():
    with pytest.raises(render.RenderError) as exc:
        render.highlight_code('print(1)', 'brainfuck')
    assert 'unsupported code language' in str(exc.value)
    assert 'python' in str(exc.value)


def test_empty_language_falls_back_to_text():
    lines = render.highlight_code('просто текст', '')
    assert ''.join(text for text, _ in lines[0]) == 'просто текст'


# ─────────────────────────── spans and colors ───────────────────────────

def test_spans_are_text_hexcolor_tuples():
    lines = render.highlight_code('def f(x):\n    return x + 1', 'python')
    assert len(lines) == 2
    for line in lines:
        for text, color in line:
            assert isinstance(text, str)
            assert isinstance(color, str) and color.startswith('#') and len(color) == 7


def test_trailing_newline_not_counted():
    assert len(render.highlight_code('a = 1\nb = 2\n', 'python')) == 2
    assert len(render.highlight_code('a = 1\nb = 2', 'python')) == 2


def test_line_count_matches_input_exactly():
    for count in (1, 5, 24):
        code = '\n'.join('# line %d' % i for i in range(count))
        assert len(render.highlight_code(code, 'python')) == count


def test_blank_lines_preserved():
    code = 'a = 1\n\nb = 2'
    lines = render.highlight_code(code, 'python')
    assert len(lines) == 3
    assert lines[1] == [] or ''.join(t for t, _ in lines[1]).strip() == ''


def test_tabs_expanded_to_four_spaces():
    lines = render.highlight_code('if x:\n\tpass', 'python')
    joined = ''.join(text for text, _ in lines[1])
    assert joined.startswith('    ') and '\t' not in joined


def test_comments_get_muted_color():
    lines = render.highlight_code('# comment\nx = 1', 'python')
    comment_color = lines[0][0][1]
    code_colors = [color for _, color in lines[1]]
    assert comment_color not in code_colors


# ─────────────────────────── formulas ───────────────────────────

def test_clean_formula_strips_delimiters():
    assert render.clean_formula('$$x^2$$') == 'x^2'
    assert render.clean_formula('  $\\frac{a}{b}$  ') == '\\frac{a}{b}'
    assert render.clean_formula('x + y') == 'x + y'


def test_render_formula_basic(tmp_path):
    out = tmp_path / 'f.png'
    info = render.render_formula('E = mc^2', out)
    assert info['ok'] is True
    assert out.exists() and out.stat().st_size > 0
    assert 0 < info['width_in'] <= 11.4
    assert info['height_in'] > 0
    assert info['fontsize'] == render.FORMULA_FONTSIZE


def test_render_formula_list_stacks_lines(tmp_path):
    one = render.render_formula('a = b', tmp_path / 'one.png')
    two = render.render_formula(['a = b', 'c = d'], tmp_path / 'two.png')
    assert two['height_in'] > one['height_in']


def test_render_formula_scales_down_oversized(tmp_path):
    long_formula = ' + '.join(['x_{%d}' % i for i in range(40)])
    info = render.render_formula(long_formula, tmp_path / 'wide.png', max_width_in=5.0)
    assert info['width_in'] <= 5.0


def test_render_formula_empty_raises(tmp_path):
    with pytest.raises(render.RenderError) as exc:
        render.render_formula(['', '   '], tmp_path / 'empty.png')
    assert 'empty' in str(exc.value)


def test_render_formula_begin_environment_raises(tmp_path):
    with pytest.raises(render.RenderError):
        render.render_formula('\\begin{cases} x & x>0 \\\\ -x & x<0 \\end{cases}',
                              tmp_path / 'env.png')


def test_render_formula_unknown_macro_raises(tmp_path):
    with pytest.raises(render.RenderError):
        render.render_formula('\\unknownmacro{x}', tmp_path / 'macro.png')


def test_render_formula_creates_parent_dirs(tmp_path):
    out = tmp_path / 'nested' / 'deep' / 'f.png'
    render.render_formula('x^2', out)
    assert out.exists()


def test_supported_mathtext_constructs(tmp_path):
    samples = [
        '\\frac{a}{b}', '\\sqrt{x}', 'x^2', 'x_i',
        '\\sum_{i=1}^{n} i^2', '\\int_a^b f(x)\\,dx',
        '\\lim_{x \\to 0} \\frac{\\sin x}{x}',
        '\\alpha + \\beta = \\gamma', 'a \\leq b \\neq c',
        '\\mathbf{A} \\cdot \\mathbf{x} = \\lambda \\mathbf{x}',
    ]
    for i, formula in enumerate(samples):
        info = render.render_formula(formula, tmp_path / ('s%d.png' % i))
        assert info['ok']


# ─────────────────────────── cache key ───────────────────────────

def test_formula_key_stable_and_sensitive():
    first = render.formula_key(['x^2', 'y^2'], '#000000', 22)
    second = render.formula_key(['x^2', 'y^2'], '#000000', 22)
    other = render.formula_key(['x^2', 'y^2'], '#FFFFFF', 22)
    assert first == second != other
    assert render.formula_key('T', '#000000', 22) == render.formula_key(['T'], '#000000', 22)
