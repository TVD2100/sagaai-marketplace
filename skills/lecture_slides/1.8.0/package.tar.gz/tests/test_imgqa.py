"""Tests for lecture.imgqa and its integration with the QA pass.

Covered: missing/unreadable files, blank (single-color) pictures, tiny
pictures, narrow pictures (small side), ink next to the bitmap border,
alpha flattening for transparent PNGs, the ``min_image_px`` override and
the end-to-end path build_deck -> qa_check with the image rules enabled
and disabled through the spec's ``qa`` block.
"""

from __future__ import annotations

import json

from PIL import Image

import qa_check
from lecture import imgqa
from lecture.deck import build_deck
from lecture.spec import load_spec


# ─────────────────────────── helpers ───────────────────────────

def _fill(path, size=(400, 300), color=(255, 255, 255), mode='RGB'):
    """Create a picture of one flat color and return its path."""
    Image.new(mode, size, color).save(path)
    return path


def _with_dot(path, dot=(31, 78, 156)):
    """Add one contrasting pixel so the picture is no longer one color."""
    image = Image.open(path)
    image.putpixel((10, 10), dot if image.mode == 'RGB' else dot + (255,))
    image.save(path)
    return path


def _lecture_spec(tmp_path, image_name, qa=None):
    """Write a two-slide spec (title + image) and load it."""
    payload = {
        'meta': {'title': 'Img QA', 'duration_min': 45},
        'slides': [
            {'type': 'title',
             'note': 'Представьте тему занятия и расскажите, что будет разобрано сегодня.'},
            {'type': 'image', 'header': 'Схема', 'path': image_name,
             'note': ('Разберите схему по шагам: что изображено на рисунке и какое '
                      'место он занимает в общем рассуждении лекции. ' * 3)},
        ],
    }
    if qa is not None:
        payload['qa'] = qa
    spec_path = tmp_path / 'lecture.json'
    spec_path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    return load_spec(spec_path)


# ─────────────────────────── unit rules ───────────────────────────

def test_missing_file_is_error(tmp_path):
    result = imgqa.inspect_image(tmp_path / 'nope.png')
    assert result['ok'] is False
    assert any('not found' in message for message in result['errors'])


def test_unreadable_file_is_error(tmp_path):
    broken = tmp_path / 'broken.png'
    broken.write_bytes(b'this is not a png')
    result = imgqa.inspect_image(broken)
    assert result['ok'] is False
    assert any('cannot read image' in message for message in result['errors'])


def test_solid_color_is_error(tmp_path):
    result = imgqa.inspect_image(_fill(tmp_path / 'flat.png', color=(240, 240, 240)))
    assert result['ok'] is False
    assert any('single solid color' in message for message in result['errors'])


def test_tiny_image_is_error(tmp_path):
    picture = _with_dot(_fill(tmp_path / 'tiny.png', size=(120, 90)))
    result = imgqa.inspect_image(picture)
    assert any('too small to read' in message for message in result['errors'])
    assert result['width'] == 120 and result['height'] == 90


def test_narrow_image_warns_about_small_side(tmp_path):
    picture = _with_dot(_fill(tmp_path / 'thin.png', size=(100, 800)))
    result = imgqa.inspect_image(picture)
    assert result['ok'] is True
    assert any('small side' in message for message in result['warnings'])


def test_border_ink_is_warning(tmp_path):
    picture = _fill(tmp_path / 'edge.png')
    image = Image.open(picture)
    for x in range(image.width):
        image.putpixel((x, 0), (0, 0, 0))
    image.save(picture)
    result = imgqa.inspect_image(picture)
    assert result['ok'] is True
    assert any('cropped' in message for message in result['warnings'])


def test_clean_drawing_is_silent(tmp_path):
    picture = _fill(tmp_path / 'plot.png')
    image = Image.open(picture)
    for x in range(60, 340):
        image.putpixel((x, 150), (31, 78, 156))
    image.save(picture)
    result = imgqa.inspect_image(picture)
    assert result['ok'] is True
    assert result['errors'] == []
    assert result['warnings'] == []
    assert result['colors'] == 2


def test_min_px_override(tmp_path):
    picture = _with_dot(_fill(tmp_path / 'small.png', size=(150, 150)))
    assert imgqa.inspect_image(picture)['ok'] is False
    assert imgqa.inspect_image(picture, min_px=100)['ok'] is True


# ─────────────────────────── transparency ───────────────────────────

def test_fully_transparent_png_reads_as_blank(tmp_path):
    picture = _fill(tmp_path / 'clear.png', color=(0, 0, 0, 0), mode='RGBA')
    result = imgqa.inspect_image(picture)
    assert any('single solid color' in message for message in result['errors'])
    assert not any('cannot read' in message for message in result['errors'])
    assert not any('border ink' in message for message in result['warnings'])


def test_transparent_margin_does_not_trigger_border(tmp_path):
    picture = tmp_path / 'framed.png'
    image = Image.new('RGBA', (400, 300), (0, 0, 0, 0))
    for x in range(100, 300):
        for y in range(100, 200):
            image.putpixel((x, y), (31, 78, 156, 255))
    image.save(picture)
    result = imgqa.inspect_image(picture)
    assert result['ok'] is True
    assert result['warnings'] == []


# ─────────────────────────── integration ───────────────────────────

def test_build_records_image_path(tmp_path):
    picture = _with_dot(_fill(tmp_path / 'ok.png'))
    spec = _lecture_spec(tmp_path, 'ok.png')
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    assert result['ok'] is True
    slide = [rec for rec in result['records'] if rec['type'] == 'image'][0]
    boxes = [box for box in slide['boxes'] if box['kind'] == 'image']
    assert boxes and boxes[0].get('image', '').endswith(str(picture.name))


def test_qa_reports_blank_image(tmp_path):
    _fill(tmp_path / 'blank.png')          # pure white plate
    spec = _lecture_spec(tmp_path, 'blank.png')
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    report = qa_check.check_deck(spec, result)
    assert any('single solid color' in message for message in report['errors'])


def test_qa_image_checks_can_be_disabled(tmp_path):
    _fill(tmp_path / 'blank.png')
    spec = _lecture_spec(tmp_path, 'blank.png', qa={'check_images': False})
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    report = qa_check.check_deck(spec, result)
    assert not any('single solid color' in message for message in report['errors'])
    assert report['settings']['check_images'] is False


def test_qa_min_image_px_from_spec(tmp_path):
    _with_dot(_fill(tmp_path / 'small.png', size=(150, 150)))
    spec = _lecture_spec(tmp_path, 'small.png')
    result = build_deck(spec, out_path=tmp_path / 'deck.pptx', assets_dir=tmp_path / 'assets')
    report = qa_check.check_deck(spec, result)
    assert any('too small to read' in message for message in report['errors'])

    spec2 = _lecture_spec(tmp_path, 'small.png', qa={'min_image_px': 100})
    result2 = build_deck(spec2, out_path=tmp_path / 'deck2.pptx', assets_dir=tmp_path / 'assets')
    report2 = qa_check.check_deck(spec2, result2)
    assert not any('too small to read' in message for message in report2['errors'])
