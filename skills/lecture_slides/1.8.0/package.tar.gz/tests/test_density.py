"""Tests for the frame-fill density metric.

The old density rule keyed on the *presence* of a visual element: any
formula, table, code listing or image marked a slide as non-sparse and
switched the check off. The metric is now the fraction of the slide frame
covered by content boxes (``qa_check._frame_fill``), using the recorded
``need_h`` where present, so a formula does not clear the check by itself.
Types whose layouts are airy by design (cover, section, cards, timeline,
process, compare) are exempt through ``qa_check.DENSITY_EXEMPT_REASONS``;
the exemption is recorded per slide and rendered in the report's
``Density`` section - never a silent PASS.

These tests were written BEFORE the feature existed and failed on the
the earlier code: ``_frame_fill`` and the exemption table did not exist, the
report rows carried no ``fill``/``density_exempt`` data, ``min_fill`` was
an unknown spec key, and the measured repro slide (a short header plus a
formula over an empty bottom half) produced no density warning.
"""

from __future__ import annotations

import pytest

import qa_check
from lecture import build_deck, themes, validate_spec

# 17 words: above the default min_note_words (12).
NOTE = ('Эта заметка содержит достаточно слов, чтобы пройти минимальный '
        'порог качества и не вызвать ошибок на этапе проверки.')

# The measurement: the second slide is a formula slide whose content
# covers roughly an eighth of the frame (the bottom half stays empty).
EMPTY_BOTTOM = [
    {'type': 'title', 'note': NOTE},
    {'type': 'formula', 'header': 'Короткий заголовок',
     'formula': '\\frac{a}{b}=c', 'note': NOTE},
]


def _spec(slides, qa=None):
    """Validate a minimal RU spec with the given slides and qa overrides."""
    payload = {'meta': {'title': 'Density', 'lang': 'ru'}, 'slides': slides}
    if qa is not None:
        payload['qa'] = qa
    return validate_spec(payload)


def _build(spec, tmp_path, name='density'):
    """Build the spec with a real deck; returns the build result."""
    out = tmp_path / (name + '.pptx')
    result = build_deck(spec, out_path=out, assets_dir=tmp_path / (name + '_assets'))
    assert result['ok'] is True, result['errors']
    return result


def _density_warnings(report):
    return [w for w in report['warnings'] if 'frame fill' in w]


# ------------------------------- metric ----------------------------------

def test_frame_fill_uses_need_height_and_skips_markers():
    rec = {'boxes': [
        {'kind': 'text', 'x': 0.0, 'y': 0.0, 'w': 2.0, 'h': 5.0, 'need_h': 1.0},
        {'kind': 'slot_marker', 'x': 0.0, 'y': 0.0, 'w': 1.0, 'h': 1.0},
    ]}
    expected = (2.0 * 1.0) / (themes.SLIDE_W * themes.SLIDE_H)
    assert qa_check._frame_fill(rec) == pytest.approx(expected)


def test_frame_fill_without_geometry_is_none():
    assert qa_check._frame_fill({'boxes': []}) is None
    assert qa_check._frame_fill({}) is None


# --------------------------- measured defect ------------------------------

def test_formula_slide_with_empty_bottom_warns(tmp_path):
    spec = _spec(EMPTY_BOTTOM)
    result = _build(spec, tmp_path, 'repro')
    report = qa_check.check_deck(spec, result)
    assert report['ok'] is True
    warnings = _density_warnings(report)
    assert warnings, report['warnings']
    assert any('slide 2 (formula)' in w for w in warnings)


def test_slide_rows_carry_fill_and_exemption(tmp_path):
    spec = _spec(EMPTY_BOTTOM)
    result = _build(spec, tmp_path, 'rows')
    report = qa_check.check_deck(spec, result)
    rows = {row['index']: row for row in report['slide_rows']}
    fill = rows[2]['fill']
    assert isinstance(fill, float) and 0.0 < fill < 0.18
    assert rows[2]['density_exempt'] is None
    assert rows[1]['density_exempt']
    assert 'by design' in rows[1]['density_exempt']


def test_min_fill_override(tmp_path):
    for value, expected in ((0.05, False), (0.5, True)):
        spec = _spec(EMPTY_BOTTOM, qa={'min_fill': value})
        result = _build(spec, tmp_path, 'min_%s' % value)
        report = qa_check.check_deck(spec, result)
        assert report['settings']['min_fill'] == value
        assert bool(_density_warnings(report)) is expected


def test_density_check_disables_the_fill_metric(tmp_path):
    spec = _spec(EMPTY_BOTTOM)
    result = _build(spec, tmp_path, 'on')
    assert _density_warnings(qa_check.check_deck(spec, result))

    off = _spec(EMPTY_BOTTOM, qa={'check_density': False})
    off_result = _build(off, tmp_path, 'off')
    report = qa_check.check_deck(off, off_result)
    assert report['settings']['check_density'] is False
    assert not _density_warnings(report)


def test_spec_accepts_min_fill_key():
    spec = _spec([{'type': 'title', 'note': NOTE}], qa={'min_fill': 0.2})
    assert not any('unknown key' in w for w in spec.warnings)


# ----------------------------- exemptions ---------------------------------

def test_exempt_types_record_the_reason(tmp_path):
    slides = [
        {'type': 'title', 'note': NOTE},
        {'type': 'section', 'header': 'Часть 1', 'note': NOTE},
        {'type': 'timeline', 'header': 'Этапы', 'note': NOTE,
         'items': [{'label': 'Этап 1', 'text': 'Сбор данных и постановка задачи.'},
                   {'label': 'Этап 2', 'text': 'Обучение базовой модели.'},
                   {'label': 'Этап 3', 'text': 'Оценка качества и внедрение.'}]},
    ]
    spec = _spec(slides)
    result = _build(spec, tmp_path, 'exempt')
    report = qa_check.check_deck(spec, result)
    assert not _density_warnings(report)
    rows = {row['index']: row for row in report['slide_rows']}
    for index in (1, 2, 3):
        assert rows[index]['density_exempt'], (index, rows[index])
        assert 'by design' in rows[index]['density_exempt']


# ------------------------------- report -----------------------------------

def test_markdown_renders_the_density_section(tmp_path):
    spec = _spec(EMPTY_BOTTOM)
    result = _build(spec, tmp_path, 'md')
    report = qa_check.check_deck(spec, result)
    text = qa_check.report_markdown(report, spec=spec)
    assert '## Density' in text
    assert 'slide 2 (formula): frame fill' in text
    assert 'below the minimum' in text
    assert 'exempt from the density check' in text
