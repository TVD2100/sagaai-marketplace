"""End-to-end scenario: a lecturer edits the finished deck by hand.

Given a deck that was built, delivered and then edited by the lecturer in
PowerPoint, when the agent is about to rebuild it, then the skill must
detect the drift, ask the user, and act only on the answer. This scenario
walks the three outcomes of that question through the public entry points:
update the sources, keep the deck as final, or rebuild anyway.
"""

from __future__ import annotations

import json

from pptx import Presentation

from build_lecture import (
    acknowledge_manual_edits,
    build,
    check_drift,
)

NOTE = ('Сегодня разберём метод Ньютона: идею касательной, условие сходимости '
        'и практические примеры применения в задачах оптимизации.')


def _write_spec(path, items=('Постановка задачи', 'Метод Ньютона')):
    payload = {'meta': {'course': 'Численные методы', 'lecture_no': 7,
                        'title': 'Метод Ньютона', 'lang': 'ru'},
               'slides': [
                   {'type': 'title', 'note': NOTE},
                   {'type': 'bullets', 'header': 'План лекции',
                    'items': list(items), 'note': NOTE},
               ]}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding='utf-8')
    return path


def _edit_slide(pptx_path, new_text):
    """Rewrite a bullet the way a human does it in PowerPoint."""
    presentation = Presentation(str(pptx_path))
    for shape in presentation.slides[1].shapes:
        if not getattr(shape, 'has_text_frame', False):
            continue
        for paragraph in shape.text_frame.paragraphs:
            if paragraph.runs:
                paragraph.runs[0].text = new_text
                presentation.save(str(pptx_path))
                return new_text
    raise AssertionError('no editable bullet on slide 2')


def _build(tmp_path):
    spec = _write_spec(tmp_path / 'lectures' / 'newton' / 'lecture.json')
    deck = tmp_path / 'lectures' / 'newton' / 'newton.pptx'
    result = build(spec, deck, qa=True)
    assert result['ok'] is True, result['errors']
    return spec, deck


def test_scenario_drift_is_detected_and_the_sources_are_updated(tmp_path):
    # given: a finished deck that the lecturer then edited by hand
    spec, deck = _build(tmp_path)
    assert check_drift(spec, deck)['changed'] is False
    _edit_slide(deck, 'Метод Ньютона и его сходимость')

    # when: the agent checks the deck before rebuilding it
    report = check_drift(spec, deck)

    # then: the manual edit is visible in the report shown to the user
    assert report['changed'] is True
    assert report['ok'] is False
    assert 'Drift' in report['markdown']
    assert 'Метод Ньютона и его сходимость' in report['markdown']

    # when: the user answers 'yes, update the sources'
    payload = json.loads(spec.read_text(encoding='utf-8'))
    payload['slides'][1]['items'] = ['Постановка задачи',
                                     'Метод Ньютона и его сходимость']
    spec.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding='utf-8')
    rebuilt = build(spec, deck, qa=True)

    # then: the rebuilt deck matches the spec again and QA passes
    assert rebuilt['ok'] is True, rebuilt['errors']
    assert check_drift(spec, deck)['changed'] is False


def test_scenario_user_keeps_the_hand_edited_deck(tmp_path):
    # given: a hand-edited deck the lecturer wants to keep as final
    spec, deck = _build(tmp_path)
    _edit_slide(deck, 'Финальная формулировка')
    assert check_drift(spec, deck)['ok'] is False

    # when: the user answers 'no, the deck is final'
    ack = acknowledge_manual_edits(deck)

    # then: the ack records this exact file and the question stops returning
    assert ack.endswith('newton_service/drift_ack.json')
    report = check_drift(spec, deck)
    assert report['acknowledged'] is True
    assert report['ok'] is True
    assert 'Acknowledged' in report['markdown']

    # and: the spec is untouched - the deck is the source of truth
    payload = json.loads(spec.read_text(encoding='utf-8'))
    assert payload['slides'][1]['items'] == ['Постановка задачи', 'Метод Ньютона']


def test_scenario_spec_moves_on_after_delivery(tmp_path):
    # given: the spec grew a new bullet after the deck was delivered
    spec, deck = _build(tmp_path)
    payload = json.loads(spec.read_text(encoding='utf-8'))
    payload['slides'][1]['items'].append('Сходимость и примеры')
    spec.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding='utf-8')

    # when: the agent checks the deck
    report = check_drift(spec, deck)

    # then: the missing bullet is reported as spec-only text
    assert report['changed'] is True
    removed = [text for entry in report['slides']
               for text in entry['user_removed']]
    assert any('Сходимость и примеры' in text for text in removed)

    # when: the deck is rebuilt from the spec
    rebuilt = build(spec, deck, qa=True)

    # then: deck and spec agree again
    assert rebuilt['ok'] is True, rebuilt['errors']
    assert check_drift(spec, deck)['changed'] is False


def test_scenario_failed_check_is_not_read_as_no_drift(tmp_path):
    # given: a spec whose deck was never built
    spec = _write_spec(tmp_path / 'lectures' / 'newton' / 'lecture.json')
    missing = tmp_path / 'lectures' / 'newton' / 'newton.pptx'

    # when: the agent checks the missing deck
    report = check_drift(spec, missing)

    # then: the check reports an error instead of a silent 'in sync'
    assert report['changed'] is False
    assert report['ok'] is False
    assert report['errors']
    assert 'Error' in report['markdown']
