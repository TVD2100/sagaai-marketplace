"""End-to-end APA citation scenarios (given -> when -> then).

A lecturer states a case, a quotation and a figure, and the audience must be
able to verify them. The scenarios walk the public entry points only - write a
JSON spec, build it with the QA pass, read the report, fix the references,
rebuild - and then reopen the PPTX to check what the audience actually sees:
a clickable citation for an external source, plain APA text for an internal
one, and an APA reference list on the literature slide. Part of the project's
regression suite, not scratch files.
"""

from __future__ import annotations

import json

from pptx import Presentation

from build_lecture import build

NOTE = ('Разберите слайд по шагам: что утверждается, откуда взята цифра '
        'и как это связано с предыдущим разделом курса.')

ARTICLE = {'id': 'smith2019', 'kind': 'article', 'authors': ['Smith, J.'],
           'year': 2019, 'title': 'Deep learning in practice',
           'container': 'Journal of AI', 'volume': '12', 'issue': '3',
           'pages': '45-67', 'doi': '10.1000/xyz123'}

RAG = {'id': 'rag1', 'kind': 'internal', 'internal': True,
       'rag_base': 'marketing', 'authors': ['Петров, П. П.'], 'year': 2024,
       'title': 'Отчёт об оттоке'}


def _write_spec(path, payload):
    """Write a lecture spec as UTF-8 JSON, creating parent dirs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding='utf-8')
    return path


def _deck_text(pptx_path, index):
    """Visible text of one slide of a built deck."""
    prs = Presentation(str(pptx_path))
    return '\n'.join(shape.text_frame.text for shape in prs.slides[index].shapes
                     if shape.has_text_frame)


def _links(pptx_path):
    """(run text, address) of every hyperlink in the deck."""
    prs = Presentation(str(pptx_path))
    found = []
    for slide in prs.slides:
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if run.hyperlink.address:
                        found.append((run.text, run.hyperlink.address))
    return found


def _unreferenced(report):
    """QA warnings about claims left without a reference or a citation."""
    return [w for w in report['warnings']
            if 'without an APA reference' in w or 'without a source' in w]


def test_scenario_unreferenced_claims_are_reported_then_fixed(tmp_path):
    # given: a deck that states a case, a figure and a quotation without references
    payload = {
        'meta': {'title': 'Рынок', 'lang': 'ru', 'sources': [ARTICLE, RAG]},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'cards', 'header': 'Практика', 'note': NOTE, 'items': [
                {'title': 'Кейс', 'text': 'Кейс компании X: выручка удвоилась'},
                {'title': 'Доля', 'text': 'Доля рынка выросла до 47%'},
                {'title': 'Отток', 'text': '«Отток снизился вдвое за квартал»'},
                {'title': 'Вывод', 'text': 'Компания выросла втрое'},
            ]},
        ],
    }
    spec_path = _write_spec(tmp_path / 'market' / 'lecture.json', payload)
    out = spec_path.parent / 'lecture.pptx'

    # when: the first build runs the QA pass
    first = build(spec_path, out, qa=True)

    # then: every claim type is named, and the draft deck still builds
    assert first['ok'] is True
    messages = ' | '.join(_unreferenced(first['qa']))
    assert 'case' in messages
    assert 'quote' in messages
    assert 'figures (47%)' in messages
    # when: the lecturer cites the sources with inline markers
    items = payload['slides'][1]['items']
    items[0]['text'] += ' [@smith2019]'
    items[1]['text'] += ' [@smith2019]'
    items[2]['text'] += ' [@rag1, с. 5]'
    _write_spec(spec_path, payload)
    second = build(spec_path, out, qa=True)

    # then: the warnings are gone and both citations are drawn on the slide
    assert second['ok'] is True
    assert _unreferenced(second['qa']) == []
    body = _deck_text(out, 1)
    assert '(Smith, 2019)' in body
    assert '(Петров, 2024, с. 5)' in body


def test_scenario_external_source_is_clickable_and_internal_is_not(tmp_path):
    # given: a deck that cites one open-web article and one RAG document
    payload = {
        'meta': {'title': 'Отток', 'lang': 'ru', 'sources': [ARTICLE, RAG]},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'Цифры', 'note': NOTE, 'items': [
                'Доля рынка выросла до 47% [@smith2019]',
                '«Отток снизился вдвое» [@rag1, с. 5]',
            ]},
            {'type': 'literature', 'header': 'Источники',
             'source_refs': ['smith2019', 'rag1'], 'note': NOTE},
        ],
    }
    spec_path = _write_spec(tmp_path / 'citing' / 'lecture.json', payload)
    out = spec_path.parent / 'lecture.pptx'

    # when: the deck is built with QA
    res = build(spec_path, out, qa=True)

    # then: the external citation is a real hyperlink to the DOI
    assert res['ok'] is True
    links = _links(out)
    assert ('(Smith, 2019)', 'https://doi.org/10.1000/xyz123') in links

    # and the internal citation keeps the APA wording but has nothing to click
    assert '(Петров, 2024, с. 5)' in _deck_text(out, 1)
    assert not [text for text, _ in links if 'Петров' in text]

    # and the literature slide formats both references in APA 7
    refs = _deck_text(out, 2)
    assert 'Smith, J. (2019).' in refs
    assert 'Journal of AI' in refs
    assert 'Петров, П. П. (2024).' in refs
    assert 'Внутренний источник' in refs


def test_scenario_internal_source_loses_its_link_with_a_warning(tmp_path):
    # given: an internal RAG entry that wrongly carries a public url
    linked = dict(RAG, url='https://intranet.example/report')
    payload = {
        'meta': {'title': 'Внутренний', 'lang': 'ru', 'sources': [linked]},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'literature', 'header': 'Источники',
             'source_refs': ['rag1'], 'note': NOTE},
        ],
    }
    spec_path = _write_spec(tmp_path / 'internal' / 'lecture.json', payload)

    # when: the deck is built with QA
    res = build(spec_path, spec_path.parent / 'lecture.pptx', qa=True)

    # then: the build succeeds, the url is dropped and the report says why
    assert res['ok'] is True
    assert 'internal source keeps no url' in ' | '.join(res['warnings'])
    assert _links(res['pptx']) == []
    assert 'Внутренний источник' in _deck_text(res['pptx'], 1)


def test_scenario_english_citation_uses_ampersand_and_et_al(tmp_path):
    # given: an English deck citing a two-author and a three-author source
    pair = {'id': 'pair', 'kind': 'article', 'authors': ['Smith, J.', 'Doe, A.'],
            'year': 2019, 'title': 'Joint work', 'container': 'Journal of AI',
            'url': 'https://example.com/pair'}
    many = {'id': 'many', 'kind': 'book',
            'authors': ['Press, W. H.', 'Teukolsky, S. A.',
                        'Vetterling, W. T.'],
            'year': 2007, 'title': 'Numerical Recipes',
            'publisher': 'Cambridge University Press'}
    payload = {
        'meta': {'title': 'English', 'lang': 'en', 'sources': [pair, many]},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'Evidence', 'note': NOTE, 'items': [
                'Growth reached 47% [@pair]',
                'The method is described in [@many]',
            ]},
        ],
    }
    spec_path = _write_spec(tmp_path / 'en' / 'lecture.json', payload)
    out = spec_path.parent / 'lecture.pptx'

    # when: the deck is built with QA
    res = build(spec_path, out, qa=True)

    # then: the in-text labels follow the English APA form
    assert res['ok'] is True
    body = _deck_text(out, 1)
    assert '(Smith & Doe, 2019)' in body
    assert '(Press et al., 2007)' in body
    assert 'и др.' not in body


def test_scenario_unknown_marker_is_reported_not_fatal(tmp_path):
    # given: a slide citing an id that the registry does not have
    payload = {
        'meta': {'title': 'Опечатка', 'lang': 'ru', 'sources': [ARTICLE]},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'Рынок', 'note': NOTE,
             'items': ['Доля выросла до 47% [@smith2020]']},
        ],
    }
    spec_path = _write_spec(tmp_path / 'typo' / 'lecture.json', payload)
    out = spec_path.parent / 'lecture.pptx'

    # when: the deck is built with QA
    res = build(spec_path, out, qa=True)

    # then: the deck still builds and the report names the unknown id
    assert res['ok'] is True
    assert "citation marker '@smith2020' is not in meta.sources" in \
        ' | '.join(res['warnings'])
    assert '[@smith2020]' in _deck_text(out, 1)
