"""End-to-end user scenarios for the lecture-slides skill (given -> when -> then).

A lecturer's real workflow is exercised through the public entry points:
write a JSON spec, build the deck with QA, read the QA report, fix what QA
flagged, rebuild, and export a PDF handout. All scenarios are automated and
run without manual interaction - they are part of the project's regression
suite (not scratch files).
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest
from pptx import Presentation

import render_preview
from build_lecture import build

TITLE_NOTE = ('Сегодня разберём метод Ньютона: идею касательной, условие '
              'сходимости и практические примеры применения в задачах оптимизации.')

LONG_NOTE = ('Поясните аудитории ключевую идею слайда, приведите один наглядный '
             'пример из практики и свяжите материал с предыдущим разделом курса, '
             'чтобы студенты увидели общую картину лекции.')

NEWTON_CODE = '\n'.join([
    'def newton(f, df, x0, tol=1e-9, nmax=50):',
    '    x = x0',
    '    for n in range(nmax):',
    '        fx = f(x)',
    '        if abs(fx) < tol:',
    '            return x, n',
    '        x = x - fx / df(x)',
    '    return x, nmax',
])


def _write_spec(path, payload):
    """Write a lecture spec as UTF-8 JSON, creating parent dirs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    return path


def test_scenario_lecturer_builds_a_full_deck(tmp_path):
    # given: a complete draft lecture (title, outline, definition, formula, code, summary)
    spec_path = _write_spec(tmp_path / 'lectures' / 'newton' / 'lecture.json', {
        'meta': {'course': 'Численные методы', 'lecture_no': 7, 'title': 'Метод Ньютона',
                 'lecturer': 'И. И. Иванов', 'org': 'Кафедра вычислительной математики',
                 'date': '2026-10-03', 'lang': 'ru', 'theme': 'academic_blue'},
        'slides': [
            {'type': 'title', 'note': TITLE_NOTE},
            {'type': 'bullets', 'header': 'План лекции',
             'items': ['Постановка задачи', '**Метод Ньютона**', 'Сходимость'],
             'note': LONG_NOTE},
            {'type': 'definition', 'term': 'Квадратичная сходимость',
             'text': 'Погрешность убывает как квадрат предыдущей погрешности.',
             'note': LONG_NOTE},
            {'type': 'formula', 'header': 'Итерация Ньютона', 'numbered': True,
             'formula': 'x_{n+1} = x_n - \\frac{f(x_n)}{f^{\\prime}(x_n)}',
             'note': LONG_NOTE},
            {'type': 'code', 'header': 'Метод Ньютона на Python', 'language': 'python',
             'code': NEWTON_CODE, 'note': LONG_NOTE},
            {'type': 'summary', 'items': ['Идея касательной', 'Квадратичная сходимость',
                                          'Реализация и примеры'], 'note': LONG_NOTE},
        ],
    })

    # when: the deck is built with the QA pass and both reports
    out = spec_path.parent / 'newton.pptx'
    res = build(spec_path, out, qa=True, qa_json=True)

    # then: deck, assets and QA reports are on disk and QA is clean
    assert res['ok'] is True
    assert res['qa']['errors'] == []
    assert out.exists() and out.stat().st_size > 15000
    assert (spec_path.parent / 'newton_service' / 'qa.md').exists()
    assert '**PASS**' in (spec_path.parent / 'newton_service' / 'qa.md').read_text(encoding='utf-8')
    assert (spec_path.parent / 'newton_service' / 'qa.json').exists()
    assert res['assets'] == []
    assert res['qa']['formula_modes']['omml'] >= 1

    # and every slide carries speaker notes inside the pptx itself
    prs = Presentation(str(out))
    assert len(prs.slides) == 6
    for slide in prs.slides:
        assert slide.notes_slide.notes_text_frame.text.strip()
    assert 'Ньютон' in prs.slides[0].notes_slide.notes_text_frame.text

    # and the footer shows the lecture label with page numbers
    slide_texts = [shape.text_frame.text for shape in prs.slides[1].shapes
                   if shape.has_text_frame]
    assert any('Лекция 7' in t for t in slide_texts)
    assert any('2 / 6' in t for t in slide_texts)


def test_scenario_qa_flags_problems_then_rebuild_passes(tmp_path):
    # given: a draft with two typical mistakes - a stub note and a 30-line listing
    long_code = '\n'.join('step_%d = root_%d / slope_%d' % (i, i, i) for i in range(30))
    payload = {
        'meta': {'course': 'Численные методы', 'title': 'Черновик', 'lang': 'ru'},
        'slides': [
            {'type': 'bullets', 'header': 'План', 'items': ['Первый шаг', 'Второй шаг'],
             'note': 'Обсудим план.'},
            {'type': 'code', 'header': 'Итерации', 'language': 'python',
             'code': long_code, 'note': LONG_NOTE},
        ],
    }
    spec_path = _write_spec(tmp_path / 'draft' / 'lecture.json', payload)

    # when: the first build runs the QA pass
    out = spec_path.parent / 'lecture.pptx'
    first = build(spec_path, out, qa=True)

    # then: QA refuses with actionable messages
    assert first['ok'] is False
    errors = ' | '.join(first['qa']['errors'])
    assert 'speaker notes too short' in errors
    assert 'code listing has 30 lines (max 22); split it' in errors

    # when: the lecturer writes real notes and splits the listing into two slides
    payload['slides'][0]['note'] = LONG_NOTE
    lines = long_code.split('\n')
    payload['slides'][1]['code'] = '\n'.join(lines[:15])
    payload['slides'].append({'type': 'code', 'header': 'Итерации (продолжение)',
                              'language': 'python', 'code': '\n'.join(lines[15:]),
                              'note': LONG_NOTE})
    _write_spec(spec_path, payload)
    second = build(spec_path, out, qa=True)

    # then: the rebuilt deck passes QA and the report says so
    assert second['ok'] is True
    assert second['qa']['errors'] == []
    assert '**PASS**' in (spec_path.parent / 'lecture_service' / 'qa.md').read_text(encoding='utf-8')


def test_scenario_deck_folder_keeps_only_artifacts(tmp_path, demo_spec_path):
    # given: a lecturer starts from an empty folder and builds a deck with QA
    assert list(tmp_path.iterdir()) == []
    out = tmp_path / 'deck.pptx'
    res = build(demo_spec_path, out, qa=True, qa_json=True)

    # then: the folder holds the deck and exactly one helper folder
    assert res['ok'] is True, res['errors']
    assert sorted(p.name for p in tmp_path.iterdir()) == ['deck.pptx', 'deck_service']
    service = tmp_path / 'deck_service'
    names = sorted(p.name for p in service.iterdir())
    assert 'qa.md' in names and 'qa.json' in names
    for report in res['qa_reports']:
        assert Path(report).parent == service, report

    # when: the lecturer also exports the PDF handout
    preview = render_preview.render(out, pdf=True)
    if preview['pdf'] is None:
        pytest.skip('LibreOffice is not installed')

    # then: the PDF joins the deck, preview helpers stay inside deck_service/
    assert sorted(p.name for p in tmp_path.iterdir()) == [
        'deck.pdf', 'deck.pptx', 'deck_service']
    previewed = render_preview.render(out, pdf=True, png=True)
    assert previewed['ok'] is True
    for page in previewed['png']:
        assert Path(page).parent == service / 'preview'
    assert sorted(p.name for p in tmp_path.iterdir()) == [
        'deck.pdf', 'deck.pptx', 'deck_service']


def test_scenario_broken_formula_and_missing_image_then_fix(tmp_path, demo_plot_path):
    # given: a draft with an unsupported LaTeX environment and a missing image file
    spec_path = _write_spec(tmp_path / 'broken' / 'lecture.json', {
        'meta': {'course': 'Численные методы', 'title': 'Ошибки', 'lang': 'ru'},
        'slides': [
            {'type': 'formula', 'header': 'Случаи',
             'formula': '\\begin{cases} x & x > 0 \\\\ -x & x < 0 \\end{cases}',
             'note': LONG_NOTE},
            {'type': 'image', 'header': 'Схема', 'path': 'scheme.png', 'note': LONG_NOTE},
        ],
    })

    # when: the build runs
    out = spec_path.parent / 'lecture.pptx'
    broken = build(spec_path, out, qa=True)

    # then: the report explains exactly what is wrong, the draft deck still exists
    assert broken['ok'] is False
    text = ' | '.join(broken['errors'])
    assert 'unsupported formula' in text
    assert 'image not found: scheme.png' in text
    assert broken['missing_images'] == ['scheme.png']
    assert out.exists()

    # when: the lecturer replaces the formula with supported mathtext and adds the picture
    shutil.copy(demo_plot_path, spec_path.parent / 'scheme.png')
    payload = json.loads(spec_path.read_text(encoding='utf-8'))
    payload['slides'][0]['formula'] = 'x_{n+1} = x_n - \\frac{f(x_n)}{g(x_n)}'
    _write_spec(spec_path, payload)
    fixed = build(spec_path, out, qa=True)

    # then: the rebuilt deck passes QA with the image embedded
    assert fixed['ok'] is True
    assert fixed['missing_images'] == []
    assert fixed['qa']['errors'] == []


def test_scenario_english_deck_with_english_labels(tmp_path):
    # given: an English lecture spec
    spec_path = _write_spec(tmp_path / 'en' / 'lecture.json', {
        'meta': {'course': 'Numerical Methods', 'lecture_no': 3,
                 'title': "Newton's Method", 'lecturer': 'I. Ivanov',
                 'org': 'Department of CS', 'date': '2026-10-03',
                 'lang': 'en', 'theme': 'graphite'},
        'slides': [
            {'type': 'title', 'note': 'Welcome the audience and announce the topic '
                                      'of the lecture today in this course.'},
            {'type': 'definition', 'term': 'Quadratic convergence',
             'text': 'The error squares each iteration.',
             'note': 'Explain quadratic convergence on a diagram and mention the '
                     'difference from linear convergence for the audience.'},
            {'type': 'summary', 'items': ['Idea', 'Convergence', 'Practice'],
             'note': 'Summarise the lecture and point the students at the reading '
                     'list before the next class session starts.'},
        ],
    })

    # when: the deck is built with QA
    res = build(spec_path, spec_path.parent / 'lecture.pptx', qa=True)

    # then: QA passes and the deck uses English labels, not Russian ones
    assert res['ok'] is True
    prs = Presentation(str(res['pptx']))
    texts = [shape.text_frame.text for shape in prs.slides[1].shapes
             if shape.has_text_frame]
    joined = ' '.join(texts)
    assert 'Definition' in joined
    assert 'Определение' not in joined

    # and the footer shows the English lecture label with page numbers
    assert 'Lecture 3' in joined
    assert '2 / 3' in joined


needs_soffice = pytest.mark.skipif(render_preview.find_soffice() is None,
                                   reason='LibreOffice is not installed')


@needs_soffice
def test_scenario_pdf_handout_for_students(tmp_path, demo_spec_path):
    # given: a finished lecture deck
    out = tmp_path / 'lecture.pptx'
    assert build(demo_spec_path, out, qa=True)['ok'] is True

    # when: the lecturer exports the PDF handout
    res = render_preview.render(out, pdf=True)

    # then: a PDF appears next to the deck and is a real PDF file
    assert res['ok'] is True
    pdf = render_preview.Path(res['pdf'])
    assert pdf == tmp_path / 'lecture.pdf'
    assert pdf.read_bytes()[:5] == b'%PDF-'
    assert pdf.stat().st_size > 10000
