"""End-to-end layout/typography scenarios (given -> when -> then-).

A lecturer's real workflow is exercised through the public entry points:
write a spec whose content slides leave an empty bottom or use hyphens as
dashes, build the deck with QA, read the report, fix the spec, rebuild and
see the checks go quiet. All scenarios are automated and part of the
regression suite.
"""

from __future__ import annotations

import json

from build_lecture import build

NOTE = ('Поясните аудитории ключевую идею слайда, приведите наглядный '
        'пример из практики и свяжите материал с предыдущим разделом курса.')


def _write(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    return path


def test_scenario_empty_bottom_flagged_then_fixed(tmp_path):
    # given: a deck whose definition slide carries almost no text
    path = _write(tmp_path / 'deck' / 'lecture.json', {
        'meta': {'course': 'Курс', 'title': 'Макет', 'lang': 'ru'},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'definition', 'header': 'Термины', 'term': 'Термин',
             'text': ['Короткое пояснение определения.'], 'note': NOTE},
        ],
    })
    out = path.parent / 'lecture.pptx'

    # when: the deck is built with QA
    first = build(path, out, qa=True, qa_json=True)

    # then: the build works but QA reports the numbers it measured
    assert first['pptx'] is not None
    rows = first['qa']['slide_rows']
    assert rows and all('void' in row for row in rows)
    assert all('dashes' in row for row in rows)


def test_scenario_hyphens_flagged_then_normalized(tmp_path):
    # given: prose hyphens used as em dashes in the visible text
    path = _write(tmp_path / 'deck2' / 'lecture.json', {
        'meta': {'course': 'Курс', 'title': 'Дефисы', 'lang': 'ru'},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'План',
             'items': ['Первый вопрос - второй ответ',
                       'Второй вопрос - третий ответ'], 'note': NOTE},
        ],
    })
    out = path.parent / 'lecture.pptx'

    # when: the first build runs QA
    first = build(path, out, qa=True)

    # then: the hyphen rule flags both items
    assert any('hyphen used as a dash' in w for w in first['qa']['warnings'])

    # when: the lecturer turns on the automatic normalization and rebuilds
    payload = json.loads(path.read_text(encoding='utf-8'))
    payload['meta']['normalize_dashes'] = True
    _write(path, payload)
    second = build(path, out, qa=True)

    # then: the warnings are gone and the deck carries a real em dash
    from pptx import Presentation
    assert not any('hyphen used as a dash' in w for w in second['qa']['warnings'])
    prs = Presentation(str(out))
    joined = ' '.join(shape.text_frame.text for shape in prs.slides[1].shapes
                      if shape.has_text_frame)
    assert '\u2014' in joined


def test_scenario_short_bullets_advised_then_autolayout(tmp_path):
    # given: a lecture plan and a mistakes slide written as short bullet lists -
    # the shape that leaves the lower part of the body frame empty
    path = _write(tmp_path / 'deck4' / 'lecture.json', {
        'meta': {'course': 'Курс', 'title': 'Медиаплан', 'lang': 'ru'},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'План лекции',
             'items': ['Постановка задачи', 'Метрики охвата', 'Бюджет', 'Контроль'],
             'note': NOTE},
            {'type': 'bullets', 'header': 'Типичные ошибки',
             'items': ['Смешивают GRP и TRP', 'Считают охват без частоты',
                       'Бюджет от возможностей', 'Нет контроля до старта'],
             'note': NOTE},
        ],
    })
    out = path.parent / 'lecture.pptx'

    # when: the deck is built with QA as written
    first = build(path, out, qa=True)

    # then: QA names the visual type that would fill the frame instead
    advice = [w for w in first['qa']['warnings'] if 'suggested type' in w]
    assert len(advice) == 2, first['qa']['warnings']
    assert all("'steps_grid'" in w for w in advice)
    assert [row['type'] for row in first['qa']['slide_rows']][1:] == ['bullets', 'bullets']

    # when: the lecturer lets the advisor apply the suggestion and rebuilds
    payload = json.loads(path.read_text(encoding='utf-8'))
    payload['meta']['auto_layout'] = True
    _write(path, payload)
    second = build(path, out, qa=True)

    # then: the slides are tiles, the advice is quiet and the rewrite is logged
    assert [row['type'] for row in second['qa']['slide_rows']][1:] == ['steps_grid', 'steps_grid']
    assert not [w for w in second['qa']['warnings'] if 'suggested type' in w]
    assert [change['to'] for change in second['auto_layout']] == ['steps_grid', 'steps_grid']
    assert any('auto-layout' in message for message in second['warnings'])


def test_scenario_titled_points_become_pillars(tmp_path):
    # given: a components slide whose points carry their own titles
    path = _write(tmp_path / 'deck5' / 'lecture.json', {
        'meta': {'course': 'Курс', 'title': 'Комплекс', 'lang': 'ru',
                 'auto_layout': True},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'Элементы комплекса',
             'items': [{'title': 'Реклама', 'text': 'Платное обращение'},
                       {'title': 'PR', 'text': 'Репутация'},
                       {'title': 'Личные продажи', 'text': 'Прямой контакт'}],
             'note': NOTE},
        ],
    })
    out = path.parent / 'lecture.pptx'

    # when: the deck is built with the advisor enabled
    res = build(path, out, qa=True)

    # then: the components slide became a full-height column layout
    assert res['ok'] is True, res['errors']
    assert res['qa']['slide_rows'][1]['type'] == 'pillars'
    assert res['qa']['errors'] == [], res['qa']['errors']


def test_scenario_duration_warn_mode_does_not_block_delivery(tmp_path):
    # given: a lecture with a long target and thesis-style short notes
    path = _write(tmp_path / 'deck3' / 'lecture.json', {
        'meta': {'course': 'Курс', 'title': 'Семинар', 'lang': 'ru',
                 'duration_min': 90},
        'qa': {'check_duration': 'warn'},
        'slides': [
            {'type': 'title', 'note': NOTE},
            {'type': 'bullets', 'header': 'Тезисы',
             'items': ['Первый тезис', 'Второй тезис'], 'note': NOTE},
        ],
    })
    out = path.parent / 'lecture.pptx'

    # when: the deck is built with QA
    res = build(path, out, qa=True)

    # then: the duration shortfall is a warning, not a hard failure
    assert res['ok'] is True
    assert res['qa']['errors'] == []
    assert any('underrun' in w for w in res['qa']['warnings'])
